# SCAF Agent Kit — travailler sur `scaf/` sans l'app ni le backend

Ce dossier permet à un LLM (ou un humain) de lire, créer, modifier et valider le contenu de `scaf/`
**à la main, avec de simples fichiers**, sans application d'édition ni serveur.

> Le préfixe `_` est volontaire : le backend traite tout dossier de `scaf/` commençant par `v` comme une
> *version*. `_agent-kit` est donc ignoré par l'outillage. Ne le renommez pas en `v...`.

> **Prérequis** : **Ruby** (stdlib seule) suffit pour la spec : audit, OpenAPI, SQL, mocks, guides. **Node + pnpm** ne sont requis que pour les *générateurs d'apps* (`tools/nextjs`, `tools/nestjs`) : `cd tools && pnpm install` (workspace partagé avec `tools/_shared`), puis `pnpm exec tsx gen_nextjs.ts …` / `gen_nestjs.ts …` depuis le dossier du générateur (voir `04-tooling-map.md`).

> **Agents (Claude Code, opencode…)** : [`templates/agents-block.md`](templates/agents-block.md) est le bloc à mettre dans `AGENTS.md`/`CLAUDE.md` du projet pour que l'agent connaisse `scaf/` ; procédure : [`templates/INSTALL.md`](templates/INSTALL.md).

> État et version du kit : voir [`.scaf-kit`](.scaf-kit) (≠ `scaf/.scaf-version`, qui est la version active du projet).

## C'est quoi `scaf/` ?

`scaf/` est un **projet SCAF** : la spécification complète d'une application, découpée en fichiers YAML/JSON
petits et diffables. Hiérarchie métier unique, partout la même :

```
app  →  module  →  feature  →  endpoint (contrat spec+mocks)
                      └────────  atomic_actions (acteurs)
usecase (flux métier, type producer|consumer|shared, rangé usecases/<type>/<app>/)  ──operationId──▶  endpoint
   └─ intent (pourquoi, qui, effets, dépendances) ──▶ output/implementation-guide/<app>/<endpoint>.md
database/visual (tables) ◀── dérivé des réponses des endpoints
```

À partir de cette spec, l'app SCAF génère (ou l'on génère à la main) : OpenAPI, SQL/Drizzle, docs,
tickets, et le code d'une app cible (export-configs → Next.js).

## Ordre de lecture (obligatoire pour un LLM qui arrive à froid)

1. **Ce README** (2 min) — règles d'or ci-dessous.
2. [`01-structure.md`](01-structure.md) — arbre des dossiers, nommage, fichier source vs dérivé, index.
3. [`02-file-formats.md`](02-file-formats.md) — schéma exact de chaque type de fichier (avec exemples réels).
4. [`03-rules-and-validation.md`](03-rules-and-validation.md) — invariants, règles des validateurs, couverture de mocks.
5. [`04-tooling-map.md`](04-tooling-map.md) — les opérations de l'outillage (validation, génération, diff) et leur équivalent à la main.
6. Le **skill** correspondant à la tâche dans [`skills/`](skills/) :

| Tâche | Skill |
|---|---|
| Ajouter/renommer une app, un module, une feature | [`skills/scaf-add-structure.md`](skills/scaf-add-structure.md) |
| Écrire un use case | [`skills/scaf-write-usecase.md`](skills/scaf-write-usecase.md) |
| Renseigner les `intent` (pourquoi/qui/effets/dépendances) et générer le guide d'implémentation | [`skills/scaf-write-intent.md`](skills/scaf-write-intent.md) + [`tools/intent_to_md.rb`](tools/intent_to_md.rb) |
| Écrire les usecases `consumer` d'une app (usage de chaque endpoint côté app cliente) | [`skills/scaf-write-consumer-usecase.md`](skills/scaf-write-consumer-usecase.md) || Écrire un endpoint (spec) | [`skills/scaf-write-endpoint-contract.md`](skills/scaf-write-endpoint-contract.md) |
| Écrire / compléter les mocks | [`skills/scaf-write-mocks.md`](skills/scaf-write-mocks.md) |
| Modéliser la base de données | [`skills/scaf-database-visual.md`](skills/scaf-database-visual.md) |
| Initialiser un projet (`.scaf-version`, lint) | [`01-structure.md`](01-structure.md) §Fichiers racine + [`templates/redocly.yaml`](templates/redocly.yaml) |
| Forker / activer / comparer une version | [`skills/scaf-version-fork.md`](skills/scaf-version-fork.md) |
| Écrire un parcours (question → étapes → endpoints, écarts) | [`skills/scaf-write-journey.md`](skills/scaf-write-journey.md) |
| Définir ce qui est permis/interdit (contraintes) | [`skills/scaf-write-constraints.md`](skills/scaf-write-constraints.md) |
| Cadrer/aligner les énumérations (statuts, types, niveaux) | [`skills/scaf-write-enums.md`](skills/scaf-write-enums.md) |
| Configurer la génération de l'app cible (base + override par app, secrets `$var:`) — sens et source de chaque option : [`05-export-config-reference.md`](05-export-config-reference.md) | [`skills/scaf-write-export-config.md`](skills/scaf-write-export-config.md) + [`tools/export_configs.rb`](tools/export_configs.rb) |
| Vérifier les mocks champ par champ (enums, erreurs, requêtes) | [`skills/scaf-check-mocks.md`](skills/scaf-check-mocks.md) + [`tools/check_mocks.rb`](tools/check_mocks.rb) |
| Générer `openapi.parts/` + les OpenAPI par app (+ doc enrichie) | [`skills/scaf-generate-openapi.md`](skills/scaf-generate-openapi.md) + [`tools/contracts_to_openapi.rb`](tools/contracts_to_openapi.rb) |
| Générer SQL / Drizzle / doc DB depuis le modèle visuel | [`skills/scaf-database-visual.md`](skills/scaf-database-visual.md) §Générer + [`tools/visual_to_sql.rb`](tools/visual_to_sql.rb) |
| Vérifier la cohérence globale | [`skills/scaf-audit-consistency.md`](skills/scaf-audit-consistency.md) + [`tools/audit.rb`](tools/audit.rb) |
| Mettre à jour le kit depuis le dépôt officiel (sur demande uniquement) | [`skills/scaf-update-kit.md`](skills/scaf-update-kit.md) |

Les skills ont un front-matter (`name`, `description`) : ils peuvent être copiés tels quels dans
`~/.claude/skills/<name>/SKILL.md` ou `.claude/skills/`.

## Règles d'or (à ne jamais enfreindre)

1. **Travaille dans la version active** : lis `scaf/.scaf-version` (ex. `v1`). Ne touche pas aux autres `v*` sauf demande explicite.
2. **Source de vérité ≠ dérivé.** Édite uniquement : `project.parts/`, `usecases/`, `contracts/`, `database/visual/`, `export-configs/`.
   `openapi.parts/` est **généré** depuis `contracts/` : ne l'édite pas à la main, régénère-le avec `ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/<version>` (voir `04-tooling-map.md`).
3. **Slug = `^[a-z][a-z0-9_-]*$`**, jamais de point, d'espace, de majuscule (les points servent de séparateur dans `<app>.<module>.yml`).
4. **Un fichier non listé dans son `_index.yml` n'existe pas** pour l'app — et sera **supprimé** au prochain enregistrement (nettoyage des orphelins).
   → toujours écrire les parts d'abord, l'`_index.yml` en dernier, et garder index et fichiers synchrones.
5. **Les mêmes slugs partout** : `app`, `module`, `feature` sont identiques dans `project.parts`, `contracts`, `openapi.parts`, `database/visual` (nom de module).
6. **Un endpoint = un id unique global**, identique dans `contracts/.../<feature>.yml` (`id`), dans `spec.endpoint.id`, dans `mocks.endpoint`,
   dans `usecase.openapi.operationId` et dans le nom du fichier `openapi.parts/.../<id>.yml`.
7. **Chemins d'API préfixés par version** : `/api/v1/...`. Les mocks (`given.path`) utilisent des valeurs **concrètes** (UUID réels), pas `{param}`.
8. **Enveloppe de réponse uniforme** : `{ success, message, data, pagination?, warnings? }` en succès (`pagination` snake_case et `warnings` hors `data`, `data` peut être null) ; `{ success:false, message, error:{code,message,cause?,resolution?} }` en erreur. Jamais `data.data`, jamais d'erreur dans `data`.
9. **Enums des specs en MAJUSCULES, alignés par concept** (voir `enums.yml`, un concept = mêmes valeurs dans toutes les apps) (`enum: [ACTIVE, INACTIVE]`) — via la clé `enum:`, jamais dans `format:`.
10. **Texte métier en français** (descriptions, messages d'erreur), identifiants techniques en anglais/kebab-case.
11. **YAML : toute valeur scalaire contenant `: ` doit être entre guillemets.** Le champ `spec` d'un endpoint est une *chaîne YAML* (`|`), `mocks` une *chaîne JSON* (`|-`).
12. **Une étape sans endpoint n'est pas à « corriger » : c'est un écart.** Dans un parcours, `endpoint: null` + `gap:` ; ne pas inventer d'endpoint pour faire taire `journeys.rb`.
13. **Après chaque modification, régénère les dérivés concernés** (tout dans `scaf/<version>/output/`, jamais édité à la main) :
    contrats/mocks modifiés → `contracts_to_openapi.rb scaf/<version> --doc` ; `intent`/steps/errors d'un usecase (producer ou consumer) modifiés → `intent_to_md.rb scaf/<version>` (le guide `output/implementation-guide/` est **entièrement effacé puis réécrit** à chaque run : ne jamais l'éditer à la main, toute modification serait perdue) ; `database/visual/` ou champ persistant modifié → `visual_to_sql.rb scaf/<version>` (mettre le visuel à jour **avant**).
14. **`intent` : ne jamais l'inventer.** Le déduire du projet (modules, journeys, contraintes, enums, DB) ; en cas de doute (acteur, règle métier, ordre d'appels), demander à l'utilisateur via `AskUserQuestion` avant d'écrire (`skills/scaf-write-intent.md`). Après modif d'un `intent` : `intent_to_md.rb scaf/<version>`.
15. **Tout endpoint doit avoir un `intent`** : l'absence est un écart sévère mais non bloquant (W de l'audit, ligne « ⚠ N endpoint(s) sans intent », liste en tête du guide) ; à combler via `skills/scaf-write-intent.md`, jamais en inventant.
16. **Après chaque modification, lance l'audit** : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` (aucune nouvelle erreur ; baseline v1 : 1 E, voir `skills/scaf-audit-consistency.md`).
17. **Modifier le kit ⇒ bumper `version` dans `.scaf-kit`** (semver : patch doc/outil, minor règle/outil/format, major format incompatible ; voir `01-structure.md`).

## Vocabulaire minimal

| Terme | Sens |
|---|---|
| projet | le dossier `scaf/` (racine) |
| version | `scaf/v1`, `scaf/v1-beta`… un snapshot complet ; `.scaf-version` désigne l'active |
| app | une application livrable (ex. `candidate`, `administration`) |
| module | un domaine fonctionnel d'une app (ex. `cv-ai-analysis`) |
| feature | une capacité d'un module (ex. `initial-matching`) ; porte les endpoints |
| atomic action | action élémentaire d'une feature, rattachée à un acteur |
| actor | `human`, `machine`, `program`, `external`, `data` (voir `project.parts/actors.yml`) |
| usecase | flux métier ordonné (steps, erreurs, liens, `intent`) relié à un endpoint par `operationId` ; `type` = `producer` (fournit), `consumer` (appelle), `shared` |
| contract | spec d'endpoint (YAML) + mocks (JSON) |
| part | fichier éclaté (un par app/module/feature/endpoint) fusionné en mémoire par l'app |
