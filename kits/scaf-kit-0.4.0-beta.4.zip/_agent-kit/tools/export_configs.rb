#!/usr/bin/env ruby
# Validation des configs d'export (génération de l'app cible) : base <techno>.json + overrides par app <techno>.<app>.json.
# Usage : ruby scaf/_agent-kit/tools/export_configs.rb scaf/v1 [--quiet]
#         ruby scaf/_agent-kit/tools/export_configs.rb scaf/v1 --resolve <techno> <app>   # config effective (secrets masqués)
# --quiet : une ligne E/W par écart (utilisé par audit.rb). Format : ../02-file-formats.md §11 · règles : ../03-rules-and-validation.md §EC (nextjs) et §NS (nestjs).
# Code retour 1 s'il y a des E. Technologies connues : nextjs, nestjs (une entrée par techno dans SCHEMAS).
require 'yaml'
require 'json'

root = ARGV[0] or abort 'usage: export_configs.rb <scaf/vN> [--quiet | --resolve <techno> <app>]'
quiet = ARGV.include?('--quiet')
inp = File.join(root, 'input'); dir = File.join(inp, 'export-configs')
abort "introuvable: #{inp}" unless Dir.exist?(inp)
exit 0 unless Dir.exist?(dir)

# ── schémas par technologie (nextjs et nestjs : définis par le kit, indépendants de tout projet) ──
SCHEMAS = {
  'nextjs' => {
    prefix: 'EC',
    enums: {
      'styling' => %w[tailwind_shadcn css_modules styled_components chakra_ui],
      'theme' => %w[light dark system],
      'font' => %w[geist inter poppins custom],
      'architecture' => %w[mvvm mvc clean_architecture],
      'apiLayer' => %w[server_actions route_handlers trpc graphql],
      'orm' => %w[prisma drizzle typeorm mongoose none],
      'database' => %w[postgresql mysql sqlite mongodb none],
      'auth' => %w[nextauth_v5 clerk supabase custom_jwt none],
      'stateManagement' => %w[zustand jotai redux_toolkit tanstack none],
      'httpClient' => %w[ky axios fetch],
      'logger' => %w[pino winston none],
      'packageManager' => %w[pnpm npm yarn bun],
      'targetOs' => %w[mac_linux windows],
      'errorMonitoring' => %w[sentry logrocket none],
      'analytics' => %w[vercel plausible none],
      'agentsFilename' => %w[AGENTS.md AI_GUIDE.md README-IA.md]
    },
    bools: %w[i18n pwa rateLimiting srcDir eslintInBuild imagesUnoptimized reactStrictMode nextDevToolsMcp docsTool],
    arrays: %w[oauthProviders i18nLanguages allowedImageDomains allowedDevOrigins],
    strings: %w[projectName description shadcnPreset customFontPath importAlias bodySizeLimit tagline principe],
    objects: %w[seo pushNotifications agentLoop behaviors session],
    required: %w[projectName seo packageManager architecture auth apiLayer styling],
    secrets: [%w[pushNotifications vapidPrivateKey], %w[pushNotifications vapidPublicKey]],
    sensitive: [%w[pushNotifications vapidPrivateKey]]
  },
  'nestjs' => {
    prefix: 'NS',
    enums: {
      'packageManager' => %w[pnpm npm yarn bun],
      'httpAdapter' => %w[express fastify],
      'versioning' => %w[none uri header],
      'orm' => %w[drizzle typeorm prisma none],
      'database' => %w[postgresql mysql sqlite none],
      'schemaKeyStyle' => %w[snake camel],
      'databaseProvider' => %w[neon pg mysql2 better_sqlite3 none],
      'migrations' => %w[drizzle_kit none],
      'idStrategy' => %w[uuid serial],
      'auth' => %w[better_auth jwt none],
      'validation' => %w[class_validator zod none],
      'logger' => %w[nest pino winston],
      'cache' => %w[none redis],
      'queue' => %w[none bullmq],
      'mailer' => %w[none resend nodemailer smtp],
      'errorMonitoring' => %w[sentry none],
      'testFramework' => %w[jest vitest],
      'envFile' => %w[example_and_file example none],
      'rls' => %w[none session],
      'architecture' => %w[ddd_layered modular_simple],
      'usecaseStyle' => %w[service_per_usecase handler],
      'usecaseBase' => %w[none template_method],
      'moduleGranularity' => %w[usecase atomic],
      'agentsFilename' => %w[AGENTS.md AI_GUIDE.md README-IA.md]
    },
    bools: %w[srcDir bodyParser rateLimiting emailVerification responseEnvelope exceptionFilter pagination healthCheck e2e tablesNames generateSecrets],
    numbers: %w[port minPasswordLength],
    arrays: %w[authPlugins oauthProviders trustedOrigins],
    array_enums: { 'authPlugins' => %w[admin username bearer jwt multiSession anonymous organization twoFactor openAPI customSession phoneNumber emailOTP magicLink apiKey] },
    strings: %w[projectName description nodeVersion globalPrefix schemaDir databaseUrl authSecret authBaseUrl authUserTable authDefaultRole],
    objects: %w[cors swagger moduleLayout generator agentLoop authUserFields],
    required: %w[projectName packageManager orm database auth architecture],
    secrets: [%w[databaseUrl], %w[authSecret]],
    refs: [%w[authBaseUrl]],   # peut être un $var: (vérifié) mais n'est pas un secret
    sensitive: [%w[databaseUrl], %w[authSecret]]
  }
}.freeze
SCHEMAS.each_value do |sc|
  sc[:numbers] ||= []; sc[:array_enums] ||= {}; sc[:refs] ||= []
  sc[:known] = (sc[:enums].keys + sc[:bools] + sc[:numbers] + sc[:arrays] + sc[:strings] + sc[:objects] + %w[version]).freeze
end
VAR = /\A\$var:([A-Za-z0-9_]+)\z/

E = []; W = []
add = ->(sev, rule, msg) { (sev == 'E' ? E : W) << "#{sev} #{rule}: #{msg}" }

load_json = lambda do |f|
  JSON.parse(File.read(f))
rescue JSON::ParserError => e
  add.('E', 'EC0', "#{File.basename(f)}: JSON invalide (#{e.message[0, 60]})"); nil
end

deep = lambda do |a, b|
  next b unless a.is_a?(Hash) && b.is_a?(Hash)
  a.merge(b) { |_, x, y| deep.(x, y) }
end

pi = YAML.safe_load(File.read(File.join(inp, 'project.parts', '_index.yml'))) || {}
apps = (pi['apps'] || []).map { |a| a['slug'] }
vf = File.join(inp, 'contracts', 'variables.yml')
vars = File.exist?(vf) ? ((YAML.safe_load(File.read(vf)) || {})['variables'] || []) : []
varkeys = vars.map { |v| v['key'] }

# ── lecture : base par techno, overrides par (techno, app) ──
bases = {}; overrides = {}
Dir.children(dir).sort.grep(/\.json\z/).each do |fn|
  name = fn.sub(/\.json\z/, ''); tech, app = name.split('.', 2)
  unless SCHEMAS.key?(tech)
    add.('E', 'EC0', "#{fn}: technologie inconnue (#{SCHEMAS.keys.join(', ')})"); next
  end
  pre = SCHEMAS[tech][:prefix]
  d = load_json.(File.join(dir, fn)) or next
  add.('E', "#{pre}0", "#{fn}: technology doit valoir #{tech}") unless d['technology'] == tech
  add.('E', "#{pre}0", "#{fn}: config doit être un objet") unless d['config'].is_a?(Hash)
  next unless d['config'].is_a?(Hash)
  if app
    add.('E', "#{pre}3", "#{fn}: app #{app} absente de project.parts") unless apps.include?(app)
    add.('E', "#{pre}3", "#{fn}: champ app doit valoir #{app}") unless d['app'] == app
    add.('E', "#{pre}3", "#{fn}: projectName n'est pas surchargeable (= slug de l'app)") if d['config'].key?('projectName')
    (d['config'].keys - SCHEMAS[tech][:known]).each { |k| add.('E', "#{pre}3", "#{fn}: clé inconnue #{k}") }
    overrides[[tech, app]] = d['config']
  else
    bases[tech] = d['config']
  end
end
overrides.each_key { |t, a| add.('E', "#{SCHEMAS[t][:prefix]}3", "#{t}.#{a}.json: pas de base #{t}.json") unless bases.key?(t) }

# ── validation d'une config effective ──
check = lambda do |label, tech, c|
  sc = SCHEMAS[tech]; pre = sc[:prefix]
  sc[:required].each { |k| add.('E', "#{pre}2", "#{label}: champ requis #{k}") unless c.key?(k) }
  sc[:enums].each do |k, vals|
    add.('E', "#{pre}1", "#{label}: #{k}=#{c[k].inspect} (valeurs : #{vals.join('|')})") if c.key?(k) && !vals.include?(c[k])
  end
  sc[:bools].each { |k| add.('E', "#{pre}2", "#{label}: #{k} doit être un booléen") if c.key?(k) && ![true, false].include?(c[k]) }
  sc[:numbers].each { |k| add.('E', "#{pre}2", "#{label}: #{k} doit être un nombre") if c.key?(k) && !c[k].is_a?(Numeric) }
  sc[:arrays].each { |k| add.('E', "#{pre}2", "#{label}: #{k} doit être un tableau") if c.key?(k) && !c[k].is_a?(Array) }
  sc[:array_enums].each do |k, vals|
    next unless c[k].is_a?(Array)
    (c[k] - vals).each { |v| add.('E', "#{pre}1", "#{label}: #{k} contient #{v.inspect} (valeurs : #{vals.join('|')})") }
  end
  sc[:strings].each { |k| add.('E', "#{pre}2", "#{label}: #{k} doit être une chaîne") if c.key?(k) && !c[k].is_a?(String) }
  sc[:objects].each { |k| add.('E', "#{pre}2", "#{label}: #{k} doit être un objet") if c.key?(k) && !c[k].is_a?(Hash) }
  (c.keys - sc[:known]).each { |k| add.('W', "#{pre}2", "#{label}: clé inconnue #{k} (ignorée par l'export ?)") }

  if tech == 'nextjs'
    push = c['pushNotifications'].is_a?(Hash) ? c['pushNotifications'] : {}
    seo = c['seo'].is_a?(Hash) ? c['seo'] : {}
    langs = c['i18nLanguages'].is_a?(Array) ? c['i18nLanguages'] : []
    add.('E', 'EC4', "#{label}: pushNotifications.enabled exige pwa: true") if push['enabled'] && !c['pwa']
    add.('E', 'EC4', "#{label}: i18n exige i18nLanguages non vide") if c['i18n'] && langs.empty?
    add.('E', 'EC4', "#{label}: seo.defaultLocale #{seo['defaultLocale'].inspect} ∉ i18nLanguages") if c['i18n'] && seo['defaultLocale'] && !langs.include?(seo['defaultLocale'])
    add.('E', 'EC4', "#{label}: font custom exige customFontPath") if c['font'] == 'custom' && c['customFontPath'].to_s.empty?
    add.('E', 'EC5', "#{label}: customFontPath absolu (#{c['customFontPath']}) — chemin relatif au dépôt (_ui-kits/…)") if c['customFontPath'].to_s.start_with?('/', '~') || c['customFontPath'].to_s =~ /\A[A-Za-z]:[\\\/]/
    add.('W', 'EC6', "#{label}: orm/database ≠ none alors que le front consomme l'API scaf") if %w[orm database].any? { |k| c.key?(k) && c[k] != 'none' }
    (c['behaviors'].is_a?(Hash) ? c['behaviors'] : {}).each { |k, v| add.('E', 'EC7', "#{label}: behaviors.#{k} doit être un booléen") unless [true, false].include?(v) }
    sess = c['session']
    if c.key?('session')
      if !sess.is_a?(Hash)
        add.('E', 'EC8', "#{label}: session doit être un objet {endpoints, logout}")
      else
        (sess.keys - %w[endpoints logout refresh]).each { |k| add.('E', 'EC8', "#{label}: session.#{k} inconnu (endpoints, logout, refresh)") }
        eps = sess['endpoints'].is_a?(Hash) ? sess['endpoints'] : {}
        add.('E', 'EC8', "#{label}: session.endpoints doit être un objet {<endpoint-id>: {accessToken, refreshToken?, expiresIn?}}") if sess.key?('endpoints') && !sess['endpoints'].is_a?(Hash)
        eps.each do |id, m|
          if !m.is_a?(Hash) || m['accessToken'].to_s.empty?
            add.('E', 'EC8', "#{label}: session.endpoints.#{id}.accessToken requis (chemin pointé, ex. data.access_token)")
          else
            (m.keys - %w[accessToken refreshToken expiresIn]).each { |k| add.('E', 'EC8', "#{label}: session.endpoints.#{id}.#{k} inconnu") }
            %w[accessToken refreshToken expiresIn].each { |k| add.('E', 'EC8', "#{label}: session.endpoints.#{id}.#{k} doit être une chaîne (chemin pointé)") if m.key?(k) && !m[k].is_a?(String) }
          end
        end
        if sess.key?('refresh')
          r = sess['refresh']
          if !r.is_a?(Hash)
            add.('E', 'EC8', "#{label}: session.refresh doit être un objet {endpoint, bodyField, accessToken, refreshToken?, expiresIn?}")
          else
            %w[endpoint bodyField accessToken].each { |k| add.('E', 'EC8', "#{label}: session.refresh.#{k} requis (chaîne)") unless r[k].is_a?(String) && !r[k].empty? }
            (r.keys - %w[endpoint bodyField accessToken refreshToken expiresIn]).each { |k| add.('E', 'EC8', "#{label}: session.refresh.#{k} inconnu") }
            %w[refreshToken expiresIn].each { |k| add.('E', 'EC8', "#{label}: session.refresh.#{k} doit être une chaîne (chemin pointé)") if r.key?(k) && !r[k].is_a?(String) }
          end
        elsif eps.values.any? { |m| m.is_a?(Hash) && m['refreshToken'] }
          add.('W', 'EC8', "#{label}: session.endpoints stocke un refreshToken mais session.refresh est absent : jamais utilisé (401 = session perdue)")
        end
        add.('E', 'EC8', "#{label}: session.logout doit être une liste d'ids d'endpoints") if sess.key?('logout') && !(sess['logout'].is_a?(Array) && sess['logout'].all?(String))
        add.('W', 'EC8', "#{label}: session ignoré (auth ≠ custom_jwt)") if c['auth'] != 'custom_jwt'
      end
    end
  else
    plugins = c['authPlugins'].is_a?(Array) ? c['authPlugins'] : []
    cors = c['cors'].is_a?(Hash) ? c['cors'] : {}
    gen = c['generator'].is_a?(Hash) ? c['generator'] : {}
    if c['auth'] == 'better_auth'
      add.('E', 'NS4', "#{label}: auth better_auth exige bodyParser: false (Better Auth lit le corps lui-même)") unless c['bodyParser'] == false
      add.('E', 'NS4', "#{label}: auth better_auth exige un orm (orm ≠ none)") if c['orm'] == 'none'
    else
      add.('E', 'NS4', "#{label}: authPlugins n'a de sens qu'avec auth: better_auth") unless plugins.empty?
    end
    add.('E', 'NS4', "#{label}: authUserTable exige auth better_auth et orm drizzle") if c['authUserTable'].to_s != '' && (c['auth'] != 'better_auth' || c['orm'] != 'drizzle')
    add.('E', 'NS4', "#{label}: authDefaultRole n'a de sens qu'avec authUserTable et le plugin admin") if c['authDefaultRole'].to_s != '' && (c['authUserTable'].to_s == '' || !Array(c['authPlugins']).include?('admin'))
    add.('E', 'NS4', "#{label}: authUserFields n'a de sens qu'avec authUserTable") if c['authUserFields'].is_a?(Hash) && !c['authUserFields'].empty? && c['authUserTable'].to_s == ''
    add.('E', 'NS4', "#{label}: rls session exige database postgresql et orm drizzle") if c['rls'] == 'session' && (c['database'] != 'postgresql' || c['orm'] != 'drizzle')
    add.('E', 'NS4', "#{label}: rls session exige authUserTable (l'identité des policies doit être l'id d'une table scaf, pas un id Better Auth sans lien avec les FK)") if c['rls'] == 'session' && c['authUserTable'].to_s == ''
    add.('E', 'NS4', "#{label}: orm ≠ none exige une database ≠ none") if c['orm'] && c['orm'] != 'none' && c['database'] == 'none'
    add.('E', 'NS4', "#{label}: orm drizzle exige database postgresql, mysql ou sqlite et migrations drizzle_kit") if c['orm'] == 'drizzle' && (c['database'] == 'none' || c['migrations'] == 'none')
    add.('E', 'NS4', "#{label}: databaseProvider #{c['databaseProvider']} incompatible avec database #{c['database']} (neon|pg : postgresql ; mysql2 : mysql ; better_sqlite3 : sqlite)") if c['databaseProvider'] && c['databaseProvider'] != 'none' && c['database'] && c['database'] != 'none' && { 'neon' => 'postgresql', 'pg' => 'postgresql', 'mysql2' => 'mysql', 'better_sqlite3' => 'sqlite' }[c['databaseProvider']] != c['database']
    add.('E', 'NS4', "#{label}: generator.level #{gen['level'].inspect} (valeurs : N0|N1|N2)") if gen.key?('level') && !%w[N0 N1 N2].include?(gen['level'])
    add.('E', 'NS4', "#{label}: generator.level N2 exige orm ≠ none (repositories)") if gen['level'] == 'N2' && c['orm'] == 'none'
    add.('E', 'NS8', "#{label}: globalPrefix doit être vide ou un segment simple (ex. api) ; versioning : none|uri (header non géré). Les chemins des contrats doivent commencer par /<globalPrefix>/ puis /vN/ si versioning uri") if (c['globalPrefix'].to_s != '' && c['globalPrefix'].to_s !~ /\A[a-z0-9-]+\z/) || (c.key?('versioning') && !%w[none uri].include?(c['versioning']))
    add.('E', 'NS9', "#{label}: swagger.path doit être un chemin de segments simples (ex. docs/admin) : l'OpenAPI de l'app y est servi (JSON : <path>-json)") if c['swagger'].is_a?(Hash) && c['swagger']['path'] && c['swagger']['path'].to_s !~ /\A[a-z0-9-]+(\/[a-z0-9-]+)*\z/
    add.('E', 'NS4', "#{label}: port hors 1–65535") if c['port'].is_a?(Numeric) && !(1..65_535).cover?(c['port'])
    add.('W', 'NS5', "#{label}: cors.credentials avec origine '*' (refusé par les navigateurs)") if cors['credentials'] && Array(cors['origins']).include?('*')
    add.('W', 'NS6', "#{label}: orm drizzle mais aucun database/visual : le SQL/Drizzle sort de visual_to_sql.rb") if c['orm'] == 'drizzle' && Dir.glob(File.join(inp, 'database', 'visual', '_visual_*.yml')).empty?
    if Dir.glob(File.join(inp, 'database', 'visual', '_visual_*.yml')).any?
      add.('W', 'NS6', "#{label}: database #{c['database'].inspect} non généré par visual_to_sql.rb (postgresql|mysql|sqlite)") if c['database'] && !%w[postgresql mysql sqlite].include?(c['database'])
      add.('W', 'NS6', "#{label}: orm #{c['orm']} — le schéma généré est Drizzle seulement") if %w[prisma typeorm mongoose].include?(c['orm'])
    end
    add.('W', 'NS6', "#{label}: responseEnvelope false — viole le contrat d'enveloppe { success, message, data }") if c['responseEnvelope'] == false
  end

  (sc[:secrets] + sc[:refs]).each do |path|
    v = c.dig(*path); next if v.nil? || v == ''
    secret = sc[:secrets].include?(path)
    if (m = v.to_s.match(VAR))
      add.('E', "#{pre}5", "#{label}: #{path.join('.')} → $var:#{m[1]} absent de contracts/variables.yml") unless varkeys.include?(m[1])
    elsif secret
      add.('W', "#{pre}5", "#{label}: #{path.join('.')} en clair — le déplacer dans contracts/variables.yml et référencer $var:NOM")
    end
  end
end

# variables sensibles : un secret référencé doit être marqué sensitive
SCHEMAS.each do |tech, sc|
  (bases[tech] ? [bases[tech]] : []).each do |c|
    sc[:sensitive].each do |path|
      m = c.dig(*path).to_s.match(VAR) or next
      v = vars.find { |x| x['key'] == m[1] }
      add.('W', "#{sc[:prefix]}5", "variables.yml: #{m[1]} devrait être sensitive: true") if v && !v['sensitive']
    end
  end
end

effective = lambda do |tech, app|
  deep.(bases[tech] || {}, overrides[[tech, app]] || {}).merge('projectName' => app)
end

if (i = ARGV.index('--resolve'))
  tech, app = ARGV[i + 1], ARGV[i + 2]
  abort 'usage: --resolve <techno> <app>' unless tech && app
  abort "base #{tech}.json introuvable" unless bases.key?(tech)
  abort "app inconnue: #{app}" unless apps.include?(app)
  c = effective.(tech, app)
  SCHEMAS[tech][:secrets].each do |p|
    v = c.dig(*p); next if v.nil? || v.to_s.match?(VAR)
    p.size == 1 ? (c[p[0]] = '***') : (c.dig(*p[0..-2])[p[-1]] = '***')
  end
  puts JSON.pretty_generate(c)
  exit 0
end

body = ->(m) { m.sub(/\A(\w) (\w+): \S+: /, '\1 \2: ') }
bases.each do |tech, base|
  check.(tech, tech, base)
  inherited = (E + W).map(&body)
  overrides.each_key do |t, a|
    next unless t == tech
    n = [E.size, W.size]; check.("#{tech}[#{a}]", tech, effective.(tech, a))
    # un écart hérité de la base n'est pas répété pour l'app
    E.slice!(n[0]..-1).each { |m| E << m unless inherited.include?(body.(m)) }
    W.slice!(n[1]..-1).each { |m| W << m unless inherited.include?(body.(m)) }
  end
end

# ── EC9 : `session` (nextjs, auth custom_jwt) confrontée aux contrats : ids existants, chemins présents dans le schéma de réponse ──
if bases.key?('nextjs')
  eps = {}
  Dir.glob(File.join(inp, 'contracts', 'apps', '*', '*', '*.yml')).sort.each do |f|
    app = f.split('/')[-3]
    ((YAML.safe_load(File.read(f)) || {})['endpoints'] || []).each do |e|
      spec = (YAML.safe_load(e['spec'].to_s) rescue nil) || {}
      mocks = (JSON.parse(e['mocks'].to_s) rescue nil)
      eps[e['id']] = { app: app, req: spec.dig('http', 'request', 'body'), schema: spec.dig('http', 'response', 'body'), mocks: mocks.is_a?(Array) ? mocks : [] }
    end
  end
  seg = lambda do |schema, path|
    path.split('.').reduce(schema) { |n, k| n.is_a?(Hash) ? (n['properties'] || {})[k] : nil }
  end
  in_mock = lambda do |ep, path|
    ep[:mocks].any? do |m|
      st = m.dig('expect', 'status')
      st.is_a?(Integer) && st < 400 && !path.split('.').reduce(m.dig('expect', 'body')) { |n, k| n.is_a?(Hash) ? n[k] : nil }.nil?
    end
  end
  types = { 'accessToken' => %w[string], 'refreshToken' => %w[string], 'expiresIn' => %w[integer number] }
  apps.each do |app|
    c = effective.('nextjs', app)
    next unless c['auth'] == 'custom_jwt' && c['session'].is_a?(Hash)
    label = "nextjs[#{app}]"
    ids = (c['session']['endpoints'].is_a?(Hash) ? c['session']['endpoints'].keys : []) + Array(c['session']['logout'])
    ids.uniq.each { |i| add.('E', 'EC9', "nextjs: session → endpoint #{i} absent des contrats") unless eps.key?(i) }
    r = c['session']['refresh']
    if r.is_a?(Hash) && r['endpoint'].is_a?(String)
      ep = eps[r['endpoint']]
      if ep.nil?
        add.('E', 'EC9', "nextjs: session.refresh → endpoint #{r['endpoint']} absent des contrats (l'ajouter au contrat avant de configurer le refresh)")
      elsif ep[:app] == app
        add.('E', 'EC9', "#{label}: session.refresh.bodyField → #{r['bodyField']} absent du corps de la requête de #{r['endpoint']}") if r['bodyField'].is_a?(String) && seg.(ep[:req], r['bodyField']).nil?
        types.each do |k, ok|
          path = r[k]; next unless path.is_a?(String)
          node = seg.(ep[:schema], path)
          if node && !ok.include?(node['type'].to_s)
            add.('E', 'EC9', "#{label}: session.refresh.#{k} → #{path} est de type #{node['type'].inspect} (attendu #{ok.join('|')})")
          elsif node.nil?
            add.('E', 'EC9', "#{label}: session.refresh.#{k} → #{path} introuvable dans la réponse de #{r['endpoint']}")
          end
        end
      end
    end
    next unless c['session']['endpoints'].is_a?(Hash)
    c['session']['endpoints'].each do |id, m|
      ep = eps[id]; next unless ep && ep[:app] == app && m.is_a?(Hash)
      types.each do |k, ok|
        path = m[k]; next unless path.is_a?(String)
        node = seg.(ep[:schema], path)
        if node && !ok.include?(node['type'].to_s)
          add.('E', 'EC9', "#{label}: session.endpoints.#{id}.#{k} → #{path} est de type #{node['type'].inspect} (attendu #{ok.join('|')})")
        elsif node.nil? && in_mock.(ep, path)
          add.('W', 'EC9', "#{label}: session.endpoints.#{id}.#{k} → #{path} présent dans les mocks mais pas dans le schéma de réponse : le déclarer dans le contrat")
        elsif node.nil?
          add.('E', 'EC9', "#{label}: session.endpoints.#{id}.#{k} → #{path} introuvable dans la réponse de #{id}")
        end
      end
    end
  end
end
E.uniq!; W.uniq!
puts E, W
puts "\nexport-configs: #{bases.size} base(s), #{overrides.size} override(s) — #{E.size} erreur(s), #{W.size} avertissement(s)" unless quiet
exit(E.empty? ? 0 : 1)
