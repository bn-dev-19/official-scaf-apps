#!/usr/bin/env ruby
# Vérification champ par champ des mocks contre leur spec (réponses, erreurs, requêtes, enums).
# Usage : ruby scaf/_agent-kit/tools/check_mocks.rb scaf/v1 [--app <slug>] [--endpoint <id>] [--quiet]
# --quiet : uniquement le résumé par règle. Code retour 1 s'il y a des E.
# Règles (voir ../03-rules-and-validation.md §MK) :
#   M1 réponse de succès : type, format, nullable, champs présents (tous requis), clés déclarées
#   M2 réponse d'erreur  : code déclaré pour le statut, error.message/cause/resolution = spec, message racine = error.message, nom du mock
#   M3 requête (given)   : query / path / body contre request.* (type, format, enum, requis, clés inconnues)
#   M4 enums             : la valeur de chaque champ portant `enum:` dans la spec doit en faire partie (réf. = champ de base, pas enums.yml)
#                          4b champ à valeurs fermées sans `enum:` · 4c mock `enum-<chemin>-<VALEUR>` · 4d valeur d'enum jamais couverte (W)
require 'yaml'
require 'json'
require 'date'

root = ARGV[0] or abort 'usage: check_mocks.rb <scaf/vN> [--app slug] [--endpoint id] [--quiet]'
opt = ->(n) { i = ARGV.index(n); i && ARGV[i + 1] }
only_app = opt.('--app'); only_ep = opt.('--endpoint'); quiet = ARGV.include?('--quiet')
inp = File.join(root, 'input')
abort "introuvable: #{inp}" unless Dir.exist?(inp)

LOAD = ->(f) { YAML.safe_load(File.read(f, encoding: 'utf-8'), permitted_classes: [Date, Time]) }
cfg = File.exist?(File.join(inp, 'enums.yml')) ? (LOAD.(File.join(inp, 'enums.yml')) || {}) : {}
WATCH = Regexp.new(cfg['watch'] || 'status|type|level|origin|decision', Regexp::IGNORECASE)
IGNORE = (cfg['ignore'] || []).map { |g| Regexp.new("\\A#{g.to_s.gsub('.', '\.').gsub('*', '.*')}\\z") }
IGNORE_EP = cfg['ignore_endpoints'] || []

R = []   # [sev, regle, endpoint, mock, chemin, message]
add = ->(sev, rule, ep, mk, path, msg) { R << [sev, rule, ep, mk, path, msg] }

UUID = /\A\h{8}-\h{4}-\h{4}-\h{4}-\h{12}\z/
DATEISO = /\A\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?\z/

# valeurs d'enum observées : [endpoint, sens, chemin gabarit] -> Set de valeurs
SEEN = Hash.new { |h, k| h[k] = [] }
ENUMS = {}   # [endpoint, sens, chemin gabarit] -> valeurs déclarées
OPEN_FIELDS = Hash.new { |h, k| h[k] = { vals: [], type: nil } }  # champs sans enum : [endpoint, sens, chemin] -> valeurs

# Validation d'une valeur contre un SchemaField du contrat.
# mode :resp (tous les champs requis) ou :req (requis seulement si `required: true`)
def val(v, s, path, tpl, mode, ctx, emit)
  return unless s.is_a?(Hash)
  if v.nil?
    emit.('M1', path, 'null sur un champ non nullable') unless s['nullable']
    return
  end
  case s['type']
  when 'object'
    return if mode == :req && v.is_a?(String) && v =~ /\A<.+>\z/   # gabarit de volume dans une requête (ex. "<501 lignes>")
    return emit.('M1', path, "attendu object, reçu #{v.class}") unless v.is_a?(Hash)
    props = s['properties'] || {}
    props.each do |k, sub|
      if v.key?(k) then val(v[k], sub, "#{path}.#{k}", "#{tpl}.#{k}", mode, ctx, emit)
      elsif path == '$' && k == 'warnings' && mode == :resp
        next   # warnings : optionnel à la racine (absent si rien à signaler)
      elsif mode == :resp || (sub.is_a?(Hash) && sub['required'] == true)
        emit.('M1', "#{path}.#{k}", 'champ absent du mock')
      end
    end
    (v.keys - props.keys - (path == '$' && mode == :resp ? ['warnings'] : [])).each { |k| emit.('M1', "#{path}.#{k}", 'clé non déclarée dans la spec') } unless props.empty?
  when 'array'
    return emit.('M1', path, "attendu array, reçu #{v.class}") unless v.is_a?(Array)
    v.each_with_index { |x, i| val(x, s['items'], "#{path}[#{i}]", "#{tpl}[]", mode, ctx, emit) }
    if s['enum']   # enum porté par le tableau lui-même : chaque élément doit en faire partie
      ENUMS[[ctx[:ep], ctx[:dir], tpl]] = s['enum'].map(&:to_s)
      v.each do |x|
        SEEN[[ctx[:ep], ctx[:dir], tpl]] << x.to_s if ctx[:record]
        emit.('M4', path, "#{x.inspect} hors enum #{s['enum'].map(&:to_s).inspect}") unless s['enum'].map(&:to_s).include?(x.to_s)
      end
    end
  when 'string'
    return if s['format'] == 'binary' && (v.is_a?(String) || (v.is_a?(Hash) && v.key?('filename')))   # upload : métadonnées du fichier (cf. skill scaf-write-mocks)
    return emit.('M1', path, "attendu string, reçu #{v.class}: #{v.inspect}") unless v.is_a?(String)
    if s['enum']
      ENUMS[[ctx[:ep], ctx[:dir], tpl]] = s['enum'].map(&:to_s)
      SEEN[[ctx[:ep], ctx[:dir], tpl]] << v if ctx[:record]
      emit.('M4', path, "#{v.inspect} hors enum #{s['enum'].map(&:to_s).inspect}") unless s['enum'].map(&:to_s).include?(v)
    elsif ctx[:record] && !s['format']
      (OPEN_FIELDS[[ctx[:ep], ctx[:dir], tpl]][:vals]) << v
    end
    case s['format']
    when 'uuid' then emit.('M1', path, "#{v.inspect} n'est pas un uuid") unless v =~ UUID
    when 'date-iso' then emit.('M1', path, "#{v.inspect} n'est pas une date ISO") unless v =~ DATEISO
    when 'email' then emit.('M1', path, "#{v.inspect} n'est pas un email") unless v.include?('@')
    when 'url' then emit.('M1', path, "#{v.inspect} n'est pas une url") unless v =~ %r{\Ahttps?://}
    end
  when 'integer'
    return emit.('M1', path, "attendu integer, reçu #{v.inspect}") unless v.is_a?(Integer)
    if s['enum']
      ENUMS[[ctx[:ep], ctx[:dir], tpl]] = s['enum'].map(&:to_s)
      SEEN[[ctx[:ep], ctx[:dir], tpl]] << v.to_s if ctx[:record]
      emit.('M4', path, "#{v.inspect} hors enum #{s['enum'].map(&:to_s).inspect}") unless s['enum'].map(&:to_s).include?(v.to_s)
    end
  when 'number' then emit.('M1', path, "attendu number, reçu #{v.inspect}") unless v.is_a?(Numeric)
  when 'boolean' then emit.('M1', path, "attendu boolean, reçu #{v.inspect}") unless [true, false].include?(v)
  end
end

# Valeur scalaire de requête (query/path : texte ou nombre) contre une FieldDef
def val_param(v, fd, path, ctx, emit)
  sch = fd.reject { |k, _| %w[name required description].include?(k) }
  if sch['type'] == 'integer' && v.is_a?(String) && v =~ /\A-?\d+\z/ then v = v.to_i
  elsif sch['type'] == 'boolean' && %w[true false].include?(v.to_s) then v = (v.to_s == 'true')
  end
  val(v, sch, path, path, :req, ctx, emit)
end

# chemin gabarit normalisé pour comparer au nom d'un mock
def norm(s)
  s.to_s.gsub(/\[\d*\]/, '').gsub('*', '').gsub(/\Adata\.|\A\$\.?/, '').gsub(/[^A-Za-z0-9]+/, '_').gsub(/\A_+|_+\z/, '').downcase.sub(/\Adata_/, '')
end

def find_values(v, steps, out)
  if steps.empty? then out << v
  elsif v.is_a?(Array) then v.each { |x| find_values(x, steps, out) }
  elsif v.is_a?(Hash) && v.key?(steps[0]) then find_values(v[steps[0]], steps[1..], out)
  end
end

cindex = LOAD.(File.join(inp, 'contracts', '_index.yml')) || {}
count = { endpoints: 0, mocks: 0 }

(cindex['apps'] || []).each do |a|
  next if only_app && only_app != a['slug']
  (a['modules'] || []).each do |m|
    (m['features'] || []).each do |ft|
      file = File.join(inp, 'contracts', 'apps', a['slug'], m['slug'], "#{ft}.yml")
      next unless File.exist?(file)
      (LOAD.(file)['endpoints'] || []).each do |e|
        id = e['id']
        next if only_ep && only_ep != id
        spec = (YAML.safe_load(e['spec'].to_s, permitted_classes: [Date, Time]) rescue nil)
        mocks = (JSON.parse(e['mocks'].to_s)['mocks'] rescue nil)
        (add.('E', 'M0', id, '-', '-', 'spec ou mocks illisibles'); next) unless spec.is_a?(Hash) && mocks
        count[:endpoints] += 1
        http = spec['http'] || {}; req = http['request'] || {}; resp = http['response'] || {}
        ok = (resp['status'] || 200).to_i
        errs = resp['errors'] || []
        path_tpl = http['path'] || e['path']
        path_re = Regexp.new("\\A#{Regexp.escape(path_tpl).gsub(/\\\{(\w+)\\\}/, '(?<\1>[^/]+)')}\\z")
        reg = lambda do |sc, tpl, dir|
          next unless sc.is_a?(Hash)
          ENUMS[[id, dir, tpl]] = sc['enum'].map(&:to_s) if sc['enum']
          (sc['properties'] || {}).each { |k, v| reg.(v, "#{tpl}.#{k}", dir) }
          reg.(sc['items'], "#{tpl}[]", dir) if sc['items']
        end
        reg.(resp['body'], '$', 'resp'); reg.(req['body'], '.body', 'req')
        (req['query'] || []).each { |fd| reg.(fd, ".query.#{fd['name']}", 'req') }
        mocks.each do |mk|
          count[:mocks] += 1
          name = mk['name'].to_s
          st = mk.dig('expect', 'status').to_i; body = mk.dig('expect', 'body'); g = mk['given'] || {}
          emit = ->(rule, p, msg) { add.('E', rule, id, name, p, msg) }
          # ── réponse ──
          if st < 300
            ctx = { ep: id, dir: 'resp', record: true }
            if body.is_a?(Hash)
              emit.('M1', '$.success', 'success doit être true') unless body['success'] == true
              emit.('M1', '$.message', 'message absent') unless body['message'].is_a?(String)
              val(body, resp['body'], '$', '$', :resp, ctx, emit) if resp['body'] && st == ok
            else
              emit.('M1', '$', 'corps de réponse absent ou non objet')
            end
          else
            er = body.is_a?(Hash) ? body['error'] : nil
            if !er.is_a?(Hash) then emit.('M2', '$.error', 'objet error absent')
            else
              emit.('M2', '$.success', 'success doit être false') unless body['success'] == false
              code = er['code']
              d = errs.find { |x| x['status'].to_i == st && x['code'] == code }
              if d.nil?
                emit.('M2', '$.error.code', "code #{code.inspect} non déclaré pour le statut #{st} (spec : #{errs.select { |x| x['status'].to_i == st }.map { |x| x['code'] }.inspect})")
              else
                { 'message' => d['message'] || d['description'], 'cause' => d['cause'], 'resolution' => d['resolution'] }.each do |k, exp|
                  emit.('M2', "$.error.#{k}", "#{er[k].inspect} ≠ spec #{exp.inspect}") if exp && er[k] != exp
                end
              end
              emit.('M2', '$.message', "message racine #{body['message'].inspect} ≠ error.message #{er['message'].inspect}") if body['message'] != er['message']
              (body.keys - %w[success message error]).each { |k| emit.('M2', "$.#{k}", 'clé inattendue dans une réponse d’erreur') }
              add.('W', 'M2', id, name, '$', "nom attendu error-#{code.to_s.downcase}[-N]") if code && name !~ /\Aerror-#{Regexp.escape(code.to_s.downcase)}(-\d+)?\z/
            end
          end
          # ── requête ──
          invalid_ok = name =~ /\Aerror-(invalid|validation)/
          before = R.size
          reqemit = ->(rule, p, msg) { add.('E', rule == 'M1' ? 'M3' : rule, id, name, "given#{p}", msg) }
          rctx = { ep: id, dir: 'req', record: false }
          qdefs = req['query'] || []
          (g['query'] || {}).each do |k, v|
            fd = qdefs.find { |x| x['name'] == k }
            if fd then val_param(v, fd, ".query.#{k}", rctx, reqemit) else reqemit.('M3', ".query.#{k}", 'paramètre de query non déclaré') end
          end
          qdefs.each { |fd| reqemit.('M3', ".query.#{fd['name']}", 'paramètre requis absent') if fd['required'] == true && !(g['query'] || {}).key?(fd['name']) } unless invalid_ok
          if (md = path_re.match(g['path'].to_s.split('?').first.to_s))
            (req['path'] || []).each { |fd| val_param(md[fd['name']], fd, ".path.#{fd['name']}", rctx, reqemit) if md.names.include?(fd['name']) }
          elsif g['path']
            reqemit.('M3', '.path', "#{g['path']} ne correspond pas à #{path_tpl}")
          end
          if req['body'].is_a?(Hash)
            val(g['body'], req['body'], '.body', '.body', :req, rctx, reqemit) unless g['body'].nil?
          elsif !g['body'].nil? && g['body'] != {} && !req['body']
            reqemit.('M3', '.body', 'corps fourni alors que la spec n’en déclare pas')
          end
          R.slice!(before..) if invalid_ok   # valeurs de requête invalides volontaires (error-invalid*, error-validation*)
          # ── 4c : mock enum-<chemin>-<VALEUR> ──
          if name =~ /\Aenum-(.+)\z/
            rest = $1
            cands = ENUMS.keys.select { |k| k[0] == id }
            ok_split = false; seen_field = false
            # enum-<chemin>-ALL : mock groupé (un champ de tableau dont les éléments portent chacun une valeur d'enum différente)
            if rest =~ /\A(.+)-ALL\z/
              left = $1
              k = cands.find { |c| norm(c[2]) == norm(left) } || cands.find { |c| norm(c[2]).end_with?("_#{norm(left)}") }
              if k
                ok_split = true
                steps = k[2].sub(/\A\$\./, '').sub(/\A\./, '').split('.').map { |x| x.sub('[]', '') }.reject(&:empty?)
                out = []; find_values(k[1] == 'resp' ? body : g['body'], steps, out)
                add.('E', 'M4', id, name, k[2], "mock groupé : aucune valeur trouvée") if out.flatten.compact.empty?
              end
            end
            rest.each_char.with_index do |ch, i|
              break if ok_split
              next unless ch == '-'
              left = rest[0...i]; right = rest[(i + 1)..]
              cands.sort_by { |k| norm(k[2]) == norm(left) ? 0 : 1 }.each do |k|
                next unless norm(k[2]) == norm(left) || norm(k[2]).end_with?("_#{norm(left)}")
                seen_field = true
                next unless ENUMS[k].any? { |x| x.downcase == right.downcase }
                ok_split = true
                steps = k[2].sub(/\A\$\./, '').sub(/\A\./, '').split('.').map { |x| x.sub('[]', '') }.reject(&:empty?)
                steps.shift if k[2].start_with?('.body', '.query')
                src = k[2].start_with?('.query') ? g['query'] : (k[1] == 'resp' ? body : g['body'])
                out = []; find_values(src, steps, out)
                add.('E', 'M4', id, name, k[2], "le mock ne contient pas la valeur #{right} (trouvé : #{out.flatten.uniq.inspect})") unless out.flatten.any? { |x| x.to_s.downcase == right.downcase }
                break
              end
              break if ok_split
            end
            add.('W', 'M4', id, name, '-', "nom enum-… ne correspond à aucun champ enum de la spec") unless ok_split
          end
        end
      end
    end
  end
end

# ── 4b : champs à valeurs fermées sans enum ; 4d : couverture ──
OPEN_FIELDS.each do |(ep, dir, tpl), h|
  next if IGNORE_EP.include?(ep)
  leaf = tpl.split('.').last.to_s.sub('[]', '')
  next unless leaf =~ WATCH
  next if IGNORE.any? { |re| re.match?(leaf) || re.match?(tpl.sub(/\A\$\./, '')) }
  vs = h[:vals].uniq
  next unless vs.size >= 1 && vs.all? { |x| x =~ /\A[A-Z][A-Z0-9_]*\z/ && x.size > 1 }
  add.('E', 'M4', ep, '*', tpl, "champ à valeurs fermées sans `enum:` dans la spec (valeurs vues : #{vs.first(8).inspect})")
end
ENUMS.each do |(ep, dir, tpl), vals|
  next unless dir == 'resp'
  miss = vals - SEEN[[ep, dir, tpl]].uniq
  add.('W', 'M4', ep, '*', tpl, "valeurs d'enum jamais couvertes par un mock : #{miss.inspect}") unless miss.empty?
end

es = R.select { |r| r[0] == 'E' }; ws = R.select { |r| r[0] == 'W' }
unless quiet
  R.sort_by { |r| [r[0], r[1], r[2], r[3]] }.each { |s, rule, ep, mk, p, msg| puts "#{s} #{rule} #{ep}/#{mk} #{p}: #{msg}" }
end
puts "\n#{count[:endpoints]} endpoints · #{count[:mocks]} mocks"
R.group_by { |r| [r[0], r[1]] }.sort.each { |(s, rule), l| puts "  #{s} #{rule} : #{l.size}" }
puts "#{es.size} erreur(s), #{ws.size} avertissement(s)"
exit(es.empty? ? 0 : 1)
