require_relative 'base'
# Dialecte PostgreSQL (Neon) : CREATE TYPE, COMMENT ON, FK en ALTER, Drizzle pg-core.
module DbDialect
  extend DbBase
  NAME = 'postgresql'
  DZ_PKG = 'drizzle-orm/pg-core'
  DZ_ANY = 'AnyPgColumn'
  DZ_IMPORTS = %w[pgTable pgEnum uuid varchar text integer bigint boolean timestamp date numeric jsonb primaryKey index uniqueIndex check].freeze
  DZ_TABLE = 'pgTable'
  class << self
    def q(n); n; end
    def type(c, e)
      case c['type']
      when 'datetime' then 'TIMESTAMPTZ'
      when 'enum' then c['enumRef']
      else (d = dec(c)) ? "NUMERIC(#{d[0]}, #{d[1]})" : c['type'].upcase
      end
    end
    def default_sql(c)
      return 'gen_random_uuid()' if uuid_pk?(c)
      c['default'].nil? ? nil : bare_default(c['default'])
    end
    def enum_ddl(enums, dash, sq)
      enums.map do |e|
        "-- #{e['name']} : #{dash.(e['description'])}\nCREATE TYPE #{e['name']} AS ENUM (#{e['values'].map { |v| "'#{v['value']}'" }.join(', ')});\n" \
        "COMMENT ON TYPE #{e['name']} IS #{sq.(e['description'])};\n"
      end.join("\n")
    end
    def comment_stmts(t, sq)
      ["COMMENT ON TABLE #{t['name']} IS #{sq.(t['description'])};"] +
        t['columns'].map { |c| "COMMENT ON COLUMN #{t['name']}.#{c['name']} IS #{sq.(c['description'])};" }
    end
    def idx_method_pre(i); i['method'] ? " USING #{i['method']}" : ''; end
    def dz_using?; true; end
    def tx_wrap(content, banner); content.sub(banner, "#{banner}\nBEGIN;\n") + "\nCOMMIT;\n"; end
    def dz_enum_file?; true; end
    def dz_enum_decl(e, camel)
      "export const #{camel.(e['name'])}Enum = pgEnum('#{e['name']}', [#{e['values'].map { |v| "'#{v['value']}'" }.join(', ')}]);"
    end
    def dz_col(c, n, camel)
      case c['type']
      when 'uuid' then "uuid('#{n}')"
      when 'text' then "text('#{n}')"
      when 'integer' then "integer('#{n}')"
      when 'bigint' then "bigint('#{n}', { mode: 'number' })"
      when 'boolean' then "boolean('#{n}')"
      when 'datetime' then "timestamp('#{n}', { withTimezone: true })"
      when 'date' then "date('#{n}')"
      when 'jsonb' then "jsonb('#{n}')"
      when 'enum' then "#{camel.(c['enumRef'])}Enum('#{n}')"
      when /\Avarchar\((\d+)\)\z/ then "varchar('#{n}', { length: #{$1} })"
      else (d = dec(c)) && "numeric('#{n}', { precision: #{d[0]}, scale: #{d[1]} })"
      end
    end
    def dz_default(c); super(c, now: '.defaultNow()', uuid: '.defaultRandom()'); end
  end
end
