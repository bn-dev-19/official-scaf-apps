require_relative 'base'
# Dialecte SQLite : enums = TEXT + CHECK, FK inline dans CREATE TABLE (pas d'ALTER ADD CONSTRAINT), commentaires `--`, Drizzle sqlite-core.
# uuid/datetime/jsonb stockés en TEXT ; défaut uuid = 32 hex aléatoires (pas un UUID RFC) : le code applicatif génère les ids.
module DbDialect
  extend DbBase
  NAME = 'sqlite'
  DZ_PKG = 'drizzle-orm/sqlite-core'
  DZ_ANY = 'AnySQLiteColumn'
  DZ_IMPORTS = %w[sqliteTable text integer numeric primaryKey index uniqueIndex check].freeze
  DZ_TABLE = 'sqliteTable'
  class << self
    def idx_unsupported(i); i['method'] && i['method'] != 'btree' ? "méthode #{i['method']} non supportée par SQLite" : nil; end
    def q(n); n; end
    def type(c, e)
      case c['type']
      when 'integer', 'bigint', 'boolean' then 'INTEGER'
      when 'decimal' then 'NUMERIC'
      else dec(c) ? 'NUMERIC' : 'TEXT'
      end
    end
    def default_sql(c)
      return '(lower(hex(randomblob(16))))' if uuid_pk?(c)
      return nil if c['default'].nil?
      s = strip_cast(c['default'].to_s)
      return 'CURRENT_TIMESTAMP' if s == 'NOW()'
      return { 'true' => '1', 'false' => '0' }[s] if %w[true false].include?(s)
      bare_default(s)
    end
    def preamble; { 'sql/00_pragma.sql' => "-- Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n\nPRAGMA foreign_keys = ON;\n" }; end
    def col_check(c, e); c['type'] == 'enum' ? " CHECK (#{c['name']} IN (#{e['values'].map { |v| "'#{esc(v['value'])}'" }.join(', ')}))" : nil; end
    def fk_inline?; true; end
    def dz_col(c, n, _camel)
      case c['type']
      when 'uuid', 'text', 'date', 'datetime' then "text('#{n}')"
      when 'integer', 'bigint' then "integer('#{n}')"
      when 'boolean' then "integer('#{n}', { mode: 'boolean' })"
      when 'jsonb' then "text('#{n}', { mode: 'json' })"
      when 'enum' then nil
      when /\Avarchar\((\d+)\)\z/ then "text('#{n}', { length: #{$1} })"
      else dec(c) && "numeric('#{n}')"
      end
    end
    def dz_enum_inline(c, n, e); "text('#{n}', { enum: [#{e['values'].map { |v| "'#{v['value']}'" }.join(', ')}] })"; end
    def dz_default(c); super(c, now: ".default(sql`(CURRENT_TIMESTAMP)`)", uuid: '.$defaultFn(() => crypto.randomUUID())'); end
  end
end
