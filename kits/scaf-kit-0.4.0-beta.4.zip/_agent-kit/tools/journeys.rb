#!/usr/bin/env ruby
# Parcours (journeys) + contraintes d'une version SCAF : « a-t-on les endpoints pour résoudre ce besoin ? »
# Usage : ruby scaf/_agent-kit/tools/journeys.rb scaf/v1 [--md rapport.md] [--quiet]
# --quiet : n'imprime que les lignes E/W (utilisé par audit.rb). Règles : ../03-rules-and-validation.md §J et §K.
# Code retour 1 s'il y a des E ; les écarts (endpoint absent) sont de l'information, pas des erreurs.
require 'yaml'
require 'date'

root = ARGV[0] or abort 'usage: journeys.rb <scaf/vN> [--md fichier] [--quiet]'
quiet = ARGV.include?('--quiet')
md_out = ARGV.include?('--md') ? ARGV[ARGV.index('--md') + 1] : nil
inp = File.join(root, 'input')
abort "introuvable: #{inp}" unless Dir.exist?(inp)
jdir = File.join(inp, 'journeys'); cfile = File.join(inp, 'constraints.yml')
exit 0 unless Dir.exist?(jdir) || File.exist?(cfile)

E = []; W = []
err = ->(r, m) { E << "E #{r}: #{m}" }
wrn = ->(r, m) { W << "W #{r}: #{m}" }
load_yaml = lambda do |p|
  YAML.safe_load(File.read(p), permitted_classes: [Date, Time])
rescue StandardError => e
  err.('YAML', "#{p}: #{e.message.lines.first.strip}"); nil
end
y = ->(*a) { File.join(inp, *a) }

# ── chargement ────────────────────────────────────────────────────────
actors = (File.exist?(y.('project.parts', 'actors.yml')) ? load_yaml.(y.('project.parts', 'actors.yml')) : nil) || []
actor_ids = actors.map { |a| a['id'] }
pi = load_yaml.(y.('project.parts', '_index.yml')) || { 'modules' => [] }
feat_actors = Hash.new { |h, k| h[k] = [] } # [app,module,feature] => actors
(pi['modules'] || []).each do |m|
  f = y.('project.parts', 'modules', "#{m['app']}.#{m['slug']}.yml")
  d = File.exist?(f) ? load_yaml.(f) : nil or next
  (d['features'] || []).each { |ft| (ft['atomic_actions'] || []).each { |aa| feat_actors[[m['app'], m['slug'], ft['slug']]] << aa['actor'] if aa['actor'] } }
end
app_actors = Hash.new { |h, k| h[k] = [] }
feat_actors.each { |(app, _, _), as| app_actors[app].concat(as) }

EP = {} # id => {app,module,feature,method,path,auth,spec}
ci = load_yaml.(y.('contracts', '_index.yml')) || { 'apps' => [] }
(ci['apps'] || []).each do |a|
  (a['modules'] || []).each do |m|
    (m['features'] || []).each do |ft|
      f = y.('contracts', 'apps', a['slug'], m['slug'], "#{ft}.yml")
      d = File.exist?(f) ? load_yaml.(f) : nil or next
      (d['endpoints'] || []).each do |e|
        spec = (YAML.safe_load(e['spec'].to_s) rescue nil) || {}
        EP[e['id']] = { app: a['slug'], module: m['slug'], feature: ft, method: e['method'], path: e['path'],
                        auth: spec.dig('http', 'auth', 'type'), spec: spec }
      end
    end
  end
end
UC_BY_OP = {}; UC = {}
Dir[y.('usecases', '**', '*.usecase.yml')].each do |f|
  u = load_yaml.(f) or next
  UC[u['id']] = u
  UC_BY_OP[u.dig('openapi', 'operationId')] = u if u.dig('openapi', 'operationId')
end

# noms de champs d'un schéma (récursif, y compris items) + paramètres
def names(node, acc = [])
  return acc unless node.is_a?(Hash)
  (node['properties'] || {}).each { |k, v| acc << k; names(v, acc) }
  names(node['items'], acc)
  acc
end
def resp_names(ep) names(ep[:spec].dig('http', 'response', 'body', 'properties', 'data')) end
def req_names(ep)
  r = ep[:spec].dig('http', 'request') || {}
  (r['path'] || []).map { |p| p['name'] } + (r['query'] || []).map { |p| p['name'] } + names(r['body'])
end
def path_params(ep) ((ep[:spec].dig('http', 'request') || {})['path'] || []).map { |p| p['name'] } | ep[:path].to_s.scan(/\{(\w+)\}/).flatten end

# jetons : "nom" ou "entite.champ=A|B"
def tok(t)
  s = t.to_s; base, vals = s.split('=', 2)
  [base, vals ? vals.split('|') : nil]
end
def satisfied?(need, produced)
  base, vals = tok(need)
  ps = produced.map { |p| tok(p) }.select { |b, _| b == base }
  return false if ps.empty?
  return true if vals.nil?
  have = ps.flat_map { |_, v| v || [] }
  ps.any? { |_, v| v.nil? } || (vals - have).empty?
end

# ── parcours ──────────────────────────────────────────────────────────
journeys = {}
Dir[File.join(jdir, '*.journey.yml')].sort.each do |f|
  j = load_yaml.(f) or next
  id = File.basename(f).sub('.journey.yml', '')
  err.('J1', "#{id}: id (#{j['id'].inspect}) != nom de fichier") if j['id'] != id
  err.('J1', "#{id}: question manquante") if j['question'].to_s.size < 5
  steps = j['steps'] || []
  err.('J1', "#{id}: aucune étape") if steps.empty?
  sids = steps.map { |s| s['id'] }
  err.('J1', "#{id}: ids d'étapes dupliqués ou manquants") if sids.uniq.size != sids.size || sids.any?(&:nil?)
  steps.each_with_index do |s, i|
    s['after'] = i.zero? ? [] : [steps[i - 1]['id']] unless s.key?('after')
    (s['after'] || []).each { |a| err.('J1', "#{id}/#{s['id']}: after #{a.inspect} inconnu") unless sids.include?(a) }
  end
  # cycles
  st = {}; cyc = false
  visit = lambda do |sid|
    return if st[sid] == 2
    (cyc = true; return) if st[sid] == 1
    st[sid] = 1
    ((steps.find { |s| s['id'] == sid } || {})['after'] || []).each { |a| visit.(a) }
    st[sid] = 2
  end
  sids.each { |s| visit.(s) }
  err.('J1', "#{id}: cycle dans les étapes (after)") if cyc
  journeys[id] = j.merge('steps' => steps)
end

report = []; app_stats = Hash.new { |h, k| h[k] = { ok: 0, gap: 0, blocked: 0 } }; used = {}
journeys.each do |id, j|
  steps = j['steps']; by = steps.to_h { |s| [s['id'], s] }
  anc = {}
  ancestors = lambda do |sid|
    anc[sid] ||= (by[sid]['after'] || []).select { |a| by.key?(a) }.flat_map { |a| [a] + ancestors.(a) }.uniq
  end
  status = {}
  given = Array(j['given'])
  # ordre topologique simple : tableau (les after pointent en général vers l'arrière) ; sinon itérer
  steps.each do |s|
    sid = s['id']; ep = s['endpoint'] && EP[s['endpoint']]
    app = s['app'] || ep&.dig(:app) || (Array(j['apps']).find { |a| app_actors[a].include?(s['actor']) })
    gap = false
    if s['endpoint']
      if ep then used[s['endpoint']] = true
      else err.('J2', "#{id}/#{sid}: endpoint #{s['endpoint'].inspect} inexistant dans contracts"); gap = true end
    elsif s['usecase']
      u = UC[s['usecase']]
      err.('J2', "#{id}/#{sid}: usecase #{s['usecase'].inspect} inexistant") unless u
      wrn.('J2', "#{id}/#{sid}: usecase #{s['usecase']} n'est pas consumer/shared (préférer endpoint:)") if u && u['type'] == 'producer'
    else
      gap = true # J3 : écart assumé
      wrn.('J3', "#{id}/#{sid}: endpoint null sans `gap:` (décrire l'écart)") if s['gap'].to_s.empty?
    end
    if ep
      wrn.('J4', "#{id}/#{sid}: acteur #{s['actor'].inspect} inconnu de actors.yml") if s['actor'] && !actor_ids.include?(s['actor'])
      wrn.('J4', "#{id}/#{sid}: acteur #{s['actor']} absent des atomic_actions de l'app #{ep[:app]}") if s['actor'] && actor_ids.include?(s['actor']) && !app_actors[ep[:app]].include?(s['actor'])
    end
    anc_steps = ancestors.(sid).map { |a| by[a] }
    produced = given + anc_steps.flat_map { |a| Array(a['produces']) }
    prod_ok = given + anc_steps.reject { |a| status[a['id']] != :ok }.flat_map { |a| Array(a['produces']) }
    blocked = false
    Array(s['needs']).each do |n|
      if !satisfied?(n, produced)
        wrn.('J5', "#{id}/#{sid}: donnée #{n.inspect} requise mais produite par aucune étape antérieure")
      elsif !satisfied?(n, prod_ok)
        blocked = true
      end
    end
    if ep # J6
      pp = path_params(ep).select { |n| n.end_with?('_id') || n == 'id' }
      avail = produced.map { |t| tok(t).first }
      pp.each { |n| wrn.('J6', "#{id}/#{sid}: paramètre de chemin {#{n}} de #{s['endpoint']} non fourni par une étape antérieure") unless avail.include?(n) || avail.any? { |a| a.split('.').last == n } }
      rn = resp_names(ep) + req_names(ep)
      Array(s['produces']).each do |t|
        base = tok(t).first; field = base.split('.').last
        next unless base.include?('.') || field.end_with?('_id') # jeton purement logique (ex. candidate_session) : non vérifié
        ent = base.include?('.') ? base.split('.').first : nil
        okf = rn.include?(field) || (field.end_with?('_id') && rn.include?('id')) || (ent && rn.include?("#{ent}_#{field}"))
        wrn.('J6', "#{id}/#{sid}: #{s['endpoint']} n'expose pas le champ #{field.inspect} (produces #{t})") unless okf
      end
    end
    status[sid] = gap ? :gap : (blocked ? :blocked : :ok)
    # J7 : passage d'app
    if ep
      (by[sid]['after'] || []).select { |a| by.key?(a) }.each do |a|
        pe = by[a]['endpoint'] && EP[by[a]['endpoint']]
        next unless pe && pe[:app] != ep[:app]
        shared = Array(s['needs']).select { |n| Array(by[a]['produces']).any? { |p| tok(p).first == tok(n).first } }
        shared.each do |n|
          field = tok(n).first.split('.').last
          next unless tok(n).first.include?('.') || field.end_with?('_id') # jeton logique : non vérifié
          wrn.('J7', "#{id}/#{sid}: état #{n} échangé #{pe[:app]} → #{ep[:app]} mais #{s['endpoint']} n'expose ni n'accepte #{field.inspect}") unless (resp_names(ep) + req_names(ep)).include?(field)
        end
      end
    end
    app_stats[app || '?'][status[sid]] += 1
  end
  report << [id, j, status]
end

# ── contraintes (K) ───────────────────────────────────────────────────
cons = File.exist?(cfile) ? (load_yaml.(cfile) || {}) : {}
KNOWN = %w[calls_app endpoint_auth actors_only http_method usecase_per_endpoint max_endpoints needs_journey endpoint_absent forbid_field response_fields request_fields endpoint_exists forbid_response_field error_codes]
(cons['rules'] || []).each do |r|
  rid = r['id'] || '?'
  sc = r['scope'] || {}
  in_scope = ->(app, mod, ft) { (sc['app'].nil? || sc['app'] == app) && (sc['module'].nil? || sc['module'] == mod) && (sc['feature'].nil? || sc['feature'] == ft) }
  eps = EP.select { |_, e| in_scope.(e[:app], e[:module], e[:feature]) && (sc['method'].nil? || Array(sc['method']).include?(e[:method])) }
  sev = r['severity'] == 'warn' ? wrn : err
  unless %w[forbid require limit].include?(r['kind'])
    err.('K1', "#{rid}: kind #{r['kind'].inspect} invalide (forbid|require|limit)"); next
  end
  unless KNOWN.include?(r['rule'])
    wrn.('K1', "#{rid}: forme #{r['rule'].inspect} non vérifiable (prose seule)"); next
  end
  warn_empty = ->() { wrn.('K1', "#{rid}: portée vide (aucun endpoint concerné)") if eps.empty? }
  case r['rule']
  when 'calls_app'
    journeys.each_value do |j|
      j['steps'].each do |s|
        ep = s['endpoint'] && EP[s['endpoint']] or next
        caller = s['app'] || ep[:app]
        sev.('K', "#{rid}: #{j['id']}/#{s['id']} — l'app #{caller} appelle #{ep[:app]} (#{s['endpoint']}) — #{r['why']}") if sc['app'] == caller && Array(r['value']).include?(ep[:app])
      end
    end
  when 'endpoint_auth'
    warn_empty.()
    eps.each { |i, e| sev.('K', "#{rid}: #{i} auth=#{e[:auth].inspect}, attendu #{r['value'].inspect}") if e[:auth] != r['value'] }
  when 'actors_only'
    feat_actors.each { |(a, m, f), as| sev.('K', "#{rid}: #{a}/#{m}/#{f} utilise l'acteur #{(as - Array(r['value'])).uniq.join(',')} (autorisés : #{Array(r['value']).join(',')})") if in_scope.(a, m, f) && !(as - Array(r['value'])).empty? }
  when 'http_method'
    eps.each { |i, e| sev.('K', "#{rid}: #{i} utilise #{e[:method]} (interdit : #{Array(r['value']).join(',')})") if Array(r['value']).include?(e[:method]) } if r['kind'] == 'forbid'
  when 'usecase_per_endpoint'
    warn_empty.()
    eps.each_key { |i| sev.('K', "#{rid}: #{i} sans usecase (operationId)") unless UC_BY_OP[i] }
  when 'endpoint_absent'
    Array(r['value']).each { |i| sev.('K', "#{rid}: l'endpoint #{i} ne devrait pas exister#{EP[i] && !in_scope.(EP[i][:app], EP[i][:module], EP[i][:feature]) ? ' (hors portée)' : ''} — #{r['why']}") if EP[i] && in_scope.(EP[i][:app], EP[i][:module], EP[i][:feature]) }
  when 'forbid_field'
    warn_empty.()
    eps.each do |i, e|
      body = req_names(e)
      (Array(r['value']) & body).each { |fld| sev.('K', "#{rid}: #{i} accepte le champ #{fld.inspect} en entrée — #{r['why']}") }
    end
  when 'forbid_response_field'
    eps.each do |i, e|
      (Array(r['value']) & resp_names(e)).each { |fld| sev.('K', "#{rid}: la réponse de #{i} expose le champ #{fld.inspect} — #{r['why']}") }
    end
  when 'error_codes'
    (r['value'] || {}).each do |i, codes|
      (sev.('K', "#{rid}: endpoint #{i} inexistant"); next) unless EP[i]
      have = (EP[i][:spec].dig('http', 'response', 'errors') || []).map { |x| x['code'] }
      miss = Array(codes) - have
      sev.('K', "#{rid}: #{i} ne déclare pas l'erreur #{miss.join(', ')} — #{r['why']}") unless miss.empty?
    end
  when 'endpoint_exists'
    Array(r['value']).each { |i| sev.('K', "#{rid}: l'endpoint #{i} devrait exister — #{r['why']}") unless EP[i] }
  when 'request_fields'
    (r['value'] || {}).each do |i, fields|
      (sev.('K', "#{rid}: endpoint #{i} inexistant"); next) unless EP[i]
      miss = Array(fields) - req_names(EP[i])
      sev.('K', "#{rid}: #{i} n'accepte pas #{miss.map(&:inspect).join(', ')} en entrée — #{r['why']}") unless miss.empty?
    end
  when 'response_fields'
    (r['value'] || {}).each do |i, fields|
      (sev.('K', "#{rid}: endpoint #{i} inexistant"); next) unless EP[i]
      miss = Array(fields) - resp_names(EP[i])
      sev.('K', "#{rid}: la réponse de #{i} n'expose pas #{miss.map(&:inspect).join(', ')} — #{r['why']}") unless miss.empty?
    end
  when 'max_endpoints'
    sev.('K', "#{rid}: #{eps.size} endpoints > limite #{r['value']}") if eps.size > r['value'].to_i
  when 'needs_journey'
    feats = eps.values.map { |e| [e[:app], e[:module], e[:feature]] }.uniq
    jf = journeys.values.flat_map { |j| j['steps'].map { |s| s['endpoint'] && EP[s['endpoint']] }.compact.map { |e| [e[:app], e[:module], e[:feature]] } }.uniq
    (feats - jf).each { |a, m, f| sev.('K', "#{rid}: feature #{a}/#{m}/#{f} absente de tout parcours") }
  end
end

# ── sortie ────────────────────────────────────────────────────────────
puts E, W
unless quiet
  out = []
  out << "\n== Parcours (#{report.size}) =="
  report.each do |id, j, status|
    c = Hash.new(0); status.each_value { |v| c[v] += 1 }
    out << "\n#{id} — #{j['question']}"
    out << "  #{status.size} étapes : #{c[:ok]} couvertes, #{c[:gap]} écart(s), #{c[:blocked]} bloquée(s)"
    j['steps'].each do |s|
      mark = { ok: 'OK     ', gap: 'ÉCART  ', blocked: 'BLOQUÉE' }[status[s['id']]]
      out << "  [#{mark}] #{s['id']} (#{s['actor']}) → #{s['endpoint'] || s['usecase'] || 'null'}#{s['gap'] ? "  « #{s['gap']} »" : ''}"
    end
  end
  out << "\n== Complétude par app =="
  app_stats.sort.each { |a, c| t = c.values.sum; out << "  #{a}: #{c[:ok]}/#{t} étapes couvertes, #{c[:gap]} écart(s), #{c[:blocked]} bloquée(s)#{c[:gap] + c[:blocked] == 0 ? '  → complète' : '  → incomplète'}" }
  orphans = EP.keys - used.keys
  out << "\n== Endpoints hors parcours : #{orphans.size}/#{EP.size} =="
  orphans.group_by { |i| EP[i][:app] }.sort.each { |a, ids| out << "  #{a}: #{ids.size}" }
  puts out
  File.write(md_out, out.join("\n") + "\n") if md_out
end
puts "\njourneys: #{journeys.size} parcours · #{(cons['rules'] || []).size} contraintes — #{E.size} erreur(s), #{W.size} avertissement(s)" unless quiet
exit(E.empty? ? 0 : 1)
