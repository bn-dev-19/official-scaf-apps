#!/usr/bin/env ruby
# Contrats -> openapi.parts -> OpenAPI réel par app.
#   contracts/apps/<app>/<module>/<feature>.yml  ==(étape 1)==>  input/openapi.parts/<app>/<module>/<feature>/<endpoint-id>.yml
#   openapi.parts/**                              ==(étape 2)==>  scaf/<version>/output/openapi/openapi.<app>.yml
# Usage : ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/v1 [--app <slug>] [--parts-only] [--parts-out <dir>] [--out <dir>] [--doc | --doc-in-place]
# --parts-out : écrit les parts ailleurs que dans input/openapi.parts (test sans écraser). --out : dossier des OpenAPI finales.
# --doc : en plus, écrit <out>/doc/openapi.<app>.yml dont le `description` de chaque opération est enrichi en Markdown
#         (accès, tableaux paramètres / corps / réponse / erreurs, exemples : 1 nominal + 1 par code d'erreur).
# --doc-in-place : idem mais enrichit directement <out>/openapi.<app>.yml (pas de version « brute »).
# --no-refs : désactive la factorisation $ref (Error, Pagination, Warnings, paramètres et sous-schémas répétés -> components).
# --license <nom> [--license-url <url>] : info.license des OpenAPI générées (défaut : Proprietary, sans url).
# Formats : ../02-file-formats.md §7 (spec/mocks) et §10 (parts). Code retour 1 s'il y a des E.
require 'yaml'
require 'json'
require 'date'
require 'fileutils'

root = ARGV[0] or abort 'usage: contracts_to_openapi.rb <scaf/vN> [--app slug] [--parts-only] [--parts-out dir] [--out dir]'
opt = ->(name) { i = ARGV.index(name); i && ARGV[i + 1] }
only_app = opt.('--app')
parts_only = ARGV.include?('--parts-only')
with_doc = ARGV.include?('--doc') || ARGV.include?('--doc-in-place')   # description Markdown enrichie (tableaux de champs + exemples)
doc_in_place = ARGV.include?('--doc-in-place')
no_refs = ARGV.include?('--no-refs')   # sortie 100 % inline (sans components.schemas/parameters)
docs = {}
license_url = opt.('--license-url')
license_name = opt.('--license') || 'Proprietary'   # info.license.name des OpenAPI générées
inp = File.join(root, 'input')
abort "introuvable: #{inp}" unless Dir.exist?(inp)
version = File.basename(File.expand_path(root))
parts_dir = opt.('--parts-out') || File.join(inp, 'openapi.parts')
out_dir = opt.('--out') || File.join(root, 'output', 'openapi')

E = []; W = []
err = ->(m) { E << "E #{m}" }
warn_ = ->(m) { W << "W #{m}" }

# ── utilitaires ────────────────────────────────────────────────────────────────
def plain(o)
  case o
  when Hash then o.each_with_object({}) { |(k, v), h| h[k.to_s] = plain(v) }
  when Array then o.map { |v| plain(v) }
  when Date, Time then o.is_a?(Time) ? o.utc.strftime('%Y-%m-%dT%H:%M:%SZ') : o.to_s
  else o
  end
end

def dump(o)
  YAML.dump(plain(o), line_width: -1).sub(/\A---\s*\n/, '')
end

def write(path, content)
  FileUtils.mkdir_p(File.dirname(path))
  File.write(path, content)
end

# Formats du contrat non standard OpenAPI -> équivalents. `date-iso` est résolu plus tard (resolve_dates) d'après les valeurs des mocks.
FORMAT_MAP = { 'url' => 'uri', 'ip' => 'ipv4' }.freeze

DATE_RE = /\A\d{4}-\d{2}-\d{2}\z/

# date-iso -> `date` (mocks tous en AAAA-MM-JJ) | `date-time` (tous en datetime, ou aucune valeur) | pas de format (mélange, signalé)
def resolve_dates(s, vals, path, mixed)
  return unless s.is_a?(Hash)
  vals = vals.compact
  if s['format'] == 'date-iso'
    kinds = vals.grep(String).map { |v| v =~ DATE_RE ? :date : :dt }.uniq
    if kinds == [:date] then s['format'] = 'date'
    elsif kinds.size > 1 then s.delete('format'); mixed << path
    else s['format'] = 'date-time'
    end
  end
  (s['properties'] || {}).each { |k, sub| resolve_dates(sub, vals.grep(Hash).map { |v| v[k] }, "#{path}.#{k}", mixed) }
  resolve_dates(s['items'], vals.grep(Array).flatten(1), "#{path}[]", mixed) if s['items']
end

# Réponse : tout champ est requis, y compris `nullable` (présent avec la valeur null) ; le contrat ne porte pas `required` sur les réponses.
def require_all(s)
  return unless s.is_a?(Hash)
  if s['properties']
    req = s['properties'].keys
    s['required'] = req unless req.empty?
    s['properties'].each_value { |v| require_all(v) }
  end
  require_all(s['items']) if s['items']
end
PASS = %w[description nullable enum default minLength maxLength pattern minimum maximum example].freeze

# SchemaField (contrat) -> JSON Schema OpenAPI 3.0.3
def schema(f)
  return {} unless f.is_a?(Hash)
  s = {}
  t = f['type']
  s['type'] = t if t && t != 'any'
  if f['format'] && !f['format'].to_s.empty? && f['format'] != 'enum' && !f['format'].to_s.include?('{')
    s['format'] = FORMAT_MAP.fetch(f['format'], f['format'])
  end
  PASS.each { |k| s[k] = f[k] if f.key?(k) }
  if f['properties'].is_a?(Hash)
    s['type'] ||= 'object'
    s['properties'] = f['properties'].transform_values { |v| schema(v) }
    req = f['properties'].select { |_, v| v.is_a?(Hash) && v['required'] == true }.keys
    req = (req + f['required']).uniq if f['required'].is_a?(Array)
    s['required'] = req unless req.empty?
  end
  s['items'] = schema(f['items']) if f['items']
  s['type'] ||= 'array' if f['items']
  if s['type'] == 'array' && s['enum']   # enum porté par le tableau dans le contrat -> OpenAPI le veut sur `items`
    s['items'] ||= { 'type' => 'string' }
    s['items']['enum'] = s.delete('enum')
  end
  s['enum'] = s['enum'] + [nil] if s['nullable'] && s['enum'] && !s['enum'].include?(nil)   # OpenAPI 3.0.3 : null doit figurer dans enum
  s
end

# enums.yml : la description du concept est ajoutée à celle des champs liés (même logique de liaison que enums.rb)
CONCEPTS = (File.exist?(File.join(inp, 'enums.yml')) ? (YAML.safe_load(File.read(File.join(inp, 'enums.yml')), permitted_classes: [Date, Time]) || {})['concepts'] : nil) || []
def annotate_enums(op, id, status_ok)
  note = lambda do |s, where, path|
    c = CONCEPTS.find { |c| (c['bindings'] || []).any? { |b| File.fnmatch(b['endpoint'].to_s, id) && File.fnmatch(b['field'].to_s, path) && (b['in'].nil? || b['in'] == where) } }
    d = c && c['description'].to_s.strip
    return if d.nil? || d.empty? || !(s['enum'] || s.dig('items', 'enum')) || s['description'].to_s.include?(d)
    s['description'] = s['description'].to_s.empty? ? d : "#{s['description'].to_s.sub(/\.?\s*\z/, '')}. #{d}"
  end
  walk = lambda do |s, where, path|
    next unless s.is_a?(Hash)
    (s['properties'] || {}).each { |k, v| p2 = path.empty? ? k : "#{path}.#{k}"; note.(v, where, p2); walk.(v, where, p2) }
    walk.(s['items'], where, path) if s['items']
  end
  (op['parameters'] || []).each { |q| note.(q['schema'] || {}, 'query', q['name']) if q['in'] == 'query' && q['schema'] }
  walk.(op.dig('requestBody', 'content', 'application/json', 'schema'), 'req', '')
  walk.(op.dig('responses', status_ok.to_s, 'content', 'application/json', 'schema', 'properties', 'data'), 'resp', '')
end

# constraints.yml : règles métier publiées dans l'OpenAPI (x-constraints par opération, info.description par app)
RULES = (File.exist?(File.join(inp, 'constraints.yml')) ? (YAML.safe_load(File.read(File.join(inp, 'constraints.yml'))) || {})['rules'] : nil) || []
META_RULES = %w[usecase_per_endpoint endpoint_exists max_endpoints needs_journey calls_app].freeze
MAP_RULES = %w[response_fields request_fields error_codes].freeze
def rule_scope?(r, app, mod, ft, method)
  sc = r['scope'] || {}
  (!sc['app'] || sc['app'] == app) && (!sc['module'] || sc['module'] == mod) && (!sc['feature'] || sc['feature'] == ft) && (!sc['method'] || Array(sc['method']).include?(method.to_s.upcase))
end
def rule_value(r, id); MAP_RULES.include?(r['rule']) ? (r['value'] || {})[id] : r['value']; end
# règles ciblant précisément l'endpoint : clé de map = id, ou portée feature / module+method (les portées app et module vont dans info.description)
def constraints_for(app, mod, ft, method, id)
  RULES.reject { |r| META_RULES.include?(r['rule']) }.select do |r|
    sc = r['scope'] || {}
    next false unless rule_scope?(r, app, mod, ft, method)
    MAP_RULES.include?(r['rule']) ? (r['value'] || {}).key?(id) : (sc['feature'] || (sc['module'] && sc['method']))
  end.map { |r| { 'id' => r['id'], 'rule' => r['rule'], 'kind' => r['kind'], 'value' => rule_value(r, id), 'why' => r['why'] }.reject { |_, v| v.nil? } }
end
RULE_LABEL = { 'forbid_field' => 'Champs d\'entrée interdits', 'request_fields' => 'Champs d\'entrée requis', 'forbid_response_field' => 'Champs de sortie interdits',
               'response_fields' => 'Champs de sortie garantis', 'error_codes' => 'Codes d\'erreur', 'actors_only' => 'Acteurs autorisés', 'http_method' => 'Méthodes interdites',
               'endpoint_auth' => 'Authentification', 'endpoint_absent' => 'Endpoints absents' }.freeze
def constraint_line(c)
  v = c['value']; lab = RULE_LABEL[c['rule']]
  det = lab && v ? " (#{lab} : #{Array(v).join(', ')})" : ''
  "- #{c['why'] || c['id']}#{det}"
end
def app_rules_md(app, mods)
  rs = RULES.reject { |r| META_RULES.include?(r['rule']) || MAP_RULES.include?(r['rule']) }.select do |r|
    sc = r['scope'] || {}
    (!sc['app'] || sc['app'] == app) && (!sc['module'] || mods.include?(sc['module'])) && !sc['feature'] && !(sc['module'] && sc['method'])
  end
  return nil if rs.empty?
  "## Règles métier de l'application\n\n" + rs.map { |r| m = (r['scope'] || {})['module']; constraint_line('id' => r['id'], 'rule' => r['rule'], 'value' => r['value'], 'why' => (m ? "[#{m}] " : '') + r['why'].to_s) }.join("\n")
end

def field_param(fd, where)
  s = schema(fd.reject { |k, _| %w[name required].include?(k) })
  p = { 'name' => fd['name'], 'in' => where }
  p['description'] = fd['description'] if fd['description']
  p['required'] = where == 'path' ? true : fd['required'] == true
  p['schema'] = s
  p
end

ERROR_BASE = {
  'type' => 'object',
  'properties' => {
    'success' => { 'type' => 'boolean', 'enum' => [false] },
    'message' => { 'type' => 'string' },
    'error' => {
      'type' => 'object',
      'properties' => {
        'code' => { 'type' => 'string' }, 'message' => { 'type' => 'string' },
        'cause' => { 'type' => 'string' }, 'resolution' => { 'type' => 'string' }
      },
      'required' => %w[code message]
    }
  },
  'required' => %w[success message error]
}.freeze

# enveloppe de succès : { success, message, data, pagination?, warnings? } — pagination et warnings sont hors data
PAGINATION_SCHEMA = {
  'type' => 'object',
  'description' => 'Métadonnées de pagination (hors data).',
  'properties' => %w[current_page page_size total_items total_pages].to_h { |k| [k, { 'type' => 'integer' }] },
  'required' => %w[current_page page_size total_items total_pages]
}.freeze
WARNINGS_SCHEMA = {
  'type' => 'array',
  'description' => 'Avertissements non bloquants.',
  'items' => {
    'type' => 'object',
    'properties' => { 'title' => { 'type' => 'string' }, 'description' => { 'type' => 'string' }, 'tips' => { 'type' => 'array', 'items' => { 'type' => 'string' } } },
    'required' => %w[title description tips]
  }
}.freeze

# impose la forme canonique de pagination/warnings ; warnings (optionnel, au niveau de data) : forme canonique s'il est déclaré, ajouté sinon ; pagination seulement si déclarée
def canon_envelope(s)
  pr = s['properties'] or return
  pr['warnings'] ||= {} if pr.key?('success')
  pr['pagination'] = Marshal.load(Marshal.dump(PAGINATION_SCHEMA)) if pr.key?('pagination')
  if pr.key?('warnings')
    pr['warnings'] = Marshal.load(Marshal.dump(WARNINGS_SCHEMA))
    s['required'] = (s['required'] || []) - ['warnings']
  end
end

def error_schema(codes)
  s = Marshal.load(Marshal.dump(ERROR_BASE))
  s['properties']['error']['properties']['code']['enum'] = codes unless codes.empty?
  s
end

# validation légère d'une valeur d'exemple contre un schéma ; retourne la liste des écarts
def check(v, s, path, out)
  return if s.nil? || s.empty?
  if v.nil?
    out << "#{path}: null non autorisé (nullable absent)" unless s['nullable']
    return
  end
  case s['type']
  when 'object'
    return out << "#{path}: attendu object, reçu #{v.class}" unless v.is_a?(Hash)
    (s['required'] || []).each { |k| out << "#{path}.#{k}: requis absent" unless v.key?(k) }
    (s['properties'] || {}).each { |k, sub| check(v[k], sub, "#{path}.#{k}", out) if v.key?(k) }
    (v.keys - (s['properties'] || {}).keys).each { |k| out << "#{path}.#{k}: clé non déclarée dans le schema" } if s['properties']
  when 'array'
    return out << "#{path}: attendu array, reçu #{v.class}" unless v.is_a?(Array)
    v.each_with_index { |x, i| check(x, s['items'], "#{path}[#{i}]", out) }
  when 'string'
    return out << "#{path}: attendu string, reçu #{v.class}" unless v.is_a?(String)
    out << "#{path}: #{v.inspect} hors enum #{s['enum']}" if s['enum'] && !s['enum'].map(&:to_s).include?(v)
    out << "#{path}: #{v.inspect} n'est pas une date (format date)" if s['format'] == 'date' && v !~ DATE_RE
    out << "#{path}: #{v.inspect} n'est pas un date-time" if s['format'] == 'date-time' && v !~ /\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})\z/
    out << "#{path}: #{v.inspect} n'est pas un uuid" if s['format'] == 'uuid' && v !~ /\A\h{8}-\h{4}-\h{4}-\h{4}-\h{12}\z/
  when 'integer'
    out << "#{path}: attendu integer, reçu #{v.inspect}" unless v.is_a?(Integer)
  when 'number'
    out << "#{path}: attendu number, reçu #{v.inspect}" unless v.is_a?(Numeric)
  when 'boolean'
    out << "#{path}: attendu boolean, reçu #{v.inspect}" unless [true, false].include?(v)
  end
end

# ── doc enrichie (--doc) : Markdown par opération ─────────────────────────────
def cell(v)
  v.to_s.gsub('|', '\|').gsub(/\s*\n\s*/, '<br>').strip
end

def table(head, rows)
  return '' if rows.empty?
  ([head.join(' | '), head.map { '---' }.join(' | ')] + rows.map { |r| r.map { |c| cell(c) }.join(' | ') }).map { |l| "| #{l} |" }.join("\n")
end

def type_label(s)
  return s['type'].to_s unless s['type'] == 'array'
  it = s['items'] || {}
  "array<#{it['type'] || 'any'}>"
end

# schema OpenAPI -> lignes [champ, type, format, requis, nullable, valeurs, description] (chemin pointé, [] pour les tableaux)
def flatten_schema(s, path, rows, required = false)
  return unless s.is_a?(Hash)
  req = s['required'] || []
  (s['properties'] || {}).each do |k, v|
    p = path.empty? ? k : "#{path}.#{k}"
    rows << [p, type_label(v), v['format'], req.include?(k) ? 'oui' : 'non', v['nullable'] ? 'oui' : 'non', (v['enum'] || v.dig('items', 'enum') || []).map { |x| x.nil? ? 'null' : x }.join(', '), v['description']]
    flatten_schema(v, p, rows) if v['properties']
    flatten_schema(v['items'], "#{p}[]", rows) if v['items'].is_a?(Hash) && v['items']['properties']
  end
end

# upload (format: binary) : les mocks décrivent le fichier par ses métadonnées ; l'exemple OpenAPI porte le nom du fichier
def unbinary(v, s)
  return v unless s.is_a?(Hash)
  return(v.is_a?(Hash) ? (v['filename'] || 'fichier') : v) if s['format'] == 'binary'
  if v.is_a?(Hash) && s['properties'] then v.each { |k, x| v[k] = unbinary(x, s['properties'][k]) if s['properties'][k] }
  elsif v.is_a?(Array) && s['items'] then v.map! { |x| unbinary(x, s['items']) } end
  v
end

# exemple lisible : 1 seul élément par liste, textes longs raccourcis
def shorten(v)
  case v
  when Array then v.first(1).map { |x| shorten(x) }
  when Hash then v.transform_values { |x| shorten(x) }
  when String then v.size > 120 ? "#{v[0, 117]}…" : v
  else v
  end
end

def json_block(v)
  "```json\n#{JSON.pretty_generate(shorten(v))}\n```"
end

def build_doc(op, method, path, http, errs, mocks, ok_status)
  out = []
  auth = http.dig('auth', 'type') == 'required' ? 'Authentification requise : en-tête `Authorization: Bearer {token}`.' : 'Endpoint public : aucune authentification.'
  out << "**`#{method.upcase} #{path}`** — #{auth}"
  out << "### Règles métier\n\n#{op['x-constraints'].map { |c| constraint_line(c) }.join("\n")}" if op['x-constraints']
  params = (op['parameters'] || []).map { |q| [q['name'], q['in'], type_label(q['schema'] || {}), q.dig('schema', 'format'), q['required'] ? 'oui' : 'non', ((q.dig('schema', 'enum') || q.dig('schema', 'items', 'enum') || []).empty? ? '' : "Valeurs : #{(q.dig('schema', 'enum') || q.dig('schema', 'items', 'enum')).map { |x| x.nil? ? 'null' : x }.join(', ')}. ") + q['description'].to_s] }
  out << "### Paramètres\n\n#{table(%w[Nom Dans Type Format Requis Description], params)}" unless params.empty?
  body = op.dig('requestBody', 'content', 'application/json', 'schema')
  if body
    rows = []; flatten_schema(body, '', rows)
    out << "### Corps de la requête\n\n#{table(%w[Champ Type Format Requis Nullable Valeurs Description], rows)}" unless rows.empty?
  end
  succ = op.dig('responses', ok_status.to_s, 'content', 'application/json', 'schema')
  if succ
    rows = []; flatten_schema(succ, '', rows)
    out << "### Réponse #{ok_status}\n\n#{table(%w[Champ Type Format Requis Nullable Valeurs Description], rows)}"
  end
  unless errs.empty?
    out << "### Erreurs\n\n" + table(%w[HTTP Code Message Cause Résolution], errs.map { |x| [x['status'], x['code'], x['message'] || x['description'], x['cause'], x['resolution']] })
  end
  nominal = mocks.select { |m| m.dig('expect', 'status').to_i == ok_status }
  nom = nominal.find { |m| m['name'].to_s.start_with?('nominal') } || nominal.first
  ex = []
  if nom
    g = nom['given'] || {}
    q = (g['query'] || {}).empty? ? '' : "?#{g['query'].map { |k, v| "#{k}=#{v}" }.join('&')}"
    ex << "#### Requête\n\n`#{g['method'] || method.upcase} #{g['path'] || path}#{q}`"
    ex << json_block(g['body']) unless g['body'].nil?
    ex << "#### Réponse #{ok_status} — #{nom['name']}\n\n#{json_block(nom.dig('expect', 'body'))}"
  end
  errs.map { |x| x['code'] }.compact.uniq.each do |code|
    es = errs.find { |x| x['code'] == code }
    mk = mocks.find { |m| m['name'] == "error-#{code.downcase}" } ||
         mocks.find { |m| m.dig('expect', 'body', 'error', 'code') == code } ||
         mocks.find { |m| m.dig('expect', 'status').to_i == es['status'].to_i && m.dig('expect', 'status').to_i != ok_status }
    ex << "#### Réponse #{es['status']} — #{code}\n\n#{json_block(mk.dig('expect', 'body'))}" if mk
  end
  out << "### Exemples\n\n#{ex.join("\n\n")}" unless ex.empty?
  out.join("\n\n")
end

# ── factorisation : $ref vers components (erreurs, pagination/warnings, paramètres, sous-schémas répétés) ──
# Appliquée à l'OpenAPI finale uniquement : les parts restent inline (check/build_doc travaillent dessus).
REPEAT_MIN = 3   # un sous-schéma objet identique n'est nommé qu'à partir de N occurrences dans une même app
def pascal(s); s.to_s.split(/[^A-Za-z0-9]+/).reject(&:empty?).map { |w| w[0].upcase + w[1..] }.join; end
def ref(kind, name); { '$ref' => "#/components/#{kind}/#{name}" }; end

def factorize(doc, warn_)
  schemas = {}; params = {}
  ops = doc['paths'].values.flat_map(&:values)
  rschemas = ->(op) { op['responses'].map { |st, r| [st, r.dig('content', 'application/json')] }.select { |_, m| m && m['schema'] } }

  # 1. erreurs (enum de codes propre à l'endpoint conservé via allOf), pagination, warnings
  ops.each do |op|
    rschemas.(op).each do |st, m|
      s = m['schema']
      dup = Marshal.load(Marshal.dump(s))
      codes = dup.dig('properties', 'error', 'properties', 'code')&.delete('enum')
      if dup == ERROR_BASE
        # structure unique `Error` ; un composant par jeu de codes = allOf + enum. Les autres propriétés de `error`
        # sont listées vides : Redocly évalue `error` par branche et rejette sinon les exemples (unevaluated)
        schemas['Error'] ||= ERROR_BASE
        name = codes ? "Error#{codes.map { |c| pascal(c.downcase) }.join('Or')}" : 'Error'
        schemas[name] ||= { 'allOf' => [ref('schemas', 'Error'), { 'properties' => { 'error' => { 'properties' => {
          'code' => { 'enum' => codes }, 'message' => {}, 'cause' => {}, 'resolution' => {} } } } }] } if codes
        m['schema'] = ref('schemas', name)
      end
      { 'pagination' => ['Pagination', PAGINATION_SCHEMA], 'warnings' => ['Warnings', WARNINGS_SCHEMA] }.each do |k, (name, canon)|
        next unless s['properties'].is_a?(Hash) && s['properties'][k] == canon
        schemas[name] ||= canon
        s['properties'][k] = ref('schemas', name)
      end
    end
  end

  # 2. paramètres identiques (>= 2 occurrences) ; un nom déjà pris par une autre définition reste inline
  all = ops.flat_map { |op| op['parameters'] || [] }
  all.group_by { |p| JSON.generate(p) }.select { |_, v| v.size >= 2 }.sort_by { |_, v| -v.size }.each do |_, v|
    name = pascal(v.first['name']); name = "#{name}#{pascal(v.first['in'])}" if v.first['in'] != 'query'
    (warn_.("components.parameters.#{name}: nom déjà pris par une définition différente (laissé inline)"); next) if params.key?(name)
    params[name] = Marshal.load(Marshal.dump(v.first))
    v.each { |p| p.replace(ref('parameters', name)) }
  end

  # 3. sous-schémas objet identiques (>= REPEAT_MIN) -> components.schemas
  named = ->(s) { s.is_a?(Hash) && !s['$ref'] && !s['allOf'] && s['properties'].is_a?(Hash) && s['properties'].size >= 2 }
  count = Hash.new(0)
  walk = lambda do |s|
    next unless s.is_a?(Hash)
    count[JSON.generate(s)] += 1 if named.(s)
    (s['properties'] || {}).each_value { |v| walk.(v) }
    walk.(s['items']) if s['items']
  end
  roots = ops.flat_map { |op| [op.dig('requestBody', 'content', 'application/json')].compact + rschemas.(op).map(&:last) }
  roots.each { |m| walk.(m['schema']) }
  by_sig = {}
  rewrite = lambda do |s, hint|
    next s unless s.is_a?(Hash) && !s['$ref']
    sig = JSON.generate(s)
    (s['properties'] || {}).each { |k, v| s['properties'][k] = rewrite.(v, k) }
    s['items'] = rewrite.(s['items'], hint.to_s.sub(/s\z/, '')) if s['items']
    next s unless named.(s) && count[sig] >= REPEAT_MIN
    unless by_sig[sig]
      name = pascal(hint); name = 'Schema' if name.empty?
      base = name; n = 2
      (name = "#{base}#{n}"; n += 1) while schemas.key?(name)
      warn_.("components.schemas.#{name}: nom dérivé de '#{hint}' en collision, suffixé") if name != base
      schemas[name] = s
      by_sig[sig] = name
    end
    ref('schemas', by_sig[sig])
  end
  ops.each do |op|
    if (m = op.dig('requestBody', 'content', 'application/json'))
      m['schema'] = rewrite.(m['schema'], "#{pascal(op['operationId'])}Request")
    end
    rschemas.(op).each { |st, m| m['schema'] = rewrite.(m['schema'], "#{pascal(op['operationId'])}Response#{st}") }
  end

  return if schemas.empty? && params.empty?
  doc['components'] ||= {}
  doc['components']['schemas'] = schemas.sort.to_h unless schemas.empty?
  doc['components']['parameters'] = params.sort.to_h unless params.empty?
end

# ── étape 1 : contrats -> parts ───────────────────────────────────────────────
cindex = YAML.safe_load(File.read(File.join(inp, 'contracts', '_index.yml')), permitted_classes: [Date, Time]) || {}
servers = (YAML.safe_load(File.read(File.join(inp, 'contracts', 'servers.yml'))) || {})['servers'] || [] rescue []
all_ids = {}
route_seen = {}
parts_index = []          # structure pour _index.yml
app_ops = Hash.new { |h, k| h[k] = [] }   # app -> [[tagname, path, method, op]]
app_tags = Hash.new { |h, k| h[k] = [] }
counts = { endpoints: 0, examples: 0 }

(cindex['apps'] || []).each do |a|
  app = a['slug']
  next if only_app && only_app != app
  pi_app = { 'slug' => app, 'modules' => [] }
  FileUtils.rm_rf(File.join(parts_dir, app))
  write(File.join(parts_dir, app, "#{app}.yml"), dump('tags' => [{ 'name' => app, 'description' => "Module #{app}" }], 'paths' => {}))
  (a['modules'] || []).each do |m|
    mod = m['slug']
    pi_mod = { 'slug' => mod, 'features' => [] }
    write(File.join(parts_dir, app, mod, "#{mod}.yml"),
          dump('info' => { 'title' => "#{app}/#{mod}", 'version' => '1.0.0' }, 'openapi' => '3.0.3', 'paths' => {}))
    (m['features'] || []).each do |ft|
      file = File.join(inp, 'contracts', 'apps', app, mod, "#{ft}.yml")
      unless File.exist?(file)
        warn_.("#{app}/#{mod}/#{ft}: fichier de contrat absent (listé dans _index.yml)")
        next
      end
      pi_mod['features'] << ft
      tag = "#{app} / #{mod} / #{ft}"
      tags = [{ 'name' => tag, 'description' => "Module #{tag}" }]
      app_tags[app] << tags.first
      feature_paths = {}
      (YAML.safe_load(File.read(file), permitted_classes: [Date, Time])['endpoints'] || []).each do |e|
        id = e['id']
        where = "#{app}/#{mod}/#{ft}/#{id}"
        err.("#{where}: id dupliqué (déjà dans #{all_ids[id]})") if all_ids[id]
        all_ids[id] = where
        spec = (YAML.safe_load(e['spec'].to_s, permitted_classes: [Date, Time]) rescue nil)
        mocks = (JSON.parse(e['mocks'].to_s)['mocks'] rescue nil)
        (err.("#{where}: spec illisible"); next) unless spec.is_a?(Hash)
        (err.("#{where}: mocks illisibles"); mocks = []) if mocks.nil?
        http = spec['http'] || {}
        method = (e['method'] || http['method']).to_s.downcase
        path = e['path'] || http['path']
        warn_.("#{where}: method/path du endpoint != spec.http") if http['method'] && (http['method'].to_s.downcase != method || http['path'] != path)
        (err.("#{where}: #{method.upcase} #{path} déjà défini par #{route_seen["#{method} #{path}"]}"); next) if route_seen["#{method} #{path}"]
        route_seen["#{method} #{path}"] = id
        req = http['request'] || {}
        resp = http['response'] || {}
        op = { 'tags' => [tag] }
        op['summary'] = e['name'] if e['name']
        desc = spec.dig('endpoint', 'description') || spec.dig('usecase', 'description')
        op['description'] = desc if desc
        op['operationId'] = id

        params = []
        (req['path'] || []).each { |fd| params << field_param(fd, 'path') }
        (req['query'] || []).each { |fd| params << field_param(fd, 'query') }
        (req['headers'] || []).each do |fd|
          next if %w[authorization content-type].include?(fd['name'].to_s.downcase)
          params << field_param(fd, 'header')
        end
        mixed = []
        params.each do |pr|
          src = pr['in'] == 'path' ? nil : (pr['in'] == 'query' ? 'query' : nil)
          vals = src ? mocks.map { |mk| mk.dig('given', src, pr['name']) } : []
          resolve_dates(pr['schema'], vals, pr['name'], mixed)
        end
        op['parameters'] = params unless params.empty?
        path_names = path.to_s.scan(/\{(\w+)\}/).flatten
        declared = (req['path'] || []).map { |fd| fd['name'] }
        (path_names - declared).each { |n| warn_.("#{where}: {#{n}} dans le chemin mais absent de request.path") }

        body_schema = req['body']
        if %w[post put patch].include?(method) && body_schema.is_a?(Hash)
          bs = schema(body_schema)
          resolve_dates(bs, mocks.map { |mk| mk.dig('given', 'body') }, 'body', mixed)
          exs = {}
          mocks.each do |mk|
            b = mk.dig('given', 'body')
            next if b.nil?
            next if mk['name'].to_s =~ /\Aerror-(invalid|validation)/   # requête invalide voulue : pas un exemple de requête valide
            next if JSON.generate(b) =~ /"<[^">]+>"/   # gabarit de volume ("<501 lignes>") : pas un exemple exploitable
            b = unbinary(Marshal.load(Marshal.dump(b)), bs)
            probs = []; check(b, bs, 'body', probs)
            (warn_.("#{where}: exemple de requête #{mk['name']} écarté (#{probs.first})"); next) unless probs.empty?
            key = mk['name'].to_s.gsub(/[^A-Za-z0-9._-]/, '_'); k2 = key; n = 2
            (k2 = "#{key}_#{n}"; n += 1) while exs.key?(k2)
            ex = { 'summary' => mk['name'] }
            ex['description'] = mk['description'] if mk['description']
            ex['value'] = b
            exs[k2] = ex
          end
          media = { 'schema' => bs }
          media['examples'] = exs unless exs.empty?
          multipart = (req['headers'] || []).any? { |fd| fd['name'].to_s.casecmp?('content-type') && fd['description'].to_s.include?('multipart/form-data') }
          op['requestBody'] = { 'required' => true, 'content' => { (multipart ? 'multipart/form-data' : 'application/json') => media } }
        end

        # réponses
        ok_status = (resp['status'] || 200).to_i
        responses = {}
        resp_schema = resp['body'] ? schema(resp['body']) : nil
        if resp_schema
          resolve_dates(resp_schema, mocks.select { |mk| mk.dig('expect', 'status').to_i == ok_status }.map { |mk| mk.dig('expect', 'body') }, '$', mixed)
          require_all(resp_schema)
          canon_envelope(resp_schema)
        end
        mixed.each { |pth| warn_.("#{where}: #{pth} mélange date et date-time dans les mocks (format omis)") }
        errs = (resp['errors'] || http['errors'] || spec['errors'] || [])
        errs_by = errs.group_by { |x| x['status'].to_i }
        statuses = ([ok_status] + errs_by.keys + mocks.map { |mk| mk.dig('expect', 'status').to_i }).reject(&:zero?).uniq
        statuses.each do |st|
          mks = mocks.select { |mk| mk.dig('expect', 'status').to_i == st }
          if st == ok_status
            r = { 'description' => e['name'] || 'Succès' }
            sch = resp_schema
          else
            es = errs_by[st] || []
            codes = es.map { |x| x['code'] }.compact.uniq
            r = { 'description' => (es.map { |x| [x['message'] || x['description'], x['cause'] && "Cause : #{x['cause']}", x['resolution'] && "Résolution : #{x['resolution']}"].compact.join(' — ') }.join(' | ')) }
            r['description'] = "Erreur #{st}" if r['description'].empty?
            sch = error_schema(codes)
            warn_.("#{where}: mock #{st} sans erreur déclarée dans spec.errors") if es.empty?
            mks.each do |mk|
              c = mk.dig('expect', 'body', 'error', 'code')
              warn_.("#{where}: mock #{mk['name']} code #{c.inspect} non déclaré pour #{st}") if c && !codes.empty? && !codes.include?(c)
            end
          end
          exs = {}
          mks.each do |mk|
            key = mk['name'].to_s.gsub(/[^A-Za-z0-9._-]/, '_'); k2 = key; n = 2
            (k2 = "#{key}_#{n}"; n += 1) while exs.key?(k2)
            ex = { 'summary' => mk['name'] }
            ex['description'] = mk['description'] if mk['description'] && mk['description'] != mk['name']
            ex['value'] = mk.dig('expect', 'body')
            exs[k2] = ex
            probs = []
            check(ex['value'], sch, '$', probs)
            probs.first(3).each { |p| warn_.("#{where}: mock #{mk['name']} (#{st}) #{p}") }
          end
          counts[:examples] += exs.size
          media = { 'schema' => sch }
          media['examples'] = exs unless exs.empty?
          r['content'] = { 'application/json' => media }
          responses[st.to_s] = r
        end
        op['responses'] = responses
        mocks_total = mocks.size
        ex_total = responses.values.sum { |r| (r.dig('content', 'application/json', 'examples') || {}).size }
        err.("#{where}: #{mocks_total} mocks mais #{ex_total} examples") if mocks_total != ex_total
        warn_.("#{where}: aucun mock") if mocks.empty?
        annotate_enums(op, id, ok_status)
        cons = constraints_for(app, mod, ft, method, id)
        op['x-constraints'] = cons unless cons.empty?
        op['security'] = http.dig('auth', 'type') == 'required' ? [{ 'BearerAuth' => [] }] : []   # [] explicite = endpoint public
        docs[id] = build_doc(op, method, path, http, errs, mocks, ok_status) if with_doc

        write(File.join(parts_dir, app, mod, ft, "#{id}.yml"), dump('tags' => tags, 'paths' => { path => { method => op } }))
        (feature_paths[path] ||= {})[method] = op
        app_ops[app] << [path, method, op]
        counts[:endpoints] += 1
      end
      write(File.join(parts_dir, app, mod, ft, "#{ft}.yml"), dump('tags' => tags, 'paths' => feature_paths))
    end
    pi_app['modules'] << pi_mod
  end
  parts_index << pi_app
end
write(File.join(parts_dir, '_index.yml'), dump('version' => 1, 'apps' => parts_index)) unless only_app

# ── étape 2 : parts -> OpenAPI par app ────────────────────────────────────────
unless parts_only
  parts_index.each do |a|
    app = a['slug']
    paths = {}
    tags = []
    a['modules'].each do |m|
      m['features'].each do |ft|
        agg = YAML.safe_load(File.read(File.join(parts_dir, app, m['slug'], ft, "#{ft}.yml")))
        tags.concat(agg['tags'] || [])
        (agg['paths'] || {}).each { |p, ops| (paths[p] ||= {}).merge!(ops) }
      end
    end
    ver = version.sub(/\Av/, '')
    ver = "#{ver}.0.0" if ver =~ /\A\d+\z/
    doc = {
      'openapi' => '3.0.3',
      'info' => { 'title' => "#{app} API", 'description' => app_rules_md(app, a['modules'].map { |m| m['slug'] }), 'version' => ver, 'license' => { 'name' => license_name }.merge(license_url ? { 'url' => license_url } : {}) }.reject { |_, v| v.nil? },
      'servers' => servers,
      'tags' => tags.uniq,
      'paths' => paths,
      'components' => { 'securitySchemes' => { 'BearerAuth' => { 'type' => 'http', 'scheme' => 'bearer', 'bearerFormat' => 'JWT' } } }
    }
    doc.delete('servers') if servers.empty?
    doc.delete('components') unless paths.values.any? { |ms| ms.values.any? { |o| (o['security'] || []).any? } }   # BearerAuth seulement si une opération l'utilise
    factorize(doc, warn_) unless no_refs
    if with_doc
      d2 =Marshal.load(Marshal.dump(doc))
      d2['paths'].each_value do |ms|
        ms.each_value do |o|
          md = docs[o['operationId']] or (err.("#{o['operationId']}: doc absente"); next)
          o['description'] = [o['description'], md].compact.join("\n\n")
        end
      end
      target = doc_in_place ? out_dir : File.join(out_dir, 'doc')
      write(File.join(target, "openapi.#{app}.yml"), dump(d2))
    end
    write(File.join(out_dir, "openapi.#{app}.yml"), dump(doc)) unless doc_in_place
    puts "OK openapi.#{app}.yml : #{paths.values.sum(&:size)} opérations#{with_doc ? ' (+ doc)' : ''}"
  end
end

puts "#{counts[:endpoints]} endpoints, #{counts[:examples]} examples"
(E + W).each { |l| puts l }
puts "#{E.size} E, #{W.size} W"
exit(E.empty? ? 0 : 1)
