export enum DocKind {
  View = "view",
  Function = "function",
  Object = "object",
  Class = "class",
  Constant = "constant",
  Module = "module",
}

export interface DocMeta {
  slug?: string;
  title: string;
  description?: string;
  notes?: string;
  tags?: string[];
  kind?: DocKind;
  parent?: string;
  children?: string[];
}

export interface GenealogyConfig {
  title?: string;
  projectName?: string;
  roots: string[];
  include?: string[];
  exclude?: string[];
  out?: string;
  agentsFile?: string;
  tagVocabulary?: string[];
}
