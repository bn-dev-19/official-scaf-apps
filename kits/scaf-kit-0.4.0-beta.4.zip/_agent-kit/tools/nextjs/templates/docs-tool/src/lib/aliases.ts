import * as fs from "node:fs";
import * as path from "node:path";

export function loadTsconfigAliases(projectRoot: string): Record<string, string> {
  const tsconfigPath = path.join(projectRoot, "tsconfig.json");
  if (!fs.existsSync(tsconfigPath)) return {};
  try {
    const raw = JSON.parse(fs.readFileSync(tsconfigPath, "utf8"));
    return (raw.compilerOptions?.paths ?? {}) as Record<string, string>;
  } catch {
    return {};
  }
}
