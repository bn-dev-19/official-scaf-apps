import * as fs from "node:fs";
import * as path from "node:path";
import * as ts from "typescript";
import { matchesAny, toPosix } from "./glob";
import { DocKind, type DocMeta, type GenealogyConfig } from "../types";

export interface RawNode {
  meta: DocMeta;
  kind: DocKind;
  file: string;
  line: number;
  anchor?: string;
  slug: string;
  slugExplicit: boolean;
  jsxParent?: string;
}

export interface ImportEdge {
  specifier: string;
  resolved?: string;
  typeOnly: boolean;
}

export interface FileResult {
  file: string;
  nodes: RawNode[];
  imports: ImportEdge[];
}

export function scanProject(projectRoot: string, config: GenealogyConfig): FileResult[] {
  const results: FileResult[] = [];
  for (const root of config.roots) {
    const absRoot = path.resolve(projectRoot, root);
    if (!fs.existsSync(absRoot)) continue;
    const files = collectFiles(absRoot);
    for (const abs of files) {
      const rel = toPosix(path.relative(projectRoot, abs));
      if (config.include && !matchesAny(rel, config.include)) continue;
      if (config.exclude && matchesAny(rel, config.exclude)) continue;
      const parsed = scanFile(abs, rel, projectRoot);
      if (parsed.nodes.length > 0 || parsed.imports.length > 0) results.push(parsed);
    }
  }
  return results;
}

function collectFiles(dir: string): string[] {
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      out.push(...collectFiles(abs));
    } else if (/\.(ts|tsx|mts|cts)$/.test(entry.name)) {
      out.push(abs);
    }
  }
  return out;
}

const META_KEYS = new Set(["slug", "title", "description", "notes", "tags", "kind", "parent", "children"]);

function scanFile(absPath: string, rel: string, projectRoot: string): FileResult {
  const source = fs.readFileSync(absPath, "utf8");
  const kind = /\.tsx?$/.test(rel) ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
  const sf = ts.createSourceFile(rel, source, ts.ScriptTarget.Latest, true, kind);

  const nodes: RawNode[] = [];
  const imports: ImportEdge[] = [];
  const jsxStack: string[] = [];
  const usedSlugs = new Map<string, number>();

  const lineOf = (node: ts.Node) => sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;

  function metaFromObject(node: ts.Expression | undefined): DocMeta {
    const out: DocMeta = { slug: "", title: "" };
    if (node && ts.isObjectLiteralExpression(node)) {
      for (const prop of node.properties) {
        if (!ts.isPropertyAssignment(prop)) continue;
        const key = prop.name.getText(sf).replace(/['"]/g, "");
        const value = evalLiteral(prop.initializer);
        if (value !== undefined && META_KEYS.has(key)) {
          setMeta(out, key, value);
        }
      }
    }
    return out;
  }

  function evalLiteral(expr: ts.Expression): unknown {
    if (ts.isStringLiteral(expr)) return expr.text;
    if (ts.isNoSubstitutionTemplateLiteral(expr)) return expr.text;
    if (ts.isNumericLiteral(expr)) return Number(expr.text);
    if (expr.kind === ts.SyntaxKind.TrueKeyword) return true;
    if (expr.kind === ts.SyntaxKind.FalseKeyword) return false;
    if (ts.isArrayLiteralExpression(expr)) {
      return expr.elements.map((e) => evalLiteral(e)).filter((v) => v !== undefined);
    }
    if (ts.isPropertyAccessExpression(expr)) {
      if (ts.isIdentifier(expr.expression) && expr.expression.text === "DocKind") {
        return (DocKind as unknown as Record<string, string>)[expr.name.text];
      }
      return undefined;
    }
    if (ts.isIdentifier(expr)) {
      const binding = findConstBinding(sf, expr.text);
      return binding ? evalLiteral(binding) : undefined;
    }
    return undefined;
  }

  function inferKind(value: ts.Expression): DocKind {
    if (ts.isAsExpression(value) || ts.isParenthesizedExpression(value)) {
      return inferKind(value.expression);
    }
    if (ts.isArrowFunction(value) || ts.isFunctionExpression(value)) return DocKind.Function;
    if (ts.isObjectLiteralExpression(value)) return DocKind.Object;
    if (ts.isClassExpression(value)) return DocKind.Class;
    return DocKind.Constant;
  }

  function visit(node: ts.Node): void {
    if (ts.isCallExpression(node)) {
      const callee = node.expression;
      if (ts.isIdentifier(callee) && callee.text === "indexDoc" && node.arguments.length >= 2) {
        const meta = metaFromObject(node.arguments[0]);
        const value = node.arguments[1];
        const kind = meta.kind ?? inferKind(value);
        const anchor = findAnchor(sf, node);
        const slug = resolveSlug(meta.slug, anchor, rel, usedSlugs);
        nodes.push({ meta, kind, file: rel, line: lineOf(node), anchor, slug, slugExplicit: slugExplicitOf(meta.slug) });
        return;
      }
    }

    if (ts.isJsxElement(node)) {
      const tag = node.openingElement.tagName;
      if (ts.isIdentifier(tag) && tag.text === "DocIndex") {
        const meta = attrsFromJsx(node.openingElement.attributes);
        const anchor = findAnchor(sf, node);
        const slug = resolveSlug(meta.slug, anchor, rel, usedSlugs);
        const parent = jsxStack.length > 0 ? jsxStack[jsxStack.length - 1] : undefined;
        jsxStack.push(slug);
        for (const child of node.children) visit(child);
        jsxStack.pop();
        nodes.push({
          meta,
          kind: meta.kind ?? DocKind.View,
          file: rel,
          line: lineOf(node),
          anchor,
          slug,
          slugExplicit: slugExplicitOf(meta.slug),
          jsxParent: parent,
        });
        return;
      }
    }

    ts.forEachChild(node, visit);
  }

  for (const stmt of sf.statements) {
    visit(stmt);
  }

  for (const stmt of sf.statements) {
    if (!ts.isImportDeclaration(stmt)) continue;
    const specifier = stmt.moduleSpecifier.getText(sf).replace(/['"]/g, "");
    const clause = stmt.importClause;
    const typeOnly =
      Boolean(clause?.isTypeOnly) ||
      (clause?.namedBindings !== undefined &&
        ts.isNamedImports(clause.namedBindings) &&
        clause.namedBindings.elements.length > 0 &&
        clause.namedBindings.elements.every((e) => e.isTypeOnly));
    imports.push({ specifier, typeOnly });
  }

  return { file: rel, nodes, imports };
}

function setMeta(target: DocMeta, key: string, value: unknown): void {
  switch (key) {
    case "slug": target.slug = value as string; break;
    case "title": target.title = value as string; break;
    case "description": target.description = value as string; break;
    case "notes": target.notes = value as string; break;
    case "tags": target.tags = value as string[]; break;
    case "kind": target.kind = value as DocKind; break;
    case "parent": target.parent = value as string; break;
    case "children": target.children = value as string[]; break;
  }
}

function attrsFromJsx(attributes: ts.JsxAttributes): DocMeta {
  const out: DocMeta = { slug: "", title: "" };
  for (const attr of attributes.properties) {
    if (!ts.isJsxAttribute(attr)) continue;
    if (!ts.isIdentifier(attr.name)) continue;
    const key = attr.name.text;
    let value: unknown;
    if (attr.initializer && ts.isStringLiteral(attr.initializer)) {
      value = attr.initializer.text;
    } else if (attr.initializer && ts.isJsxExpression(attr.initializer) && attr.initializer.expression) {
      const e = attr.initializer.expression;
      if (ts.isStringLiteral(e)) value = e.text;
      else if (ts.isNoSubstitutionTemplateLiteral(e)) value = e.text;
      else if (ts.isArrayLiteralExpression(e)) value = e.elements.map((el) => (ts.isStringLiteral(el) ? el.text : undefined)).filter((v) => v !== undefined);
      else if (ts.isPropertyAccessExpression(e) && ts.isIdentifier(e.expression) && e.expression.text === "DocKind") {
        value = (DocKind as unknown as Record<string, string>)[e.name.text];
      } else if (e.kind === ts.SyntaxKind.TrueKeyword) value = true;
    }
    if (value !== undefined && META_KEYS.has(key)) {
      setMeta(out, key, value);
    }
  }
  return out;
}

function resolveSlug(explicit: string | undefined, anchor: string | undefined, rel: string, used: Map<string, number>): string {
  const trimmed = explicit?.trim();
  if (trimmed) return trimmed;
  const base = kebabCase(anchor ?? path.basename(rel).replace(/\.(ts|tsx|mts|cts)$/, ""));
  const count = used.get(base) ?? 0;
  used.set(base, count + 1);
  return count === 0 ? base : `${base}-${count + 1}`;
}

function slugExplicitOf(slug: string | undefined): boolean {
  return Boolean(slug?.trim());
}

function kebabCase(name: string): string {
  return name
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1-$2")
    .replace(/[_\s]+/g, "-")
    .toLowerCase()
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function findAnchor(sf: ts.SourceFile, node: ts.Node): string | undefined {
  let cur = node.parent;
  while (cur) {
    if (ts.isVariableDeclaration(cur) && ts.isIdentifier(cur.name)) return cur.name.text;
    if (ts.isFunctionDeclaration(cur) && cur.name) return cur.name.text;
    if (ts.isClassDeclaration(cur) && cur.name) return cur.name.text;
    cur = cur.parent;
  }
  return undefined;
}

function findConstBinding(sf: ts.SourceFile, name: string): ts.Expression | undefined {
  for (const stmt of sf.statements) {
    if (!ts.isVariableStatement(stmt)) continue;
    for (const decl of stmt.declarationList.declarations) {
      if (ts.isIdentifier(decl.name) && decl.name.text === name && decl.initializer) {
        return decl.initializer;
      }
    }
  }
  return undefined;
}
