import * as fs from "node:fs";
import * as path from "node:path";
import { pathToFileURL } from "node:url";
import type { GenealogyConfig } from "../types";

export const DEFAULT_CONFIG: Required<Pick<GenealogyConfig, "include" | "exclude" | "out">> & { roots: string[] } = {
  roots: ["src"],
  include: ["**/*.{ts,tsx}"],
  exclude: ["**/node_modules/**", "**/.next/**", "**/docs-tool/**"],
  out: "docs/genealogy",
};

export async function loadConfig(projectRoot: string): Promise<GenealogyConfig> {
  const configPath = path.join(projectRoot, "genealogy.config.ts");
  const mod = await import(pathToFileURL(configPath).href);
  const raw = (mod.default ?? mod.config ?? {}) as Partial<GenealogyConfig>;
  return {
    ...DEFAULT_CONFIG,
    ...raw,
    include: raw.include ?? DEFAULT_CONFIG.include,
    exclude: [...(raw.exclude ?? []), ...DEFAULT_CONFIG.exclude],
  };
}

export function resolveProjectName(projectRoot: string, config: GenealogyConfig): string {
  if (config.projectName?.trim()) return config.projectName.trim();
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(projectRoot, "package.json"), "utf8")) as { name?: unknown };
    if (typeof pkg.name === "string" && pkg.name.trim()) return pkg.name.trim();
  } catch {
    // package.json absent ou invalide → fallback
  }
  return path.basename(projectRoot) || "projet";
}

export function resolveAgentsFile(projectRoot: string, config: GenealogyConfig): string {
  const outDir = config.out ?? DEFAULT_CONFIG.out;
  return path.resolve(projectRoot, config.agentsFile ?? path.join(path.dirname(outDir), "AGENTS.md"));
}
