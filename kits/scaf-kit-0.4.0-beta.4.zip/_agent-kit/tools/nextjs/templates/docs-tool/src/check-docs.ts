import { loadConfig } from "./lib/config";
import { loadTsconfigAliases } from "./lib/aliases";
import { scanProject } from "./lib/scanner";
import { buildGraph } from "./lib/graph";
import { DocKind } from "./types";

async function main(): Promise<void> {
  const projectRoot = process.cwd();
  const config = await loadConfig(projectRoot);
  const aliases = loadTsconfigAliases(projectRoot);

  const files = scanProject(projectRoot, config);
  const result = buildGraph(projectRoot, files, aliases);

  let hasError = false;

  for (const err of result.errors) {
    console.error(`✗ ${err}`);
    hasError = true;
  }

  for (const node of result.nodes) {
    if (!node.title) {
      console.error(`✗ ${node.slug}: titre manquant`);
      hasError = true;
    }
    if (node.parent && node.children.length === 0) {
      // ok: parent leaf allowed
    }
    if (node.kind && !Object.values(DocKind).includes(node.kind as DocKind)) {
      console.error(`✗ ${node.slug}: kind inconnu "${node.kind}"`);
      hasError = true;
    }
    if (config.tagVocabulary && node.tags) {
      for (const tag of node.tags) {
        if (!config.tagVocabulary.includes(tag)) {
          console.error(`✗ ${node.slug}: tag inconnu "${tag}" (vocabulaire configuré)`);
          hasError = true;
        }
      }
    }
  }

  const orphanChildren = new Set<string>();
  for (const node of result.nodes) {
    for (const child of node.children) {
      if (!result.nodes.some((n) => n.slug === child)) orphanChildren.add(child);
    }
  }
  for (const child of orphanChildren) {
    console.error(`✗ child inconnu déclaré : ${child}`);
    hasError = true;
  }

  console.log(`✓ ${result.nodes.length} nœuds, ${result.imports.length} imports, ${result.errors.length} erreurs de graphe`);
  if (hasError) process.exit(1);
  console.log("✓ Généalogie valide");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
