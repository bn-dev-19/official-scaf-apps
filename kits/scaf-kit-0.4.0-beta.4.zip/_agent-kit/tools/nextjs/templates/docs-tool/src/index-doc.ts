import type { DocMeta } from "./types";

export type { DocMeta };
export { DocKind } from "./types";

export function indexDoc<T>(meta: DocMeta, value: T): T {
  return value;
}
