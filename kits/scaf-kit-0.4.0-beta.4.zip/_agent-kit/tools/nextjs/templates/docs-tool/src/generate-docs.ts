import * as fs from "node:fs";
import * as path from "node:path";
import { loadConfig, resolveAgentsFile, resolveProjectName } from "./lib/config";
import { loadTsconfigAliases } from "./lib/aliases";
import { scanProject } from "./lib/scanner";
import { buildGraph } from "./lib/graph";
import { renderAgents, renderIndex, renderImports, renderJson, renderNesting, renderNodes } from "./lib/render";

async function main(): Promise<void> {
  const projectRoot = process.cwd();
  const config = await loadConfig(projectRoot);
  const aliases = loadTsconfigAliases(projectRoot);

  const files = scanProject(projectRoot, config);
  const result = buildGraph(projectRoot, files, aliases);

  for (const err of result.errors) {
    console.error(`✗ ${err}`);
  }

  const projectName = resolveProjectName(projectRoot, config);
  const title = config.title ?? `Généalogie — ${projectName}`;
  const outDir = path.resolve(projectRoot, config.out!);
  fs.mkdirSync(outDir, { recursive: true });

  fs.writeFileSync(path.join(outDir, "README.md"), renderIndex(title, result));
  fs.writeFileSync(path.join(outDir, "nesting.md"), renderNesting(title, result));
  fs.writeFileSync(path.join(outDir, "imports.md"), renderImports(title, result));
  fs.writeFileSync(path.join(outDir, "nodes.md"), renderNodes(title, result));
  fs.writeFileSync(path.join(outDir, "genealogy.json"), renderJson(title, result));

  const legacy = path.join(outDir, "genealogy.md");
  if (fs.existsSync(legacy)) fs.unlinkSync(legacy);

  const agentsPath = resolveAgentsFile(projectRoot, config);
  const relOut = path.relative(path.dirname(agentsPath), outDir) || ".";
  fs.mkdirSync(path.dirname(agentsPath), { recursive: true });
  fs.writeFileSync(agentsPath, renderAgents(projectName, relOut, result));

  console.log(`✓ ${result.nodes.length} nœuds indexés, ${result.imports.length} imports, ${result.errors.length} erreurs`);
  console.log(`✓ Écrit : README.md, nesting.md, imports.md, nodes.md, genealogy.json dans ${config.out!}`);
  console.log(`✓ Écrit : ${path.relative(projectRoot, agentsPath)}`);

  if (result.errors.length > 0) process.exit(1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
