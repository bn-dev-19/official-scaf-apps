import * as fs from "node:fs";
import * as path from "node:path";
import { toPosix } from "./glob";
import type { ImportEdge, RawNode } from "./scanner";
import type { DocKind } from "../types";

const EXTENSIONS = [".ts", ".tsx", ".mts", ".cts"];

export function resolveSpecifier(specifier: string, fromFile: string, projectRoot: string, aliases: Record<string, string>): string | undefined {
  let base: string;
  if (specifier.startsWith("./") || specifier.startsWith("../")) {
    base = path.resolve(path.dirname(fromFile), specifier);
  } else {
    const alias = Object.keys(aliases).find((a) => specifier.startsWith(a));
    if (alias) {
      const prefix = alias.replace(/\*$/, "");
      base = path.resolve(projectRoot, aliases[alias].replace(/\*$/, ""), specifier.slice(prefix.length));
    } else {
      return undefined;
    }
  }
  return resolveFile(base);
}

function resolveFile(base: string): string | undefined {
  if (fs.existsSync(base) && fs.statSync(base).isFile()) return base;
  for (const ext of EXTENSIONS) {
    const withExt = base + ext;
    if (fs.existsSync(withExt) && fs.statSync(withExt).isFile()) return withExt;
  }
  const indexCandidates = EXTENSIONS.map((ext) => path.join(base, "index" + ext));
  for (const idx of indexCandidates) {
    if (fs.existsSync(idx) && fs.statSync(idx).isFile()) return idx;
  }
  return undefined;
}

export interface NodeMeta {
  slug: string;
  title: string;
  description?: string;
  notes?: string;
  tags?: string[];
  kind: DocKind;
  path: string;
  line: number;
  anchor?: string;
  parent?: string;
  children: string[];
}

export interface TreeEntry {
  id: string;
  type: "folder" | "node";
  label: string;
  location?: string;
  children: TreeEntry[];
}

export interface BuildResult {
  nodes: NodeMeta[];
  tree: TreeEntry[];
  imports: { from: string; to: string; specifier: string; typeOnly: boolean }[];
  errors: string[];
}

export function buildGraph(
  projectRoot: string,
  files: { file: string; nodes: RawNode[]; imports: ImportEdge[] }[],
  aliases: Record<string, string>,
): BuildResult {
  const errors: string[] = [];
  const fileNodes = new Map<string, RawNode[]>();
  for (const f of files) fileNodes.set(f.file, f.nodes);

  const bySlug = new Map<string, NodeMeta>();
  const rawSlug = new Map<RawNode, string>();
  const renamedByFile = new Map<string, Map<string, string>>();

  for (const f of files) {
    for (const n of f.nodes) {
      let slug = n.slug;
      if (bySlug.has(slug)) {
        if (n.slugExplicit) {
          errors.push(`duplicate slug "${slug}" (${f.file} and ${bySlug.get(slug)!.path})`);
        } else {
          let i = 2;
          while (bySlug.has(`${slug}-${i}`)) i++;
          const next = `${slug}-${i}`;
          let renamed = renamedByFile.get(f.file);
          if (!renamed) {
            renamed = new Map();
            renamedByFile.set(f.file, renamed);
          }
          renamed.set(slug, next);
          slug = next;
        }
      }
      bySlug.set(slug, {
        slug,
        title: n.meta.title,
        description: n.meta.description,
        notes: n.meta.notes,
        tags: n.meta.tags,
        kind: n.kind,
        path: n.file,
        line: n.line,
        anchor: n.anchor,
        children: [],
      });
      rawSlug.set(n, slug);
    }
  }

  for (const f of files) {
    const renamed = renamedByFile.get(f.file);
    if (!renamed) continue;
    const apply = (s: string): string => renamed.get(s) ?? s;
    for (const n of f.nodes) {
      if (n.jsxParent) n.jsxParent = apply(n.jsxParent);
      if (n.meta.parent) n.meta.parent = apply(n.meta.parent);
      if (n.meta.children) n.meta.children = n.meta.children.map(apply);
    }
  }

  for (const f of files) {
    for (const n of f.nodes) {
      const meta = bySlug.get(rawSlug.get(n)!)!;
      const parentRef = n.meta.parent ?? n.jsxParent;
      if (parentRef) meta.parent = parentRef;
      if (n.meta.children) {
        for (const child of n.meta.children) {
          const c = bySlug.get(child);
          if (c && !c.parent) c.parent = meta.slug;
        }
        meta.children.push(...n.meta.children);
      }
    }
  }

  for (const meta of bySlug.values()) {
    if (meta.parent) {
      const p = bySlug.get(meta.parent);
      if (p && !p.children.includes(meta.slug)) p.children.push(meta.slug);
    }
  }

  for (const meta of bySlug.values()) {
    if (meta.children.length > 0) {
      const seen = new Set<string>();
      meta.children = meta.children.filter((c) => (seen.has(c) ? (errors.push(`node "${meta.slug}" has duplicate child "${c}"`), false) : (seen.add(c), true)));
    }
    if (meta.parent && !bySlug.has(meta.parent)) {
      errors.push(`node "${meta.slug}" references unknown parent "${meta.parent}"`);
    }
    for (const child of meta.children) {
      if (!bySlug.has(child)) errors.push(`node "${meta.slug}" references unknown child "${child}"`);
    }
  }

  const cycle = findCycle(bySlug);
  if (cycle) errors.push(`nesting cycle detected: ${cycle.join(" → ")}`);

  const nodes = [...bySlug.values()].sort((a, b) => a.slug.localeCompare(b.slug));
  const tree = buildAutoTree(nodes, bySlug);
  const imports = buildImportEdges(projectRoot, files, aliases, rawSlug, fileNodes);

  return { nodes, tree, imports, errors };
}

function buildAutoTree(nodes: NodeMeta[], bySlug: Map<string, NodeMeta>): TreeEntry[] {
  interface Folder {
    path: string;
    folders: Folder[];
    nodes: NodeMeta[];
  }

  const parented = (n: NodeMeta): boolean => Boolean(n.parent && bySlug.has(n.parent));
  const folderMap = new Map<string, Folder>();
  for (const n of nodes) {
    if (parented(n)) continue;
    let dir = path.posix.dirname(n.path);
    while (dir && dir !== ".") {
      if (!folderMap.has(dir)) folderMap.set(dir, { path: dir, folders: [], nodes: [] });
      dir = path.posix.dirname(dir);
    }
  }
  for (const n of nodes) {
    if (parented(n)) continue;
    const folder = folderMap.get(path.posix.dirname(n.path));
    if (folder) folder.nodes.push(n);
  }
  for (const folder of folderMap.values()) {
    const parent = folderMap.get(path.posix.dirname(folder.path));
    if (parent) parent.folders.push(folder);
  }

  const rootFolders = [...folderMap.values()]
    .filter((f) => !folderMap.has(path.posix.dirname(f.path)))
    .sort((a, b) => a.path.localeCompare(b.path));
  const rootNodes = nodes
    .filter((n) => !parented(n) && path.posix.dirname(n.path) === ".")
    .sort((a, b) => a.slug.localeCompare(b.slug));

  const visited = new Set<string>();
  const nodeEntry = (n: NodeMeta): TreeEntry => {
    const children: TreeEntry[] = [];
    if (!visited.has(n.slug)) {
      visited.add(n.slug);
      for (const c of [...n.children].sort()) {
        const child = bySlug.get(c);
        if (child) children.push(nodeEntry(child));
      }
    }
    return { id: n.slug, type: "node", label: n.slug, location: `${n.path}:${n.line}`, children };
  };
  const folderEntry = (f: Folder): TreeEntry => ({
    id: `folder:${f.path}`,
    type: "folder",
    label: path.posix.basename(f.path),
    children: [
      ...f.folders.sort((a, b) => a.path.localeCompare(b.path)).map(folderEntry),
      ...f.nodes.sort((a, b) => a.slug.localeCompare(b.slug)).map(nodeEntry),
    ],
  });

  return [...rootFolders.map(folderEntry), ...rootNodes.map(nodeEntry)];
}

function buildImportEdges(
  projectRoot: string,
  files: { file: string; nodes: RawNode[]; imports: ImportEdge[] }[],
  aliases: Record<string, string>,
  rawSlug: Map<RawNode, string>,
  fileNodes: Map<string, RawNode[]>,
): BuildResult["imports"] {
  const edges: BuildResult["imports"] = [];
  for (const f of files) {
    if (f.nodes.length === 0) continue;
    for (const imp of f.imports) {
      const resolved = resolveSpecifier(imp.specifier, path.join(projectRoot, f.file), projectRoot, aliases);
      if (!resolved) continue;
      const rel = toPosix(path.relative(projectRoot, resolved));
      const targets = fileNodes.get(rel);
      if (!targets) continue;
      for (const target of targets) {
        edges.push({ from: rawSlug.get(f.nodes[0])!, to: rawSlug.get(target)!, specifier: imp.specifier, typeOnly: imp.typeOnly });
      }
    }
  }
  return edges;
}

function findCycle(bySlug: Map<string, NodeMeta>): string[] | undefined {
  const state = new Map<string, "visiting" | "done">();
  const stack: string[] = [];
  const visit = (slug: string): string[] | undefined => {
    if (state.get(slug) === "done") return undefined;
    if (state.get(slug) === "visiting") return [...stack.slice(stack.indexOf(slug)), slug];
    state.set(slug, "visiting");
    stack.push(slug);
    const meta = bySlug.get(slug)!;
    for (const child of meta.children) {
      const c = bySlug.get(child);
      if (!c) continue;
      const cycle = visit(child);
      if (cycle) return cycle;
    }
    stack.pop();
    state.set(slug, "done");
    return undefined;
  };
  for (const slug of bySlug.keys()) {
    const cycle = visit(slug);
    if (cycle) return cycle;
  }
  return undefined;
}
