import type { ReactNode } from "react";
import type { DocMeta } from "./types";

export type { DocMeta };
export { DocKind } from "./types";

export type DocIndexProps = Omit<DocMeta, "children"> & { children?: ReactNode };

export function DocIndex({ children, ..._meta }: DocIndexProps) {
  return <>{children}</>;
}
