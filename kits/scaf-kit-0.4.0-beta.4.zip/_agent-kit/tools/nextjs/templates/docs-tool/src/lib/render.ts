import * as path from "node:path";
import type { BuildResult, NodeMeta, TreeEntry } from "./graph";

export const HEADER = `<!-- AUTO-GENERATED — do not edit manually. Regenerate with: pnpm generate:docs -->

`;

export interface RenderedDocs {
  index: string;
  nesting: string;
  imports: string;
  nodes: string;
}

function statsLines(result: BuildResult): string[] {
  return [
    "- **Nœuds indexés :** " + result.nodes.length,
    "- **Arêtes d'imports :** " + result.imports.length,
  ];
}

function vocabLines(): string[] {
  return [
    "| Terme | Sens |",
    "| --- | --- |",
    "| `slug` | Id libre d'un nœud (auto = kebab-case de l'export si omis) |",
    "| `path` | Chemin relatif du fichier + ligne (`src/.../file.ts:14`) |",
    "| `kind` | Nature : `view` / `function` / `object` / `class` / `constant` / `module` |",
    "| Nesting | Hiérarchie parent/enfants : explicite (`parent`/`children`), imbrication JSX, ou auto (dossier du fichier) |",
    "",
  ];
}

export function renderIndex(title: string, result: BuildResult): string {
  const lines: string[] = [];
  lines.push(HEADER);
  lines.push(`# ${title}`);
  lines.push("");
  lines.push("> Indexation documentaire du projet, générée par `docs-tool`. Ne pas éditer à la main.");
  lines.push("");
  lines.push("## Sommaire");
  lines.push("");
  lines.push("- [`nesting.md`](./nesting.md) — arbre de nesting : où vit chaque nœud et sa hiérarchie");
  lines.push("- [`imports.md`](./imports.md) — graphe d'imports : dépendances entre nœuds et importeurs inverses");
  lines.push("- [`nodes.md`](./nodes.md) — détail de chaque nœud : slug, kind, chemin:ligne, parent/enfants, tags");
  lines.push("- [`genealogy.json`](./genealogy.json) — données machine (source de vérité)");
  lines.push("");
  lines.push("## Statistiques");
  lines.push("");
  lines.push(...statsLines(result));
  lines.push("");
  lines.push("## Vocabulaire");
  lines.push("");
  lines.push(...vocabLines());
  lines.push("## Régénération");
  lines.push("");
  lines.push("```bash");
  lines.push("pnpm generate:docs   # régénère toute la sortie");
  lines.push("pnpm check:docs      # valide l'indexation (slugs, refs, cycles, kind, tags)");
  lines.push("```");
  lines.push("");
  return lines.join("\n");
}

export function renderNesting(title: string, result: BuildResult): string {
  const lines: string[] = [];
  lines.push(HEADER);
  lines.push("# Arbre de nesting");
  lines.push("");
  lines.push("> Hiérarchie des nœuds documentés — auto depuis l'arborescence des fichiers, surchargée par `parent`/`children` (explicite) et l'imbrication JSX.");
  lines.push("");
  lines.push("## Statistiques");
  lines.push("");
  lines.push(...statsLines(result));
  lines.push("");
  lines.push("## Arbre");
  lines.push("");
  lines.push("```");
  if (result.tree.length === 0) lines.push("(aucune racine)");
  for (const entry of result.tree) {
    lines.push(treeLabel(entry));
    renderTreeLines(entry, lines, "  ");
  }
  lines.push("```");
  lines.push("");
  lines.push("### Légende");
  lines.push("");
  lines.push("- **Dossiers** (sans `·`) : arborescence physique des fichiers.");
  lines.push("- **`slug · chemin:ligne`** : nœud documenté et sa localisation exacte.");
  lines.push("- **Indentation** : nesting explicite (`parent`/`children`) ou imbrication JSX.");
  lines.push("");
  return lines.join("\n");
}

export function renderImports(title: string, result: BuildResult): string {
  const lines: string[] = [];
  lines.push(HEADER);
  lines.push("# Graphe d'imports");
  lines.push("");
  lines.push("> Dépendances entre nœuds documentés : imports résolus vers des fichiers indexés.");
  lines.push("");
  lines.push("## Statistiques");
  lines.push("");
  lines.push(`- **Arêtes résolues :** ${result.imports.length}`);
  lines.push("");
  lines.push("## Arêtes (De → Vers)");
  lines.push("");
  if (result.imports.length === 0) {
    lines.push("_(aucune arête résolue entre nœuds indexés)_");
  } else {
    lines.push("| De | Vers | Spécificateur | Type |");
    lines.push("| --- | --- | --- | --- |");
    for (const imp of result.imports) {
      lines.push(`| \`${imp.from}\` | \`${imp.to}\` | \`${imp.specifier}\` | ${imp.typeOnly ? "type" : "value"} |`);
    }
  }
  lines.push("");
  lines.push("## Importeurs inverses");
  lines.push("");
  const importers = new Map<string, { from: string; specifier: string; typeOnly: boolean }[]>();
  for (const imp of result.imports) {
    const arr = importers.get(imp.to) ?? [];
    arr.push(imp);
    importers.set(imp.to, arr);
  }
  let withImporters = 0;
  for (const node of result.nodes) {
    const arr = (importers.get(node.slug) ?? []).sort((a, b) => a.from.localeCompare(b.from));
    if (arr.length === 0) continue;
    withImporters++;
    lines.push(`### \`${node.slug}\``);
    lines.push("");
    for (const imp of arr) {
      lines.push(`- importé par \`${imp.from}\` via \`${imp.specifier}\` (${imp.typeOnly ? "type" : "value"})`);
    }
    lines.push("");
  }
  if (withImporters === 0) lines.push("_(aucun nœud importé par un autre nœud indexé)_");
  lines.push("");
  return lines.join("\n");
}

export function renderNodes(title: string, result: BuildResult): string {
  const lines: string[] = [];
  lines.push(HEADER);
  lines.push("# Nœuds");
  lines.push("");
  lines.push("> Détail de chaque nœud documenté. Source machine : `genealogy.json`.");
  lines.push("");
  lines.push("## Index");
  lines.push("");
  lines.push("| Slug | Titre | Chemin |");
  lines.push("| --- | --- | --- |");
  for (const node of result.nodes) {
    lines.push(`| \`${node.slug}\` | ${mdCell(node.title)} | \`${node.path}:${node.line}\` |`);
  }
  lines.push("");
  for (const node of result.nodes) {
    lines.push("---");
    lines.push("");
    lines.push(`## \`${node.slug}\``);
    lines.push("");
    lines.push("| Champ | Valeur |");
    lines.push("| --- | --- |");
    lines.push(`| Titre | ${mdCell(node.title)} |`);
    lines.push(`| Kind | \`${node.kind}\` |`);
    lines.push(`| Chemin | \`${node.path}:${node.line}\` |`);
    if (node.anchor) lines.push(`| Export | \`${node.anchor}\` |`);
    lines.push(`| Slug | \`${node.slug}\` |`);
    lines.push(`| Parent | ${parentLabel(node)} |`);
    lines.push(`| Enfants | ${childrenLabel(node)} |`);
    if (node.tags && node.tags.length > 0) {
      lines.push(`| Tags | ${node.tags.map((t) => `\`${t}\``).join(", ")} |`);
    }
    lines.push("");
    if (node.description) {
      lines.push(node.description);
      lines.push("");
    }
    if (node.notes) {
      lines.push("### Explication technique");
      lines.push("");
      lines.push(node.notes);
      lines.push("");
    }
  }
  return lines.join("\n");
}

function mdCell(value: string): string {
  return value.replace(/\|/g, "\\|");
}

function parentLabel(node: NodeMeta): string {
  if (node.parent) return `\`${node.parent}\``;
  return `dossier \`${path.posix.dirname(node.path)}\` _(auto)_`;
}

function childrenLabel(node: NodeMeta): string {
  if (node.children.length === 0) return "_(aucun)_";
  return node.children.map((c) => `\`${c}\``).join(", ");
}

function treeLabel(entry: TreeEntry): string {
  if (entry.type === "folder") return entry.label;
  return entry.location ? `${entry.label} · ${entry.location}` : entry.label;
}

function renderTreeLines(entry: TreeEntry, lines: string[], indent: string): void {
  for (let i = 0; i < entry.children.length; i++) {
    const child = entry.children[i];
    const last = i === entry.children.length - 1;
    lines.push(`${indent}${last ? "└─" : "├─"} ${treeLabel(child)}`);
    renderTreeLines(child, lines, indent + (last ? "  " : "│ "));
  }
}

export function renderJson(title: string, result: BuildResult): string {
  return JSON.stringify(
    {
      generatedAt: new Date().toISOString(),
      title,
      nodes: result.nodes,
      tree: result.tree,
      imports: result.imports,
    },
    null,
    2,
  );
}

export function renderAgents(projectName: string, relOut: string, result: BuildResult): string {
  const lines: string[] = [];
  lines.push(HEADER);
  lines.push("# AGENTS.md — Documentation technique (docs/)");
  lines.push("");
  lines.push(
    `Ce dossier contient la documentation **générée** du projet \`${projectName}\`. Le fichier le plus utile est la **généalogie du code** dans \`${relOut}/\` : l'index documentaire in-place de l'application.`,
  );
  lines.push("");
  lines.push("## Rôle");
  lines.push("");
  lines.push(`Quand tu débogues ou explores ce projet, commence par \`${relOut}/\` pour te repérer rapidement :`);
  lines.push("");
  lines.push("- **« Où est défini X ? »** → `nodes.md` (détail de chaque nœud) ou `nesting.md` (arbre). Chaque nœud expose son `chemin:ligne` exact.");
  lines.push("- **« Qui importe quoi ? »** → `imports.md` (arêtes De → Vers + importeurs inverses par nœud).");
  lines.push("- **« Quelle est la hiérarchie parent/enfant ? »** → `nesting.md` (arbre) + `nodes.md` (champs Parent / Enfants).");
  lines.push("");
  lines.push(`Le fichier de départ est \`${relOut}/README.md\` : sommaire, vocabulaire, statistiques.`);
  lines.push("");
  lines.push("## Vocabulaire");
  lines.push("");
  lines.push(...vocabLines());
  lines.push("## Règles");
  lines.push("");
  lines.push(`- **Ne jamais éditer les fichiers générés** dans \`${relOut}/\` (en-tête \`AUTO-GENERATED\`). Régénérer via \`pnpm generate:docs\`.`);
  lines.push("- L'indexation est **opt-in et in-place** : un fichier non annoté (`DocIndex` / `indexDoc`) n'apparaît pas. Une absence de nœud ne signifie pas une absence de code.");
  lines.push("- La doc générée reflète uniquement **ce que l'équipe de dev a choisi de documenter** : ce n'est ni un miroir exhaustif, ni une limite. Tout le code reste exploitable — la doc est une **référence de départ**, pas le reflet complet du codebase.");
  lines.push("- Les annotations vivent dans `src/` (ex: `src/components/_nodes/input-node.tsx`). Si tu modifies une annotation, régénère la doc.");
  lines.push("- Le `chemin:ligne` dans les fichiers Markdown pointe vers le code réel — utilise-le pour localiser le symbole annoté.");
  lines.push("");
  lines.push("## Outils");
  lines.push("");
  lines.push(`- \`pnpm generate:docs\` — régénère toute la sortie (\`${relOut}/\`).`);
  lines.push("- `pnpm check:docs` — valide l'indexation (slugs uniques, refs parent/enfant existantes, pas de cycle, kind valide, vocabulaire de tags).");
  lines.push("- Le code de l'outil vit dans `docs-tool/` (scanner TS, graphe, rendu) — autonome et portable vers d'autres projets.");
  lines.push("");
  return lines.join("\n");
}
