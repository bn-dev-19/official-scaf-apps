function escapeRegExpChar(ch: string): string {
  return /[a-zA-Z0-9_\-/]/.test(ch) ? ch : ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function globToRegex(glob: string): RegExp {
  const norm = glob.replace(/\\/g, "/");
  let re = "";
  let i = 0;
  while (i < norm.length) {
    const ch = norm[i];
    if (ch === "*") {
      if (norm[i + 1] === "*") {
        if (norm[i + 2] === "/") {
          re += "(?:.*/)?";
          i += 3;
          continue;
        }
        re += ".*";
        i += 2;
        continue;
      }
      re += "[^/]*";
      i += 1;
      continue;
    }
    if (ch === "?") {
      re += "[^/]";
      i += 1;
      continue;
    }
    if (ch === "{") {
      const end = norm.indexOf("}", i);
      if (end > i) {
        const parts = norm
          .slice(i + 1, end)
          .split(",")
          .map((p) => p.replace(/\*/g, "[^/]*"));
        re += "(" + parts.join("|") + ")";
        i = end + 1;
        continue;
      }
    }
    re += escapeRegExpChar(ch);
    i += 1;
  }
  return new RegExp(`^${re}$`);
}

export function matchesAny(value: string, globs: string[]): boolean {
  return globs.some((g) => globToRegex(g).test(value));
}

export function toPosix(p: string): string {
  return p.replace(/\\/g, "/");
}
