# AGENTS.md — docs-tool

## Rôle

`docs-tool/` est un outil **autonome et portable** de généalogie de code : indexation documentaire **opt-in in-place** (annoter n'importe quelle vue/fonction/objet/classe où il se trouve) puis génération d'un arbre de nesting + d'un graphe d'imports en Markdown + JSON.

Il vit à côté du code de l'outil, pas dans la doc générée. Il produit, dans le projet hôte :

- `docs/genealogy/` — README, nesting, imports, nodes, genealogy.json (AUTO-GENERATED)
- `docs/AGENTS.md` — guide de la doc pour les agents (généré via `renderAgents`, configurable par `agentsFile`)

**Règle absolue : aucun nom de projet hôte en dur ici.** Tout nom provient de `resolveProjectName` (config `projectName` → `package.json` du hôte → nom du dossier racine).

## Architecture

- `src/generate-docs.ts` — point d'entrée `generate:docs` : scan → graphe → rendus + `AGENTS.md`
- `src/check-docs.ts` — point d'entrée `check:docs` : valide l'indexation (slugs, refs, cycles, kind, tags)
- `src/types.ts` — `GenealogyConfig`, `DocMeta`, `DocKind`
- `src/doc-index.tsx` / `src/index-doc.ts` — helpers d'annotation no-op, importés par l'hôte via `@docs/*` (zéro impact runtime/visuel)
- `src/lib/config.ts` — défauts, `loadConfig`, `resolveProjectName`, `resolveAgentsFile`
- `src/lib/scanner.ts` — AST TypeScript : extrait `DocMeta` depuis `indexDoc()` et `<DocIndex>`, infère les kinds, collecte les imports
- `src/lib/graph.ts` — dédup des slugs (auto-slugs suffixés `-2`, `-3`), nesting (explicite → JSX → dossier auto), arbre, arêtes d'imports, détection de cycles
- `src/lib/render.ts` — rendus Markdown/JSON (dont `renderAgents`), helper vocabulaire partagé
- `src/lib/glob.ts` — conversion glob → regex
- `src/lib/aliases.ts` — lecture des alias `paths` du tsconfig hôte

## Contrat d'annotation (`DocMeta`)

| Champ | Type | Rôle |
| --- | --- | --- |
| `slug` | `string?` | Id libre ; dérivé de l'export en kebab-case si omis (collision → suffixe déterministe) |
| `title` | `string` | Titre court (requis — `check:docs`) |
| `description` | `string?` | Description courte |
| `notes` | `string?` | **Explication technique approfondie** (markdown multi-paragraphes) → section « Explication technique » dans `nodes.md` |
| `tags` | `string[]` | Tags libres (validés si `tagVocabulary` configuré) |
| `kind` | `DocKind?` | Inféré si absent (JSX → view, arrow → function, objet → object, classe → class) |
| `parent` / `children` | `string?` / `string[]` | Nesting explicite par slugs |

`notes` multi-lignes en JSX : toujours en **template literal** (`notes={`...`}`) — le scanner ne lit pas les expressions arbitraires.

## Valeurs supportées par le scanner

- `indexDoc(meta, value)` (fonction) et `<DocIndex>` (JSX)
- Littéraux : string, template literal (sans substitution), nombre, booléen, array de strings
- `kind={DocKind.View}` / `kind: DocKind.View` — enum résolu
- Clés inconnues de `DocMeta` : ignorées silencieusement

## Règles

- **Jamais** de nom de projet hôte en dur → `resolveProjectName` (config → `package.json` → basename)
- Pas de registre central : opt-in in-place. **Une absence de nœud ne signifie pas une absence de code.**
- Tout fichier généré porte l'en-tête `AUTO-GENERATED` — on régénère, on n'édite pas
- README, AGENTS.md et sorties générées restent synchronisés (le README documente les champs de `DocMeta`)
- Ne pas casser la portabilité : le seul lien avec l'hôte est `genealogy.config.ts` + les scripts `package.json` + l'alias `@docs/*`

## Vérification

Depuis la racine du projet hôte :

```bash
npx tsc --noEmit -p tsconfig.json   # typage (les scripts sont lancés via tsx)
pnpm generate:docs                  # régénère docs/genealogy/ + docs/AGENTS.md
pnpm check:docs                     # valide : slugs uniques, title requis, kind valide,
                                    # refs parent/enfant existantes, pas de cycle, vocabulaire de tags
```

## Portabilité

Copier `docs-tool/` dans un autre projet hôte :

1. tsconfig : `"@docs/*": ["./docs-tool/src/*"]` dans `compilerOptions.paths`
2. Créer `genealogy.config.ts` (`roots`, `include`, `exclude`, `out`, optionnellement `projectName` / `agentsFile` / `title` / `tagVocabulary`)
3. Ajouter `generate:docs` et `check:docs` dans le `package.json` hôte (voir README)
4. Dépendances requises dans l'hôte : `typescript`, `tsx`
