# docs-tool — Généalogie de code

Indexation documentaire **in-place** : annoter n'importe quelle vue/fonction/objet/classe où qu'il se trouve, puis générer un arbre de nesting + un graphe d'imports en Markdown + JSON.

## Principe

Deux formes d'annotation (aucun registre central, opt-in) :

1. **Vues (JSX)** — wrapper transparent :

```tsx
import { DocIndex, DocKind } from "@docs/doc-index";

export function InputNode(props) {
  return (
    <DocIndex
      title="Input Node"
      description="..."
      notes={`Nœud feuille du graphe : collecte une entrée utilisateur et ne fait aucun traitement en aval.

Champs optionnels transmis par l'output :
- \`$value\` — valeur saisie ; masquée (••••) si \`$sensitive\` est vrai.
- \`$pattern\` — motif attendu, affiché en badge \`pattern\`.
- \`$attempt\` — numéro de tentative, affiché en \`#n\`.`}
      tags={["node", "input"]}
      kind={DocKind.View}
    >
      {/* contenu réel */}
    </DocIndex>
  );
}
```

2. **Fonctions / objets / classes / constantes** — helper no-op :

```ts
import { DocKind, indexDoc } from "@docs/index-doc";

export const cn = indexDoc(
  {
    title: "cn — merge de classes",
    description: "...",
    notes: `Merge les classes Tailwind via clsx puis déduplique les conflits avec twMerge.

Le résultat est stable (pas de re-creation d'objet à chaque appel), donc sûr à passer en \`memo\`.`,
    tags: ["utils", "classnames", "tailwind"],
    kind: DocKind.Function,
  },
  (...inputs: ClassValue[]) => twMerge(clsx(inputs)),
);
```

`indexDoc(meta, value)` retourne `value` à l'identique : zéro impact runtime. `DocIndex` ne rend que ses `children` : zéro impact visuel.

## Slug vs chemin

- **`slug`** est un **id simple et libre**, optionnel. S'il est omis, il est dérivé de l'export/cellule annotée en kebab-case : `InputNode` → `input-node`, `APP_INFO` → `app-info`, `cn` → `cn`. En cas de collision entre auto-slugs, un suffixe déterministe `-2`, `-3` est ajouté. Deux slugs manuels identiques → erreur `check:docs`.
- **`path`** est le **chemin relatif du fichier**, récupéré automatiquement par le générateur (jamais saisi) et affiché en sortie (`src/components/_nodes/input-node.tsx:14`). Il ne doit pas être reflété dans le slug.

## Usage

À la racine du projet hôte, un fichier `genealogy.config.ts` :

```ts
import type { GenealogyConfig } from "./docs-tool/src/types";

export default {
  title: "Généalogie — mon projet",
  roots: ["src"],
  include: ["**/*.{ts,tsx}"],
  exclude: ["**/node_modules/**", "**/.next/**"],
  out: "docs/genealogy",
} satisfies GenealogyConfig;
```

Options additionnelles :

- `projectName` (optionnel) — nom du projet affiché dans l'`AGENTS.md` généré. Par défaut : `package.json` du projet hôte (champ `name`), puis nom du dossier racine.
- `agentsFile` (optionnel) — chemin de l'`AGENTS.md` généré. Par défaut : `../AGENTS.md` relatif à `out` (soit `docs/AGENTS.md` avec l'exemple ci-dessus).
- `title` (optionnel) — titre des fichiers générés. Par défaut : `Généalogie — <projectName>`. Aucun nom de projet n'est codé en dur dans l'outil : tout provient de la config ou du `package.json` du projet hôte.

Scripts (à ajouter dans le `package.json` hôte) :

```json
{
  "generate:docs": "tsx docs-tool/src/generate-docs.ts",
  "check:docs": "tsx docs-tool/src/check-docs.ts"
}
```

## Sortie

Dans `docs/genealogy/` (configurable via `out`), cinq fichiers — **séparation des responsabilités** :

- `README.md` — index : sommaire, vocabulaire (slug/path/kind/nesting), statistiques, régénération.
- `nesting.md` — arbre de nesting : hiérarchie (dossiers auto + surcharges), chaque nœud avec son `chemin:ligne`.
- `imports.md` — graphe d'imports : arêtes De → Vers + importeurs inverses par nœud.
- `nodes.md` — détail de chaque nœud (slug, kind, chemin:ligne, export, parent/enfants, tags, description + « Explication technique » via `notes`) avec index en tête.
- `genealogy.json` — données machine (source de vérité).

En plus, `docs/AGENTS.md` (configurable via `agentsFile`) est généré : guide de la doc pour les agents IA (rôle, vocabulaire, règles, outils) avec le nom du projet injecté.

Chaque fichier porte l'en-tête `AUTO-GENERATED` et se régénère via `pnpm generate:docs`.

## Métadonnées (`DocMeta`)

| Champ | Type | Rôle |
| --- | --- | --- |
| `slug` | `string?` | Id libre et simple (ex: `input-node`). Dérivé de l'export en kebab-case si omis. |
| `title` | `string` | Titre court |
| `description` | `string?` | Description courte |
| `notes` | `string?` | **Explication technique approfondie** (markdown, multi-paragraphes) : fonctionnement interne, algorithmes, invariants, pièges. Rendu dans une section dédiée de `nodes.md`. |
| `tags` | `string[]` | Tags libres |
| `kind` | `DocKind?` (enum `"view" \| "function" \| "object" \| "class" \| "constant" \| "module"`) | Inféré si absent (JSX → view, arrow → function, objet → object, classe → class). Usage : `kind={DocKind.View}` en JSX, `kind: DocKind.Function` dans `indexDoc`. |
| `parent` | `string?` | Slug du parent (nesting explicite) |
| `children` | `string[]` | Slugs des enfants (nesting explicite) |

## Nesting — auto + surcharges

L'arbre se construit en priorité **explicite**, puis **auto depuis l'arborescence des fichiers** :

1. **Explicite** : `parent` / `children` (par slugs), ou imbrication réelle dans le JSX (un `<DocIndex>` dans un `<DocIndex>` → parent JSX).
2. **Auto** : sinon, le nœud s'accroche sous le **dossier de son fichier** (nœuds de dossier rendus en groupes, ex: `src/components/_nodes`).

Si un enfant déclare `parent`, il est automatiquement ajouté aux enfants du parent.

## Vérification (`check:docs`)

- slugs manuels uniques (auto-slugs dédupliqués par suffixe `-2`, `-3`)
- `title` requis
- kind valide
- parent/enfants référencés existent
- pas de cycle de nesting
- vocabulaire de tags si `tagVocabulary` configuré (optionnel — par défaut libre)

## Portabilité

`docs-tool/` est autonome : il suffit de le copier dans un autre projet (avec `@docs/*` pointant vers `docs-tool/src/*` dans le tsconfig), de créer `genealogy.config.ts`, et d'ajouter les deux scripts. Dépendances requises dans l'hôte : `typescript`, `tsx`.
