import type { GeneratedFile } from "../../_shared/generated-file";
import type { SpecContext } from "../../_shared/_lib/spec-types";
import { generateAuthToken, isCustomJwt, type GenOpts } from "./session";
import { kebabToScreamingSnake, pathToImportAlias, getVersionDir } from "../../_shared/_lib/naming";

export function generateApiClient(context: SpecContext, versionDir?: string, opts: GenOpts = {}): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const vd = versionDir ?? "v1";

  // src/lib/api-client.ts
  files.push({ path: "src/lib/api-client.ts", content: generateLibApiClient(opts, !!refreshEp(context, opts)) });

  // src/lib/auth-token.ts (cookie par requête en custom_jwt, sinon aucun jeton)
  files.push({ path: "src/lib/auth-token.ts", content: generateAuthToken(opts, refreshEp(context, opts)) });

  // api-client-index.ts — central index (imports from shared types which now include call+Mock)
  const entries: PathEntry[] = [];

  for (const ep of context.endpoints) {
    const parts = [ep.app, ep.module, ep.feature, ep.id];
    const alias = pathToImportAlias(parts);

    entries.push({
      parts,
      importAlias: alias,
      importPath: `./${vd}/${ep.app}/${ep.module}/${ep.feature}/${ep.id}/${ep.id}`,
    });
  }

  const indexContent = generateApiClientIndex(entries);
  files.push({ path: "src/api-shared/api-client-index.ts", content: indexContent });

  return files;
}

// ── lib/api-client.ts ──

function refreshEp(context: SpecContext, o: GenOpts) {
  const id = o.session?.refresh?.endpoint;
  const ep = id ? context.endpoints.find(e => e.id === id) : undefined;
  return isCustomJwt(o) && ep ? { method: ep.method.toUpperCase(), path: ep.path } : undefined;
}

function generateLibApiClient(opts: GenOpts, hasRefresh: boolean): string {
  const lines: string[] = [];

  lines.push("// ============================================================");
  lines.push("// API Client — shared ky instance");
  lines.push("// AUTO-GENERATED — do not edit manually");
  lines.push("// ============================================================");
  lines.push("");
  lines.push('import ky from "ky";');
  const cj = isCustomJwt(opts);
  lines.push(`import { getAccessToken${cj ? ", clearSession" : ""}${hasRefresh ? ", refreshSession" : ""} } from "./auth-token";`);
  lines.push("");
  lines.push("// ── Shared types ──");
  lines.push("");
  lines.push("/**");
  lines.push(" * Error thrown by call() when the API returns a non-2xx response.");
  lines.push(" * Check `.code` to discriminate between known error types.");
  lines.push(" */");
  lines.push("export class ApiClientError extends Error {");
  lines.push("  readonly status: number;");
  lines.push("  readonly code: string;");
  lines.push("  readonly body: unknown;");
  lines.push("");
  lines.push("  constructor(status: number, code: string, body: unknown) {");
  lines.push('    const b = body as Record<string, unknown> | undefined;');
  lines.push("    const errors = b?.errors;");
  lines.push('    const nested = b?.error as Record<string, unknown> | undefined;');
  lines.push("    const detail = Array.isArray(errors) && errors.length > 0");
  lines.push('      ? (errors as string[]).join("; ")');
  lines.push('      : typeof b?.message === "string"');
  lines.push("        ? b.message");
  lines.push('        : typeof nested?.message === "string"');
  lines.push("          ? nested.message");
  lines.push('          : "";');
  lines.push('    super(`[${code}] ${status}${detail ? ": " + detail : ""}`);');
  lines.push('    this.name = "ApiClientError";');
  lines.push("    this.status = status;");
  lines.push("    this.code = code;");
  lines.push("    this.body = body;");
  lines.push("  }");
  lines.push("}");
  lines.push("");
  lines.push("// ── Helpers ──");
  lines.push("");
  lines.push("/**");
  lines.push(" * Replace path parameters in a URL template.");
  lines.push(" */");
  lines.push("export function buildUrl(path: string, params?: object): string {");
  lines.push("  return path.replace(/\\{(\\w+)\\}/g, (_: string, k: string) =>");
  lines.push('    String((params as Record<string, string>)?.[k] ?? ""),');
  lines.push("  );");
  lines.push("}");
  lines.push("");
  lines.push("/**");
  lines.push(" * Convert a query object to URLSearchParams.");
  lines.push(" */");
  lines.push("export function toSearchParams(query: object | undefined): URLSearchParams | undefined {");
  lines.push("  if (query == null) return undefined;");
  lines.push("  const entries = Object.entries(query).filter(([_, v]) => v != null);");
  lines.push("  return new URLSearchParams(entries.map(([k, v]) => [k, String(v)]));");
  lines.push("}");
  lines.push("");
  lines.push("const API_BASE_URL =");
  lines.push('  typeof process !== "undefined"');
  lines.push('    ? (process.env?.NEXT_PUBLIC_API_URL ?? "http://localhost:3000")');
  lines.push('    : "http://localhost:3000";');
  lines.push("");
  lines.push("export const apiClient = ky.extend({");
  lines.push("  prefix: API_BASE_URL,");
  lines.push("  timeout: 10000,");
  lines.push("  retry: 2,");
  lines.push("  hooks: {");
  lines.push("    beforeRequest: [");
  lines.push("      async ({ request }) => {");
  lines.push("        if (!request.headers.has('Authorization')) {");
  lines.push("          const token = await getAccessToken();");
  lines.push("          if (token) request.headers.set('Authorization', `Bearer ${token}`);");
  lines.push("        }");
  lines.push("      },");
  lines.push("    ],");
  lines.push("    afterResponse: [");
  if (hasRefresh) {
    lines.push("      async ({ request, response, retryCount }) => {");
    lines.push("        if (response.status !== 401 || retryCount > 0) return;");
    lines.push("        const token = await refreshSession(API_BASE_URL);");
    lines.push("        if (!token) return;");
    lines.push("        const headers = new Headers(request.headers);");
    lines.push("        headers.set('Authorization', `Bearer ${token}`);");
    lines.push("        return ky.retry({ request: new Request(request, { headers }), code: 'TOKEN_REFRESHED' });");
    lines.push("      },");
  } else if (cj) {
    lines.push("      async ({ response }) => {");
    lines.push("        // Session expirée sans refresh configuré : on efface les cookies (échoue hors Server Action) ; la vue redirige vers le login.");
    lines.push("        if (response.status === 401) { try { await clearSession(); } catch { /* lecture seule */ } }");
    lines.push("      },");
  } else {
    lines.push("      async ({ response }) => {");
    lines.push("        if (response.status === 401) {");
    lines.push("          // Non géré (auth ≠ custom_jwt) : redirection vers le login à brancher.");
    lines.push("        }");
    lines.push("      },");
  }
  lines.push("    ],");
  lines.push("  },");
  lines.push("});");
  lines.push("");

  return lines.join("\n");
}

// ── Central index ──

interface PathEntry {
  parts: string[];
  importAlias: string;
  importPath: string;
}

function generateApiClientIndex(entries: PathEntry[]): string {
  const lines: string[] = [
    "// ────────────────────────────────────────────────────────────",
    "// Central index for all endpoint call(), Mock, and Hdr exports",
    "// AUTO-GENERATED — do not edit manually",
    "// ────────────────────────────────────────────────────────────",
    "",
  ];

  for (const entry of entries) {
    lines.push(`import * as ${entry.importAlias} from "${entry.importPath}";`);
  }
  lines.push("");
  lines.push("export const ApiSharedClient = {");
  lines.push("");

  interface NSNode {
    name: string;
    children: Map<string, NSNode>;
    entry: PathEntry | null;
  }

  const root = new Map<string, NSNode>();

  for (const entry of entries) {
    let current = root;
    for (let i = 0; i < entry.parts.length; i++) {
      const key = kebabToScreamingSnake(entry.parts[i]);
      let node = current.get(key);
      if (!node) {
        node = { name: key, children: new Map(), entry: null };
        current.set(key, node);
      }
      if (i === entry.parts.length - 1) {
        node.entry = entry;
      }
      current = node.children;
    }
  }

  function writeNS(nodes: Map<string, NSNode>, indent: string) {
    const sorted = [...nodes.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    for (const [, node] of sorted) {
      lines.push(`${indent}${node.name}: {`);
      if (node.entry) {
        const alias = node.entry.importAlias;
        lines.push(`${indent}  call: ${alias}.call,`);
        lines.push(`${indent}  Hdr: ${alias}.Hdr,`);
      }
      if (node.children.size > 0) {
        lines.push("");
        writeNS(node.children, `${indent}  `);
      }
      lines.push(`${indent}} as const,`);
      lines.push("");
    }
  }

  writeNS(root, "  ");
  lines.push("} as const;");

  return lines.join("\n");
}
