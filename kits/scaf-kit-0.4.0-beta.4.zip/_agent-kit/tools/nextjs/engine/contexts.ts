// L3 — api-contexts/ : un contexte React + un wrapper par endpoint, un <Feature>Providers par feature.
// Les contextes appellent les api-actions (serveur) : jamais la DI ni l'API en direct depuis le client.
// État maison (useState), sans dépendance : { data, error, isLoading, query } + load() (GET) ou mutate() (autres méthodes).
import type { GeneratedFile } from "../../_shared/generated-file";
import type { SpecContext, ParsedEndpoint } from "../../_shared/_lib/spec-types";
import { HEADER } from "../../_shared/_lib/header";
import { kebabToPascal } from "../../_shared/_lib/naming";

const USE_API_CALL = `${HEADER}"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import type { ApiErrorResponse } from "@/api-shared/shapes/error-shapes";
import type { PaginationData } from "@/api-shared/shapes/response-shapes";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Action = (opts?: any) => Promise<unknown>;
export type ApiData<A extends Action> = Exclude<Awaited<ReturnType<A>>, ApiErrorResponse>;
export type ApiOpts<A extends Action> = NonNullable<Parameters<A>[0]>;

export interface ApiCallState<A extends Action> {
  /** Dernière réponse réussie (conservée si un appel ultérieur échoue). */
  data: ApiData<A> | null;
  /** Erreur du dernier appel (null s'il a réussi). */
  error: ApiErrorResponse | null;
  isLoading: boolean;
  /** Options du dernier appel. */
  query: ApiOpts<A> | undefined;
  reset: () => void;
}

const isApiError = (r: unknown): r is ApiErrorResponse => (r as { success?: unknown } | null)?.success === false;

const networkError = (e: unknown): ApiErrorResponse => ({
  success: false,
  message: e instanceof Error ? e.message : "Erreur réseau",
  error: { code: "NETWORK_ERROR", message: e instanceof Error ? e.message : "Erreur réseau" },
});

/** Appelle une api-action et suit son état. Un appel plus récent invalide les réponses des précédents. */
export function useApiCall<A extends Action>(action: A) {
  const [state, setState] = useState<Omit<ApiCallState<A>, "reset">>({ data: null, error: null, isLoading: false, query: undefined });
  const seq = useRef(0);

  const run = useCallback(async (opts?: ApiOpts<A>): Promise<void> => {
    const id = ++seq.current;
    setState(s => ({ ...s, isLoading: true, query: opts }));
    let r: unknown;
    try { r = await action(opts); } catch (e) { r = networkError(e); }
    if (id !== seq.current) return;
    setState(s => isApiError(r)
      ? { ...s, error: r, isLoading: false }
      : { ...s, data: r as ApiData<A>, error: null, isLoading: false });
  }, [action]);

  const reset = useCallback(() => {
    seq.current++;
    setState({ data: null, error: null, isLoading: false, query: undefined });
  }, []);

  return useMemo(() => ({ ...state, reset, run }), [state, reset, run]);
}

export interface Pager {
  /** Pagination de la dernière réponse réussie (null avant le premier chargement). */
  pagination: PaginationData | null;
  /** Charge la page \`n\` (bornée à 1..total_pages) avec les mêmes options. */
  goTo: (n: number) => Promise<void>;
  next: () => Promise<void>;
  prev: () => Promise<void>;
  /** Change la taille de page et revient à la page 1. */
  setPageSize: (n: number) => Promise<void>;
}

/** Page \`n\` bornée : au moins 1, au plus \`total\` (si connu). */
export const clampPage = (n: number, total?: number): number => Math.max(1, total ? Math.min(n, total) : n);

/** Navigation de pages au-dessus d'un \`useApiCall\` dont la query accepte \`page\` / \`page_size\`. */
export function usePager<A extends Action>(c: { data: ApiData<A> | null; query: ApiOpts<A> | undefined; run: (o?: ApiOpts<A>) => Promise<void> }): Pager {
  const pagination = (c.data as { pagination?: PaginationData } | null)?.pagination ?? null;
  return useMemo(() => {
    const load = (q: Record<string, unknown>) => c.run({ ...c.query, query: { ...(c.query as { query?: object } | undefined)?.query, ...q } } as ApiOpts<A>);
    const goTo = (n: number) => load({ page: clampPage(n, pagination?.total_pages) });
    const cur = pagination?.current_page ?? 1;
    return { pagination, goTo, next: () => goTo(cur + 1), prev: () => goTo(cur - 1), setPageSize: (n: number) => load({ page: 1, page_size: n }) };
  }, [c, pagination]);
}
`;


export const COMPOSE = `${HEADER}"use client";

import type { ComponentType, ReactNode } from "react";

/** Compose des wrappers en un seul composant : le premier de la liste est le plus externe. */
export function composeWrappers(wrappers: ComponentType<{ children: ReactNode }>[]): ComponentType<{ children: ReactNode }> {
  return function Composed({ children }) {
    return wrappers.reduceRight<ReactNode>((acc, W) => <W>{acc}</W>, children);
  };
}
`;

const dir = (vd: string, kind: string, ep: ParsedEndpoint) => `src/api-contexts/${vd}/${kind}/${ep.app}/${ep.module}/${ep.feature}`;
const alias = (vd: string, kind: string, ep: ParsedEndpoint) => `@/api-contexts/${vd}/${kind}/${ep.app}/${ep.module}/${ep.feature}`;

export function generateContexts(context: SpecContext, vd = "v1"): GeneratedFile[] {
  const files: GeneratedFile[] = [
    { path: "src/api-contexts/use-api-call.ts", content: USE_API_CALL },
    { path: "src/api-contexts/compose-wrappers.tsx", content: COMPOSE },
  ];
  const byFeature = new Map<string, ParsedEndpoint[]>();
  for (const ep of context.endpoints) {
    const P = kebabToPascal(ep.id);
    const isGet = ep.method.toLowerCase() === "get";
    const fn = isGet ? "load" : "mutate";
    const action = `handle${P}Action`;
    const q = ep.spec.http?.request?.query ?? [];
    const paged = isGet && q.some(f => f.name === "page") && q.some(f => f.name === "page_size"); // convention scaf §7.3
    const actionPath = `@/api-actions/${vd}/${ep.app}/${ep.module}/${ep.feature}/${ep.id}`;

    files.push({
      path: `${dir(vd, "contexts", ep)}/${ep.id}-context.tsx`,
      content: [HEADER + `"use client";`, "",
        `import { createContext, useContext } from "react";`,
        `import type { ${action} } from "${actionPath}";`,
        `import type { ApiCallState, ApiOpts${paged ? ", Pager" : ""} } from "@/api-contexts/use-api-call";`, "",
        `export type ${P}ContextType = ApiCallState<typeof ${action}>${paged ? " & Pager" : ""} & {`,
        `  ${fn}: (opts?: ApiOpts<typeof ${action}>) => Promise<void>;`,
        `};`, "",
        `export const ${P}Context = createContext<${P}ContextType | null>(null);`, "",
        `export function use${P}Context(): ${P}ContextType {`,
        `  const ctx = useContext(${P}Context);`,
        `  if (!ctx) throw new Error("use${P}Context must be used within ${P}Wrapper");`,
        `  return ctx;`,
        `}`, ""].join("\n"),
    });

    const load = isGet ? [`  /** Charge au montage avec \`opts\` (une seule fois). */`, `  autoLoad?: boolean;`, `  opts?: ApiOpts<typeof ${action}>;`] : [];
    const effect = isGet ? [`  // eslint-disable-next-line react-hooks/exhaustive-deps`, `  useEffect(() => { if (autoLoad) void c.run(opts); }, []);`, ""] : [];
    files.push({
      path: `${dir(vd, "wrappers", ep)}/${ep.id}-wrapper.tsx`,
      content: [HEADER + `"use client";`, "",
        `import { ${isGet ? "useEffect, " : ""}useMemo, type ReactNode } from "react";`,
        `import { ${action} } from "${actionPath}";`,
        `import { useApiCall${isGet ? ", type ApiOpts" : ""}${paged ? ", usePager" : ""} } from "@/api-contexts/use-api-call";`,
        `import { ${P}Context, type ${P}ContextType } from "${alias(vd, "contexts", ep)}/${ep.id}-context";`, "",
        `export function ${P}Wrapper({ children${isGet ? ", autoLoad, opts" : ""} }: {`,
        `  children: ReactNode;`, ...load, `}) {`,
        `  const c = useApiCall(${action});`,
        ...(paged ? [`  const pager = usePager(c);`] : []),
        ...effect,
        `  const value = useMemo<${P}ContextType>(() => {`,
        `    const { run, ...state } = c;`,
        `    return { ...state, ${fn}: run${paged ? ", ...pager" : ""} };`,
        `  }, [c${paged ? ", pager" : ""}]);`,
        `  return <${P}Context.Provider value={value}>{children}</${P}Context.Provider>;`,
        `}`, ""].join("\n"),
    });

    const key = `${ep.app}|${ep.module}|${ep.feature}`;
    byFeature.set(key, [...(byFeature.get(key) ?? []), ep]);
  }

  for (const eps of byFeature.values()) {
    const e0 = eps[0];
    const F = kebabToPascal(e0.feature);
    files.push({
      path: `${dir(vd, "providers", e0)}/${e0.feature}-providers.tsx`,
      content: [HEADER + `"use client";`, "",
        `import { composeWrappers } from "@/api-contexts/compose-wrappers";`,
        ...eps.map(ep => `import { ${kebabToPascal(ep.id)}Wrapper } from "${alias(vd, "wrappers", ep)}/${ep.id}-wrapper";`), "",
        `/** Tous les wrappers de la feature (sans chargement auto). À monter par la page qui en a besoin. */`,
        `export const ${F}Providers = composeWrappers([`,
        ...eps.map(ep => `  ${kebabToPascal(ep.id)}Wrapper,`),
        `]);`, ""].join("\n"),
    });
  }
  return files;
}
