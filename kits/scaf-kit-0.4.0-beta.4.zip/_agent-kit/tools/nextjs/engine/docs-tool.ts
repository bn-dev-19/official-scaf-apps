// docs-tool (généalogie de code) : fichiers statiques de templates/docs-tool/ copiés sous docs-tool/ + genealogy.config.ts.
// Requis par le mode docs (`indexDoc` de `@docs/index-doc`) quand docsTool = true.
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";
import type { GeneratedFile } from "../../_shared/generated-file";

const TEMPLATES = fileURLToPath(new URL("../templates/docs-tool", import.meta.url));

function walk(dir: string): string[] {
  return readdirSync(dir).flatMap(n => (statSync(join(dir, n)).isDirectory() ? walk(join(dir, n)) : [join(dir, n)])).sort();
}

export function generateDocsTool(projectName: string): GeneratedFile[] {
  const files = walk(TEMPLATES).map(p => ({ path: `docs-tool/${relative(TEMPLATES, p)}`, content: readFileSync(p, "utf8") }));
  files.push({
    path: "genealogy.config.ts",
    content: `import type { GenealogyConfig } from "./docs-tool/src/types";

export default {
  title: "Généalogie — ${projectName}",
  roots: ["src"],
  include: ["**/*.{ts,tsx}"],
  exclude: ["**/node_modules/**", "**/.next/**", "**/*.d.ts"],
  out: "docs/genealogy",
} satisfies GenealogyConfig;
`,
  });
  return files;
}

// Prérequis côté app (idempotent, n'écrase rien) : paths `@docs/*`, scripts generate:docs/check:docs, devDependency tsx.
// Fichier absent ou JSON non strict (commentaires) : on n'y touche pas, on avertit.
export function patchAppForDocs(root: string, dry: boolean): string[] {
  const msgs: string[] = [];
  const edit = (name: string, fn: (j: any) => boolean, hint: string) => {
    const p = join(root, name);
    if (!existsSync(p)) return void msgs.push(`${name} absent : ${hint}`);
    let j: any;
    try { j = JSON.parse(readFileSync(p, "utf8")); } catch { return void msgs.push(`${name} non lisible (JSON strict requis) : ${hint}`); }
    if (!fn(j)) return;
    if (!dry) writeFileSync(p, JSON.stringify(j, null, 2) + "\n");
    msgs.push(`${name} complété (docs-tool)`);
  };
  edit("package.json", j => {
    const before = JSON.stringify(j);
    j.scripts = { ...j.scripts }; j.devDependencies = { ...j.devDependencies };
    j.scripts["generate:docs"] ??= "tsx docs-tool/src/generate-docs.ts";
    j.scripts["check:docs"] ??= "tsx docs-tool/src/check-docs.ts";
    j.devDependencies.tsx ??= j.dependencies?.tsx ?? "^4.19.0";
    return JSON.stringify(j) !== before;
  }, 'ajouter les scripts generate:docs / check:docs (tsx docs-tool/src/…) et le devDependency tsx');
  edit("tsconfig.json", j => {
    j.compilerOptions ??= {}; j.compilerOptions.paths ??= {};
    if (j.compilerOptions.paths["@docs/*"]) return false;
    j.compilerOptions.paths["@docs/*"] = ["./docs-tool/src/*"];
    return true;
  }, 'ajouter paths "@docs/*": ["./docs-tool/src/*"]');
  return msgs;
}
