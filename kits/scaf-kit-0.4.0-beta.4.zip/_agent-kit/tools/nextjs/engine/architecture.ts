// L2 — api-modules/ (clean_architecture | mvvm | mvc, selon `architecture` du config) + di/api_di.ts.
// Les types d'options/réponse sont dérivés de `call()` de l'endpoint : un seul point de vérité (api-shared).
import type { GeneratedFile } from "../../_shared/generated-file";
import type { SpecContext, ParsedEndpoint } from "../../_shared/_lib/spec-types";
import { HEADER } from "../../_shared/_lib/header";
import { kebabToPascal, kebabToCamel, toIdentifier } from "../../_shared/_lib/naming";

interface FeatureGroup { app: string; module: string; feature: string; usecases: ParsedEndpoint[] }

function groupByFeature(endpoints: ParsedEndpoint[]): FeatureGroup[] {
  const map = new Map<string, FeatureGroup>();
  for (const ep of endpoints) {
    const key = `${ep.app}|${ep.module}|${ep.feature}`;
    const g = map.get(key) ?? { app: ep.app, module: ep.module, feature: ep.feature, usecases: [] };
    g.usecases.push(ep);
    map.set(key, g);
  }
  return [...map.values()];
}

export const ARCHITECTURES = ["clean_architecture", "mvvm", "mvc"] as const;
export type Architecture = (typeof ARCHITECTURES)[number];

export function generateModules(context: SpecContext, versionDir = "v1", architecture: Architecture = "clean_architecture"): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const groups = groupByFeature(context.endpoints);
  for (const g of groups) {
    const base = `src/api-modules/${versionDir}/${architecture}/${g.app}/${g.module}/${g.feature}`;
    const F = kebabToPascal(g.feature);
    const opts = (uc: ParsedEndpoint) => `${kebabToPascal(uc.id)}Opts`;
    const res = (uc: ParsedEndpoint) => `${kebabToPascal(uc.id)}Response`;
    const sig = (uc: ParsedEndpoint) => `${kebabToCamel(uc.id)}(opts?: M.${opts(uc)}): Promise<M.${res(uc)}>`;
    const modelImport = (rel: string) => `import type * as M from "${rel}/data/models/${g.feature}.model";`;

    // data/models : types dérivés de call()
    const model = [HEADER];
    for (const uc of g.usecases) {
      const alias = `E_${toIdentifier(uc.id)}`;
      model.push(`import type * as ${alias} from "@/api-shared/${versionDir}/${uc.app}/${uc.module}/${uc.feature}/${uc.id}/${uc.id}";`);
    }
    model.push("");
    for (const uc of g.usecases) {
      const alias = `E_${toIdentifier(uc.id)}`;
      model.push(`export type ${opts(uc)} = NonNullable<Parameters<typeof ${alias}.call>[0]>;`);
      model.push(`export type ${res(uc)} = ${alias}.Response;`);
    }
    const modelDir = architecture === "clean_architecture" ? "data/models" : "model";
    files.push({ path: `${base}/${modelDir}/${g.feature}.model.ts`, content: model.join("\n") + "\n" });

    if (architecture === "mvc") { files.push(...mvc(g, base, versionDir)); continue; }
    if (architecture === "mvvm") { files.push(...mvvm(g, base, versionDir)); continue; }

    // domain/repositories + data/datasources : interfaces
    const iface = (name: string, doc: string) => [HEADER, modelImport("../.."), "", `/** ${doc} \`${g.feature}\`. */`,
      `export interface ${name} {`, ...g.usecases.map(uc => `  ${sig(uc)};`), "}", ""].join("\n");
    files.push({ path: `${base}/domain/repositories/${g.feature}.repository.ts`, content: iface(`${F}Repository`, "Repository interface for") });
    files.push({ path: `${base}/data/datasources/${g.feature}.datasource.ts`, content: iface(`${F}DataSource`, "Data source interface for") });

    // data/datasources impl : appelle call() de l'endpoint
    const dsImpl = [HEADER, modelImport("../.."), `import type { ${F}DataSource } from "./${g.feature}.datasource";`];
    for (const uc of g.usecases) {
      dsImpl.push(`import { call as call_${toIdentifier(uc.id)} } from "@/api-shared/${versionDir}/${uc.app}/${uc.module}/${uc.feature}/${uc.id}/${uc.id}";`);
    }
    dsImpl.push("", `export class ${F}DataSourceImpl implements ${F}DataSource {`);
    for (const uc of g.usecases) {
      dsImpl.push(`  async ${sig(uc)} {`, `    return call_${toIdentifier(uc.id)}(opts);`, "  }");
    }
    dsImpl.push("}", "");
    files.push({ path: `${base}/data/datasources/${g.feature}.datasource.impl.ts`, content: dsImpl.join("\n") });

    // data/repositories impl : délègue au datasource
    const repoImpl = [HEADER, modelImport("../.."),
      `import type { ${F}Repository } from "../../domain/repositories/${g.feature}.repository";`,
      `import type { ${F}DataSource } from "../datasources/${g.feature}.datasource";`, "",
      `export class ${F}RepositoryImpl implements ${F}Repository {`,
      `  constructor(private readonly _datasource: ${F}DataSource) {}`];
    for (const uc of g.usecases) {
      repoImpl.push("", `  async ${sig(uc)} {`, `    return this._datasource.${kebabToCamel(uc.id)}(opts);`, "  }");
    }
    repoImpl.push("}", "");
    files.push({ path: `${base}/data/repositories/${g.feature}.repository.impl.ts`, content: repoImpl.join("\n") });

    // domain/usecases : un fichier par endpoint
    for (const uc of g.usecases) {
      const U = kebabToPascal(uc.id);
      files.push({ path: `${base}/domain/usecases/${uc.id}.ts`, content: [HEADER,
        `import { logger } from "@/lib/logger";`, modelImport("../.."),
        `import type { ${F}Repository } from "../repositories/${g.feature}.repository";`, "",
        `export class ${U}Usecase {`,
        `  constructor(private readonly _repository: ${F}Repository) {}`, "",
        `  async execute(opts?: M.${opts(uc)}): Promise<M.${res(uc)}> {`,
        `    try {`, `      return await this._repository.${kebabToCamel(uc.id)}(opts);`,
        `    } catch (error) {`, `      logger.error({ err: error, usecase: "${uc.id}" }, "${uc.id} failed");`,
        `      throw error;`, `    }`, `  }`, `}`, ""].join("\n") });
    }

    // adapter : câblage datasource → repository → usecases
    const adapter = [HEADER,
      `import { ${F}DataSourceImpl } from "./data/datasources/${g.feature}.datasource.impl";`,
      `import { ${F}RepositoryImpl } from "./data/repositories/${g.feature}.repository.impl";`,
      ...g.usecases.map(uc => `import { ${kebabToPascal(uc.id)}Usecase } from "./domain/usecases/${uc.id}";`), "",
      `const _repository = new ${F}RepositoryImpl(new ${F}DataSourceImpl());`, "",
      `export const ${kebabToCamel(g.feature)}Adapter = {`,
      ...g.usecases.map(uc => `  ${kebabToCamel(uc.id)}: new ${kebabToPascal(uc.id)}Usecase(_repository),`), "};", ""];
    files.push({ path: `${base}/${g.feature}.adapter.ts`, content: adapter.join("\n") });
  }

  files.push(generateDi(groups, versionDir, architecture));
  return files;
}

function names(uc: ParsedEndpoint) {
  const id = kebabToPascal(uc.id);
  return { opts: `M.${id}Opts`, res: `M.${id}Response`, camel: kebabToCamel(uc.id), call: `call_${toIdentifier(uc.id)}` };
}
function callImports(g: FeatureGroup, vd: string): string[] {
  return g.usecases.map(uc => `import { call as call_${toIdentifier(uc.id)} } from "@/api-shared/${vd}/${uc.app}/${uc.module}/${uc.feature}/${uc.id}/${uc.id}";`);
}

function mvc(g: FeatureGroup, base: string, vd: string): GeneratedFile[] {
  const F = kebabToPascal(g.feature);
  const L = [HEADER, `import { logger } from "@/lib/logger";`, `import type * as M from "../model/${g.feature}.model";`, ...callImports(g, vd), "", `export class ${F}Controller {`];
  for (const uc of g.usecases) {
    const n = names(uc);
    L.push(`  async ${n.camel}(opts?: ${n.opts}): Promise<${n.res}> {`, `    try {`, `      return await ${n.call}(opts);`,
      `    } catch (error) {`, `      logger.error({ err: error, usecase: "${uc.id}" }, "${uc.id} failed");`, `      throw error;`, `    }`, `  }`, "");
  }
  L.pop(); L.push("}", "");
  return [{ path: `${base}/controller/${g.feature}.controller.ts`, content: L.join("\n") }];
}

function mvvm(g: FeatureGroup, base: string, vd: string): GeneratedFile[] {
  const F = kebabToPascal(g.feature);
  const L = [HEADER, `import { logger } from "@/lib/logger";`, `import type * as M from "../model/${g.feature}.model";`, ...callImports(g, vd), "",
    `export class ${F}ViewModel {`,
    `  private _subscribers = new Set<() => void>();`, `  private _snapshot = 0;`, "",
    `  subscribe(cb: () => void): () => void {`, `    this._subscribers.add(cb);`, `    return () => { this._subscribers.delete(cb); };`, `  }`, "",
    `  getSnapshot(): number {`, `    return this._snapshot;`, `  }`, "",
    `  private _notify(): void {`, `    this._snapshot++;`, `    this._subscribers.forEach(cb => cb());`, `  }`, ""];
  for (const uc of g.usecases) {
    const n = names(uc);
    L.push(`  ${n.camel}State: { data: ${n.res} | null; error: unknown; loading: boolean } = { data: null, error: null, loading: false };`, "",
      `  async ${n.camel}(opts?: ${n.opts}): Promise<void> {`,
      `    this.${n.camel}State.loading = true;`, `    this.${n.camel}State.error = null;`, `    this._notify();`, `    try {`,
      `      this.${n.camel}State.data = await ${n.call}(opts);`, `    } catch (error) {`, `      this.${n.camel}State.error = error;`,
      `      logger.error({ err: error, usecase: "${uc.id}" }, "${uc.id} failed");`, `    } finally {`,
      `      this.${n.camel}State.loading = false;`, `      this._notify();`, `    }`, `  }`, "");
  }
  L.pop(); L.push("}", "");
  const hook = [HEADER, `import { useMemo, useSyncExternalStore } from "react";`, `import { ${F}ViewModel } from "./${g.feature}.vm";`, "",
    `/** Hook réactif : même instance de VM entre les rendus, re-render quand loading/data/error changent. */`,
    `export function use${F}ViewModel(): ${F}ViewModel {`, `  const vm = useMemo(() => new ${F}ViewModel(), []);`,
    `  useSyncExternalStore(vm.subscribe.bind(vm), vm.getSnapshot.bind(vm));`, `  return vm;`, `}`, ""];
  return [{ path: `${base}/viewmodel/${g.feature}.vm.ts`, content: L.join("\n") }, { path: `${base}/viewmodel/${g.feature}.hook.ts`, content: hook.join("\n") }];
}

// di/api_di.ts : ApiDi_<v>.<app>.<module>.<feature>.<usecase>(opts) — chemin attendu par api-actions.
function generateDi(groups: FeatureGroup[], vd: string, arch: Architecture): GeneratedFile {
  const L = [HEADER];
  const alias = (g: FeatureGroup) => kebabToCamel(`${g.app}-${g.module}-${g.feature}`);
  const dir = (g: FeatureGroup) => `@/api-modules/${vd}/${arch}/${g.app}/${g.module}/${g.feature}`;
  for (const g of groups) {
    const F = kebabToPascal(g.feature);
    if (arch === "clean_architecture") L.push(`import { ${kebabToCamel(g.feature)}Adapter as ${alias(g)}Adapter } from "${dir(g)}/${g.feature}.adapter";`);
    if (arch === "mvc") L.push(`import { ${F}Controller } from "${dir(g)}/controller/${g.feature}.controller";`.replace(`{ ${F}Controller }`, `{ ${F}Controller as ${alias(g)}Controller }`));
    if (arch === "mvvm") L.push(`import { ${F}ViewModel as ${alias(g)}ViewModel } from "${dir(g)}/viewmodel/${g.feature}.vm";`);
  }
  L.push("");
  for (const g of groups) {
    if (arch === "mvc") L.push(`const _${alias(g)} = new ${alias(g)}Controller();`);
    if (arch === "mvvm") L.push(`const _${alias(g)} = new ${alias(g)}ViewModel();`);
  }
  L.push("", `export const ApiDi_${toIdentifier(vd)} = {`);
  const entry = (g: FeatureGroup, uc: ParsedEndpoint): string => {
    const c = kebabToCamel(uc.id);
    if (arch === "clean_architecture") return `(opts?: Parameters<typeof ${alias(g)}Adapter.${c}.execute>[0]) => ${alias(g)}Adapter.${c}.execute(opts)`;
    if (arch === "mvc") return `(opts?: Parameters<typeof _${alias(g)}.${c}>[0]) => _${alias(g)}.${c}(opts)`;
    return `async (opts?: Parameters<typeof _${alias(g)}.${c}>[0]) => {\n          await _${alias(g)}.${c}(opts);\n          const st = _${alias(g)}.${c}State;\n          if (st.error) throw st.error;\n          return st.data!;\n        }`;
  };
  const apps = [...new Set(groups.map(g => g.app))].sort();
  for (const app of apps) {
    L.push(`  ${kebabToCamel(app)}: {`);
    const mods = [...new Set(groups.filter(g => g.app === app).map(g => g.module))].sort();
    for (const mod of mods) {
      L.push(`    ${kebabToCamel(mod)}: {`);
      for (const g of groups.filter(x => x.app === app && x.module === mod)) {
        L.push(`      ${kebabToCamel(g.feature)}: {`);
        for (const uc of g.usecases) L.push(`        ${kebabToCamel(uc.id)}: ${entry(g, uc)},`);
        L.push("      },");
      }
      L.push("    },");
    }
    L.push("  },");
  }
  L.push("};", "");
  return { path: "src/di/api_di.ts", content: L.join("\n") };
}
