// Écriture d'un arbre généré : fichiers `preserve`, manifeste .scaf-generated.json (chemin → sha256), obsolètes, dry-run.
// Un fichier déjà présent mais non suivi par le manifeste (code écrit avant/à la main) est conservé et signalé, jamais écrasé.
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, rmdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import type { GeneratedFile } from "./generated-file";

const MANIFEST = ".scaf-generated.json";
const sha = (c: string | Buffer) => createHash("sha256").update(c).digest("hex");

export interface WriteOpts {
  root: string; level: string; dry: boolean; tag: string;
  /** Réécrire aussi les fichiers générés modifiés à la main. */
  force?: boolean;
  /** Chemins d'autres architectures (jamais supprimés) ; défaut : tous les chemins sont à nous. */
  foreign?: (path: string) => boolean;
}

export function writeTree(files: GeneratedFile[], o: WriteOpts): void {
  const { root, dry, tag } = o;
  const mpath = join(root, MANIFEST);
  const prev: { level?: string; files: Record<string, string> } = existsSync(mpath) ? JSON.parse(readFileSync(mpath, "utf8")) : { files: {} };
  const next: Record<string, string> = {};
  for (const f of files) {
    const p = join(root, f.path);
    const exists = existsSync(p);
    if (f.preserve) {
      if (exists) { console.log(`[${tag}] conservé (fichier utilisateur) : ${f.path}`); continue; }
    } else {
      if (exists && !(f.path in prev.files) && readFileSync(p, "utf8") !== f.content) {
        console.warn(`[${tag}] existant non généré, conservé : ${f.path}`); continue;
      }
      if (exists && f.path in prev.files && !o.force && sha(readFileSync(p)) !== prev.files[f.path] && readFileSync(p, "utf8") !== f.content) {
        console.warn(`[${tag}] modifié à la main, conservé (--force pour réécrire) : ${f.path}`); next[f.path] = prev.files[f.path]; continue;
      }
      next[f.path] = sha(f.content);
    }
    if (dry) { console.log(`[${tag}] écrit : ${f.path}`); continue; }
    mkdirSync(dirname(p), { recursive: true });
    writeFileSync(p, f.content);
  }
  for (const [path, hash] of Object.entries(prev.files)) {
    if (path in next) continue;
    if (o.foreign?.(path)) { next[path] = hash; continue; }
    const p = join(root, path);
    if (!existsSync(p)) continue;
    if (sha(readFileSync(p)) !== hash) { console.warn(`[${tag}] obsolète mais modifié, conservé : ${path}`); next[path] = hash; continue; }
    console.log(`[${tag}] supprimé (obsolète) : ${path}`);
    if (dry) continue;
    rmSync(p);
    for (let d = dirname(p); d.startsWith(root + "/") && readdirSync(d).length === 0; d = dirname(d)) rmdirSync(d);
  }
  if (!dry) writeFileSync(mpath, JSON.stringify({ level: o.level, files: Object.fromEntries(Object.entries(next).sort()) }, null, 2) + "\n");
}
