export interface CoercedFieldDef {
  name: string;
  type: string;
  format?: string;
  required?: boolean;
  description?: string;
  enum?: string[];
  [key: string]: unknown;
}

function isRepairableScalar(value: string): boolean {
  if (!value) return false;
  if (!value.includes(": ")) return false;
  const c = value[0];
  return c !== '"' && c !== "'" && c !== "[" && c !== "{" && c !== "*" && c !== "&" && c !== "|" && c !== ">";
}

/**
 * Répare un YAML produit par l'IA : toute valeur scalaire non quotée contenant
 * un ": " (ex: `format: enum: A|B|C`) est invalide en YAML. On la quote.
 * Ne modifie pas le reste (path, url, collections, scalaires quotés, blocs).
 */
export function repairSpecYaml(yaml: string): string {
  return yaml
    .split("\n")
    .map((line) => {
      const m = /^(\s*[A-Za-z0-9_-]+:\s*)(\S.*)$/.exec(line);
      if (m && isRepairableScalar(m[2])) return `${m[1]}"${m[2]}"`;
      return line;
    })
    .join("\n");
}

export interface CoercedErrorDef {
  status: string | number;
  code?: string;
  description?: string;
  message?: string;
  cause?: string;
  resolution?: string;
  [key: string]: unknown;
}

const FR_STATUS_MESSAGES: Record<string, string> = {
  "400": "Requête invalide.",
  "401": "Jeton manquant ou invalide.",
  "403": "Permissions insuffisantes.",
  "404": "Ressource introuvable.",
  "405": "Méthode non autorisée.",
  "409": "Conflit avec l'état actuel de la ressource.",
  "422": "Les données envoyées sont invalides.",
  "429": "Trop de requêtes, réessayez plus tard.",
  "500": "Erreur interne du serveur.",
  "502": "Passerelle invalide.",
  "503": "Service indisponible.",
};

/**
 * Message d'erreur par défaut, dérivé du statut HTTP puis du code.
 * Priorité attendue (hors de cette fonction) : message > description > défaut.
 */
export function defaultErrorMessage(status: string | number, code?: string): string {
  const fr = FR_STATUS_MESSAGES[String(status)];
  if (fr) return fr;
  return code ? `${code.toLowerCase().replace(/_/g, " ")}.` : `Erreur HTTP ${String(status)}.`;
}

export function coerceFieldDefs(value: unknown): CoercedFieldDef[] {
  if (value === null || value === undefined) return [];
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) return [];
    return [{ name: trimmed, type: "string" }];
  }
  if (Array.isArray(value)) {
    return value
      .filter((v): v is Record<string, unknown> => typeof v === "object" && v !== null)
      .map((v) => ({
        ...v,
        name: String(v.name ?? ""),
        type: String(v.type ?? "string"),
        format: typeof v.format === "string" ? v.format : undefined,
        required: v.required === true,
        description: typeof v.description === "string" ? v.description : undefined,
        enum: Array.isArray(v.enum) ? v.enum.map((e) => String(e)) : undefined,
      }));
  }
  if (typeof value === "object") {
    return Object.entries(value as Record<string, unknown>).map(([name, def]) => {
      if (def && typeof def === "object") {
        const r = def as Record<string, unknown>;
        return {
          ...r,
          name,
          type: String(r.type ?? "string"),
          format: typeof r.format === "string" ? r.format : undefined,
          required: r.required === true,
          description: typeof r.description === "string" ? r.description : undefined,
          enum: Array.isArray(r.enum) ? r.enum.map((e) => String(e)) : undefined,
        };
      }
      return { name, type: def === null ? "string" : String(def) };
    });
  }
  return [];
}

export function coerceErrorDefs(value: unknown): CoercedErrorDef[] {
  if (value === null || value === undefined) return [];
  if (typeof value === "string") return [];
  if (Array.isArray(value)) {
    return value
      .filter((v): v is Record<string, unknown> => typeof v === "object" && v !== null)
      .map((v) => ({
        ...v,
        status: String(v.status ?? "500"),
        code: typeof v.code === "string" ? v.code : undefined,
        description: typeof v.description === "string" ? v.description : undefined,
        message: typeof v.message === "string" ? v.message : undefined,
        cause: typeof v.cause === "string" ? v.cause : undefined,
        resolution: typeof v.resolution === "string" ? v.resolution : undefined,
      }));
  }
  if (typeof value === "object") {
    return Object.entries(value as Record<string, unknown>).map(([status, def]) => {
      if (def && typeof def === "object") {
        const r = def as Record<string, unknown>;
        return {
          ...r,
          status,
          code: typeof r.code === "string" ? r.code : undefined,
          description: typeof r.description === "string" ? r.description : undefined,
          message: typeof r.message === "string" ? r.message : undefined,
          cause: typeof r.cause === "string" ? r.cause : undefined,
          resolution: typeof r.resolution === "string" ? r.resolution : undefined,
        };
      }
      return { status };
    });
  }
  return [];
}
