import type { SpecProp, MockScenario } from "./spec-types";
import { kebabToPascal, toPascalEnumKey } from "./naming";

export function mockValueToConst(value: unknown, indent: number): string {
  if (value === null) return "null";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") return String(value);
  if (typeof value === "boolean") return String(value);
  if (Array.isArray(value)) {
    if (value.length === 0) return "[]";
    const pad = " ".repeat(indent);
    const innerPad = " ".repeat(indent + 2);
    const items = value.map(v => `${innerPad}${mockValueToConst(v, indent + 2)}`);
    return `[\n${items.join(",\n")}\n${pad}]`;
  }
  if (typeof value === "object") {
    const pad = " ".repeat(indent);
    const innerPad = " ".repeat(indent + 2);
    const entries = Object.entries(value as Record<string, unknown>).map(
      ([k, v]) => {
        const qk = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(k) ? k : JSON.stringify(k);
        return `${innerPad}${qk}: ${mockValueToConst(v, indent + 2)},`;
      }
    );
    return `{\n${entries.join("\n")}\n${pad}}`;
  }
  return "unknown";
}

export function collectEnumTypes(
  props: Record<string, SpecProp> | undefined,
  fieldPath: string,
  out: Map<string, string[]>
): void {
  if (!props) return;
  for (const [key, val] of Object.entries(props)) {
    const childPath = fieldPath ? `${fieldPath}${kebabToPascal(key)}` : kebabToPascal(key);
    if (Array.isArray(val.enum) && val.enum.length > 0) {
      out.set(childPath, val.enum.map(v => String(v)));
    }
    if (val.properties && typeof val.properties === "object" && !Array.isArray(val.properties)) {
      collectEnumTypes(val.properties, childPath, out);
    }
    if (val.items && typeof val.items === "object" && !Array.isArray(val.items)) {
      if (val.items.properties) {
        collectEnumTypes(val.items.properties, childPath, out);
      }
      if (Array.isArray(val.items.enum) && val.items.enum.length > 0) {
        out.set(childPath, val.items.enum.map(v => String(v)));
      }
    }
  }
}

/**
 * Noms des champs requis d'un objet body/properties.
 *
 * Les specs réelles utilisent deux conventions : la liste `required: [a, b]`
 * (OpenAPI standard) et/ou le flag de champ `required: true` porté par chaque
 * propriété. On fusionne les deux. Les valeurs invalides (boolean, objet…)
 * sont ignorées pour ne jamais faire crasher `new Set(...)`.
 */
export function requiredFieldNames(
  properties: Record<string, unknown> | undefined,
  required: unknown,
): string[] {
  const names: string[] = [];
  if (Array.isArray(required)) {
    for (const name of required) {
      if (typeof name === "string") names.push(name);
    }
  }
  if (properties && typeof properties === "object" && !Array.isArray(properties)) {
    for (const [key, val] of Object.entries(properties)) {
      if (
        val &&
        typeof val === "object" &&
        !Array.isArray(val) &&
        (val as Record<string, unknown>).required === true
      ) {
        names.push(key);
      }
    }
  }
  return names;
}

export function generateEnumDef(typeName: string, values: string[], indent: number): string {
  const pad = " ".repeat(indent);
  const innerPad = " ".repeat(indent + 2);
  const entries = values.map(v => {
    const key = toPascalEnumKey(v);
    if (key === v || /^[a-zA-Z_$]/.test(key)) {
      return `${innerPad}${key}: "${v}",`;
    }
    return `${innerPad}"${v}": "${v}",`;
  });
  return [
    `/** Enum values for \`${typeName}\`. */`,
    `export const ${typeName} = {`,
    ...entries,
    `${pad}} as const;`,
    `/** Type derived from \`${typeName}\` const. */`,
    `export type ${typeName} = (typeof ${typeName})[keyof typeof ${typeName}];`,
  ].join("\n");
}

export function yamlTypeToTS(
  prop: SpecProp,
  indent: number = 4,
  fieldPath: string = "",
  enumMap?: Map<string, string[]>
): string {
  const ts = yamlTypeToTSBase(prop, indent, fieldPath, enumMap);
  return prop.nullable ? `${ts} | null` : ts;
}

function yamlTypeToTSBase(
  prop: SpecProp,
  indent: number,
  fieldPath: string,
  enumMap?: Map<string, string[]>
): string {
  if (prop.enum && prop.enum.length > 0) {
    // enum posé sur un array = enum des éléments
    const arr = prop.type === "array" ? "[]" : "";
    if (fieldPath && enumMap?.has(fieldPath)) {
      return `${fieldPath}${arr}`;
    }
    const u = prop.enum.map(e => `"${e}"`).join(" | ");
    return arr ? `(${u})[]` : u;
  }

  switch (prop.type) {
    case "string":
      return "string";
    case "integer":
    case "number":
      return "number";
    case "boolean":
      return "boolean";
    case "object": {
      if (!prop.properties || Object.keys(prop.properties).length === 0) {
        return prop.additionalProperties ? "Record<string, unknown>" : "Record<string, never>";
      }
      const pad = " ".repeat(indent);
      const innerPad = " ".repeat(indent + 2);
      const reqSet = new Set(requiredFieldNames(prop.properties, prop.required));
      const entries = Object.entries(prop.properties).map(([key, val]) => {
        const opt = reqSet.has(key) ? "" : "?";
        const childPath = fieldPath ? `${fieldPath}${kebabToPascal(key)}` : kebabToPascal(key);
        const tsType = yamlTypeToTS(val, indent + 2, childPath, enumMap);
        return `${innerPad}${key}${opt}: ${tsType};`;
      });
      return `{\n${entries.join("\n")}\n${pad}}`;
    }
    case "array": {
      if (prop.items) {
        // fieldPath inchangé : même clé que collectEnumTypes pour items.
        const itemTs = yamlTypeToTS(prop.items, indent, fieldPath, enumMap);
        return /[|]/.test(itemTs) ? `(${itemTs})[]` : `${itemTs}[]`;
      }
      return "unknown[]";
    }
    default:
      return "unknown";
  }
}

export function yamlTypeToZod(
  prop: SpecProp,
  indent: number = 4,
  isRequired: boolean = true,
  fieldPath: string = "",
  enumMap?: Map<string, string[]>
): string {
  const pad = " ".repeat(indent);
  const innerPad = " ".repeat(indent + 2);

  let zod: string;

  if (prop.enum && prop.enum.length > 0) {
    if (fieldPath && enumMap?.has(fieldPath)) {
      zod = `z.enum(${fieldPath})`;
    } else {
      const vals = prop.enum.map(e => `"${e}"`);
      zod = vals.length === 1 ? `z.literal(${vals[0]})` : `z.enum([${vals.join(", ")}])`;
    }
    if (prop.type === "array") zod = `z.array(${zod})`;
  } else {
    switch (prop.type) {
      case "string":
        zod = "z.string()";
        if (prop.format === "uuid") zod = "z.string().uuid()";
        else if (prop.format === "email") zod = "z.string().email()";
        else if (prop.format === "uri" || prop.format === "url") zod = "z.string().url()";
        else if (prop.format === "date-time") zod = "z.iso.datetime()";
        else if (prop.format === "date") zod = "z.string().date()";
        break;
      case "integer":
        zod = "z.number().int()";
        break;
      case "number":
        zod = "z.number()";
        break;
      case "boolean":
        zod = "z.boolean()";
        break;
      case "object": {
        if (!prop.properties || Object.keys(prop.properties).length === 0) {
          zod = prop.additionalProperties
            ? "z.record(z.string(), z.unknown())"
            : "z.object({}).strip()";
          break;
        }
        const reqSet = new Set(requiredFieldNames(prop.properties, prop.required));
        const entries = Object.entries(prop.properties).map(([key, val]) => {
          const childReq = reqSet.has(key);
          const childPath = fieldPath ? `${fieldPath}${kebabToPascal(key)}` : kebabToPascal(key);
          const childZod = yamlTypeToZod(val, indent + 2, childReq, childPath, enumMap);
          return `${innerPad}${key}: ${childZod},`;
        });
        const modifier = prop.additionalProperties ? ".loose()" : ".strip()";
        zod = `z.object({\n${entries.join("\n")}\n${pad}})${modifier}`;
        break;
      }
      case "array": {
        if (prop.items) {
          zod = `z.array(${yamlTypeToZod(prop.items, indent, true)})`;
        } else {
          zod = "z.array(z.unknown())";
        }
        break;
      }
      default:
        zod = "z.unknown()";
    }
  }

  if (!isRequired) zod += ".optional()";
  if (prop.nullable) zod += ".nullable()";

  return zod;
}

export function mockScenarioFromMocksJson(mocksJson: string): MockScenario[] {
  try {
    const parsed = JSON.parse(mocksJson);
    return parsed.mocks ?? parsed ?? [];
  } catch {
    return [];
  }
}

export function findSuccessScenario(scenarios: MockScenario[], successStatus: number): MockScenario | undefined {
  return scenarios.find(s => s.expect.status === successStatus);
}

export function buildMockByKey(scenarios: MockScenario[]): Map<string, unknown> {
  const map = new Map<string, unknown>();
  if (!Array.isArray(scenarios)) return map;
  for (const sc of scenarios) {
    if (!sc?.expect) continue;
    const body = sc.expect.body;
    const bodyObj = typeof body === "object" && body !== null ? (body as Record<string, unknown>) : null;
    // Support both old format { error: { code } } and new ApiError format { code }
    let bodyCode: string | undefined;
    if (bodyObj) {
      if (typeof bodyObj.error === "object" && bodyObj.error !== null) {
        bodyCode = String((bodyObj.error as Record<string, unknown>).code ?? "");
      } else if (typeof bodyObj.code === "string") {
        bodyCode = bodyObj.code;
      }
    }
    if (bodyCode && typeof bodyCode === "string") {
      map.set(`${sc.expect.status}-${bodyCode}`, body);
    }
  }
  return map;
}
