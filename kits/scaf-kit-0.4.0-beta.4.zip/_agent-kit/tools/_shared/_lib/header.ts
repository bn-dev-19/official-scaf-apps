export const HEADER = `// ────────────────────────────────────────────────────────────
// AUTO-GENERATED — do not edit manually
// ────────────────────────────────────────────────────────────

`;

export const EDITABLE_HEADER = `// ────────────────────────────────────────────────────────────
// You can edit manually — ce fichier peut être modifié à la main
// ────────────────────────────────────────────────────────────

`;
