export function kebabToPascal(str: string): string {
  return str.split("-").map(s => s.charAt(0).toUpperCase() + s.slice(1)).join("");
}

export function kebabToCamel(str: string): string {
  const [first, ...rest] = str.split("-");
  return first + rest.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join("");
}

export function kebabToScreamingSnake(str: string): string {
  return str.split("-").map(s => s.toUpperCase()).join("_");
}

export function toPascalEnumKey(v: string): string {
  const pascal = kebabToPascal(v);
  if (/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(pascal)) return pascal;
  if (/^\d/.test(pascal)) return `_${pascal}`;
  return pascal.replace(/[^a-zA-Z0-9_$]/g, "_");
}

export function pathToImportAlias(parts: string[]): string {
  return "_" + parts.map(p => kebabToPascal(p)).join("");
}

export function escapeString(s: string): string {
  return s.trim().replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");
}

export function stripAccents(s: string): string {
  return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

/** Normalise un libellé pour comparaison (minuscules, sans accents, espaces uniques). */
export function normalizeForMatch(s: string): string {
  return stripAccents(s.trim().toLowerCase()).replace(/\s+/g, " ");
}

/** Libellé français → nom de méthode TS valide (camelCase). */
export function labelToMethodName(label: string): string {
  const cleaned = stripAccents(label)
    .replace(/[^a-zA-Z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const words = cleaned.split(" ").filter(Boolean);
  if (words.length === 0) return "action";
  const [first, ...rest] = words;
  return (
    first.toLowerCase() +
    rest.map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join("")
  );
}

/** Libellé français → nom TS PascalCase valide. */
export function labelToPascal(label: string): string {
  const cleaned = stripAccents(label)
    .replace(/[^a-zA-Z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const words = cleaned.split(" ").filter(Boolean);
  if (words.length === 0) return "Behavior";
  return words.map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join("");
}

/** Vrai si le texte est un identifiant TS valide (utilisable sans guillemets). */
export function isTsIdentifier(s: string): boolean {
  return /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(s);
}

export function extractPathParams(path: string): string[] {
  const matches = path.match(/\{(\w+)\}/g);
  if (!matches) return [];
  return [...new Set(matches.map(m => m.slice(1, -1)))];
}

/**
 * Extract the version directory from a project version string.
 * "1.0.0" → "v1", "2.3.1" → "v2", undefined → "v1"
 */
export function getVersionDir(version?: string): string {
  const v = version ?? "1.0.0";
  return `v${v.split(".")[0]}`;
}

/** Convert a version dir name to a valid JS identifier (snake_case). "v2-beta" → "v2_beta" */
export function toIdentifier(dirName: string): string {
  return dirName.replace(/-/g, "_");
}
