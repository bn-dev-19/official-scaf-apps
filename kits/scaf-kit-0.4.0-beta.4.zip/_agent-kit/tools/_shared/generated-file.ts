export interface GeneratedFile {
  path: string;
  content: string;
  warnings?: string[];
  /** Fichier modifiable par l'utilisateur : jamais écrasé s'il existe déjà. */
  preserve?: boolean;
  /** Fichier du socle : ignoré si ce dossier (relatif à la racine de l'app) existait déjà avant la génération. */
  scaffoldDir?: string;
}

export interface LightFile {
  path: string;
  warnings?: string[];
}

export interface FileTreeNode {
  name: string;
  path: string;
  isFile: boolean;
  children?: FileTreeNode[];
}

export function buildFileTree(files: { path: string }[]): FileTreeNode[] {
  const nodeMap = new Map<string, FileTreeNode>();

  for (const file of files) {
    const parts = file.path.split("/");
    let parentPath = "";

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      const isFile = i === parts.length - 1;
      const nodePath = parentPath ? `${parentPath}/${part}` : part;

      if (nodeMap.has(nodePath)) {
        parentPath = nodePath;
        continue;
      }

      const node: FileTreeNode = {
        name: part,
        path: nodePath,
        isFile,
        children: isFile ? undefined : [],
      };
      nodeMap.set(nodePath, node);

      const parentNode = nodeMap.get(parentPath);
      if (parentNode?.children) {
        parentNode.children.push(node);
      }

      parentPath = nodePath;
    }
  }

  const rootNodes: FileTreeNode[] = [];
  for (const node of nodeMap.values()) {
    const slashCount = node.path.split("/").length - 1;
    if (slashCount === 0 && !node.isFile) {
      rootNodes.push(node);
    }
  }

  sortTree(rootNodes);
  return rootNodes;
}

function sortTree(nodes: FileTreeNode[]): void {
  nodes.sort((a, b) => {
    if (a.isFile !== b.isFile) return a.isFile ? 1 : -1;
    return a.name.localeCompare(b.name);
  });
  for (const node of nodes) {
    if (node.children) sortTree(node.children);
  }
}
