import { load as yamlLoad } from "js-yaml";
import type { IndexSpec, ParsedEndpoint, MockScenario, SpecContext } from "./_lib/spec-types";
import { collectEnumTypes } from "./_lib/yaml-utils";
import { kebabToPascal } from "./_lib/naming";

export type SpecInputApp = {
  slug?: string;
  modules?: Array<{
    slug?: string;
    features?: Array<{
      slug?: string;
      endpoints?: Array<{ id?: string; name?: string; method?: string; path?: string; spec?: string; mocks?: string }>;
    }>;
  }>;
};

export function parseContractsToSpecContext(apps: SpecInputApp[]): SpecContext {
  const endpoints: ParsedEndpoint[] = [];
  const warnings: string[] = [];
  const enumMap = new Map<string, string[]>();

  for (const app of apps) {
    const appSlug = app.slug || "unknown";
    for (const mod of app.modules || []) {
      const moduleSlug = mod.slug || "unknown";
      for (const feat of mod.features || []) {
        const featureSlug = feat.slug || "unknown";
        for (const ep of feat.endpoints || []) {
          const specYaml = ep.spec || "";
          const mocksJson = ep.mocks || "";
          if (!specYaml) {
            warnings.push(`Endpoint ${ep.id || "?"} (${appSlug}/${moduleSlug}/${featureSlug}) : spec vide`);
            continue;
          }
          let spec: IndexSpec;
          try {
            spec = yamlLoad(specYaml) as IndexSpec;
          } catch (e) {
            warnings.push(`Erreur de parsing YAML pour ${ep.id} : ${e}`);
            continue;
          }
          if (!spec.http?.method || !spec.http?.path) {
            warnings.push(`Endpoint ${ep.id} : http.method ou http.path manquant`);
            continue;
          }
          let scenarios: MockScenario[] = [];
          if (mocksJson) {
            try {
              const parsed = JSON.parse(mocksJson);
              scenarios = parsed.mocks ?? parsed ?? [];
            } catch {
              warnings.push(`Erreur de parsing JSON mocks pour ${ep.id}`);
            }
          }
          const parsed: ParsedEndpoint = {
            app: appSlug,
            module: moduleSlug,
            feature: featureSlug,
            id: spec.endpoint?.id ?? ep.id ?? "unknown",
            name: spec.endpoint?.name ?? ep.name ?? "unnamed",
            method: spec.http.method,
            path: spec.http.path,
            spec,
            scenarios,
            specYaml,
            mocksJson,
          };
          collectEndpointEnums(parsed, enumMap);
          endpoints.push(parsed);
        }
      }
    }
  }
  return { endpoints, enumMap, warnings };
}

export function splitSpecContextByApp(context: SpecContext, declaredApps: string[] = []): Map<string, SpecContext> {
  const byApp = new Map<string, ParsedEndpoint[]>();
  for (const ep of context.endpoints) {
    const list = byApp.get(ep.app) ?? [];
    list.push(ep);
    byApp.set(ep.app, list);
  }
  for (const a of declaredApps) if (!byApp.has(a)) byApp.set(a, []); // app sans API : contexte vide, générée quand même
  const result = new Map<string, SpecContext>();
  for (const [app, endpoints] of byApp) {
    const enumMap = new Map<string, string[]>();
    for (const ep of endpoints) collectEndpointEnums(ep, enumMap);
    result.set(app, { endpoints, enumMap, warnings: context.warnings });
  }
  return result;
}

function collectEndpointEnums(ep: ParsedEndpoint, out: Map<string, string[]>): void {
  collectEnumTypes(ep.spec?.http?.request?.body?.properties, "", out);
  collectEnumTypes(ep.spec?.http?.response?.body?.properties, "", out);
  for (const q of ep.spec?.http?.request?.query ?? []) {
    if (q.enum && q.enum.length > 0) out.set(kebabToPascal(q.name), q.enum);
  }
}
