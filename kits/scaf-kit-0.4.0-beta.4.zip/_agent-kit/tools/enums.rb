#!/usr/bin/env ruby
# Alignement des énumérations : un même concept (ex. statut de candidature) a le MÊME ensemble de valeurs partout (apps, endpoints, requête/réponse).
# Usage : ruby scaf/_agent-kit/tools/enums.rb scaf/v1 [--quiet]
# --quiet : une ligne E/W par concept (utilisé par audit.rb) ; sinon le détail champ par champ + les champs non cadrés.
# Format : ../02-file-formats.md §15 · règles : ../03-rules-and-validation.md §EN. Code retour 1 s'il y a des E.
require 'yaml'
require 'date'

root = ARGV[0] or abort 'usage: enums.rb <scaf/vN> [--quiet]'
quiet = ARGV.include?('--quiet')
inp = File.join(root, 'input'); efile = File.join(inp, 'enums.yml')
abort "introuvable: #{inp}" unless Dir.exist?(inp)
exit 0 unless File.exist?(efile)

E = []; W = []
cfg = YAML.safe_load(File.read(efile), permitted_classes: [Date, Time]) || {}
default_sev = cfg['severity'] == 'error' ? 'E' : 'W'
add = ->(sev, rule, msg) { (sev == 'E' ? E : W) << "#{sev} #{rule}: #{msg}" }

# ── champs des contrats : [endpoint, in(resp|req|query), chemin pointé, enum|nil, type] ──
fields = []
walk = lambda do |n, ep, where, path|
  next unless n.is_a?(Hash)
  (n['properties'] || {}).each do |k, v|
    p2 = path + [k]
    fields << [ep, where, p2.join('.'), v['enum'], v['type']]
    walk.(v, ep, where, p2)
  end
  walk.(n['items'], ep, where, path) if n['items']
end
ci = YAML.safe_load(File.read(File.join(inp, 'contracts', '_index.yml'))) || { 'apps' => [] }
(ci['apps'] || []).each do |a|
  (a['modules'] || []).each do |m|
    (m['features'] || []).each do |ft|
      f = File.join(inp, 'contracts', 'apps', a['slug'], m['slug'], "#{ft}.yml")
      next unless File.exist?(f)
      (YAML.safe_load(File.read(f))['endpoints'] || []).each do |e|
        spec = (YAML.safe_load(e['spec'].to_s) rescue nil) || {}
        h = spec['http'] || {}
        walk.(h.dig('response', 'body', 'properties', 'data'), e['id'], 'resp', [])
        walk.(h.dig('request', 'body'), e['id'], 'req', [])
        (h.dig('request', 'query') || []).each { |q| fields << [e['id'], 'query', q['name'], q['enum'], q['type']] }
      end
    end
  end
end

# ── concepts ──────────────────────────────────────────────────────────
bound = {}  # index de champ => true
report = []
(cfg['concepts'] || []).each do |c|
  cid = c['id'] || '?'
  sev = (c['severity'] || (cfg['severity'] == 'error' ? 'error' : 'warn')) == 'error' ? 'E' : 'W'
  vals = Array(c['values']).map(&:to_s)
  E << "E EN0: #{cid}: values manquantes" if vals.empty?
  vals.each { |v| E << "E EN0: #{cid}: valeur #{v.inspect} non UPPER_SNAKE_CASE" unless v =~ /\A([A-Z][A-Z0-9_]*|\d+)\z/ }
  problems = []
  (c['bindings'] || []).each do |b|
    hits = fields.each_index.select do |i|
      ep, wh, path, = fields[i]
      File.fnmatch(b['endpoint'].to_s, ep) && File.fnmatch(b['field'].to_s, path) && (b['in'].nil? || b['in'] == wh)
    end
    if hits.empty?
      problems << ["EN2", "liaison #{b['endpoint']} / #{b['field']} ne correspond à aucun champ"]
      next
    end
    hits.each do |i|
      bound[i] = true
      ep, wh, path, en = fields[i]
      where = "#{ep} [#{wh}] #{path}"
      if en.nil?
        problems << ['EN1', "#{where} : valeurs libres (pas d'enum) ; attendu #{vals.join('|')}"]
      else
        got = en.map(&:to_s)
        if b['subset']
          extra = got - vals
          problems << ['EN1', "#{where} : valeurs hors concept #{extra.join(', ')}"] unless extra.empty?
        else
          miss = vals - got; extra = got - vals
          problems << ['EN1', "#{where} : manque [#{miss.join(', ')}] en trop [#{extra.join(', ')}]"] unless miss.empty? && extra.empty?
        end
      end
    end
  end
  report << [cid, c['description'], vals, problems]
  next if problems.empty?
  if quiet
    add.(sev, 'EN1', "#{cid} : #{problems.size} champ(s) non alignés sur #{vals.join('|')} (détail : ruby scaf/_agent-kit/tools/enums.rb #{root})")
  else
    problems.each { |r, m| add.(sev, r, "#{cid} — #{m}") }
  end
end

# ── champs de typologie non cadrés par un concept ─────────────────────
watch = Regexp.new(cfg['watch'] || 'status|state|type|level|kind|origin|source|decision|recommendation|visibility|confidentiality|stage|severity|priority|mode', Regexp::IGNORECASE)
skip = Array(cfg['ignore'])
skip_ep = Array(cfg['ignore_endpoints'])
unbound = fields.each_index.reject { |i| bound[i] }.select do |i|
  ep, wh, path, en, ty = fields[i]
  last = path.split('.').last
  last =~ watch && !skip_ep.any? { |s| File.fnmatch(s, ep) } && !skip.include?(last) && !skip.any? { |s| File.fnmatch(s, path) } && (en || ty == 'string')
end
by_name = unbound.group_by { |i| fields[i][2].split('.').last }
by_name.sort.each do |name, idx|
  free = idx.select { |i| fields[i][3].nil? }
  sets = idx.map { |i| fields[i][3] }.compact.map { |e| e.map(&:to_s).sort }.uniq
  msgs = []
  msgs << "#{free.size} champ(s) sans enum" unless free.empty?
  msgs << "#{sets.size} ensembles de valeurs distincts" if sets.size > 1
  next if msgs.empty?
  add.('W', 'EN3', "champ \"#{name}\" non cadré par un concept : #{msgs.join(', ')} (#{idx.size} occurrence(s))")
  next if quiet
  idx.each { |i| ep, wh, path, en = fields[i]; W << "W EN3:   #{ep} [#{wh}] #{path} = #{en ? en.join('|') : '(libre)'}" } if ARGV.include?('--verbose')
end

# ── EN4 : champ string libre dont tous les mocks sont des valeurs fixes MAJUSCULES (≤ 12) = enum probable, même hors `watch` ──
require 'json'
free_vals = Hash.new { |h, k| h[k] = { v: [], ep: [] } }
(ci['apps'] || []).each do |a|
  (a['modules'] || []).each do |m|
    (m['features'] || []).each do |ft|
      f = File.join(inp, 'contracts', 'apps', a['slug'], m['slug'], "#{ft}.yml")
      next unless File.exist?(f)
      (YAML.safe_load(File.read(f))['endpoints'] || []).each do |e|
        next if skip_ep.any? { |x| File.fnmatch(x, e['id']) }
        spec = (YAML.safe_load(e['spec'].to_s) rescue nil) || {}
        h = spec['http'] || {}; free = {}
        fw = lambda { |n| next unless n.is_a?(Hash); (n['properties'] || {}).each { |k, v| free[k] = true if v['type'] == 'string' && !v['enum'] && !v['format']; fw.(v) }; fw.(n['items']) }
        fw.(h.dig('response', 'body', 'properties', 'data')); fw.(h.dig('request', 'body'))
        (h['request'] && h['request']['query'] || []).each { |q| free[q['name']] = true if q['type'] == 'string' && !q['enum'] && !q['format'] }
        next if free.empty?
        col = lambda { |n, &b| case n when Hash then n.each { |k, v| b.(k, v); col.(v, &b) } when Array then n.each { |x| col.(x, &b) } end }
        ((JSON.parse(e['mocks'].to_s) rescue {})['mocks'] || []).each do |mk|
          [mk.dig('expect', 'body'), mk.dig('given', 'body'), mk.dig('given', 'query')].each do |x|
            col.(x) { |k, v| (free_vals[k][:v] << v; free_vals[k][:ep] << e['id']) if free[k] && v.is_a?(String) }
          end
        end
      end
    end
  end
end
free_vals.sort.each do |k, d|
  vs = d[:v].uniq
  next if skip.include?(k) || skip.any? { |g| File.fnmatch(g, k) } || vs.empty? || vs.size > 12 || !vs.all? { |v| v =~ /\A[A-Z][A-Z0-9_]+\z/ }
  add.('W', 'EN4', "champ \"#{k}\" sans enum mais à valeurs fixes MAJUSCULES (#{vs.first(6).join('|')}) sur #{d[:ep].uniq.size} endpoint(s) : en faire un enum et un concept")
end

puts E, W
unless quiet
  puts "\n== Concepts =="
  report.each { |cid, d, vals, pr| puts "  #{pr.empty? ? 'OK  ' : 'ÉCART'} #{cid} (#{vals.join('|')}) — #{pr.size} écart(s)" }
end
puts "\nenums: #{report.size} concepts — #{E.size} erreur(s), #{W.size} avertissement(s)" unless quiet
exit(E.empty? ? 0 : 1)
