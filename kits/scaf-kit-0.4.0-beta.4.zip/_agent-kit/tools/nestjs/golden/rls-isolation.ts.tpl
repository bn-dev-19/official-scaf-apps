import "reflect-metadata";
try { process.loadEnvFile(); } catch {}
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { createDb } from "./src/database/db";
import { withRls, runWithUser } from "./src/database/db-context";
import { NotesRepository } from "./src/database/repositories/notes.repository";
import { PlainThingsRepository } from "./src/database/repositories/plain-things.repository";

async function main() {
const root = createDb(); const db = withRls(root);
const notes = new NotesRepository(db), plain = new PlainThingsRepository(db);
const A = randomUUID(), B = randomUUID(), ADM = randomUUID();
const as = <T>(id: string | undefined, roles: string[], fn: () => Promise<T>) => runWithUser(db, id ? { id, roles } : undefined, fn);
await (root as any).$client.query("truncate notes, plain_things");
const ok = (m: string) => console.log("ok  " + m);

// données (hors requête : rôle propriétaire, sans RLS)
const a1 = await notes.insert({ id: randomUUID(), owner_id: A, body: "a-private", is_public: false } as any);
await notes.insert({ id: randomUUID(), owner_id: A, body: "a-public", is_public: true } as any);
const b1 = await notes.insert({ id: randomUUID(), owner_id: B, body: "b-private", is_public: false } as any);
ok("propriétaire hors requête : insère sans policy");

const bodies = (r: any[]) => r.map(x => x.body).sort();
assert.deepEqual(bodies(await as(A, [], () => notes.findAll())), ["a-private", "a-public"]); ok("A voit ses lignes + publiques, pas celles de B");
assert.deepEqual(bodies(await as(B, [], () => notes.findAll())), ["a-public", "b-private"]); ok("B voit les siennes + publiques");
assert.equal((await as(ADM, ["admin"], () => notes.findAll())).length >= 3, true); ok("admin voit tout");
assert.deepEqual(bodies(await as(undefined, [], () => notes.findAll())), ["a-public"]); ok("anonyme : seulement le public");
assert.equal(await as(A, [], () => notes.findById(b1.id)), undefined); ok("A ne lit pas la ligne de B par id");
assert.equal(await as(A, [], () => notes.update(b1.id, { body: "hack" })), undefined); ok("A ne modifie pas la ligne de B");
assert.equal(await as(A, [], () => notes.delete(b1.id)), false); ok("A ne supprime pas la ligne de B");
assert.equal((await as(A, [], () => notes.update(a1.id, { body: "a-edit" })))?.body, "a-edit"); ok("A modifie la sienne");
await assert.rejects(as(A, [], () => notes.insert({ id: randomUUID(), owner_id: B, body: "forged", is_public: false } as any))); ok("insert pour autrui refusé (WITH CHECK)");
// rollback sur exception
await assert.rejects(as(A, [], async () => { await notes.insert({ id: randomUUID(), owner_id: A, body: "tmp", is_public: false } as any); throw new Error("boom"); }));
assert.equal((await root.select().from((notes as any).table)).some((r: any) => r.body === "tmp"), false); ok("exception ⇒ rollback");
// table sans RLS accessible, contexte nettoyé
await plain.insert({ id: randomUUID(), label: "x" } as any);
assert.equal((await as(undefined, [], () => plain.findAll())).length, 1); ok("table sans RLS accessible à app_user");
assert.equal((await notes.findAll()).length === 3, true); ok("hors requête : plus de rôle app_user (contexte nettoyé)");
// requêtes concurrentes isolées
const [ra, rb] = await Promise.all([as(A, [], () => notes.findAll()), as(B, [], () => notes.findAll())]);
assert.deepEqual([bodies(ra).includes("b-private"), bodies(rb).includes("a-private")], [false, false]); ok("requêtes concurrentes A/B isolées");
await (root as any).$client.end();
console.log("rls : tout est ok");
}
main().catch(e => { console.error(e); process.exit(1); });
