// DTO class-validator (query/params/body) + types de réponse + erreurs typées d'un endpoint. Indépendant de l'architecture.
import type { SpecProp } from "../../_shared/_lib/spec-types";
import { requiredFieldNames } from "../../_shared/_lib/yaml-utils";
import { isTsIdentifier } from "../../_shared/_lib/naming";
import type { EndpointIR, Param } from "./ir";

export function tsType(p: SpecProp | undefined): string {
  if (!p) return "unknown";
  let t: string;
  if (p.enum?.length) t = p.enum.map(v => JSON.stringify(v)).join(" | ");
  else if (p.type === "array") t = `(${tsType(p.items)})[]`;
  else if (p.type === "object" && p.properties) {
    const req = requiredFieldNames(p.properties, p.required);
    t = `{ ${Object.entries(p.properties).map(([k, v]) => `${key(k)}${req.includes(k) ? "" : "?"}: ${tsType(v)}`).join("; ")} }`;
  } else if (p.type === "object") t = "Record<string, unknown>";
  else t = ({ string: "string", integer: "number", number: "number", boolean: "boolean" } as Record<string, string>)[p.type ?? ""] ?? "unknown";
  return p.nullable ? `${t} | null` : t;
}
const key = (k: string) => (isTsIdentifier(k) ? k : JSON.stringify(k));

/** Décorateurs class-validator/transformer d'une propriété. ponytail: objets/tableaux imbriqués non validés en profondeur (@IsObject/@IsArray). */
function decorators(p: SpecProp, required: boolean, fromString: boolean, imp: Set<string>): string[] {
  const d: string[] = [];
  const v = (n: string, args = "") => { imp.add(n); d.push(`@${n}(${args})`); };
  if (!required || p.nullable) v("IsOptional");
  if (p.enum?.length) v("IsIn", `[${p.enum.map(e => JSON.stringify(e)).join(", ")}]`);
  else if (p.type === "integer") { if (fromString) { imp.add("Type"); d.push("@Type(() => Number)"); } v("IsInt"); }
  else if (p.type === "number") { if (fromString) { imp.add("Type"); d.push("@Type(() => Number)"); } v("IsNumber"); }
  else if (p.type === "boolean") { if (fromString) { imp.add("Transform"); d.push(`@Transform(({ value }) => value === "true" || value === true)`); } v("IsBoolean"); }
  else if (p.type === "array") v("IsArray");
  else if (p.type === "object") v("IsObject");
  else if (p.type === "string") {
    if (p.format === "email") v("IsEmail");
    else if (p.format === "uuid") v("IsUUID");
    else if (p.format === "date-time" || p.format === "date") v("IsISO8601");
    else v("IsString");
  }
  return d;
}

function cls(name: string, props: { name: string; spec: SpecProp; required: boolean }[], fromString: boolean, imp: Set<string>): string {
  const body = props.map(({ name: n, spec, required }) =>
    `${decorators(spec, required, fromString, imp).map(x => `  ${x}\n`).join("")}  ${key(n)}${required ? "!" : "?"}: ${tsType(spec)};\n`).join("\n");
  return `export class ${name} {\n${body}}\n`;
}

export function endpointDto(ep: EndpointIR, coreRel: string): string {
  const imp = new Set<string>();
  const parts: string[] = [];
  if (ep.pathParams.length) {
    parts.push(cls(`${ep.pascal}Params`, ep.pathParams.map(n => ({ name: n, spec: ep.pathSpecs[n] ?? { type: "string" }, required: true })), true, imp));
  }
  if (ep.query.length) parts.push(cls(`${ep.pascal}Query`, ep.query.map((q: Param) => ({ name: q.name, spec: { type: q.type, format: q.format, enum: q.enum }, required: q.required })), true, imp));
  if (ep.body?.properties) {
    const req = requiredFieldNames(ep.body.properties, ep.body.required);
    parts.push(cls(`${ep.pascal}Body`, Object.entries(ep.body.properties).map(([n, s]) => ({ name: n, spec: s, required: req.includes(n) })), false, imp));
  } else if (ep.body) parts.push(`export type ${ep.pascal}Body = ${tsType(ep.body as SpecProp)};\n`);
  const out = ep.data ? tsType(ep.data) : "void";
  parts.push(`/** Retour du usecase : \`result(data)\`${ep.paginated ? " + \\`.paged(paginate(...))\\` (obligatoire, endpoint paginé)" : ""}, avec .message() / .warn() / .withHeaders() au besoin. */\nexport type ${ep.pascal}Output = ${ep.paginated ? "PagedApiResult" : "ApiResult"}<${out}>;\n`);
  const input = [
    ep.pathParams.length && `params: ${ep.pascal}Params`, ep.query.length && `query: ${ep.pascal}Query`,
    ep.body && `body: ${ep.pascal}Body`, ep.guard && "user: AuthUser",
  ].filter(Boolean);
  parts.push(`export interface ${ep.pascal}Input { ${input.join("; ")} }\n`);
  if (ep.stepList.length) parts.push(`/** Étapes de la spec (usecase) : un handler par code dans le usecase. */\nexport const ${ep.pascal}Steps = [\n${[...ep.stepList].sort((a, b) => a.order - b.order).map(s => `  { code: ${JSON.stringify(s.code)}, order: ${s.order}, severity: ${JSON.stringify(s.severity)}, description: ${JSON.stringify(s.description)} },`).join("\n")}\n] as const;\n`);
  const seen = new Set<string>();
  const errs = ep.errors.filter(e => !seen.has(e.code) && seen.add(e.code));
  if (errs.length) {
    parts.push(`/** Erreurs du contrat : \`throw ${ep.pascal}Errors.${errs[0].code}()\`. */\nexport const ${ep.pascal}Errors = {\n${errs.map(e =>
      `  ${e.code}: (message = ${JSON.stringify(e.message)}, extra?: ErrorExtra) => new AppException(${e.status}, "${e.code}", message, extra),`).join("\n")}\n};\n`);
  }
  const cv = [...imp].filter(n => n !== "Type" && n !== "Transform").sort();
  const head = [
    cv.length && `import { ${cv.join(", ")} } from "class-validator";`,
    (imp.has("Type") || imp.has("Transform")) && `import { ${["Transform", "Type"].filter(n => imp.has(n)).join(", ")} } from "class-transformer";`,
    `import type { ${ep.paginated ? "PagedApiResult" : "ApiResult"} } from "${coreRel}/api-result";`,
    errs.length && `import { AppException, type ErrorExtra } from "${coreRel}/app-exception";`,
    ep.guard && `import type { AuthUser } from "${coreRel}/auth/auth.port";`,
  ].filter(Boolean).join("\n");
  return `${head}${head ? "\n\n" : ""}${parts.join("\n")}`;
}
