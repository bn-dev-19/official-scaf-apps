// Swagger : sert l'OpenAPI déjà dérivé par scaf (contracts_to_openapi.rb) tel quel, sans décorateurs ni second constructeur. Un document par app.
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { load as yamlLoad } from "js-yaml";
import type { GeneratedFile } from "../../_shared/generated-file";

/** src/docs/openapi.<app>.json par app : version enrichie (output/openapi/doc/) si présente, sinon brute ; absente → avertissement, app ignorée (jamais de doc partiel).
 *  Chemin servi : plusieurs docs → `<base>/<app>` (sauf si base finit déjà par l'app), une seule → `<base>`. */
export function swaggerDocs(versionDir: string, targets: { app: string; base: string }[], warn: (m: string) => void): { files: GeneratedFile[]; served: { app: string; path: string }[] } {
  const files: GeneratedFile[] = [], served: { app: string; path: string }[] = [];
  for (const { app, base } of targets) {
    const p = [join(versionDir, "output", "openapi", "doc", `openapi.${app}.yml`), join(versionDir, "output", "openapi", `openapi.${app}.yml`)].find(existsSync);
    if (!p) { warn(`swagger : OpenAPI de ${app} absent (lancer ruby scaf/_agent-kit/tools/contracts_to_openapi.rb ${versionDir} --doc) : doc ignorée`); continue; }
    files.push({ path: `src/docs/openapi.${app}.json`, content: JSON.stringify(yamlLoad(readFileSync(p, "utf8"))) + "\n" });
    served.push({ app, path: targets.length > 1 && base !== app && !base.endsWith(`/${app}`) ? `${base}/${app}` : base });
  }
  return { files, served };
}
