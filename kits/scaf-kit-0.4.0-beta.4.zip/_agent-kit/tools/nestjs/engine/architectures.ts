// Stratégies d'architecture : où vont les fichiers d'un module. Le contenu (DTO, contrôleur, usecase) est commun.
import { posix } from "node:path";
import type { GeneratedFile } from "../../_shared/generated-file";
import { EDITABLE_HEADER, HEADER } from "../../_shared/_lib/header";
import { endpointDto } from "./dto";
import type { EndpointIR, ModuleIR } from "./ir";
import type { RepoRef } from "./database";

interface Layout { dto(m: string, id: string): string; controller(m: string, f: string): string; usecase(m: string, id: string): string; module(m: string): string }
export const ARCHITECTURES: Record<string, Layout> = {
  // couches : application (usecases) / presentation (controllers, dto)
  ddd_layered: {
    dto: (m, id) => `${m}/presentation/dto/${id}.dto.ts`, controller: (m, f) => `${m}/presentation/controllers/${f}.controller.ts`,
    usecase: (m, id) => `${m}/application/usecases/${id}/${id}.usecase.ts`, module: m => `${m}/${m}.module.ts`,
  },
  // module → controller / dto / usecases à plat
  modular_simple: {
    dto: (m, id) => `${m}/dto/${id}.dto.ts`, controller: (m, f) => `${m}/${f}.controller.ts`,
    usecase: (m, id) => `${m}/usecases/${id}.usecase.ts`, module: m => `${m}/${m}.module.ts`,
  },
};

const rel = (from: string, to: string) => { const r = posix.relative(posix.dirname(from), to).replace(/\.ts$/, ""); return r.startsWith(".") ? r : `./${r}`; };
export const roleOf = (g: string | null) => (g && g !== "RequireAuth" ? g.replace(/^Require/, "").replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase() : undefined);
const dec = (m: string) => ({ GET: "Get", POST: "Post", PUT: "Put", PATCH: "Patch", DELETE: "Delete" } as Record<string, string>)[m] ?? "Get";

/** Repository injecté dans un usecase (issu de `intent.tables`). */
interface UcRepo { cls: string; field: string; from: string; table: string; access: string; why?: string; description?: string; hasId: boolean; returning: boolean }

/** Bloc du guide pour un repository injecté : rôle (why), méthodes réelles, exemple, particularité du moteur. */
function repoGuide(r: UcRepo): string {
  const meths = ["findAll(limit = 50, offset = 0)", "insert(values)", ...(r.hasId ? ["findById(id)", "update(id, values)", "delete(id)"] : [])];
  const ex = r.access === "write" ? (r.hasId ? `await this.${r.field}.update(id, { ... })` : `await this.${r.field}.insert({ ... })`) : (r.hasId ? `await this.${r.field}.findById(id)` : `await this.${r.field}.findAll()`);
  return [` *    - this.${r.field} → table ${r.table} (${r.access})${r.why ? ` : ${r.why}` : ""}`,
    r.description && ` *        Table : ${r.description}`,
    ` *        Méthodes : ${meths.join(", ")}${r.hasId ? "" : " (pas de colonne id : pas de lecture/mise à jour par id)"}.`,
    ` *        Exemple : ${ex}`,
    !r.returning && ` *        MySQL : insert renvoie l'en-tête du pilote (insertId), update relit la ligne.`].filter(Boolean).join("\n");
}

function usecaseStub(ep: EndpointIR, dtoRel: string, base: string | null, repos: UcRepo[] = []): string {
  const desc = ep.usecaseDescription || ep.description || ep.name;
  const notes = ([] as string[]).concat(ep.intent?.consumer_notes ?? []);
  const doc = [desc, ep.intent?.purpose && `@purpose ${ep.intent.purpose}`,
    ep.intent?.actors?.length && `@actors ${ep.intent.actors.join(", ")}`,
    ...(ep.intent?.preconditions ?? []).map(x => `@precondition ${x}`), ...(ep.intent?.effects ?? []).map(x => `@effect ${x}`),
    ...repos.map(r => `@table ${r.table} (${r.access})`),
    ...(ep.intent?.depends_on ?? []).map(d => `@dependsOn ${d.endpoint}${d.when ? ` (${d.when})` : ""}${d.why ? ` — ${d.why}` : ""}`), ...notes.map(x => `@consumerNote ${x}`),
    ...ep.steps.map((s, i) => `@step ${i + 1} ${s}`), ...ep.errors.map(e => `@throws ${e.status} ${e.code}`),
    ep.errors.length && "@note Code d'erreur hors contrat : journalisé (warn « erreur hors contrat ») puis relayé tel quel au client ; seuls les @throws ci-dessus sont promis — ajouter le code au contrat scaf si légitime."].filter(Boolean).join("\n * ");
  const E = ep.pascal, hasSteps = !!base && ep.stepList.length > 0, hasErr = ep.errors.length > 0;
  const gen = [`${E}Input`, `${E}Output`, ...(hasSteps ? [hasErr ? `typeof ${E}Errors` : "Record<string, never>", `typeof ${E}Steps`] : hasErr ? [`typeof ${E}Errors`] : [])].join(", ");
  const sup = [JSON.stringify(desc), ...(hasSteps ? [hasErr ? `${E}Errors` : "{}", `${E}Steps`] : hasErr ? [`${E}Errors`] : [])].join(", ");
  const ctor = repos.length ? `\n${repos.map(r => `    private readonly ${r.field}: ${r.cls},`).join("\n")}\n  ` : "";
  const body = hasSteps
    ? `  /**
   * @ImplMode [Steps]
   * Un handler par étape de la spec (ctx.input, ctx.state, ctx.output, ctx.skip) ; todo(...) = à implémenter : écrire le corps puis retirer l'enveloppe todo (tant qu'il reste, usecase « pas prêt », 501 NOT_READY).
   */
  protected readonly steps: StepHandlers<typeof ${E}Steps, ${E}Input, ${E}Output> = {
${[...ep.stepList].sort((a, b) => a.order - b.order).map(st => `    ${JSON.stringify(st.code)}: todo(async (ctx) => {\n      // ${st.severity}${st.description ? ` — ${st.description.replace(/\s+/g, " ")}` : ""}\n    }),`).join("\n")}
  };

  /*
   * @ImplMode [Run] — alternative : écrire le usecase d'un bloc, sans les étapes
   * Supprimer ou commenter le bloc "steps" ci-dessus (les deux ensemble = erreur au 1er appel),
   * puis décommenter (retirer ce commentaire de bloc) :
   *
  protected async run(input: ${E}Input): Promise<${E}Output> {
    todo : implémenter la logique complète ici ; renvoyer result(data)${ep.paginated ? ".paged(paginate(page, pageSize, total))" : ""} (.message / .warn / .withHeaders au besoin) ; ${hasErr ? `lever ${E}Errors.<CODE>()` : "lever AppException"} pour les erreurs du contrat
    throw new Error("${ep.id} : à implémenter");
  }
   */`
    : `  /** @ImplMode [Run] */
  protected async run(_input: ${E}Input): Promise<${E}Output> {
    throw new NotImplementedException("${ep.id}");
  }`;
  const cls = base
    ? `export class ${E}Usecase extends BaseUsecase<${gen}> {
  constructor(${ctor}) {
    super(${sup});
  }

${body}
}`
    : `export class ${E}Usecase {${repos.length ? `\n  constructor(${ctor}) {}\n` : ""}
  async execute(_input: ${E}Input): Promise<${E}Output> {
    throw new NotImplementedException("${ep.id}");
  }
}`;
  const inputs = [ep.pathParams.length && "params (paramètres de chemin)", ep.query.length && "query", ep.body && "body", ep.guard && "user (utilisateur authentifié)"].filter(Boolean).join(", ") || "aucun champ";
  const paged = ep.paginated ? `
 *      .paged(paginate(page, pageSize, total))   ajoute "pagination" { current_page, page_size, total_items, total_pages } à côté de data.
 *                                                OBLIGATOIRE ici (endpoint paginé) : sans lui la compilation échoue. total = nombre total d'éléments, pas de la page.` : `
 *      .paged(paginate(page, pageSize, total))   ajoute "pagination" ; inutile ici (endpoint non paginé).`;
  const out = `Un usecase renvoie TOUJOURS un ApiResult, jamais l'objet brut (valeur brute = warn au runtime). Les méthodes se chaînent dans n'importe quel ordre :
 *      result(data)                              construit le résultat ; data = contenu de "data" dans la réponse (type ${E}Output).
 *                                                result() sans argument → data: null (suppression, action sans retour).
 *      .message("Litige ouvert")                 message de la réponse (défaut "OK"). Texte lisible par l'usager, pas un code.
 *      .warn({ title, description, tips: [] })   succès avec réserves : s'ajoute au tableau "warnings" (plusieurs appels = cumul).
 *                                                Ex. import terminé mais 2 lignes ignorées. Ne sert PAS aux erreurs (voir 4).${paged}
 *      .withHeaders({ Location: "/trips/42" })   en-têtes HTTP de la réponse (Location, ETag, Set-Cookie…), hors du corps ; cumul entre appels.
 *    Exemple : return result({ id }).message("Créé").withHeaders({ Location: "/x/" + id });
 *    Le statut HTTP vient du contrat (@HttpCode du controller), pas d'ApiResult ; une erreur se LÈVE (throw, voir 4), elle ne se renvoie pas.`;
  const uniq = ep.errors.filter((e, i, l) => l.findIndex(x => x.code === e.code) === i), w = Math.max(0, ...uniq.map(e => e.code.length));
  const errList = hasErr
    ? `lever l'une d'elles (throw), options { cause, resolution } :\n${uniq.map(e => ` *      ${E}Errors.${(e.code + "()").padEnd(w + 2)}  → ${e.status}`).join("\n")}\n *    Un code hors contrat est journalisé (warn) puis relayé tel quel.`
    : "aucune erreur déclarée au contrat ; AppException(status, code, message) pour les codes génériques.";
  const guide = `
/*
 * GUIDE D'UTILISATION — ${E}Usecase
 *
 * Appel : le controller appelle execute(input)${base ? " → contrôle d'état (readiness)" : ""} → ${hasSteps ? "étapes (steps) ou run()" : "run()"} → ApiResult → intercepteur → enveloppe { success, message, data, pagination?, warnings? }.
 *${hasSteps ? `
 * 1. Mode d'implémentation : un seul des deux. [Steps] = un handler par étape de la spec, exécutés dans l'ordre (retirer l'enveloppe todo(...) une fois écrit ; ctx.skip("raison") si sans objet) ;
 *    [Run] = run() d'un bloc, en supprimant ou commentant "steps" (les deux ensemble = erreur 500 au 1er appel).` : `
 * 1. Mode d'implémentation : [Run] — écrire le corps de run().`}
 * 2. Entrée (${E}Input) : ${inputs}.
 * 3. Sortie : ${out}${hasSteps ? "\n *    (dans les steps : ctx.output = result(...))." : "."}
 * 4. Erreurs : ${errList}${hasSteps ? `
 * 5. État : étape critical/high en todo → 501 NOT_READY ; medium/low en todo → warn et étape sautée ; "N/M usecases prêts" journalisé au démarrage.` : ""}
 * ${repos.length ? `${hasSteps ? "6" : "5"}. Repositories (intent.tables) : injectés dans le constructeur, à utiliser dans ${hasSteps ? "les handlers de steps" : "run()"} (scaf ne lie pas une étape à une table : à vous de placer les appels).\n${repos.map(repoGuide).join("\n")}\n *    Requête spécifique (jointure, filtre, transaction) : l'ajouter au fichier repository (fichier utilisateur) plutôt qu'ici.\n * ${hasSteps ? "7" : "6"}` : hasSteps ? "6" : "5"}. Régénération : ce fichier n'est jamais réécrit. Étape ajoutée à la spec → la compilation échoue tant que son handler manque ; route, DTO ou erreur à changer → modifier le contrat scaf puis régénérer.
 */
`;
  const valImp = [hasErr && `${E}Errors`, hasSteps && `${E}Steps`].filter(Boolean);
  return `${EDITABLE_HEADER}import { Injectable${hasSteps ? "" : ", NotImplementedException"} } from "@nestjs/common";
${repos.map(r => `import { ${r.cls} } from "${r.from}";\n`).join("")}${base ? `import { BaseUsecase${hasSteps ? ", todo" : ""}${hasSteps ? ", type StepHandlers" : ""} } from "${base}";\n` : ""}import type { ${E}Input, ${E}Output } from "${dtoRel}";${valImp.length ? `\nimport { ${valImp.join(", ")} } from "${dtoRel}";` : ""}

/**
 * ${doc}
 */
@Injectable()
${cls}
${guide}`;
}
/** Segments statiques communs en tête des chemins (ex. ["me","trips"]) : posés une fois dans @Controller. */
function commonPrefix(paths: string[]): string[] {
  const segs = paths.map(p => p.split("/").filter(Boolean));
  const out: string[] = [];
  for (let i = 0; ; i++) {
    const s = segs[0]?.[i];
    if (s === undefined || s.startsWith(":") || !segs.every(x => x[i] === s)) return out;
    out.push(s);
  }
}
const pascalOf = (k: string) => k.replace(/(^|[-_.])(\w)/g, (_, __, c) => c.toUpperCase());

interface CtrlGroup { name: string; cls: string; version?: string; prefix: string; eps: EndpointIR[] }
/** Un controller par feature (et par version si une feature en a plusieurs), dans l'ordre de leur 1re route. */
function groupControllers(m: ModuleIR): CtrlGroup[] {
  const by = new Map<string, EndpointIR[]>();
  for (const ep of m.endpoints) { const k = `${ep.feature}\u0000${ep.version ?? ""}`; (by.get(k) ?? by.set(k, []).get(k)!).push(ep); }
  const versionsOf = new Map<string, Set<string>>();
  for (const ep of m.endpoints) (versionsOf.get(ep.feature) ?? versionsOf.set(ep.feature, new Set()).get(ep.feature)!).add(ep.version ?? "");
  const rank = (p: string) => p.replace(/:\w+/g, "~");
  // Dans un controller, une route statique passe avant une route paramétrée de même forme (sinon `:id` capte `export`) ; tri stable, ordre de la spec sinon.
  const seg = (p: string) => p.split("/").map(x => (x.startsWith(":") ? "\uffff" : x));
  const byStatic = (a: EndpointIR, b: EndpointIR) => { const x = seg(a.nestPath), y = seg(b.nestPath); for (let i = 0; i < Math.min(x.length, y.length); i++) if (x[i] !== y[i]) return x[i] === "\uffff" ? 1 : y[i] === "\uffff" ? -1 : 0; return 0; };
  return [...by.values()].map(eps => {
    eps = eps.map((e, i) => ({ e, i })).sort((a, b) => byStatic(a.e, b.e) || a.i - b.i).map(x => x.e);
    const f = eps[0], multi = (versionsOf.get(f.feature)?.size ?? 1) > 1 && f.version;
    const name = multi ? `${f.feature}.v${f.version!.replace(/[^0-9A-Za-z.-]/g, "_")}` : f.feature;
    const prefix = eps.length > 1 ? commonPrefix(eps.map(e => e.nestPath)).join("/") : "";
    return { name, cls: `${pascalOf(f.feature)}${multi ? `V${f.version!.replace(/[^0-9A-Za-z]+(.)?/g, (_, c) => (c ?? "").toUpperCase())}` : ""}Controller`, version: f.version, prefix, eps };
  }).sort((a, b) => rank(a.eps[0].nestPath).localeCompare(rank(b.eps[0].nestPath)));
}

export interface UcLink { path: string; classes: string[] }
export function generateModule(arch: string, m: ModuleIR, usecaseBase = "none", repos?: Map<string, RepoRef>): { files: GeneratedFile[]; moduleClass: string; modulePath: string; links: UcLink[]; unresolved: string[] } {
  const lay = ARCHITECTURES[arch];
  const root = `src/modules/${arch}`;
  const at = (p: string) => `${root}/${p}`;
  const core = (from: string) => rel(from, "src/core/x").replace(/\/x$/, "");
  const files: GeneratedFile[] = [];
  const uses: string[] = [];
  const links: UcLink[] = [], unresolved: string[] = [];
  for (const ep of m.endpoints) {
    const dtoPath = at(lay.dto(m.key, ep.id)), ucPath = at(lay.usecase(m.key, ep.id));
    const ucRepos: UcRepo[] = [];
    for (const t of ep.intent?.tables ?? []) {
      const r = repos?.get(t.table);
      if (!r) { if (repos) unresolved.push(`${ep.id} : table ${t.table} sans repository`); continue; }
      if (ucRepos.some(x => x.cls === r.cls)) continue;
      ucRepos.push({ cls: r.cls, field: r.cls[0].toLowerCase() + r.cls.slice(1), from: rel(ucPath, r.path), table: t.table, access: t.access ?? "read", why: t.why, description: t.description, hasId: r.hasId, returning: r.returning });
    }
    if (ucRepos.length) links.push({ path: ucPath, classes: ucRepos.map(r => r.cls) });
    files.push({ path: dtoPath, content: HEADER + endpointDto(ep, core(dtoPath)) });
    files.push({ path: ucPath, preserve: true, content: usecaseStub(ep, rel(ucPath, dtoPath), usecaseBase === "template_method" ? rel(ucPath, "src/core/base-usecase.ts") : null, ucRepos) });
    uses.push(`${ep.pascal}Usecase`);
  }
  if (arch === "ddd_layered") for (const d of ["domain", "infrastructure"]) files.push({ path: at(`${m.key}/${d}/.gitkeep`), preserve: true, content: "" });

  const groups = groupControllers(m);
  const ctrlPaths: string[] = [];
  for (const g of groups) {
    const ctrlPath = at(lay.controller(m.key, g.name));
    ctrlPaths.push(ctrlPath);
    const coreImp = new Set<string>(["Controller"]);
    const imports: string[] = [];
    const methods: string[] = [];
    let needAuth = false;
    for (const ep of g.eps) {
      const dtoPath = at(lay.dto(m.key, ep.id)), ucPath = at(lay.usecase(m.key, ep.id));
      const names = [ep.pathParams.length && `${ep.pascal}Params`, ep.query.length && `${ep.pascal}Query`, ep.body && `${ep.pascal}Body`, `type ${ep.pascal}Output`].filter(Boolean);
      imports.push(`import { ${names.join(", ")} } from "${rel(ctrlPath, dtoPath)}";`);
      imports.push(`import { ${ep.pascal}Usecase } from "${rel(ctrlPath, ucPath)}";`);
      const args: string[] = [], input: string[] = [];
      if (ep.pathParams.length) { args.push(`@Param() params: ${ep.pascal}Params`); input.push("params"); coreImp.add("Param"); }
      if (ep.query.length) { args.push(`@Query() query: ${ep.pascal}Query`); input.push("query"); coreImp.add("Query"); }
      if (ep.body) { args.push(`@Body() body: ${ep.pascal}Body`); input.push("body"); coreImp.add("Body"); }
      if (ep.guard) { args.push("@CurrentUser() user: AuthUser"); input.push("user"); needAuth = true; }
      const role = roleOf(ep.guard);
      coreImp.add(dec(ep.method)); coreImp.add("HttpCode");
      const rel_ = g.prefix ? ep.nestPath.slice(g.prefix.length).replace(/^\//, "") : ep.nestPath;
      const doc = [`${ep.name}${ep.description ? ` — ${ep.description.replace(/\s+/g, " ")}` : ""}`, `@operationId ${ep.id}`, ...ep.errors.map(e => `@throws ${e.status} ${e.code}`), `@see ${ep.pascal}Usecase`];
      methods.push(`  /**\n${doc.map(l => `   * ${l}`).join("\n")}\n   */\n  @${dec(ep.method)}(${rel_ ? JSON.stringify(rel_) : ""})\n  @HttpCode(${ep.status})${ep.guard ? `\n  @Access(${role ? JSON.stringify(role) : ""})` : ""}\n  ${ep.camel}(${args.join(", ")}): Promise<${ep.pascal}Output> {\n    return this.${ep.camel}Usecase.execute({ ${input.join(", ")} });\n  }`);
    }
    const opts = [g.prefix && `path: ${JSON.stringify(g.prefix)}`, g.version && `version: ${JSON.stringify(g.version)}`].filter(Boolean);
    const ctrlArg = !opts.length ? "" : g.version ? `{ ${opts.join(", ")} }` : JSON.stringify(g.prefix);
    files.push({
      path: ctrlPath,
      content: `${HEADER}import { ${[...coreImp].sort().join(", ")} } from "@nestjs/common";
${needAuth ? `import { Access, CurrentUser } from "${core(ctrlPath)}/auth/access";\nimport type { AuthUser } from "${core(ctrlPath)}/auth/auth.port";\n` : ""}${imports.join("\n")}

@Controller(${ctrlArg})
export class ${g.cls} {
  constructor(
${g.eps.map(ep => `    private readonly ${ep.camel}Usecase: ${ep.pascal}Usecase,`).join("\n")}
  ) {}

${methods.join("\n\n")}
}
`,
    });
  }
  warnShadowed(m, groups);

  const modPath = at(lay.module(m.key));
  files.push({
    path: modPath,
    content: `${HEADER}import { Module } from "@nestjs/common";
${groups.map((g, i) => `import { ${g.cls} } from "${rel(modPath, ctrlPaths[i])}";`).join("\n")}
${m.endpoints.map(ep => `import { ${ep.pascal}Usecase } from "${rel(modPath, at(lay.usecase(m.key, ep.id)))}";`).join("\n")}

@Module({
  controllers: [${groups.map(g => g.cls).join(", ")}],
  providers: [${uses.join(", ")}],
})
export class ${m.pascal}Module {}
`,
  });
  return { files, moduleClass: `${m.pascal}Module`, modulePath: modPath, links, unresolved };
}

/** Une route paramétrée d'un controller placé avant masque une route statique d'un controller suivant (même méthode, même version). */
function warnShadowed(m: ModuleIR, groups: CtrlGroup[]) {
  const routes = groups.flatMap((g, gi) => g.eps.map(ep => ({ gi, ep })));
  routes.forEach((a, i) => {
    if (!a.ep.nestPath.includes(":")) return;
    const re = new RegExp("^" + a.ep.nestPath.replace(/:\w+/g, "[^/]+") + "$");
    for (const b of routes.slice(i + 1)) if (b.gi !== a.gi && b.ep.method === a.ep.method && b.ep.version === a.ep.version && !b.ep.nestPath.includes(":") && re.test(b.ep.nestPath))
      console.warn(`[nestjs] ${m.key} : ${b.ep.method} ${b.ep.nestPath} (${b.ep.id}) est masquée par ${a.ep.nestPath} (${a.ep.id}), controller placé avant`);
  });
}

/** Ordre d'import des modules dans AppModule : un module dont une route statique serait masquée par une route paramétrée d'un autre (même méthode, même version) passe avant lui. Ordre d'origine sinon (Kahn stable). */
export function orderModules(modules: ModuleIR[]): string[] {
  const n = modules.length, after = modules.map(() => new Set<number>()), indeg = modules.map(() => 0);
  modules.forEach((a, i) => modules.forEach((b, j) => {
    if (i === j || after[j].has(i)) return;
    const masks = a.endpoints.some(x => x.nestPath.includes(":") && b.endpoints.some(y => y.method === x.method && y.version === x.version && !y.nestPath.includes(":") && new RegExp("^" + x.nestPath.replace(/:\w+/g, "[^/]+") + "$").test(y.nestPath)));
    if (masks && !after[j].has(i)) { after[j].add(i); indeg[i]++; }
  }));
  const out: number[] = [], done = new Set<number>();
  while (out.length < n) {
    const k = modules.findIndex((_, i) => !done.has(i) && indeg[i] === 0);
    const i = k >= 0 ? k : modules.findIndex((_, i) => !done.has(i)); // cycle : ordre d'origine
    done.add(i); out.push(i); after[i].forEach(j => indeg[j]--);
  }
  return out.map(i => modules[i].key);
}
