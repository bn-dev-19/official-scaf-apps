// Adaptateurs d'authentification : chacun implémente AuthPort. Les guards des contrats n'en dépendent que par ce port.
import type { GeneratedFile } from "../../_shared/generated-file";

/** Config d'auth issue de nestjs.json (adaptateur better_auth) + base N2 si présente. */
export interface AuthCtx {
  plugins: string[]; oauthProviders: string[]; secretVar: string; baseUrlVar: string; trustedOrigins: string[];
  emailVerification: boolean; minPasswordLength?: number; globalPrefix?: string;
  db?: { dialect: string };
  /** Table du visuel scaf qui EST la table d'identité (remplace `user` de Better Auth) ; `userFields` : champ Better Auth → colonne ; ids selon `idStrategy`. */
  userTable?: string; userFields?: Record<string, string>; defaultRole?: string; idStrategy?: string;
}

export interface AuthAdapter {
  deps: string[]; notes: string[];
  files: (ctx: AuthCtx) => GeneratedFile[];
  /** Dépendances, scripts et notes qui dépendent de la config (surchargent les statiques). */
  plan?: (ctx: AuthCtx, warn: (m: string) => void) => { deps: string[]; devDeps?: string[]; scripts: Record<string, string>; notes: string[] };
  /** Import + expression du provider AUTH_PORT dans core.module. */
  provider: { imp: string; cls: string };
}

const none: AuthAdapter = {
  deps: [], notes: ["auth: none — tous les guards laissent passer (à remplacer avant mise en production)"],
  provider: { imp: "./auth/none.adapter", cls: "NoneAuthAdapter" },
  files: () => [{ path: "src/core/auth/none.adapter.ts", content: `import { Injectable } from "@nestjs/common";
import type { AuthPort, AuthUser } from "./auth.port";

/** Aucune authentification : tout passe. */
@Injectable()
export class NoneAuthAdapter implements AuthPort {
  async authenticate(): Promise<AuthUser | null> { return { id: "anonymous", roles: [] }; }
  hasRole(): boolean { return true; }
}
` }],
};

const jwt: AuthAdapter = {
  deps: [], notes: ["auth: jwt — définir JWT_SECRET ; le jeton (HS256) porte `sub` et `role`/`roles`"],
  provider: { imp: "./auth/jwt.adapter", cls: "JwtAuthAdapter" },
  files: () => [{ path: "src/core/auth/jwt.adapter.ts", content: `import { Injectable } from "@nestjs/common";
import { createHmac, timingSafeEqual } from "node:crypto";
import type { AuthPort, AuthUser } from "./auth.port";

/** JWT HS256 sans dépendance : \`Authorization: Bearer <jeton>\`, secret dans JWT_SECRET. */
@Injectable()
export class JwtAuthAdapter implements AuthPort {
  async authenticate(req: any): Promise<AuthUser | null> {
    const secret = process.env.JWT_SECRET;
    const token = /^Bearer (.+)$/.exec(req.headers?.authorization ?? "")?.[1];
    if (!secret || !token) return null;
    const [h, p, s] = token.split(".");
    if (!h || !p || !s) return null;
    const good = createHmac("sha256", secret).update(\`\${h}.\${p}\`).digest();
    const got = Buffer.from(s, "base64url");
    if (got.length !== good.length || !timingSafeEqual(got, good)) return null;
    try {
      const c = JSON.parse(Buffer.from(p, "base64url").toString());
      if (c.exp && c.exp * 1000 < Date.now()) return null;
      return { id: String(c.sub), roles: [].concat(c.roles ?? c.role ?? []) };
    } catch { return null; }
  }
  hasRole(user: AuthUser, role: string): boolean { return user.roles.includes(role); }
}
` }],
};

// Plugins Better Auth (v1.7) : nom nestjs.json → import + appel. `todo` = plugin qui exige un callback d'envoi (e-mail/SMS) à brancher.
const BA_PLUGINS: Record<string, { imp: string; call: string; from?: string; todo?: string; dep?: string }> = {
  admin: { imp: "admin", call: "admin()" },
  username: { imp: "username", call: "username()" },
  bearer: { imp: "bearer", call: "bearer()" },
  jwt: { imp: "jwt", call: "jwt()" },
  multiSession: { imp: "multiSession", call: "multiSession()" },
  anonymous: { imp: "anonymous", call: "anonymous()" },
  organization: { imp: "organization", call: "organization()" },
  twoFactor: { imp: "twoFactor", call: "twoFactor()" },
  openAPI: { imp: "openAPI", call: "openAPI()" },
  customSession: { imp: "customSession", call: "customSession(async ({ user, session }) => ({ user, session }))" },
  phoneNumber: { imp: "phoneNumber", call: "phoneNumber({ sendOTP: ({ phoneNumber, code }) => { /* À brancher : envoi SMS */ console.warn(`[auth] OTP ${code} pour ${phoneNumber} (envoi SMS non branché)`); } })", todo: "phoneNumber.sendOTP (SMS)" },
  emailOTP: { imp: "emailOTP", call: "emailOTP({ sendVerificationOTP: async ({ email, otp, type }) => { /* À brancher : envoi e-mail */ console.warn(`[auth] OTP ${otp} (${type}) pour ${email} (envoi e-mail non branché)`); } })", todo: "emailOTP.sendVerificationOTP (e-mail)" },
  magicLink: { imp: "magicLink", call: "magicLink({ sendMagicLink: async ({ email, url }) => { /* À brancher : envoi e-mail */ console.warn(`[auth] lien ${url} pour ${email} (envoi e-mail non branché)`); } })", todo: "magicLink.sendMagicLink (e-mail)" },
  apiKey: { imp: "apiKey", call: "apiKey()", from: "@better-auth/api-key", dep: "@better-auth/api-key" },
};
/** Tables natives Better Auth (SQL) créées par `auth generate` selon les plugins ; sert à détecter un conflit de nom avec le visuel scaf. */
const BA_PLUGIN_TABLES: Record<string, string[]> = { apiKey: ["apikey"], organization: ["organization", "member", "invitation", "team", "team_member"], twoFactor: ["two_factor"], jwt: ["jwks"] };
export const betterAuthTables = (plugins: string[]) => ["user", "session", "account", "verification", ...plugins.flatMap(p => BA_PLUGIN_TABLES[p] ?? [])];
/** Champs `user` ajoutés par un plugin : se mappent via `schema.user.fields` du plugin (pas via `user.fields` du cœur). */
const BA_PLUGIN_USER_FIELDS: Record<string, string[]> = { admin: ["role", "banned", "banReason", "banExpires"], username: ["username", "displayUsername"] };
const pluginCall = (p: string, x: AuthCtx) => {
  const m = Object.fromEntries((BA_PLUGIN_USER_FIELDS[p] ?? []).filter(f => x.userFields?.[f]).map(f => [f, x.userFields![f]]));
  const o = [...(p === "admin" && x.defaultRole ? [`defaultRole: ${JSON.stringify(x.defaultRole)}`] : []), ...(Object.keys(m).length ? [`schema: { user: { fields: ${JSON.stringify(m)} } }`] : [])];
  return x.userTable && o.length ? BA_PLUGINS[p].call.replace("()", `({ ${o.join(", ")} })`) : BA_PLUGINS[p].call;
};
const BA_DIALECT: Record<string, string> = { postgresql: "pg", mysql: "mysql", sqlite: "sqlite" };
const envName = (v: string, d: string) => (v?.startsWith("$var:") ? v.slice(5) : v) || d;
const betterAuthFiles = (x: AuthCtx): GeneratedFile[] => {
  const known = x.plugins.filter(p => BA_PLUGINS[p]), unknown = x.plugins.filter(p => !BA_PLUGINS[p]);
  const core = [...new Set(known.map(p => BA_PLUGINS[p]).filter(p => !p.from).map(p => p.imp))];
  const ext = known.map(p => BA_PLUGINS[p]).filter(p => p.from);
  const secret = envName(x.secretVar, "BETTER_AUTH_SECRET"), url = envName(x.baseUrlVar, "BETTER_AUTH_URL");
  const db = x.db ? BA_DIALECT[x.db.dialect] : undefined;
  const social = x.oauthProviders.map(p => `    ${p}: { clientId: process.env.${p.toUpperCase()}_CLIENT_ID!, clientSecret: process.env.${p.toUpperCase()}_CLIENT_SECRET! },`);
  const lines = [
    db ? `  database: drizzleAdapter(createDb(), { provider: "${db}", schema }),` : "  // Sans base (niveau < N2) : sessions stateless (cookie signé) ; fournir une base pour les comptes persistants.",
    `  secret: process.env.${secret},`,
    `  baseURL: process.env.${url},`,
    ...(`/${x.globalPrefix ? x.globalPrefix + "/" : ""}auth` !== "/api/auth" ? [`  basePath: "/${x.globalPrefix ? x.globalPrefix + "/" : ""}auth",`] : []),
    `  trustedOrigins: ${JSON.stringify(x.trustedOrigins)},`,
    `  emailAndPassword: { enabled: true${x.minPasswordLength ? `, minPasswordLength: ${x.minPasswordLength}` : ""}${x.emailVerification ? ", requireEmailVerification: true" : ""} },`,
    ...(social.length ? ["  socialProviders: {", ...social, "  },"] : []),
    ...(x.db && x.userTable ? [`  user: { modelName: ${JSON.stringify(x.userTable)}${x.userFields && Object.keys(x.userFields).length ? `, fields: ${JSON.stringify(Object.fromEntries(Object.entries(x.userFields).filter(([f]) => !Object.values(BA_PLUGIN_USER_FIELDS).flat().includes(f))))}` : ""} },`, `  advanced: { database: { generateId: "${x.idStrategy === "serial" ? "serial" : "uuid"}" } },`] : []),
    `  plugins: [${known.map(p => pluginCall(p, x)).join(", ")}],`,
  ];
  return [
    { path: "src/better-auth/auth.ts", preserve: true, content: `// Instance Better Auth du projet (fichier utilisateur, créé une fois) : générée depuis nestjs.json (plugins, secret, origines), à adapter.
// Tables Better Auth : \`pnpm auth:generate\` (réécrit src/better-auth/schema.ts d'après ce fichier), puis \`pnpm db:generate\` et \`pnpm db:migrate\`.
import { betterAuth } from "better-auth";
${db ? `import { drizzleAdapter } from "better-auth/adapters/drizzle";
` : ""}${core.length ? `import { ${core.join(", ")} } from "better-auth/plugins";
` : ""}${ext.map(p => `import { ${p.imp} } from "${p.from}";
`).join("")}${db ? `import { createDb } from "../database/db";
import * as schema from "./schema";
` : ""}
try { process.loadEnvFile(); } catch { /* pas de .env : variables d'environnement du shell */ }

export const auth = betterAuth({
${lines.join("\n")}
});
${unknown.length ? `// Plugins de nestjs.json non gérés par le générateur (à ajouter à la main) : ${unknown.join(", ")}\n` : ""}` },
    ...(db ? [{ path: "src/better-auth/schema.ts", preserve: true, content: `// Schéma Drizzle de Better Auth : écrit par \`pnpm auth:generate\` (d'après src/better-auth/auth.ts). Placeholder tant que la commande n'a pas été lancée.
export {};
` }] : []),
  ];
};

/** Table d'identité du visuel : `auth generate` la redéclare, on la retire de src/better-auth/schema.ts et on l'importe depuis le schéma scaf. */
const authSchemaScript = (table: string): GeneratedFile => ({ path: "scripts/auth-schema.mjs", content: `// Exécuté après \`auth generate\` : retire de src/better-auth/schema.ts la table ${table} (déjà définie dans le visuel scaf) et l'importe de ../database/schema.
import { readFileSync, writeFileSync } from "node:fs";
const file = "src/better-auth/schema.ts", table = ${JSON.stringify(table)};
let src = readFileSync(file, "utf8");
const cut = (re) => {
  const m = re.exec(src); if (!m) return null;
  let i = src.indexOf("(", m.index), d = 0, j = i;
  for (; j < src.length; j++) { if (src[j] === "(") d++; else if (src[j] === ")" && --d === 0) break; }
  src = src.slice(0, m.index) + src.slice(src.indexOf("\\n", j) + 1);
  return m[1];
};
const v = cut(new RegExp(\`export const ([A-Za-z0-9_]+) = [A-Za-z0-9_]+Table[(][^"]*"\${table}"\`));
if (!v) { console.error(\`auth-schema: table "\${table}" introuvable dans \${file}\`); process.exit(1); }
cut(new RegExp(\`export const (\${v}Relations) = relations[(]\`));
src = \`import { \${v} } from "../database/schema";\\nexport { \${v} }; // le drizzleAdapter résout modelName dans ce module\\n\` + src;
writeFileSync(file, src);
console.log(\`auth-schema: \${table} retiré de \${file} (importé de ../database/schema)\`);
` });

const betterAuth: AuthAdapter = {
  deps: ["better-auth"], notes: ["auth: better_auth — src/better-auth/auth.ts généré depuis nestjs.json ; le rôle vient de session.user.role"],
  provider: { imp: "./auth/better-auth.adapter", cls: "BetterAuthAdapter" },
  plan: (x, warn) => {
    const unknown = x.plugins.filter(p => !BA_PLUGINS[p]);
    if (unknown.length) warn(`auth: plugin(s) Better Auth non gérés (${unknown.join(", ")}) : à ajouter à la main dans src/better-auth/auth.ts`);
    const todo = x.plugins.map(p => BA_PLUGINS[p]?.todo).filter(Boolean);
    return {
      devDeps: x.db ? ["auth"] : [], // CLI Better Auth épinglée (auth generate)
      deps: ["better-auth", ...x.plugins.map(p => BA_PLUGINS[p]?.dep).filter((d): d is string => !!d)],
      scripts: x.db ? { "auth:generate": `auth generate --adapter drizzle --dialect ${BA_DIALECT[x.db.dialect]} --config src/better-auth/auth.ts --output src/better-auth/schema.ts --yes${x.userTable ? " && node scripts/auth-schema.mjs" : ""}` } as Record<string, string> : {},
      notes: [
        ...(x.db ? ["better_auth N2 : pnpm db:setup (auth:generate → db:generate → db:guard → db:migrate[ → db:rls], dans cet ordre) ; variables : voir .env.example"] : ["better_auth sans base (niveau < N2) : sessions stateless"]),
        ...(todo.length ? [`auth: à brancher dans src/better-auth/auth.ts : ${todo.join(", ")}`] : []),
      ],
    };
  },
  files: x => [
    { path: "src/core/auth/better-auth.adapter.ts", content: `import { Injectable } from "@nestjs/common";
import { auth } from "../../better-auth/auth";
import type { AuthPort, AuthUser } from "./auth.port";

/** Better Auth derrière AuthPort : session lue depuis les en-têtes/cookies de la requête. */
@Injectable()
export class BetterAuthAdapter implements AuthPort {
  async authenticate(req: any): Promise<AuthUser | null> {
    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers ?? {})) if (typeof v === "string") headers.set(k, v);
    const session = await auth.api.getSession({ headers });
    const u = session?.user as { id: string; role?: string | null } | undefined;
    return u ? { id: u.id, roles: String(u.role ?? "").split(",").filter(Boolean) } : null;
  }
  hasRole(user: AuthUser, role: string): boolean { return user.roles.includes(role); }
}
` },
    ...betterAuthFiles(x),
    ...(x.db && x.userTable ? [authSchemaScript(x.userTable)] : []),
  ],
};

export const AUTH_ADAPTERS: Record<string, AuthAdapter> = { none, jwt, better_auth: betterAuth };
