// N2 : accès base (drizzle ; postgresql, mysql, sqlite). Le schéma Drizzle est celui dérivé par scaf (visual_to_sql.rb) ; le générateur le copie,
// branche la connexion (selon moteur/provider) et crée un repository par table. Le lien usecase → table vient de `intent.tables` (scaf) : `repos` indexe les repositories par nom SQL de table.
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import type { GeneratedFile } from "../../_shared/generated-file";
import { HEADER } from "../../_shared/_lib/header";

export interface DbCfg { dialect: string; provider: string; migrations: string; url?: string; authSchema?: boolean; rls?: boolean }
export interface RepoRef { cls: string; path: string; hasId: boolean; returning: boolean }
export interface DbOut { repos: Map<string, RepoRef>; files: GeneratedFile[]; deps: string[]; devDeps: string[]; scripts: Record<string, string>; notes: string[]; module: { cls: string; path: string } }

const kebab = (s: string) => s.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const pascal = (s: string) => s[0].toUpperCase() + s.slice(1);

const DB = (imports: string, type: string, create: string, doc: string) => ({ imports, type, create, doc });
/** Moteurs gérés : syntaxe de table du schéma Drizzle, type de table, connexion par provider, dépendances. */
export const DB_ENGINES: Record<string, { tableFn: string; tableType: string; core: string; configDialect: string; returning: boolean; providers: Record<string, { imports: string; type: string; create: string; doc: string; deps: string[]; devDeps: string[] }> }> = {
  postgresql: {
    tableFn: "pgTable", tableType: "PgTable", core: "pg-core", configDialect: "postgresql", returning: true,
    providers: {
      neon: { ...DB(`import { Pool } from "@neondatabase/serverless";\nimport { drizzle, type NeonDatabase } from "drizzle-orm/neon-serverless";`, "NeonDatabase<typeof schema>", "drizzle(new Pool({ connectionString: url }), { schema })", "Neon (WebSocket, transactions possibles ; Node 22+)"), deps: ["drizzle-orm", "@neondatabase/serverless"], devDeps: [] },
      pg: { ...DB(`import { Pool } from "pg";\nimport { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";`, "NodePgDatabase<typeof schema>", "drizzle(new Pool({ connectionString: url }), { schema })", "PostgreSQL (pg)"), deps: ["drizzle-orm", "pg"], devDeps: ["@types/pg"] },
    },
  },
  mysql: {
    tableFn: "mysqlTable", tableType: "MySqlTable", core: "mysql-core", configDialect: "mysql", returning: false,
    providers: { mysql2: { ...DB(`import { createPool } from "mysql2/promise";\nimport { drizzle, type MySql2Database } from "drizzle-orm/mysql2";`, "MySql2Database<typeof schema>", `drizzle(createPool(url), { schema, mode: "default" })`, "MySQL (mysql2)"), deps: ["drizzle-orm", "mysql2"], devDeps: [] } },
  },
  sqlite: {
    tableFn: "sqliteTable", tableType: "SQLiteTable", core: "sqlite-core", configDialect: "sqlite", returning: true,
    providers: { better_sqlite3: { ...DB(`import Database from "better-sqlite3";\nimport { drizzle, type BetterSQLite3Database } from "drizzle-orm/better-sqlite3";`, "BetterSQLite3Database<typeof schema>", "drizzle(new Database(url), { schema })", "SQLite (better-sqlite3), `databaseUrl` = chemin du fichier"), deps: ["drizzle-orm", "better-sqlite3"], devDeps: ["@types/better-sqlite3"] } },
  },
};

/** Tables = exports `<tableFn>(` du schéma ; `hasId` = colonne `id` (repository CRUD par id). */
export function parseTables(src: string, tableFn: string): { name: string; sql: string; hasId: boolean }[] {
  return src.split(/^(?=export const )/m).flatMap(b => { const m = new RegExp(`^export const (\\w+) = ${tableFn}\\(\\s*['"]([^'"]+)['"]`).exec(b); return m ? [{ name: m[1], sql: m[2], hasId: /^\s+id: /m.test(b) }] : []; });
}

/** MySQL n'a pas `returning()` : insert renvoie l'en-tête du pilote, update re-lit la ligne, delete compte `affectedRows`. */
const baseRepo = (e: (typeof DB_ENGINES)[string]) => `import type { ${e.tableType} } from "drizzle-orm/${e.core}";
import { eq } from "drizzle-orm";
import type { Db } from "../db";

/** Fichier utilisateur : accès générique à une table (lecture, insertion). Y ajouter ce qui est commun à tous les repositories. */
export abstract class BaseRepository<T extends ${e.tableType}> {
  constructor(protected readonly db: Db, protected readonly table: T) {}
  findAll(limit = 50, offset = 0): Promise<T["$inferSelect"][]> { return this.db.select().from(this.table as any).limit(limit).offset(offset) as any; }
${e.returning
  ? `  async insert(values: T["$inferInsert"]): Promise<T["$inferSelect"]> { return (await this.db.insert(this.table).values(values as any).returning() as any[])[0]; }`
  : `  /** MySQL : pas de \`returning()\` — renvoie l'en-tête du pilote (insertId, affectedRows) ; relire la ligne par son id si besoin. */
  async insert(values: T["$inferInsert"]): Promise<unknown> { return (await this.db.insert(this.table).values(values as any) as any)[0]; }`}
}

/** Table à clé \`id\` : lecture, mise à jour et suppression par identifiant. */
export abstract class IdRepository<T extends ${e.tableType}> extends BaseRepository<T> {
  private get id() { return (this.table as any).id; }
  async findById(id: string | number): Promise<T["$inferSelect"] | undefined> { return (await this.db.select().from(this.table as any).where(eq(this.id, id)).limit(1) as any[])[0]; }
${e.returning
  ? `  async update(id: string | number, values: Partial<T["$inferInsert"]>): Promise<T["$inferSelect"] | undefined> { return (await this.db.update(this.table).set(values as any).where(eq(this.id, id)).returning() as any[])[0]; }
  async delete(id: string | number): Promise<boolean> { return (await this.db.delete(this.table).where(eq(this.id, id)).returning() as any[]).length > 0; }`
  : `  async update(id: string | number, values: Partial<T["$inferInsert"]>): Promise<T["$inferSelect"] | undefined> { await this.db.update(this.table).set(values as any).where(eq(this.id, id)); return this.findById(id); }
  async delete(id: string | number): Promise<boolean> { return ((await this.db.delete(this.table).where(eq(this.id, id)) as any)[0].affectedRows ?? 0) > 0; }`}
}
`;

export function databaseFiles(versionDir: string, c: DbCfg): DbOut {
  const dir = join(versionDir, "output", "database", c.dialect, "drizzle");
  if (!existsSync(join(dir, "index.ts"))) throw new Error(`schéma Drizzle absent (${dir}) : lancer ruby scaf/_agent-kit/tools/visual_to_sql.rb ${versionDir}`);
  const eng = DB_ENGINES[c.dialect], prov = eng?.providers[c.provider];
  if (!prov) throw new Error(`N2 : ${c.dialect}/${c.provider} non géré (${Object.entries(DB_ENGINES).map(([d, e]) => `${d} : ${Object.keys(e.providers).join("|")}`).join(" ; ")})`);
  const env = c.url?.startsWith("$var:") ? c.url.slice(5) : "DATABASE_URL";
  const f = (path: string, content: string): GeneratedFile => ({ path, content: HEADER + content });
  const user = (path: string, content: string): GeneratedFile => ({ path, content, preserve: true });
  const schema = readdirSync(dir).filter(x => x.endsWith(".ts")).sort();
  const tables = schema.filter(x => !["index.ts", "enums.ts", "tables-names.ts"].includes(x)).flatMap(x => parseTables(readFileSync(join(dir, x), "utf8"), eng.tableFn));
  const cls = (t: { name: string }) => `${pascal(t.name)}Repository`;
  // RLS (rls: session, PostgreSQL) : policies installées par scripts/apply-rls.mjs (Drizzle ne les connaît pas) ; contexte utilisateur par requête (db-context.ts + rls.interceptor.ts).
  const rlsSql = ["05_rls_setup.sql", "90_rls.sql"].map(x => join(versionDir, "output", "database", c.dialect, "sql", x));
  const rls = !!c.rls && c.dialect === "postgresql" && rlsSql.every(existsSync);
  const rlsWarn = c.rls && !rls ? [c.dialect !== "postgresql" ? `rls: session ignoré (${c.dialect} sans RLS natif)` : "rls: session mais aucune table avec rls.enabled dans le visuel (ou SQL non régénéré : visual_to_sql.rb)"] : [];
  const pool = c.provider === "neon" ? "@neondatabase/serverless" : "pg";
  const guard = c.migrations === "drizzle_kit" && !!c.authSchema;
  const files: GeneratedFile[] = [
    ...(guard ? [f("scripts/db-guard.mjs", `// Étape de db:setup entre db:generate et db:migrate : refuse une migration destructive (DROP TABLE, changement de type de colonne sans USING).
// Cas typique : l'identité Better Auth change (authUserTable, idStrategy) alors que les tables existent déjà. Jamais de DROP automatique.
// Migration voulue : SCAF_ALLOW_DESTRUCTIVE=1 pnpm db:setup (la migration est alors mémorisée dans drizzle/.guard-ack).
import { existsSync, readFileSync, appendFileSync } from "node:fs";
const jf = "drizzle/meta/_journal.json";
const last = existsSync(jf) ? JSON.parse(readFileSync(jf, "utf8")).entries.at(-1) : undefined;
if (!last) process.exit(0);
const ackf = "drizzle/.guard-ack";
if ((existsSync(ackf) ? readFileSync(ackf, "utf8").split("\\n") : []).includes(last.tag)) process.exit(0);
const bad = readFileSync(\`drizzle/\${last.tag}.sql\`, "utf8").split("--> statement-breakpoint").map(s => s.trim())
  .filter(s => /^DROP TABLE/i.test(s) || (/SET DATA TYPE/i.test(s) && !/USING/i.test(s)));
if (!bad.length) process.exit(0);
if (process.env.SCAF_ALLOW_DESTRUCTIVE === "1") { appendFileSync(ackf, last.tag + "\\n"); console.warn(\`db-guard : \${last.tag} autorisée (destructive)\`); process.exit(0); }
console.error(\`db-guard : la migration \${last.tag} est destructive :\\n  \${bad.map(s => s.split("\\n")[0]).join("\\n  ")}\\n
Cause probable : l'identité Better Auth a changé (authUserTable, idStrategy, authUserFields) alors que les tables existent déjà (ex. ids text -> uuid).
 - Base de test sans données utiles : supprimer les tables Better Auth (et cette migration + son entrée de drizzle/meta/_journal.json), puis relancer pnpm db:setup.
 - Base avec données : écrire la migration à la main (ALTER COLUMN ... TYPE uuid USING id::uuid, sans DROP), puis SCAF_ALLOW_DESTRUCTIVE=1 pnpm db:setup.\`);
process.exit(1);
`)] : []),
    ...(rls ? [
      ...rlsSql.map(p => ({ path: `rls/${p.split("/").pop()}`, content: readFileSync(p, "utf8") })),
      f("scripts/apply-rls.mjs", `// Applique rls/*.sql (fonctions app_user_id()/app_has_role(), rôle app_user, policies) : idempotent, à relancer après chaque migration. Connexion directe (rôle propriétaire).
import { readFileSync } from "node:fs";
import * as m from "${pool}";
try { process.loadEnvFile(); } catch { /* pas de .env */ }
const url = process.env.${env}_DIRECT ?? process.env.${env};
if (!url) { console.error("${env} non définie"); process.exit(1); }
const Pool = m.Pool ?? m.default.Pool;
const pool = new Pool({ connectionString: url });
try { for (const f of ["rls/05_rls_setup.sql", "rls/90_rls.sql"]) { await pool.query(readFileSync(f, "utf8")); console.log("rls : " + f + " appliqué"); } } finally { await pool.end(); }
`),
      f("src/database/db-context.ts", `import { AsyncLocalStorage } from "node:async_hooks";
import { sql } from "drizzle-orm";
import type { Db } from "./db";

/** Rôle PostgreSQL des policies (sql/05_rls_setup.sql) : l'API l'endosse par transaction (SET LOCAL ROLE). */
const RLS_ROLE = "app_user";
const als = new AsyncLocalStorage<Db>();

/** Proxy : tout accès à la base passe par la transaction de la requête en cours (sinon par la connexion normale, rôle propriétaire). */
export function withRls(root: Db): Db {
  return new Proxy(root, { get(_, p) { const t: any = als.getStore() ?? root; const v = t[p]; return typeof v === "function" ? v.bind(t) : v; } });
}

/** Exécute \`fn\` dans une transaction soumise aux policies de \`user\` (anonyme si absent). Une exception annule la transaction. */
export async function runWithUser<T>(db: Db, user: { id: string; roles: string[] } | undefined, fn: () => Promise<T>): Promise<T> {
  if (als.getStore()) return fn();
  return db.transaction(async tx => {
    await tx.execute(sql\`select set_config('app.user_id', \${user?.id ?? ""}, true), set_config('app.roles', \${(user?.roles ?? []).join(",")}, true)\`);
    await tx.execute(sql.raw(\`SET LOCAL ROLE \${RLS_ROLE}\`));
    return als.run(tx as unknown as Db, fn);
  });
}
`),
      f("src/database/rls.interceptor.ts", `import { CallHandler, ExecutionContext, Inject, Injectable, NestInterceptor } from "@nestjs/common";
import { from, lastValueFrom } from "rxjs";
import { DRIZZLE, type Db } from "./db";
import { runWithUser } from "./db-context";

/** Enveloppe chaque requête HTTP dans une transaction RLS (AccessGuard a déjà posé req.user ; anonyme sinon). */
@Injectable()
export class RlsInterceptor implements NestInterceptor {
  constructor(@Inject(DRIZZLE) private readonly db: Db) {}
  intercept(ctx: ExecutionContext, next: CallHandler) {
    if (ctx.getType() !== "http") return next.handle();
    return from(runWithUser(this.db, ctx.switchToHttp().getRequest().user, () => lastValueFrom(next.handle(), { defaultValue: undefined })));
  }
}
`),
    ] : []),
    ...schema.map(x => ({ path: `src/database/schema/${x}`, content: readFileSync(join(dir, x), "utf8") })),
    f("src/database/db.ts", `${prov.imports}
import * as schema from "./schema";

export const DRIZZLE = Symbol("DRIZZLE");
export type Db = ${prov.type};

/** ${prov.doc} : ${c.dialect === "sqlite" ? "chemin du fichier" : "chaîne de connexion"} dans ${env}. */
export function createDb(): Db {
  const url = process.env.${env};
  if (!url) throw new Error("${env} non définie");
  return ${prov.create};
}
`),
    user("src/database/repositories/base.repository.ts", baseRepo(eng)),
    ...tables.map(t => user(`src/database/repositories/${kebab(t.name)}.repository.ts`, `import { Inject, Injectable } from "@nestjs/common";
import { ${t.name} } from "../schema";
import { DRIZZLE, type Db } from "../db";
import { ${t.hasId ? "IdRepository" : "BaseRepository"} } from "./base.repository";

/** Fichier utilisateur : accès à la table \`${t.name}\` ; y ajouter les requêtes propres (jointures, filtres, transactions). */
@Injectable()
export class ${cls(t)} extends ${t.hasId ? "IdRepository" : "BaseRepository"}<typeof ${t.name}> {
  constructor(@Inject(DRIZZLE) db: Db) { super(db, ${t.name}); }
}
`)),
    f("src/database/database.module.ts", `import { Global, Module } from "@nestjs/common";
${rls ? `import { APP_INTERCEPTOR } from "@nestjs/core";\nimport { withRls } from "./db-context";\nimport { RlsInterceptor } from "./rls.interceptor";\n` : ""}import { createDb, DRIZZLE } from "./db";
${tables.map(t => `import { ${cls(t)} } from "./repositories/${kebab(t.name)}.repository";`).join("\n")}

const repositories = [
${tables.map(t => `  ${cls(t)},`).join("\n")}
];

/** Connexion Drizzle (DRIZZLE${rls ? ", proxy vers la transaction RLS de la requête" : ""}) et un repository par table, injectables partout. */
@Global()
@Module({ providers: [{ provide: DRIZZLE, useFactory: () => ${rls ? "withRls(createDb())" : "createDb()"} }, ...repositories${rls ? ", { provide: APP_INTERCEPTOR, useClass: RlsInterceptor }" : ""}], exports: [DRIZZLE, ...repositories] })
export class DatabaseModule {}
`),
    user("drizzle.config.ts", `import { defineConfig } from "drizzle-kit";
try { process.loadEnvFile(); } catch { /* pas de .env : variables d'environnement du shell */ }

export default defineConfig({
  dialect: "${eng.configDialect}",
  schema: [${["./src/database/schema/index.ts", ...(c.authSchema ? ["./src/better-auth/schema.ts"] : [])].map(x => `"${x}"`).join(", ")}],
  out: "./drizzle",
  dbCredentials: { url: (process.env.${env}_DIRECT ?? process.env.${env})! }, // migrations : URL directe (sans pooler) si ${env}_DIRECT est définie
});
`),
  ];
  return {
    repos: new Map(tables.map(t => [t.sql, { cls: cls(t), path: `src/database/repositories/${kebab(t.name)}.repository`, hasId: t.hasId, returning: eng.returning }])),
    files, module: { cls: "DatabaseModule", path: "./database/database.module" },
    deps: prov.deps,
    devDeps: [...(c.migrations === "drizzle_kit" ? ["drizzle-kit"] : []), ...prov.devDeps],
    scripts: { ...(c.migrations === "drizzle_kit" ? { "db:generate": "drizzle-kit generate", "db:migrate": "drizzle-kit migrate", "db:studio": "drizzle-kit studio" } : {}), ...(guard ? { "db:guard": "node scripts/db-guard.mjs" } : {}), ...(rls ? { "db:rls": "node scripts/apply-rls.mjs" } : {}) },
    notes: [...rlsWarn, ...(rls ? ["rls: session : policies dans rls/ (pnpm db:rls, après db:migrate) ; chaque requête HTTP tient une connexion (transaction, SET LOCAL ROLE app_user) ; jobs et Better Auth hors requête = rôle propriétaire (sans RLS)"] : []), `N2 : ${tables.length} repositories (src/database/repositories), schéma copié depuis scaf (src/database/schema, régénéré à chaque passage : modifier le visuel scaf, pas ces fichiers)`, `base de données : variable ${env} (.env) ; migrations : pnpm db:setup`, ...(c.provider === "neon" ? ["neon : Node 22+ requis (WebSocket global)"] : [])],
  };
}
