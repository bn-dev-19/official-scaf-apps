#!/usr/bin/env ruby
# frozen_string_literal: true
# Écart visuel <-> schéma Drizzle d'un backend (lecture seule, informatif, code retour 0).
#   ruby db_compare.rb scaf/<version> [--backend-schema <dossier>]
# Dossier par défaut : `schemaDir` de input/export-configs/nestjs.json (config), ex. backend/<app>/src/infrastructure/database/schemas
# Limite : lecture par expressions régulières (pgTable|mysqlTable|sqliteTable), pas d'analyse TypeScript.
require 'yaml'
require 'json'

ver = ARGV.shift or abort 'usage: db_compare.rb scaf/<version> [--backend-schema <dossier>]'
dir = nil
dir = ARGV[ARGV.index('--backend-schema') + 1] if ARGV.include?('--backend-schema')
inp = File.join(ver, 'input')
if dir.nil?
  cfg = File.join(inp, 'export-configs', 'nestjs.json')
  dir = (JSON.parse(File.read(cfg))['config'] || {})['schemaDir'] if File.exist?(cfg)
end
abort 'dossier de schéma backend inconnu : --backend-schema <dossier> ou schemaDir dans nestjs.json' if dir.to_s.empty?
abort "introuvable : #{dir}" unless Dir.exist?(dir)

# visuel : table => colonnes (tables externes ignorées)
vis = {}
Dir.glob(File.join(inp, 'database', 'visual', '_visual_*.yml')).sort.each do |f|
  next if f.end_with?('_visual_enums.yml')
  (YAML.safe_load(File.read(f)) || {}).fetch('tables', []).each do |t|
    next if t['external']
    vis[t['name']] = t.fetch('columns', []).map { |c| c['name'] }
  end
end

# backend : constantes DB_TABLES_NAMES (KEY: 'nom') puis tables déclarées
names = {}
Dir.glob(File.join(dir, '..', 'tables-names.ts')).each do |f|
  File.read(f).scan(/^\s*([A-Z0-9_]+):\s*'([^']+)'/) { |k, v| names[k] = v }
end
back = {}
Dir.glob(File.join(dir, '**', '*.ts')).sort.each do |f|
  parts = File.read(f).split(/\b(?:pgTable|mysqlTable|sqliteTable)\(/)
  parts.shift
  parts.each do |blk|
    m = blk.match(/\A\s*(?:DB_TABLES_NAMES\.([A-Z0-9_]+)|['"]([^'"]+)['"])/) or next
    n = m[2] || names[m[1]] or next
    back[n] = blk.scan(/^\s+\w+:\s*(?:t\.)?\w+\(\s*['"]([^'"]+)['"]/).flatten
  end
end

common = vis.keys & back.keys
puts "visuel : #{vis.size} tables · backend : #{back.size} tables · communes : #{common.size}"
puts "\nvisuel seul (#{(vis.keys - back.keys).size}) : #{(vis.keys - back.keys).sort.join(', ')}"
puts "\nbackend seul (#{(back.keys - vis.keys).size}) : #{(back.keys - vis.keys).sort.join(', ')}"
diverge = common.map { |t| [t, vis[t] - back[t], back[t] - vis[t]] }.reject { |_, a, b| a.empty? && b.empty? }
puts "\ncolonnes divergentes (#{diverge.size} table(s)) :"
diverge.each { |t, a, b| puts "  #{t} : visuel seul [#{a.join(', ')}] · backend seul [#{b.join(', ')}]" }
