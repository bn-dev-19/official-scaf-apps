#!/usr/bin/env ruby
# Guide d'implémentation : un .md par usecase producer portant un bloc `intent`, groupé par app.
# Usage : ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/v1   → <version>/output/implementation-guide/{README.md,<app>/<endpoint-id>.md}
# --check : n'écrit rien ; émet un `W GI:` par page absente, périmée ou éditée à la main (utilisé par audit.rb).
# Dérivé : ne jamais éditer. N'altère pas l'OpenAPI. Règles : ../02-file-formats.md §5 (bloc intent).
require 'yaml'
require 'fileutils'

root = ARGV.find { |a| !a.start_with?('--') } or abort 'usage: intent_to_md.rb <scaf/vN> [--check]'
check = ARGV.include?('--check')
inp  = File.join(root, 'input')
out  = File.join(root, 'output', 'implementation-guide')
ld   = ->(f) { YAML.safe_load(File.read(f), aliases: true) }

ep = {} # endpoint id => { app:, method:, path:, name: }
Dir[File.join(inp, 'contracts', 'apps', '*', '*', '*.yml')].each do |f|
  app = f.split('/')[-3]
  (ld.(f)['endpoints'] || []).each { |e| ep[e['id']] = { app: app, method: e['method'], path: e['path'], name: e['name'] } }
end
actors = (ld.(File.join(inp, 'project.parts', 'actors.yml')) || []).to_h { |a| [a['id'], a['description']] }

all = Dir[File.join(inp, 'usecases', '**', '*.usecase.yml')].map { |f| ld.(f) }.select { |u| u.dig('openapi', 'operationId') }
ucs = all.reject { |u| u['type'] == 'consumer' } # pages côté producteur
consumers = Hash.new { |h, k| h[k] = [] }        # endpoint id => usecases consumer (écrans/flux qui l'appellent)
all.select { |u| u['type'] == 'consumer' }.each { |u| consumers[u.dig('openapi', 'operationId')] << u }
called_by = Hash.new { |h, k| h[k] = [] } # endpoint id => [[appelant, when, why]]
ucs.each { |u| ((u['intent'] || {})['depends_on'] || []).each { |d| called_by[d['endpoint']] << [u.dig('openapi', 'operationId'), d['when'], d['why']] if d['endpoint'] } }

documented = ucs.map { |u| u.dig('openapi', 'operationId') }
lnk = ->(id, from_app) { e = ep[id]; e && documented.include?(id) ? "[`#{id}`](#{e[:app] == from_app ? '' : "../#{e[:app]}/"}#{id}.md)" : "`#{id}`" }
list = ->(a) { Array(a).map { |x| "- #{x}" }.join("\n") }
files = {} # chemin => contenu attendu
put = ->(path, str) { files[path] = str }
index = Hash.new { |h, k| h[k] = [] }
ucs.each do |u|
  id = u.dig('openapi', 'operationId'); n = u['intent'] || {}; e = ep[id] or next
  app = e[:app]
  md = +"# #{u['name']}\n\n`#{e[:method]} #{e[:path]}` · id `#{id}` · app `#{app}`\n\n#{n['purpose'] ? "## Pourquoi\n#{n['purpose']}" : "## Description\n#{u['description']}\n\n_Intent à renseigner (voir 02-file-formats.md §5)._"}\n"
  md << "\n## Qui\n#{Array(n['actors']).map { |a| "- **#{a}** — #{actors[a]}" }.join("\n")}\n" if n['actors']&.any?
  md << "\n## Préconditions\n#{list.(n['preconditions'])}\n" if n['preconditions']&.any?
  md << "\n## Étapes d'implémentation\n#{(u['steps'] || []).sort_by { |s| s['order'] }.map { |s| "#{s['order']}. `#{s['code']}` — #{s['stepDescription']}" }.join("\n")}\n"
  md << "\n## Tables\n#{n['tables'].map { |t| "- `#{t['table']}` (#{t['access'] || 'read'})#{t['why'] ? " : #{t['why']}" : ''}" }.join("\n")}\n" if n['tables']&.any?
  md << "\n## Effets\n#{list.(n['effects'])}\n" if n['effects']&.any?
  deps = n['depends_on'] || []
  { 'before' => 'Avant', 'during' => 'Pendant', 'after' => 'Après' }.each do |w, t|
    r = deps.select { |d| d['when'] == w }
    md << "\n## Endpoints à appeler — #{t.downcase}\n#{r.map { |d| "- #{lnk.(d['endpoint'] || d['usecase'], app)} — #{d['why']}" }.join("\n")}\n" if r.any?
  end
  cb = called_by[id]
  md << "\n## Appelé par\n#{cb.map { |c, w, y| "- #{lnk.(c, app)} (#{w}) — #{y}" }.join("\n")}\n" if cb.any?
  md << "\n## Notes pour le consommateur\n#{n['consumer_notes']}\n" if n['consumer_notes']
  consumers.fetch(id, []).each do |c|
    md << "\n## Côté consommateur — #{c['name']}\n#{c['description']}\n\n#{(c['steps'] || []).sort_by { |x| x['order'] }.map { |x| "#{x['order']}. `#{x['code']}` — #{x['stepDescription']}" }.join("\n")}\n"
    md << "\nRéactions aux erreurs :\n#{c['errors'].map { |x| "- `#{x['code']}` (#{x['status']}) — #{x['description']}" }.join("\n")}\n" if c['errors']&.any?
  end
  md << "\n## Erreurs\n#{(u['errors'] || []).map { |x| "- `#{x['code']}` (#{x['status']}) — #{x['description']}" }.join("\n")}\n"
  put.(File.join(out, app, "#{id}.md"), md)
  index[app] << "- #{u['intent'] ? '✦ ' : ''}[#{id}](#{app}/#{id}.md) — #{u['name']}"
end
gaps = ucs.reject { |u| u['intent'] }.map { |u| u['id'] }
put.(File.join(out, 'README.md'), "# Guide d'implémentation\n\nDérivé des usecases (ne pas éditer). ✦ = bloc `intent` renseigné (#{ucs.count { |u| u['intent'] }} / #{ucs.size}).\n" + (gaps.empty? ? '' : "\n> ⚠ **Écart : #{gaps.size} endpoint(s) sans intent** — #{gaps.sort.map { |g| "`#{g}`" }.join(', ')}\n") + index.sort.map { |a, l| "\n## #{a}\n#{l.sort.join("\n")}\n" }.join) unless index.empty?
if check
  stale = files.reject { |p, c| File.file?(p) && File.read(p) == c }.keys + (Dir[File.join(out, '**', '*.md')] - files.keys)
  stale.sort.each { |p| puts "W GI: #{p.delete_prefix("#{root}/")} : guide d'implémentation absent, périmé ou édité à la main (régénérer avec intent_to_md.rb #{root})" } if File.directory?(out)
  exit
end
FileUtils.rm_rf(out)
files.each { |p, c| FileUtils.mkdir_p(File.dirname(p)); File.write(p, c) }
puts "consommateurs : #{consumers.values.sum(&:size)} usecase(s) consumer rattaché(s) à #{consumers.size} endpoint(s)"
puts "OK implementation-guide : #{index.values.sum(&:size)} endpoint(s) documenté(s) (#{ucs.count { |u| u['intent'] }} avec intent)"
