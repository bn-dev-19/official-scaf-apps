---
name: scaf-write-enums
description: Cadrer les énumérations d'un projet SCAF (statuts, états, types, niveaux) dans enums.yml pour qu'un même concept ait les mêmes valeurs dans toutes les apps, et traiter les écarts relevés par tools/enums.rb. À utiliser quand on ajoute un champ de statut/type, une valeur d'enum, ou qu'on aligne deux apps.
---

# Cadrer et aligner les enums

Format : `../02-file-formats.md §15` · règles : `../03-rules-and-validation.md §EN` · outil : `../tools/enums.rb`.

## Principe
Un champ de statut, d'état, de type ou de niveau n'est jamais une chaîne libre : c'est un `enum` fixe (MAJUSCULES). Un **concept** (« statut d'une candidature », « état d'analyse d'un CV ») a un seul ensemble de valeurs, identique dans toutes les apps et tous les sens (réponse, requête, filtre). On ne peut pas avoir `a,b,c` dans une app et `A,b,C` dans une autre pour le même concept.

## Procédure
1. Nommer le **contexte** du champ (de quoi est-ce le statut ? vu par qui ?). Deux contextes distincts = deux concepts, même si les valeurs coïncident aujourd'hui (état d'analyse global d'un CV ≠ état d'un matching pour une offre).
2. Chercher un concept existant dans `enums.yml` ; sinon en créer un : `id` kebab-case, `description`, `values` fixes (quoter `YES`/`NO`).
3. Lier chaque occurrence : `endpoint` (id ou glob) + `field` (chemin pointé sous `data`/corps, ou nom de query) + `in` si besoin. Réponses d'action (création, suppression) qui n'exposent qu'un état : `subset: true`.
4. Écrire/aligner les `enum:` des specs **et** les mocks (valeurs en MAJUSCULES, exactement celles du concept), puis `ruby scaf/_agent-kit/tools/enums.rb scaf/<v>`.
5. Écart « valeurs libres » : ajouter l'`enum` à la spec. Écart « manque/en trop » : décider quelle valeur est juste (concept) et corriger le champ ; ne pas élargir un concept pour faire taire un écart sans accord.
6. Champ non cadré (EN3) : le rattacher à un concept existant, créer un concept, ou l'exclure (`ignore`) s'il n'est pas une énumération (MIME, schema.org…).

## Pièges
`YES`/`NO` non quotés = booléens YAML · une liaison trop large (`endpoint: "*"`) attrape des champs d'autres contextes · un chemin faux donne EN2 · `subset: true` n'est pas un moyen de contourner un écart sur une lecture.
