---
name: scaf-check-mocks
description: Vérifier champ par champ que les mocks (succès, erreurs, requêtes given) respectent leur spec, surtout les valeurs d'enum, avec tools/check_mocks.rb, puis corriger les contrats. À lancer après toute modification de mocks ou de spec et avant de générer les OpenAPI.
---

# Vérifier les mocks contre la spec

Règles : `../03-rules-and-validation.md §MK` (M1–M4). La **référence est la spec** (`enum:`, `nullable`, `format`, `errors`), pas `enums.yml`.

## Lancer

```bash
ruby scaf/_agent-kit/tools/check_mocks.rb scaf/$(cat scaf/.scaf-version) [--app <slug>] [--endpoint <id>] [--quiet]
```
Sortie : `E|W <règle> <endpoint>/<mock> <chemin> : <message>`, puis un résumé par règle. `--quiet` = résumé seul. Code retour 1 s'il y a des E. Cible : 0 E.

## Lire et corriger (dans le contrat)

| Message | Cause | Correction |
|---|---|---|
| `M4 … "X" hors enum [...]` | valeur de mock absente du `enum:` du champ | corriger la valeur du mock, **ou** ajouter la valeur à l'`enum:` de la spec si elle est légitime (puis `enums.yml` + `enums.rb`) |
| `M4 champ à valeurs fermées sans enum:` | champ de typologie aux valeurs MAJUSCULES sans `enum:` | déclarer `enum:` dans la spec (`scaf-write-enums`) |
| `M4 le mock ne contient pas la valeur V` | un mock `enum-<chemin>-V` ne porte pas V | mettre V à ce chemin (ou renommer le mock) |
| `W M4 valeurs d'enum jamais couvertes` | une valeur d'enum n'a aucun mock | ajouter un mock `enum-<chemin>-<VALEUR>` ; pour un champ de tableau, un mock groupé `enum-<chemin avec *>-ALL` (éléments à valeurs différentes) (`scaf-write-mocks`) |
| `M2 code non déclaré pour le statut` | `error.code` absent de `errors` de la spec pour ce statut | ajouter l'erreur à la spec ou corriger le code/statut du mock |
| `M2 $.error.message / cause / resolution` | texte du mock ≠ spec | aligner le mock sur la spec (ou la spec si c'est elle la mauvaise version) |
| `M2 $.message` | `message` racine ≠ `error.message` | recopier `error.message` |
| `W M2 nom attendu error-<code>` | nom du mock ≠ code | renommer le mock |
| `M1 champ absent du mock` / `null sur un champ non nullable` / `clé non déclarée` | mock incomplet ou spec incomplète | compléter le mock, ou déclarer `nullable: true` / le champ dans la spec |
| `M3 … paramètre / clé non déclaré`, `champ absent du mock` | `given` incohérent avec `request.*` | corriger `given` ou déclarer le champ dans `request.*` |

Exemptions volontaires : mocks `error-invalid*` / `error-validation*` (requête invalide voulue), upload `format: binary` (métadonnées du fichier).

## Boucle

1. `check_mocks.rb … --endpoint <id>` sur l'endpoint modifié, puis sur toute la version avant livraison.
2. Corriger le contrat (réécriture ciblée du bloc `mocks`, relire le diff).
3. `contracts_to_openapi.rb` (`0 E, 0 W`), `audit.rb` et `enums.rb` : aucune nouvelle erreur.
