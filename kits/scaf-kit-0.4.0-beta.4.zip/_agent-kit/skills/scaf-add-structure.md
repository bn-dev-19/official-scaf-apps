---
name: scaf-add-structure
description: Ajouter, renommer ou supprimer une app, un module ou une feature dans un projet SCAF (scaf/vN/input) en gardant project.parts, contracts, openapi.parts et database/visual synchronisés. À utiliser dès qu'on touche à la hiérarchie app → module → feature.
---

# Ajouter / renommer / supprimer app, module, feature

Prérequis : lire `../README.md` (règles d'or) et `../01-structure.md`. Version cible = contenu de `scaf/.scaf-version`.
Notation : `V=scaf/<version>/input`.

## 1. Ajouter une APP (`<app>`)

1. Choisir `<app>` (slug valide, unique). Choisir un `label` libre pour les contrats.
2. Créer `V/project.parts/apps/<app>.yml` (`name`, `slug`, `description`, `tagline?`, `principe?`, `seo?`) — format : `02 §3`.
3. Éditer `V/project.parts/_index.yml` : ajouter `- slug: <app>` + `modules: []` dans `apps:`.
4. Éditer `V/contracts/_index.yml` : ajouter `- slug: <app>` / `label: <label>` / `modules: []`.
5. (Après avoir ajouté des modules/features/endpoints) `V/openapi.parts/_index.yml` gagne l'app ; régénérer les parts.

## 2. Ajouter un MODULE (`<module>` dans `<app>`)

1. Créer `V/project.parts/modules/<app>.<module>.yml` : `name`, `slug`, `description`, `app: <app>`, `more?`, `explication?`,
   `dependencies?` (slugs de modules **existants**), `features: []` — format `02 §4`.
2. `V/project.parts/_index.yml` : ajouter le slug dans `apps[<app>].modules` **et** `- { app: <app>, slug: <module> }` dans `modules:` (ordre global).
3. `V/contracts/_index.yml` : ajouter sous l'app `- { slug: <module>, name: <module>, features: [] }`.
4. Créer le dossier `V/contracts/apps/<app>/<module>/` (créé par la 1re feature).
5. Si un acteur est nouveau : l'ajouter dans `V/project.parts/actors.yml`.
6. Dépendances : relire `03 §A8` — le projet actuel contient déjà des cycles (baseline) ; **ne pas en ajouter de nouveaux**.

## 3. Ajouter une FEATURE (`<feature>` dans `<app>/<module>`)

1. Projet : dans `V/project.parts/modules/<app>.<module>.yml`, ajouter sous `features:` :
   ```yaml
   - name: <Nom lisible>
     slug: <feature>
     description: <≥ 15 caractères>
     more: ...
     explication: ...
     atomic_actions:
       - { name: <Verbe + objet>, description: ..., actor: <id acteur existant> }
   ```
2. Contrats : créer `V/contracts/apps/<app>/<module>/<feature>.yml` :
   ```yaml
   slug: <feature>
   name: <feature>
   endpoints: []
   ```
   puis ajouter `<feature>` dans `contracts/_index.yml` (`apps[<app>].modules[<module>].features`).
   Écrire les endpoints avec `scaf-write-endpoint-contract.md` + `scaf-write-mocks.md`.
3. **Ne pas** nommer un endpoint comme la feature (invariant A13).
4. Dériver les use cases : un usecase par atomic action backend exposée en HTTP → `scaf-write-usecase.md`.
5. Régénérer `openapi.parts/` (ou le compléter à la main, `../04-tooling-map.md`) ; ajouter `<feature>` dans `openapi.parts/_index.yml`.
6. Base de données : `scaf-database-visual.md` si de nouvelles entités apparaissent.
7. `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>`.

## 4. Renommer un slug (app / module / feature)

Un slug est une **clé** répétée dans de nombreux fichiers : traiter comme une migration complète.

| Slug renommé | À modifier |
|---|---|
| app `a→b` | `project.parts/apps/a.yml→b.yml` (+`slug:`) ; `project.parts/_index.yml` (2 endroits : `apps[].slug`, `modules[].app`) ; chaque `modules/a.<m>.yml → b.<m>.yml` (+ `app:`) ; `contracts/_index.yml` ; dossier `contracts/apps/a→b` ; dossier `openapi.parts/a→b` (+ `a.yml→b.yml`, tags `a / ...`) ; **ids d'endpoints** qui contiennent `a` (convention : `<méthode>-<chemin>`, et le chemin contient souvent `/a/`) ⇒ si le chemin change, id/`spec.endpoint.id`/`mocks.endpoint`/`usecase.openapi.operationId`/nom du fichier openapi part changent aussi |
| module `m→n` | `project.parts/modules/<app>.m.yml→<app>.n.yml` (+`slug`) ; les `dependencies:` des autres modules ; `_index.yml` ×3 ; dossier `contracts/apps/<app>/m→n` ; dossier `openapi.parts/<app>/m→n` (+`m.yml→n.yml`, tags) ; `database/visual/_visual_m.yml→_visual_n.yml` (+`name:`) |
| feature `f→g` | `slug` dans `project.parts/modules/...` ; `contracts/apps/<app>/<module>/f.yml→g.yml` (+`slug:`) ; `_index.yml` (contracts + openapi) ; dossier `openapi.parts/<app>/<module>/f→g` (+`f.yml→g.yml`, tags `... / f`) |

Changer un **chemin d'endpoint** (ex. ajout `/v1`) : modifier `path` (contrat), `spec.http.path`, `mocks[].given.path`, regénérer openapi part ; garder l'`id` stable
sauf demande explicite (les use cases le référencent).
Terminer par : `grep -rn "<ancien-slug>" scaf/<version>/input` → doit être vide, puis l'audit.

## 5. Supprimer

Retirer l'entrée de **chaque** index, supprimer les fichiers/dossiers correspondants (`project.parts`, `contracts`, `openapi.parts`),
les use cases dont `openapi.operationId` pointe vers les endpoints supprimés, les tables/enums DB devenus orphelins, les `dependencies:` des autres modules.
Le backend supprimerait de toute façon les orphelins non listés : mieux vaut être explicite.

## Définition de « terminé »

- [ ] audit : aucune **nouvelle** E (baseline v1 : 1 E, cycles A8)
- [ ] mêmes slugs dans project / contracts / openapi.parts / DB
- [ ] aucun fichier hors index, aucune entrée d'index sans fichier
