---
name: scaf-write-mocks
description: Écrire ou compléter la chaîne JSON `mocks` d'un endpoint SCAF (cas nominal, erreurs, enums, nullables, booléens, tableaux vides, cas critique) en respectant nommage, enveloppe de réponse et couverture. À utiliser après avoir écrit/modifié une spec.
---

# Écrire les mocks d'un endpoint

Formats : `../02-file-formats.md §7.2` · nommage & couverture : `../03-rules-and-validation.md §F` · enveloppe : `§E`.

## Principe

Les mocks sont des scénarios `given → expect` servant à (1) tester/valider le contrat, (2) alimenter les `examples` OpenAPI (le **nom** du mock devient la clé d'exemple),
(3) simuler le backend côté front. Ils doivent être **déterministes, concrets et conformes à la spec**.

## Procédure

1. Lire la spec de l'endpoint (`http.response.status`, `errors[]`, enums, champs `nullable`/`required:false`, tableaux).
2. **Calculer les mocks recommandés** :
   `nb_statuts(distincts, succès + erreurs)` + `max(1, Σ valeurs d'enum du body de REQUÊTE)` + `(nullables>0 ? min(2^nullables, 8) : 0)` + `(liste ? 1 : 0)` + `1 (critical)`.
3. **Écrire, dans cet ordre** :
   | Mock | Contenu |
   |---|---|
   | `nominal-<status>` | cas heureux complet, toutes les propriétés remplies |
   | `error-<code>` ×N | un par entrée `errors[]`, `body.error` **identique** à la spec (code, message, cause, resolution) |
   | `enum-<champ>-<VALEUR>` | une valeur d'enum par mock (champs enum du body de requête) |
   | `nullable-<combinaison>` | champs nullables à `null` (combinaisons, max 8) |
   | `boolean-<champ>-<true\|false>` | les deux états d'un booléen significatif |
   | `empty-arrays` | tous les tableaux vides, `message` adapté (« Aucune offre trouvée ») |
   | `critical-all-edge-cases` | nullables `null`, booléens `false`, dernière valeur d'enum, tableaux vides, `success: true` |
   | `nominal-…`/libres | cas métier (`low-confidence`, `nominal-multiple`) |
4. **Squelette d'un mock** :
   ```json
   {
     "name": "nominal-200",
     "description": "Cas nominal — <ce qui est démontré>",
     "given": {
       "method": "GET",
       "path": "/api/v1/candidate/ia/match/3a4b5c6d-7e8f-4a1b-9c0d-2e3f4a5b6c7d/offers",
       "headers": { "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.<payload>.<sig>" },
       "query": {},
       "body": null
     },
     "expect": {
       "status": 200,
       "headers": { "Content-Type": "application/json" },
       "body": { "success": true, "message": "Matching IA calculé avec succès", "data": { } }
     }
   }
   ```
5. **Règles de contenu** :
   - `given.path` : **chemin concret** avec préfixe `/api/v1`, UUID réels à la place de `{cv_id}` ; le même UUID réapparaît dans `expect.body.data`.
   - `given.headers` : `Authorization: Bearer <jwt factice>` si `auth.required` ; `{}` pour le mock `error-unauthorized`.
   - `given.query` : valeurs en **chaînes** (`"page": "1"`). `given.body` : objet conforme au body de requête, ou `null`.
   - `expect.status` ∈ {`response.status`} ∪ {`errors[].status`}.
   - Succès : `{ "success": true, "message": "...", "data": ... }` — **jamais** `data.data`.
   - Erreur : `{ "success": false, "message": "<=error.message>", "error": { "code", "message", "cause", "resolution" } }` — `code` et `message` **exactement** ceux de la spec ; `cause`/`resolution` seulement s'ils sont déclarés.
   - Types respectés : UUID valides, dates ISO 8601 `Z`, nombres non quotés, enums en MAJUSCULES, `matched_skills` etc. = tableaux de chaînes.
   - Données réalistes en français (noms de sociétés, villes), pas de `"string"` / `"foo"`.
   - Noms de mocks : minuscules, tirets ; l'`error-<code>` est le code en **minuscules** (`error-not_found`).
   - Un nom de mock peut se répéter dans un endpoint (les exemples OpenAPI seront suffixés `_2`…) mais préférer des noms uniques.
6. **Format de fichier** : dans la feature, `mocks: |-` suivi d'un JSON indenté 2 espaces (comme les voisins) ; `"endpoint": "<id>"` en tête ; pas de commentaires, pas de virgule finale.
7. Vérifier : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` → pas de W de type D/E sur l'endpoint ; la ligne `F` indique s'il manque encore des mocks.
8. Régénérer l'`openapi.parts` de l'endpoint (les exemples viennent des mocks).

## Cas particuliers

- **Couverture des enums** : chaque valeur d'un `enum:` de réponse doit apparaître dans au moins un mock (sinon `W M4` de `check_mocks.rb`). Champ simple : un mock `enum-<chemin>-<VALEUR>` (clone du nominal, champ patché). Champ dans un tableau d'objets : un seul mock `enum-<chemin avec *>-ALL` dont les éléments portent chacun une valeur différente (dupliquer le 1er élément, identifiants distincts, `total` = nombre d'éléments).

- **Mocks 2xx complets** (exigé par `tools/contracts_to_openapi.rb`, voir `03 §OA`) : chaque mock de succès contient **tous** les champs de la spec, mêmes noms et même casse ; un champ `nullable` sans valeur vaut `null` (jamais omis) ; un champ que le cas ne peut pas avoir doit être déclaré `nullable: true` dans la spec. Un seul format de date par champ (AAAA-MM-JJ **ou** horodatage) dans tous les mocks. Après modification : `ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/<version> --parts-out <tmp> --out <tmp>` doit afficher `0 E, 0 W`. Lancer aussi `ruby scaf/_agent-kit/tools/check_mocks.rb scaf/<version> --endpoint <id>` : aucune valeur d'enum hors du `enum:` du champ, erreurs identiques à la spec (`skills/scaf-check-mocks.md`).

- **Auth publique** (`auth.type: none`) : pas de mock `error-unauthorized`.
- **Login/refresh** : le token renvoyé dans `data` est factice mais syntaxiquement un JWT (3 segments).
- **Pagination** : `data` contient les items ; `pagination: { current_page, page_size, total_items, total_pages }` (entiers, hors `data`) ; mock `nominal-pagination` page 2/3 et `empty-arrays` page 1/0. Autres formes (`data: null`, `warnings`) : `02-file-formats.md §7.3`.
- **Upload / body binaire** : décrire `given.body` avec des métadonnées (nom, taille, type) et non le binaire.
- **Statut 201** : mock `nominal-201`, pas `nominal-200`.
- **Réparation automatique de l'app** (à imiter) : corps sans enveloppe → `{success:true, data:<body>, message:"Récupération/Création/Mise à jour/Suppression réussie"}` ; `data.data` → aplati ; `{data:{error}}` → `{success:false, error}`.
