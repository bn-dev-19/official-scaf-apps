---
name: scaf-version-fork
description: Lister, forker, activer, comparer ou supprimer une version d'un projet SCAF (dossiers scaf/v1, scaf/v1-beta, fichier .scaf-version) sans le backend. À utiliser avant tout changement risqué ou pour préparer une nouvelle version d'API.
---

# Gérer les versions SCAF

Modèle : `01-structure.md §Versions`. Une version est un dossier `scaf/<nom>` **commençant par `v`** et contenant `input/`.

## Lister / connaître la version active

```bash
cat scaf/.scaf-version            # ex. v1
ls -d scaf/v*/                    # toutes les versions
```
Sans `.scaf-version`, l'outillage prend le dernier dossier `v*` par ordre alphabétique.

## Forker `vA → vB`

```bash
test ! -e scaf/vB                 # la cible ne doit pas exister
cp -R scaf/vA scaf/vB             # copie récursive de TOUT (input/ + output/)
printf 'vB' > scaf/.scaf-version  # le fork devient actif
ruby scaf/_agent-kit/tools/audit.rb scaf/vB
```
Puis adapter `project.parts/info.yml` (`version: 1.1.0`, `1.0.0-beta`…) ; les chemins d'API gardent `/api/v1` sauf **nouvelle version d'API** (voir ci-dessous).
Nom de version : `v<chiffres>[-suffixe]`, sans espace ni `/`. Ne jamais créer d'autre dossier commençant par `v` dans `scaf/`.

## Activer

`printf 'vX' > scaf/.scaf-version` — `scaf/vX/input` doit exister.

## Supprimer

Interdit sur la version active : activer une autre version d'abord, puis `rm -rf scaf/vX`.

## Comparer deux versions

```bash
diff -rq scaf/vA/input scaf/vB/input
diff -ru scaf/vA/input/project.parts scaf/vB/input/project.parts
diff -ru scaf/vA/input/contracts     scaf/vB/input/contracts
```
Cas réel : `v1-beta` est un fork plus ancien de `v1` (`version: 1.0.0-beta`, modules sans `more`/`explication`/`dependencies`, atomic_actions sans `actor`, enrichis ensuite dans `v1`).
Lecture d'un diff : un endpoint ajouté/supprimé = fichier feature modifié + fichier `openapi.parts/.../<id>.yml` ajouté/supprimé ; une table = `_visual_*.yml`.

## Introduire une nouvelle version d'API (`/api/v2`)

1. Forker `vA → vB` (version SCAF).
2. Dans `vB`, pour chaque endpoint modifié : changer le préfixe `/api/v1 → /api/v2` dans `path` (contrat), `spec.http.path`, **tous** les `mocks[].given.path`, `usecase.openapi.path` ; garder les ids ou les suffixer de façon cohérente (cascade : spec, mocks, use cases, openapi part).
3. Régénérer `openapi.parts/` ; auditer.
4. Un endpoint inchangé reste en `/api/v1` : le préfixe ne doit pas être un mélange accidentel — l'audit exige seulement `^/(api/)?v\d+/`.

## Règles

- Toute modification d'une version active livrée = fork d'abord si le changement est cassant.
- Les fichiers `*.bak.*` ou `.history` ne font pas partie du modèle : les ignorer.
- Ne pas copier `node_modules`/builds dans `scaf/`.
