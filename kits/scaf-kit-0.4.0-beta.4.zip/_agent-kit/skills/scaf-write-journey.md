---
name: scaf-write-journey
description: Écrire un parcours (journeys/<id>.journey.yml) qui décompose une question métier en étapes logiques reliées aux endpoints, pour savoir si l'app (ou plusieurs apps) est complète ; les étapes sans endpoint deviennent des écarts. À utiliser pour vérifier qu'un besoin in-app ou inter-app est réalisable avec les endpoints existants.
---

# Écrire un parcours de vérification

Format : `../02-file-formats.md §13` · règles : `../03-rules-and-validation.md §J` · outil : `../tools/journeys.rb`.

## Principe
Un parcours répond à une **question** (« un candidat peut-il postuler puis connaître le résultat ? »). On liste les étapes dans l'ordre logique,
chacune avec l'acteur, l'endpoint qui la réalise, ce dont elle a besoin (`needs`) et ce qu'elle produit (`produces`). Si aucun endpoint ne
réalise l'étape : `endpoint: null` + `gap:` — c'est un **écart à combler**, pas une erreur. Ne jamais inventer un endpoint pour combler.

## Procédure
1. Formuler la question en une phrase ; lister les acteurs et les apps traversées (`apps:`).
2. Dérouler le besoin de bout en bout, **sans regarder les endpoints** : une étape = une action d'un acteur (voir l'offre, téléverser, postuler, traiter, consulter le résultat).
3. Pour chaque étape, chercher l'endpoint : `grep -rn "^    - id: .*<mot>" scaf/v1/input/contracts/` ; sinon `endpoint: null` et `gap:` (dire ce qui manque).
   Étape purement UI (saisie, navigation) : `usecase: <id d'un usecase frontend/shared>`.
4. Renseigner les données : `produces` (ids et états : `application_id`, `application.status=SUBMITTED`) puis `needs` de l'étape suivante.
   Utiliser les **noms de champs réels** des réponses (`cv_id`, `offer_id`) ; états inter-apps sous la forme `entité.champ=VALEUR|VALEUR`.
5. Cas selon le contexte (accepté/refusé, avec/sans CV) : une étape par branche, produisant des états alternatifs.
6. `after:` seulement si l'étape ne suit pas la précédente du tableau (étapes parallèles, jointures).
7. Lancer `ruby scaf/_agent-kit/tools/journeys.rb scaf/<v>` et lire le rapport : écarts, étapes bloquées (dépendent d'un écart), complétude par app, endpoints hors parcours.
8. `ruby scaf/_agent-kit/tools/audit.rb scaf/<v>` : aucune nouvelle E.

## Lire le résultat
- `[ÉCART]` : endpoint manquant → candidat à création (voir `scaf-write-endpoint-contract.md`) ; `[BLOQUÉE]` : débloquée par la création de l'écart en amont.
- W J5 : donnée requise jamais produite (étape manquante ou nom incohérent) ; W J6/J7 : l'endpoint n'expose pas le champ annoncé (renommer le jeton ou compléter la spec).
- Une app est « complète » quand ses parcours n'ont ni écart ni étape bloquée.

## Pièges
`endpoint:` avec un id inventé → E J2 · jetons nommés différemment d'une étape à l'autre (`offerId` / `offer_id`) → W J5 · oublier `app:` sur une étape qui appelle une autre app que la sienne → la contrainte `calls_app` ne la voit pas.
