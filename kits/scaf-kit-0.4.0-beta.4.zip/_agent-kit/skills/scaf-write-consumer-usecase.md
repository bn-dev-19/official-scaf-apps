---
name: scaf-write-consumer-usecase
description: Écrire les usecases `consumer` d'une app (comment l'app cliente appelle un endpoint producer : écran, étapes UI, réactions aux erreurs), un par endpoint appelé, à partir du contrat, de l'intent producer et du code frontend existant, puis régénérer le guide. À utiliser pour documenter l'usage côté consommateur des endpoints d'une app.
---

# Usecases consumer (usage des endpoints côté app cliente)

Format commun : `../02-file-formats.md §5` · outil : `../tools/intent_to_md.rb` (ajoute la section « Côté consommateur » à la page de l'endpoint).

## Principe
Le usecase `producer` dit ce que le serveur fait ; le usecase `consumer` dit **comment l'app cliente appelle l'endpoint** : depuis quel écran/action, ce qu'elle charge avant, ce qu'elle valide en local, ce qu'elle affiche, comment elle réagit à chaque erreur. **Un fichier par endpoint de l'app** (pas par parcours : les journeys sont incomplets et servent à détecter les écarts).

## Convention
- Fichier `usecases/consumer/<app>/consume-<operationId>.usecase.yml` ; `id: consume-<operationId>` (= nom de fichier) ; `type: consumer` ; `name` unique (ex. « Demander un retrait depuis l'écran de retrait »).
- `openapi: { operationId, method, path }` **identiques** au contrat ; `<app>` = app du contrat.
- `description` : écran(s) concerné(s) désigné(s) par leur **route ou leur nom fonctionnel** (ex. `/wallet/withdraw`, « écran de retrait ») et rôle de l'appel. **Aucune référence technique** : ni nom de fichier ou d'extension (`.tsx`, `.php`, `.dart`…), ni composant, fonction, hook, variable, constante de mock ou bibliothèque : la techno du client n'est pas connue du scaf et peut changer. Écran non encore existant : écrire « Écran à créer » + route attendue déduite des flux ; jamais d'écran inventé.
- `input.schema` = ce que l'écran fournit (saisies, état local) ; `output.schema` = ce que l'écran affiche/conserve après réponse (clés lisibles, pas la recopie complète du corps).
- `steps` : 3 à 6 étapes UI, codes `ui.verbe_objet`, ordre continu (charger les prérequis [endpoints `before` de l'intent producer], valider en local, appeler, afficher le succès/navigation, gérer les erreurs). Pas d'étape vide.
- `errors` : les codes/statuts du contrat qui demandent une réaction ; `description` = **réaction UI** (message, champ ciblé, redirection, rechargement). 401 : renvoi à la connexion, une seule fois si c'est la règle commune.
- `calls: [{ usecase: <id producer>, when: ... }]` vers le usecase producer de l'endpoint.
- Pas de bloc `intent` (il vit côté producer). Ne pas inventer : ce qui n'est pas dans le contrat, l'intent producer ou le code frontend se déduit prudemment ou se signale en fin de rapport.

## Procédure
1. Lire le contrat, le usecase producer + son `intent`, puis chercher dans le frontend existant (code lu comme **source d'information seulement**) l'écran qui porte l'action ; ne reporter dans le usecase que le comportement visible (route, libellés, boutons, champs), jamais le code.
2. Écrire le fichier (exemple : `usecases/consumer/user/consume-post-wallet-withdrawals.usecase.yml`).
3. `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` (0 erreur) puis `ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/<version>`.
