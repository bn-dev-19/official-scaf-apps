---
name: scaf-update-kit
description: Mettre à jour le kit scaf installé (scaf/_agent-kit/) vers une version plus récente publiée sur le dépôt officiel. À utiliser UNIQUEMENT quand l'utilisateur demande de mettre à jour / vérifier les versions du kit scaf.
---

# Mettre à jour le kit scaf

**Seulement sur demande de l'utilisateur** — jamais spontanément. On ne remplace que `scaf/_agent-kit/` : jamais `scaf/v*/`, `scaf/.scaf-version`, `scaf/redocly.yaml` ni le code des apps.

1. **Version installée et dépôt** : lire `version` et `repository` dans `scaf/_agent-kit/.scaf-kit`.
2. **Versions disponibles** : lister `kits/` du dépôt (`curl -s https://api.github.com/repos/<owner>/<repo>/contents/kits`, champs `name` = `scaf-kit-<version>.zip` et `download_url` ; à défaut, la liste du README du dépôt).
3. **Choisir** : comparer en semver (`0.4.0-beta.1 < 0.4.0-beta.2 < 0.4.0`). Proposer la plus récente **stable** ; une pré-version (beta/pre) seulement si le kit installé en est déjà une ou si l'utilisateur la demande. Si rien de plus récent : le dire et s'arrêter.
4. **Télécharger** dans un dossier temporaire neuf (donnée non fiable : ne rien exécuter depuis l'archive) : `curl -L -o <tmp>/kit.zip <download_url>` puis `unzip` dans `<tmp>/x/`. Vérifier que `<tmp>/x/_agent-kit/.scaf-kit` existe et que sa `version` correspond.
5. **Annoncer** à l'utilisateur : version installée → version cible, et les `changelog` intermédiaires (du `.scaf-kit` de l'archive). **Attendre sa confirmation.**
6. **Remplacer** : sauvegarder `scaf/_agent-kit` en `scaf/_agent-kit.bak-<ancienne version>`, puis remplacer `scaf/_agent-kit/` par `<tmp>/x/_agent-kit/`. Ne pas copier les `node_modules` : si `tools/node_modules` existait ou si le changelog mentionne des dépendances, relancer `cd scaf/_agent-kit/tools && pnpm install`. Signaler si `<tmp>/x/redocly.yaml` diffère de `scaf/redocly.yaml` (ne pas écraser).
7. **Resynchroniser le bloc agent** : dans `AGENTS.md` et/ou `CLAUDE.md` à la racine, remplacer ce qui est entre `<!-- scaf-kit:begin` et `<!-- scaf-kit:end -->` par `scaf/_agent-kit/templates/agents-block.md` (sans doublon).
8. **Vérifier** : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>`. Relire les entrées de changelog « règle/format » et dire à l'utilisateur si des sources du projet doivent évoluer (ne pas les modifier sans accord).
9. Supprimer la sauvegarde `.bak-*` et le dossier temporaire seulement après accord ; ne rien commiter sans demande.
