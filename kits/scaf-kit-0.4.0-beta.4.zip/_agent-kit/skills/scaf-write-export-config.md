---
name: scaf-write-export-config
description: Écrire ou modifier la config de génération de l'app cible d'un projet SCAF (export-configs/nextjs.json ou nestjs.json, override par app <techno>.<app>.json, secrets via $var: dans variables.yml) et la valider avec tools/export_configs.rb. À utiliser quand on change une option Next.js (auth, i18n, pwa, seo…) ou NestJS (orm, auth, modules, cors…), qu'une app doit différer d'une autre, ou qu'un secret apparaît dans la config.
---

# Écrire une config d'export

Sens, défaut et source de chaque option : `../05-export-config-reference.md` (**ne jamais deviner une option absente de la référence : la demander ou l'omettre ; `scaf` = se déduit du projet, `choix` = à demander**) · Format : `../02-file-formats.md §11` · règles : `../03-rules-and-validation.md §EC` (nextjs) / `§NS` (nestjs) · outil : `../tools/export_configs.rb`.

## Principe
`nextjs.json` = valeurs **communes** à toutes les apps. Ce qui diffère pour une app (ex. back-office sans PWA ni push) va dans `nextjs.<app>.json` : un patch partiel, pas une copie. `projectName`, description, tagline, `seo.siteName/baseUrl` viennent de `project.parts/apps/<app>.yml`, pas de la config.

## Procédure
1. Option commune → `nextjs.json`. Option propre à une app → `nextjs.<slug>.json` (`{technology, app, config:{…seulement les clés qui changent…}}`).
2. Secret ou clé générée (VAPID…) : jamais en clair. L'ajouter à `contracts/variables.yml` (`sensitive: true` pour une clé privée) et écrire `"$var:NOM"` dans la config.
3. `customFontPath` : chemin relatif au dépôt (`_ui-kits/…`), jamais absolu.
4. Vérifier : `ruby scaf/_agent-kit/tools/export_configs.rb scaf/<v>` puis `--resolve <techno> <app>` pour lire le résultat fusionné ; enfin `audit.rb`.

## Pièges
Un tableau dans un override **remplace** celui de la base (pas de concaténation) · `pushNotifications.enabled: true` exige `pwa: true` dans la config **effective** · overrides et `$var:` = convention du kit : un outil externe qui ne les connaît pas ne les appliquera pas · NestJS : `auth: better_auth` impose `bodyParser: false` ; les secrets (`databaseUrl`, `authSecret`) vont en `$var:` ; `nestjs.json` est un format propre au kit (un outil externe peut ne pas le lire).
