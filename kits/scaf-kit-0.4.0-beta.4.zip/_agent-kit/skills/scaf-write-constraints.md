---
name: scaf-write-constraints
description: Écrire/modifier constraints.yml pour cadrer une app, un module ou une feature (ce qui est permis, interdit ou limité) avec des règles vérifiables automatiquement par tools/journeys.rb. À utiliser pour fixer des garde-fous de faisabilité avant ou pendant la conception.
---

# Écrire des contraintes de faisabilité

Format : `../02-file-formats.md §14` · règles : `../03-rules-and-validation.md §K`.

## Procédure
1. Dire la contrainte en français (`why:`), puis choisir la **portée** (`scope: {app, module, feature}`, cumulatifs) la plus étroite possible.
2. Choisir la forme vérifiable : `calls_app`, `endpoint_auth`, `actors_only`, `http_method`, `usecase_per_endpoint`, `max_endpoints`, `needs_journey`, `endpoint_absent`, `forbid_field`, `response_fields`, `request_fields`, `endpoint_exists`, `forbid_response_field`, `error_codes`.
   Aucune ne convient → ne pas contourner : la règle reste en prose (W K1 « non vérifiable ») jusqu'à ce qu'une forme soit ajoutée à `tools/journeys.rb`.
3. `kind` : `forbid` (interdit), `require` (obligatoire), `limit` (plafond). `severity: warn` pour une contrainte cible, pas encore respectée.
4. `id` unique, kebab-case. Lancer `ruby scaf/_agent-kit/tools/journeys.rb scaf/<v>` : une violation = E (ligne `K`) avec l'endpoint ou l'étape fautif.
5. Ne pas adapter la règle pour la faire passer : soit le projet viole le cadrage (le corriger), soit le cadrage est faux (en discuter).

## Pièges
Portée vide (W K1) → faute de slug · `calls_app` ne contrôle que les étapes de parcours (écrire les parcours pour qu'il serve) · `http_method` n'a de sens qu'avec `forbid`.
