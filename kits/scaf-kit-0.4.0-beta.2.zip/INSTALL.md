# Intégrer le kit scaf à un projet (pour l'utilisateur ou son agent)

Le kit est déjà dans `scaf/` (contenu de l'archive : `_agent-kit/`, `.scaf-version`, `redocly.yaml`, `v0/`). Il reste à **faire connaître `scaf/` aux agents** (Claude Code, opencode, Codex…) :

1. Vérifier que `scaf/_agent-kit/.scaf-kit` et `scaf/.scaf-version` existent.
2. Ajouter le bloc `scaf/_agent-kit/templates/agents-block.md` (de `<!-- scaf-kit:begin` à `<!-- scaf-kit:end -->`) à la **racine du projet** :
   - dans `AGENTS.md` (lu par opencode, Codex…) ;
   - dans `CLAUDE.md` (lu par Claude Code) : soit le même bloc, soit une ligne `@AGENTS.md` si AGENTS.md le contient déjà.
   Créer le fichier s'il n'existe pas. Le bloc déjà présent (mêmes marqueurs) se **remplace**, il ne s'ajoute pas une 2e fois.
3. Vérifier : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` (`<version>` = contenu de `scaf/.scaf-version`).
