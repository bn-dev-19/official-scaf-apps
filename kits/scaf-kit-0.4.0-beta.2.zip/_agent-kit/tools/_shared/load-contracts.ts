// Lit scaf/<version>/input/contracts/ (format du kit) → SpecInputApp[].
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { load as yamlLoad } from "js-yaml";
import type { SpecInputApp } from "./spec-loader";

type Index = { apps?: { slug: string; modules?: { slug: string; features?: string[] }[] }[] };
type FeatureFile = { endpoints?: { id?: string; name?: string; method?: string; path?: string; spec?: string; mocks?: string }[] };

export function loadContracts(versionDir: string): SpecInputApp[] {
  const root = join(versionDir, "input", "contracts");
  const index = yamlLoad(readFileSync(join(root, "_index.yml"), "utf8")) as Index;
  return (index.apps ?? []).map((app) => ({
    slug: app.slug,
    modules: (app.modules ?? []).map((mod) => ({
      slug: mod.slug,
      features: (mod.features ?? []).map((feat) => {
        const file = yamlLoad(readFileSync(join(root, "apps", app.slug, mod.slug, `${feat}.yml`), "utf8")) as FeatureFile;
        return { slug: feat, endpoints: file.endpoints ?? [] };
      }),
    })),
  }));
}
