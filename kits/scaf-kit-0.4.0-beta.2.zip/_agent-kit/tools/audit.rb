#!/usr/bin/env ruby
# Audit de cohérence d'une version SCAF, sans app ni backend.
# Usage : ruby scaf/_agent-kit/tools/audit.rb scaf/v1      (ruby + psych livrés avec macOS/Linux courants)
# Sortie : liste E (erreur) / W (avertissement) + compteurs ; code retour 1 s'il y a des E.
# Règles : voir ../03-rules-and-validation.md (références A1..A13, D, E).
require 'yaml'
require 'date'
require 'json'

root = ARGV[0] or abort 'usage: audit.rb <scaf/vN>'
inp  = File.join(root, 'input')
abort "introuvable: #{inp}" unless Dir.exist?(inp)

E = []; W = []
err  = ->(r, m) { E << "E #{r}: #{m}" }
warn_ = ->(r, m) { W << "W #{r}: #{m}" }
SLUG = /\A[a-z][a-z0-9_-]*\z/
load_yaml = lambda do |p|
  YAML.safe_load(File.read(p), permitted_classes: [Date, Time])
rescue StandardError => e
  err.('YAML', "#{p}: #{e.message.lines.first.strip}"); nil
end
p_ = ->(*a) { File.join(inp, *a) }

# ── index ─────────────────────────────────────────────────────────────
pi = load_yaml.(p_.('project.parts', '_index.yml')) || { 'modules' => [], 'apps' => [] }
ci = load_yaml.(p_.('contracts', '_index.yml'))     || { 'apps' => [] }
oi = File.exist?(p_.('openapi.parts', '_index.yml')) ? load_yaml.(p_.('openapi.parts', '_index.yml')) : nil

# ── project.parts (B, A2, A7-A9) ─────────────────────────────────────
info = load_yaml.(p_.('project.parts', 'info.yml')) || {}
%w[name version description].each { |k| err.('B', "info.#{k} manquant/trop court") if info[k].to_s.strip.size < 3 }
actors = File.exist?(p_.('project.parts', 'actors.yml')) ? (load_yaml.(p_.('project.parts', 'actors.yml')) || []) : []
actor_ids = actors.map { |a| a['id'] }
err.('B', 'project.parts/actors.yml absent ou vide (obligatoire)') if actors.empty?
actors.each do |a|
  err.('B', "acteur #{a['id'].inspect}: id invalide") unless a['id'].to_s =~ SLUG
  err.('B', "acteur #{a['id']}: type #{a['type'].inspect} invalide") unless %w[human machine program external data].include?(a['type'])
end
err.('B', 'acteurs: ids dupliqués') if actor_ids.uniq.size != actor_ids.size

app_slugs = []
(pi['apps'] || []).each do |a|
  f = p_.('project.parts', 'apps', "#{a['slug']}.yml")
  (err.('A2', "fichier manquant #{f}"); next) unless File.exist?(f)
  d = load_yaml.(f) or next
  err.('B', "#{f}: slug != nom de fichier") if d['slug'] != a['slug']
  err.('B', "#{f}: slug invalide") unless d['slug'].to_s =~ SLUG
  err.('B', "#{f}: name/description manquants") if d['name'].to_s.size < 2 || d['description'].to_s.size < 2
  warn_.('B', "#{f}: description < 15 caractères") if d['description'].to_s.size < 15
  if (u = d.dig('seo', 'baseUrl')) && u !~ %r{\Ahttps?://[^/\s]+}
    err.('B', "#{f}: seo.baseUrl invalide")
  end
  app_slugs << a['slug']
end

mods = {}  # slug => [app, doc]
(pi['modules'] || []).each do |m|
  app = m['app'].to_s.empty? ? '__noapp__' : m['app']
  f = p_.('project.parts', 'modules', "#{app}.#{m['slug']}.yml")
  (err.('A2', "fichier manquant #{f}"); next) unless File.exist?(f)
  d = load_yaml.(f) or next
  err.('B', "module #{m['slug']}: slug du fichier différent") if d['slug'] != m['slug']
  err.('B', "module #{m['slug']}: slug dupliqué") if mods.key?(m['slug'])
  err.('B', "module #{m['slug']}: slug invalide") unless m['slug'] =~ SLUG
  %w[name description].each { |k| err.('B', "module #{m['slug']}.#{k} manquant") if d[k].to_s.size < 2 }
  warn_.('B', "module #{m['slug']}: description < 15 car.") if d['description'].to_s.size < 15
  warn_.('A9', "module #{m['slug']}: app #{d['app'].inspect} non déclarée") if !app_slugs.empty? && !app_slugs.include?(d['app'])
  warn_.('A9', "module #{m['slug']}: app du fichier (#{d['app']}) != index (#{m['app']})") if d['app'].to_s != m['app'].to_s
  mods[m['slug']] = [m['app'], d]
  fs = {}
  (d['features'] || []).each do |ft|
    %w[name slug description].each { |k| err.('B', "#{m['slug']}/#{ft['slug']}.#{k} manquant") if ft[k].to_s.size < 2 }
    err.('B', "#{m['slug']}: feature #{ft['slug']} dupliquée") if fs[ft['slug']]
    err.('B', "#{m['slug']}: feature slug invalide #{ft['slug'].inspect}") unless ft['slug'].to_s =~ SLUG
    fs[ft['slug']] = true
    warn_.('B', "#{m['slug']}/#{ft['slug']}: atomic_actions absentes") if (ft['atomic_actions'] || []).empty?
    (ft['atomic_actions'] || []).each do |aa|
      err.('B', "#{m['slug']}/#{ft['slug']}: atomic_action sans name (>=3)") if aa['name'].to_s.size < 3
      warn_.('A7', "#{m['slug']}/#{ft['slug']}: acteur #{aa['actor'].inspect} inconnu") if aa['actor'] && !actor_ids.empty? && !actor_ids.include?(aa['actor'])
    end
  end
end
# dépendances + cycles (A8)
graph = mods.transform_values { |(_, d)| d['dependencies'] || [] }
graph.each { |s, deps| deps.each { |x| err.('A8', "module #{s}: dépendance #{x} inconnue") unless mods.key?(x) } }
seen = {}; stack = {}; cycles = []
dfs = lambda do |s|
  seen[s] = stack[s] = true
  (graph[s] || []).each do |x|
    next unless graph.key?(x)
    if !seen[x] then dfs.(x) elsif stack[x] then cycles << "#{s} → #{x}" end
  end
  stack.delete(s)
end
graph.each_key { |s| dfs.(s) unless seen[s] }
err.('A8', "#{cycles.size} arête(s) fermant un cycle de dépendances, ex. #{cycles.first(3).join(' ; ')}") unless cycles.empty?

# ── contracts (A1, A3-A5, A13, D, E) ─────────────────────────────────
ids = Hash.new { |h, k| h[k] = [] }
eps = []
cfeat = {} # [app,module] => [features]
(ci['apps'] || []).each do |a|
  (a['modules'] || []).each do |m|
    cfeat[[a['slug'], m['slug']]] = m['features'] || []
    (m['features'] || []).each do |ft|
      f = p_.('contracts', 'apps', a['slug'], m['slug'], "#{ft}.yml")
      (err.('A1', "fichier manquant #{f}"); next) unless File.exist?(f)
      d = load_yaml.(f) or next
      err.('A1', "#{f}: slug (#{d['slug']}) != nom de fichier") if d['slug'] != ft
      (d['endpoints'] || []).each { |e| eps << [a['slug'], m['slug'], ft, e]; ids[e['id']] << f }
    end
  end
end
ids.each { |i, fs| err.('A4', "id d'endpoint dupliqué #{i} (#{fs.uniq.size} fichiers)") if fs.size > 1 }

ep_meta = {}
envelope_ok = lambda do |body|
  body.is_a?(Hash) && body['success'] != nil && (body.key?('data') || body.key?('error'))
end
eps.each do |app, mod, ft, e|
  r = "#{app}/#{mod}/#{ft}/#{e['id']}"
  err.('A13', "#{r}: id d'endpoint == slug de feature") if e['id'] == ft
  err.('D', "#{r}: id invalide") unless e['id'].to_s =~ SLUG
  err.('D', "#{r}: path ne commence pas par /") unless e['path'].to_s.start_with?('/')
  warn_.('D', "#{r}: path sans préfixe de version (#{e['path']})") unless e['path'].to_s =~ %r{\A/(api/)?v[^/{}]+/}
  err.('D', "#{r}: méthode invalide #{e['method'].inspect}") unless %w[GET POST PUT PATCH DELETE].include?(e['method'])
  sp = begin; YAML.safe_load(e['spec'].to_s); rescue StandardError => ex; err.('D', "#{r}: spec YAML invalide (#{ex.message.lines.first.strip})"); nil; end
  mk = begin; JSON.parse(e['mocks'].to_s); rescue StandardError; err.('D', "#{r}: mocks JSON invalide"); nil; end
  next unless sp.is_a?(Hash)
  err.('A4', "#{r}: spec.endpoint.id (#{sp.dig('endpoint', 'id')}) != id") if sp.dig('endpoint', 'id') != e['id']
  http = sp['http'] || (err.('D', "#{r}: spec sans section http"); {})
  err.('A5', "#{r}: method/path du contrat != spec.http") if http['method'] != e['method'] || http['path'] != e['path']
  resp = http['response'] || (err.('D', "#{r}: pas de http.response"); {})
  warn_.('D', "#{r}: http.response.status manquant") unless resp['status'].is_a?(Integer)
  body = resp['body']
  if body.nil? then warn_.('E', "#{r}: missing-response-body")
  elsif !(body['properties'] || {}).key?('data') then warn_.('E', "#{r}: not-api-response (properties.data absent)")
  elsif (body.dig('properties', 'data', 'properties') || {}).key?('data') then err.('E', "#{r}: double-nested-data (spec)")
  elsif !body['properties'].key?('warnings') then warn_.('E', "#{r}: warnings-missing (properties.warnings absent : à déclarer au niveau de data, optionnel)")
  end
  errs = resp['errors'] || []
  ep_meta[e['id']] = { guard: http.dig('auth', 'guard'), method: e['method'], statuses: errs.map { |x| x['status'] } }
  errs.each do |x|
    %w[status code description message].each { |k| warn_.('D', "#{r}: erreur #{x['code'] || x['status']} sans #{k}") if x[k].nil? || x[k].to_s.empty? }
  end
  # enums MAJUSCULES + pas de "format: enum:"
  walk = lambda do |n|
    case n
    when Hash
      if n['enum'].is_a?(Array)
        n['enum'].each { |v| warn_.('RULE9', "#{r}: enum #{v.inspect} pas en MAJUSCULES") if v.to_s != v.to_s.upcase }
      end
      warn_.('RULE9', "#{r}: format: #{n['format']} (utiliser enum:)") if n['format'].to_s.start_with?('enum')
      n.each_value { |v| walk.(v) }
    when Array then n.each { |v| walk.(v) }
    end
  end
  walk.(sp)
  next unless mk.is_a?(Hash)
  err.('A4', "#{r}: mocks.endpoint (#{mk['endpoint']}) != id") if mk['endpoint'] != e['id']
  scen = mk['mocks'] || []
  warn_.('D', "#{r}: aucun mock") if scen.empty?
  codes = ([resp['status']] + errs.map { |x| x['status'] }).compact
  qp = (sp.dig('http', 'request', 'query') || []).map { |x| x['name'].to_s }
  qp.each { |q| warn_.('E', "#{r}: query-snake-case (#{q} : paramètres en snake_case)") if q =~ /[a-z][A-Z]/ }
  warn_.('E', "#{r}: query-sans-400 (paramètres de query #{qp.first(3).join(', ')}… sans réponse 400/422)") if !qp.empty? && (codes & [400, 422]).empty?
  scen.each do |s|
    n = "#{r}:#{s['name']}"
    st = s.dig('expect', 'status')
    err.('D', "#{n}: expect.status invalide") unless st.is_a?(Integer) && st.between?(100, 599)
    warn_.('D', "#{n}: status #{st} absent de la spec") unless codes.include?(st)
    gp = s.dig('given', 'path').to_s
    warn_.('D', "#{n}: given.path sans préfixe de version") unless gp =~ %r{\A/(api/)?v[^/{}]+/}
    warn_.('D', "#{n}: given.path contient un placeholder {…}") if gp.include?('{')
    eb = s.dig('expect', 'body')
    if st.is_a?(Integer) && st >= 400
      ee = eb.is_a?(Hash) ? eb['error'] : nil
      if ee.nil? then warn_.('E', "#{n}: mock d'erreur sans body.error")
      else
        warn_.('D', "#{n}: error.code #{ee['code']} (#{st}) non déclaré dans la spec") unless errs.any? { |x| x['status'] == st && x['code'] == ee['code'] }
        warn_.('D', "#{n}: error.message vide") if ee['message'].to_s.strip.empty?
      end
      warn_.('E', "#{n}: error-in-data-wrapper") if eb.is_a?(Hash) && eb['data'].is_a?(Hash) && eb['data'].key?('error')
    elsif eb
      warn_.('E', "#{n}: enveloppe {success,data} absente") unless envelope_ok.(eb)
      err.('E', "#{n}: double-nested-data (mock)") if eb.is_a?(Hash) && eb['success'] != nil && eb['data'].is_a?(Hash) && eb['data'].key?('data')
      if eb.is_a?(Hash) && eb['data'].is_a?(Hash)
        warn_.('E', "#{n}: pagination-in-data (page/page_size/total ou data.pagination : pagination va hors data)") if (eb['data'].key?('page') && eb['data'].key?('page_size')) || eb['data'].key?('pagination')
      end
      if eb.is_a?(Hash) && eb.key?('pagination')
        pg = eb['pagination']
        ok = pg.is_a?(Hash) && pg.keys.sort == %w[current_page page_size total_items total_pages] && pg.values.all? { |v| v.is_a?(Integer) }
        warn_.('E', "#{n}: pagination-shape (attendu current_page, page_size, total_items, total_pages entiers)") unless ok
        if ok && eb['data'].is_a?(Hash)
          arr = (eb['data'].values.find { |v| v.is_a?(Array) } || [])
          gq = s.dig('given', 'query'); gq = {} unless gq.is_a?(Hash)
          bad = []
          # Une liste vide a 0 page (ceil) ou 1 page (convention du backend, Q71 : helper de pagination commun).
          expected_pages = pg['page_size'] > 0 ? (pg['total_items'].to_f / pg['page_size']).ceil : 0
          bad << 'total_pages != ceil(total_items/page_size)' if pg['total_pages'] != expected_pages && !(pg['total_items'] == 0 && pg['total_pages'] == 1)
          bad << 'éléments > page_size' if arr.size > pg['page_size']
          bad << 'total_items < éléments' if pg['total_items'] < arr.size
          bad << 'current_page > total_pages' if !arr.empty? && pg['current_page'] > pg['total_pages']
          bad << 'current_page != query.page' if gq['page'].to_i > 0 && gq['page'].to_i != pg['current_page']
          bad << 'page_size != query.page_size' if gq['page_size'].to_i > 0 && gq['page_size'].to_i != pg['page_size']
          warn_.('E', "#{n}: pagination-consistency (#{bad.join(' ; ')})") unless bad.empty?
        end
      end
      if eb.is_a?(Hash) && eb.key?('warnings')
        ok = eb['warnings'].is_a?(Array) && eb['warnings'].all? { |w| w.is_a?(Hash) && w['title'].is_a?(String) && w['description'].is_a?(String) && w['tips'].is_a?(Array) }
        warn_.('E', "#{n}: warnings-shape (attendu tableau de {title, description, tips[]})") unless ok
      end
    end
  end
  # couverture recommandée (03 §F), indicatif
  nb = codes.uniq.size + 1 + 1
  warn_.('F', "#{r}: #{scen.size} mocks < ~#{nb} (statuts+empty/critical minimum)") if scen.size < nb
end

# A3 : project.parts == contracts
mods.each do |slug, (app, d)|
  pf = (d['features'] || []).map { |x| x['slug'] }.sort
  cf = (cfeat[[app, slug]] || []).sort
  err.('A3', "#{app}/#{slug}: features projet #{(pf - cf).inspect} absentes des contrats / contrats #{(cf - pf).inspect} absentes du projet") if pf != cf
end
cfeat.each_key { |(a, m)| err.('A3', "contracts #{a}/#{m}: module absent de project.parts") unless mods.key?(m) && mods[m][0] == a }

# ── usecases (C, A6, A11) ────────────────────────────────────────────
epids = ids.keys
ep_app = eps.to_h { |a, _, _, e| [e['id'], a] }
ep_by_id = eps.to_h { |_, _, _, e| [e['id'], e] }
unames = {}
uc_ops = {}; cons_ops = {}; no_intent = 0; before_edges = Hash.new { |h, k| h[k] = [] }
known_tokens = (Dir[p_.('contracts', '**', '*.yml')] + Dir[p_.('database', 'visual', '**', '*.yml')] + Dir[p_.('journeys', '*.yml')] +
                [p_.('enums.yml'), p_.('constraints.yml')]).select { |f| File.file?(f) }
               .flat_map { |f| File.read(f).scan(/\b[A-Z][A-Z0-9_]{3,}\b/) }.to_h { |t| [t, true] }
db_tables = Dir[p_.('database', 'visual', '_visual_*.yml')].reject { |f| f.end_with?('_visual_enums.yml') }
            .flat_map { |f| ((load_yaml.(f) || {})['tables'] || []).map { |t| t['name'] } }.to_h { |t| [t, true] }
Dir[p_.('usecases', '**', '*.usecase.yml')].sort.each do |f|
  d = load_yaml.(f) or next
  r = File.basename(f)
  err.('A11', "#{r}: id (#{d['id']}) != nom de fichier") if "#{d['id']}.usecase.yml" != r
  uc_app = File.basename(File.dirname(f)); uc_type = File.basename(File.dirname(File.dirname(f)))
  err.('C', "#{r}: doit être dans usecases/#{d['type']}/<app>/ (dossier actuel : usecases/#{uc_type}/#{uc_app}/)") if uc_type != d['type']
  err.('C', "#{r}: dossier d'app #{uc_app.inspect} absent de project.parts") unless (pi['apps'] || []).any? { |a| a['slug'] == uc_app }
  if (cap = ep_app[d.dig('openapi', 'operationId')])
    err.('C', "#{r}: dossier d'app #{uc_app} != app du contrat #{cap}") if cap != uc_app
  end
  err.('C', "#{r}: name dupliqué") if unames[d['name']]; unames[d['name']] = true
  err.('C', "#{r}: type invalide #{d['type'].inspect}") unless %w[producer consumer shared].include?(d['type'])
  err.('C', "#{r}: description < 5") if d['description'].to_s.size < 5
  %w[input output].each { |k| err.('C', "#{r}: #{k}.schema manquant") unless d.dig(k, 'schema').is_a?(Hash) }
  (d['steps'] || []).each do |s|
    err.('C', "#{r}: step sans code/order") if s['code'].to_s.empty? || !s['order'].is_a?(Integer)
    err.('C', "#{r}: step severity #{s['severity'].inspect}") if s['severity'] && !%w[critical high medium low].include?(s['severity'])
  end
  err.('C', "#{r}: steps manquants") unless d['steps'].is_a?(Array)
  warn_.('C', "#{r}: errors absent") unless d['errors'].is_a?(Array)
  (d['errors'] || []).each { |x| err.('C', "#{r}: erreur sans code/status") if x['code'].to_s.empty? || !x['status'].is_a?(Integer) }
  if (o = d['openapi'])
    err.('A6', "#{r}: operationId #{o['operationId']} inexistant dans contracts") unless epids.include?(o['operationId'])
    err.('C', "#{r}: openapi.method invalide") unless %w[GET POST PUT PATCH DELETE].include?(o['method'])
    err.('C', "#{r}: openapi.path doit commencer par /") unless o['path'].to_s.start_with?('/')
    warn_.('C', "#{r}: openapi.path sans /vN (#{o['path']})") unless o['path'].to_s =~ %r{\A/(api/)?v[^/{}]+/}
  elsif d['type'] == 'producer'
    warn_.('C', "#{r}: usecase producer sans bloc openapi")
  end
  # C : schémas du usecase producer recoupés avec le contrat (le contrat fait foi) — noms de champs de premier niveau
  if d['type'] == 'producer' && (ce = ep_by_id[d.dig('openapi', 'operationId')]) && (h = (YAML.safe_load(ce['spec'].to_s, aliases: true) || {})['http'])
    ci_ = ((h.dig('request', 'query') || []).map { |q| q['name'] } + (h.dig('request', 'body', 'properties') || {}).keys + ce['path'].to_s.scan(/\{(\w+)\}/).flatten).uniq
    ui_ = (d.dig('input', 'schema') || {}).keys
    warn_.('C', "#{r}: input.schema diffère du contrat (contrat seul : #{(ci_ - ui_).inspect}, usecase seul : #{(ui_ - ci_).inspect})") if ci_.sort != ui_.sort
    if (dd = h.dig('response', 'body', 'properties', 'data')) && dd['properties']
      co_ = dd['properties'].keys; uo_ = (d.dig('output', 'schema') || {}).keys - ['pagination']
      warn_.('C', "#{r}: output.schema diffère de response.data du contrat (contrat seul : #{(co_ - uo_).inspect}, usecase seul : #{(uo_ - co_).inspect})") if co_.sort != uo_.sort
    end
  end
  (d['type'] == 'consumer' ? (cons_ops[uc_app] ||= {}) : uc_ops)[d.dig('openapi', 'operationId')] = true if d['openapi']
  if !d['intent'] && d['type'] == 'producer' && d['openapi']
    no_intent += 1
    warn_.('C', "#{r}: intent manquant — endpoint sans guide d'implémentation (écart sévère, voir skills/scaf-write-intent.md)")
  end
  if (n = d['intent'])
    err.('C', "#{r}: intent.purpose manquant (>= 10)") if n['purpose'].to_s.size < 10
    (n['actors'] || []).each { |a| err.('C', "#{r}: intent.actors #{a.inspect} absent de actors.yml") unless actor_ids.include?(a) }
    seen_t = {}
    (n['tables'] || []).each do |t|
      err.('C', "#{r}: intent.tables.table #{t['table'].inspect} absente de database/visual") unless db_tables[t['table']]
      err.('C', "#{r}: intent.tables.access #{t['access'].inspect} invalide (read|write)") unless t['access'].nil? || %w[read write].include?(t['access'])
      err.('C', "#{r}: intent.tables.why de #{t['table']} doit être un texte non vide") if t.key?('why') && !(t['why'].is_a?(String) && !t['why'].strip.empty?)
      warn_.('C', "#{r}: intent.tables : table #{t['table']} en double") if seen_t[t['table']]
      seen_t[t['table']] = true
    end
    (n['depends_on'] || []).each do |dep|
      err.('C', "#{r}: intent.depends_on.when #{dep['when'].inspect} invalide") unless %w[before during after].include?(dep['when'])
      err.('C', "#{r}: intent.depends_on.why manquant") if dep['why'].to_s.empty?
      if dep['endpoint'] then err.('C', "#{r}: intent.depends_on endpoint inconnu #{dep['endpoint']}") unless epids.include?(dep['endpoint'])
      elsif !dep['usecase'] then err.('C', "#{r}: intent.depends_on sans endpoint ni usecase") end
      if (t = dep['endpoint']) && ep_meta[t] && (me = d.dig('openapi', 'operationId'))
        warn_.('C', "#{r}: intent.depends_on auto-référence #{t}") if t == me
        warn_.('C', "#{r}: intent.depends_on #{t} est dans une autre app (#{ep_app[t]} != #{ep_app[me]})") if ep_app[t] != ep_app[me]
        before_edges[me] << t if dep['when'] == 'before' && t != me
      end
    end
    # cohérence avec le contrat : garde ↔ acteurs, erreurs métier mentionnées, valeurs d'enum connues
    txt = [n['purpose'], *n['preconditions'], *n['effects'], n['consumer_notes'], *(n['depends_on'] || []).map { |x| x['why'] }].compact.join(' ')
    if (m = ep_meta[d.dig('openapi', 'operationId')])
      guarded = actors.select { |a| a['guards'] }
      if m[:guard] && !guarded.empty? && !(n['actors'] || []).any? { |a| (actors.find { |x| x['id'] == a } || {})['guards'].to_a.include?(m[:guard]) }
        warn_.('C', "#{r}: intent.actors #{n['actors'].inspect} incompatibles avec la garde #{m[:guard]} du contrat")
      end
    end
    txt.scan(/\b[A-Z][A-Z0-9_]{3,}\b/).uniq.each do |t|
      warn_.('C', "#{r}: valeur #{t} citée dans l'intent mais inconnue des contrats/enums/DB/journeys") unless known_tokens[t]
    end
  end
end
before_edges.each_key do |a|
  seen = {}; stack = before_edges[a].dup
  while (x = stack.pop)
    (err.('C', "intent.depends_on : cycle de dépendances before autour de #{a}"); break) if x == a
    next if seen[x]; seen[x] = true; stack.concat(before_edges.fetch(x, []))
  end
end
# couverture consommateur : une app qui a au moins un usecase consumer doit tous les couvrir
cons_ops.each do |capp, done|
  (epids.select { |e| ep_app[e] == capp } - done.keys).each { |e| warn_.('C', "#{e}: aucun usecase consumer pour l'app #{capp} (usecases/consumer/#{capp}/consume-#{e}.usecase.yml)") }
end
(epids - uc_ops.keys).each do |e|
  no_intent += 1
  warn_.('C', "#{e}: endpoint sans usecase donc sans intent — endpoint sans guide d'implémentation (écart sévère)")
end
all_uc = Dir[p_.('usecases', '**', '*.usecase.yml')].map { |f| File.basename(f, '.usecase.yml') }
Dir[p_.('usecases', '**', '*.usecase.yml')].each do |f|
  d = load_yaml.(f) or next
  ((d['links'] || []) + (d['calls'] || []) + (d.dig('intent', 'depends_on') || []).select { |x| x['usecase'] }).each do |l|
    err.('C', "#{File.basename(f)}: référence à un usecase inconnu #{l['usecase']}") unless all_uc.include?(l['usecase'])
  end
end

# ── openapi.parts (A10) ──────────────────────────────────────────────
if oi
  eps.each do |app, mod, ft, e|
    f = p_.('openapi.parts', app, mod, ft, "#{e['id']}.yml")
    warn_.('A10', "openapi.parts: fichier manquant pour #{e['id']} → régénérer") unless File.exist?(f)
  end
else
  warn_.('A10', 'openapi.parts/_index.yml absent → à générer')
end

# ── database/visual (A12) ────────────────────────────────────────────
enum_names = []
ef = p_.('database', 'visual', '_visual_enums.yml')
enum_names = (load_yaml.(ef) || {})['enums'].to_a.map { |x| x['name'] } if File.exist?(ef)
Dir[p_.('database', 'visual', '_visual_*.yml')].sort.each do |f|
  next if f.end_with?('_visual_enums.yml')
  d = load_yaml.(f) or next
  err.('DB', "#{File.basename(f)}: nom de fichier != _visual_#{d['name']}.yml") if File.basename(f) != "_visual_#{d['name']}.yml"
  warn_.('DB', "#{File.basename(f)}: module #{d['name']} sans module de contrat homonyme") unless mods.key?(d['name'])
  tn = {}
  (d['tables'] || []).each do |t|
    err.('DB', "#{d['name']}: table #{t['name']} dupliquée") if tn[t['name']]; tn[t['name']] = true
    err.('DB', "#{d['name']}.#{t['name']}: kind #{t['kind'].inspect} manquant ou invalide (entity|pivot|internal|audit)") if !t['external'] && (t['kind'].nil? || !%w[entity pivot internal audit].include?(t['kind'])) || t['external'] && t['kind'] && !%w[entity pivot internal audit].include?(t['kind'])
    (t['columns'] || []).each do |c|
      err.('DB', "#{d['name']}.#{t['name']}.#{c['name']}: type manquant") if c['type'].to_s.empty?
      err.('DB', "#{d['name']}.#{t['name']}.#{c['name']}: type inconnu #{c['type']}") unless c['type'].to_s.empty? || c['type'].to_s =~ /\A(uuid|text|integer|bigint|decimal|boolean|datetime|date|jsonb|enum|varchar\(\d+\)|decimal\(\d+,\s*\d+\))\z/
      if (r = c['references'])
        %w[onDelete onUpdate].each { |k| err.('DB', "#{d['name']}.#{t['name']}.#{c['name']}: references.#{k} #{r[k].inspect} invalide (cascade|set null|restrict|no action)") if r[k] && !['cascade', 'set null', 'restrict', 'no action'].include?(r[k]) }
        err.('DB', "#{d['name']}.#{t['name']}.#{c['name']}: onDelete/onUpdate 'set null' exige nullable: true") if [r['onDelete'], r['onUpdate']].include?('set null') && !c['nullable']
      end
      if c['type'] == 'enum'
        if c['enumRef'].to_s.empty? then err.('A12', "#{d['name']}.#{t['name']}.#{c['name']}: enum sans enumRef")
        elsif !enum_names.include?(c['enumRef']) then err.('A12', "#{d['name']}.#{t['name']}.#{c['name']}: enumRef #{c['enumRef']} absent de _visual_enums.yml")
        end
      end
    end
    err.('DB', "#{d['name']}.#{t['name']}: table external sans colonne primary (cible de FK)") if t['external'] && !(t['columns'] || []).any? { |c| c['primary'] }
    (t['indexes'] || []).each do |ix|
      cols = (t['columns'] || []).map { |c| c['name'] }
      (ix['columns'] || []).each { |c| err.('DB', "#{d['name']}.#{t['name']}: index #{ix['name']} → colonne #{c} inconnue") unless cols.include?(c) }
      w = "#{d['name']}.#{t['name']}: index #{ix['name']}"
      err.('DB', "#{w} : columns et expressions vides") if Array(ix['columns']).empty? && Array(ix['expressions']).empty?
      err.('DB', "#{w} : method #{ix['method'].inspect} invalide (btree|hash|gin|gist|brin)") if ix['method'] && !%w[btree hash gin gist brin].include?(ix['method'])
      err.('DB', "#{w} : un index gin/gist/brin ne peut pas être unique") if ix['unique'] && %w[gin gist brin].include?(ix['method'])
      err.('DB', "#{w} : where vide") if ix.key?('where') && ix['where'].to_s.strip.empty?
      err.('DB', "#{w} : expressions doit être une liste de chaînes non vides") if ix.key?('expressions') && !(ix['expressions'].is_a?(Array) && ix['expressions'].all? { |e| e.is_a?(String) && !e.strip.empty? })
    end
    ck = {}
    (t['checks'] || []).each do |k|
      w = "#{d['name']}.#{t['name']}: check #{k['name'].inspect}"
      err.('DB', "#{w} : name et expression requis") if k['name'].to_s.empty? || k['expression'].to_s.strip.empty?
      err.('DB', "#{w} : nom dupliqué") if ck[k['name']]; ck[k['name']] = true
    end
    if (r = t['rls'])   # A13 : RLS (PostgreSQL)
      w = "#{d['name']}.#{t['name']}: rls"
      if !r.is_a?(Hash) then err.('A13', "#{w} : doit être un objet (enabled, owner, admin, policies)")
      else
        cn = (t['columns'] || []).map { |c| c['name'] }
        warn_.('A13', "#{w} : table external, RLS à déclarer dans son module propriétaire") if t['external']
        err.('A13', "#{w}.enabled : booléen requis") unless [true, false].include?(r['enabled'])
        Array(r['owner']).each { |c| err.('A13', "#{w}.owner : colonne #{c} inconnue") unless cn.include?(c) }
        err.('A13', "#{w}.admin : liste de rôles (chaînes)") unless Array(r['admin']).all? { |a| a.is_a?(String) && !a.empty? }
        pn = {}
        Array(r['policies']).each do |x|
          err.('A13', "#{w}.policies : name et using (ou withCheck) requis") if x['name'].to_s.empty? || (x['using'].to_s.strip.empty? && x['withCheck'].to_s.strip.empty?)
          err.('A13', "#{w}.policies #{x['name']} : for #{x['for'].inspect} invalide (select|insert|update|delete|all)") if x['for'] && !%w[select insert update delete all].include?(x['for'])
          err.('A13', "#{w}.policies : nom #{x['name']} dupliqué") if pn[x['name']]; pn[x['name']] = true
        end
        err.('A13', "#{w} : enabled sans owner, admin ni policies (aucune ligne accessible)") if r['enabled'] && Array(r['owner']).empty? && Array(r['admin']).empty? && Array(r['policies']).empty?
      end
    end
  end
end

# parcours + contraintes (J, K) : seulement si input/journeys/ ou constraints.yml existe
`ruby #{File.join(__dir__, 'journeys.rb')} #{root} --quiet`.each_line do |l|
  l.start_with?('E ') ? E << l.chomp : (W << l.chomp if l.start_with?('W '))
end

# guide d'implémentation dérivé (G) : W si absent/périmé/édité à la main (seulement si output/implementation-guide/ existe)
`ruby #{File.join(__dir__, 'intent_to_md.rb')} #{root} --check`.each_line { |l| W << l.chomp if l.start_with?('W ') }

# alignement des enums (EN) : seulement si input/enums.yml existe
`ruby #{File.join(__dir__, 'enums.rb')} #{root} --quiet`.each_line do |l|
  l.start_with?('E ') ? E << l.chomp : (W << l.chomp if l.start_with?('W '))
end

# configs d'export (EC) : seulement si input/export-configs/ existe
`ruby #{File.join(__dir__, 'export_configs.rb')} #{root} --quiet`.each_line do |l|
  l.start_with?('E ') ? E << l.chomp : (W << l.chomp if l.start_with?('W '))
end

puts E, W
puts "\n#{File.basename(root)}: #{(pi['apps'] || []).size} apps · #{mods.size} modules · #{cfeat.values.flatten.size} features · " \
     "#{eps.size} endpoints · #{all_uc.size} usecases — #{E.size} erreur(s), #{W.size} avertissement(s)" \
     "#{no_intent > 0 ? " — ⚠ #{no_intent} endpoint(s) sans intent" : ''}"
exit(E.empty? ? 0 : 1)
