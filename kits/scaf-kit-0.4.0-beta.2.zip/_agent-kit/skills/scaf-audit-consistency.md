---
name: scaf-audit-consistency
description: Auditer la cohérence d'une version SCAF (index vs fichiers, slugs, ids d'endpoints, use cases, mocks vs specs, enums, DB) avec tools/audit.rb et corriger les écarts. À lancer après toute modification de scaf/ et avant de livrer.
---

# Audit de cohérence

## Lancer

```bash
ruby scaf/_agent-kit/tools/audit.rb scaf/$(cat scaf/.scaf-version)
```
Ruby + `psych` sont fournis par défaut (macOS). Sortie : lignes `E` (erreur, code retour 1) et `W` (avertissement), puis un résumé de compteurs.
Chaque ligne cite la règle (`A1…A13`, `B`, `C`, `D`, `E`, `F`, `DB`, `RULE9`) définie dans `../03-rules-and-validation.md`.

## Baseline connue de `v1` (à ne pas « corriger » sans décision métier)

| Constat | Détail |
|---|---|
| `E A8` — 18 arêtes fermant un cycle de dépendances | les `dependencies:` des modules sont fortement cycliques (la validation de l'app les signale aussi). Ne pas en ajouter ; à traiter par un refactoring des dépendances |
| `W A10` — 1 endpoint sans fichier `openapi.parts` | `get-recruitment-portal-private-offers` → régénérer |
| `W C` — 42 use cases : `openapi.path` sans `/v1` ; 1 use case backend sans bloc `openapi` (`classify-profile-domain`) | corriger le chemin pour qu'il égale celui du contrat |
| `W F` — ~85 endpoints sous la couverture indicative de mocks | compléter avec `scaf-write-mocks.md` |

Résumé de référence : `v1: 4 apps · 12 modules · 40 features · 194 endpoints · 64 usecases`.
Après ton travail : **aucune nouvelle E ni nouveau W** par rapport à cette baseline.

## Boucle de correction

1. Lancer l'audit, noter la baseline (compteurs).
2. Corriger les `E` d'abord, groupe par règle (A1 → A13, puis B, C, D, E, DB).
3. Corriger les `W` des fichiers que tu as touchés.
4. Relancer ; comparer au compteur initial.

## Correspondance règle → correction

| Règle | Correction type |
|---|---|
| A1 / A2 | créer le fichier manquant ou retirer l'entrée d'index ; `slug:` = nom de fichier |
| A3 | aligner les features entre `project.parts/modules/<app>.<module>.yml` et `contracts/_index.yml` |
| A4 | `spec.endpoint.id` / `mocks.endpoint` = `id` ; id unique (renommer en cascade) |
| A5 | `method`/`path` du contrat = `spec.http.*` |
| A6 | `usecase.openapi.operationId` = id d'endpoint existant (corriger l'un des deux) |
| C (intent incohérent) | `actors` incompatibles avec la garde : corriger l'acteur (ou `guards` dans `actors.yml`) ; valeur inconnue : corriger la faute ou aligner contrat/enum ; `depends_on` : auto-référence, autre app, cycle `before` à retirer |
| C (intent manquant) | W sévère non bloquant : renseigner l'`intent` via `skills/scaf-write-intent.md` (ou créer le usecase manquant) ; ne jamais l'inventer |
| C (intent) | corriger `intent.actors` (id de `actors.yml`) ou `depends_on` (id d'endpoint/usecase existant, `when` ∈ before/during/after, `why` requis) |
| A7 | ajouter l'acteur dans `actors.yml` ou corriger l'id |
| A8 | retirer une dépendance ; pas de retour vers un module qui dépend déjà de soi |
| A10 | régénérer `openapi.parts` |
| A11 | renommer le fichier en `<id>.usecase.yml` |
| A12 | créer l'enum dans `_visual_enums.yml` ou corriger `enumRef` |
| A13 | renommer l'endpoint (≠ slug de feature) |
| B/C | compléter les champs requis (voir `02`) |
| D | chemin avec `/api/v1`, statut du mock dans la spec, `error.code`+`message` conformes, pas de `{param}` dans `given.path` |
| E | enveloppe `{success,message,data}` ; pas de `data.data` ; erreur à la racine |
| RULE9 | enums en MAJUSCULES, `enum:` et non `format:` |
| F | ajouter des mocks (nominal, error-*, enum-*, empty-arrays, critical-all-edge-cases) |

## Ce que l'audit **ne** vérifie **pas**

La qualité métier (pertinence des steps, justesse des descriptions), la conformité complète JSON-schema des mocks vs la spec (types champ par champ),
la validité du SQL, la fraîcheur du contenu de `openapi.parts` (existence seulement) — relire à la main ou régénérer. Il ne modifie jamais de fichier.
