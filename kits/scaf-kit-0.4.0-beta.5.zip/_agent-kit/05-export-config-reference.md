# 05 — Référence des configs d'export (sens, défaut, effet, source)

Complète `02-file-formats.md §11` (forme) : ici, **ce que chaque option fait** et **d'où vient sa valeur**. Règle : une option absente de cette référence ne se devine pas — la demander à l'utilisateur ou l'omettre.

Les valeurs et défauts Next.js sont ceux du format de config Next.js que le kit décrit (`02 §11`). NestJS : voir §NestJS.

**Colonne « Source »** : `scaf` = se déduit des fichiers du projet (ne pas redemander) · `choix` = décision de l'utilisateur (le demander) · `fixe` = valeur technique sans choix métier.

**Lecture « Effet »** : *code* = l'option change des fichiers, dépendances ou config générés ; *brief* = l'option est consignée dans le guide IA (`AGENTS.md`) pour orienter celui qui implémente, sans code propre.

## Next.js

### Projet et outillage
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `projectName` | string · `my-next-app` | nom du dossier/projet | `scaf` (= slug de l'app) |
| `description` `tagline` `principe` | string · `""` | métadonnées de l'app (`app-info`, SEO) | `scaf` (`project.parts/apps/<app>.yml`) |
| `packageManager` | `pnpm\|npm\|yarn\|bun` · `pnpm` | gestionnaire des commandes générées | `choix` |
| `targetOs` | `mac_linux\|windows` · `mac_linux` | *code* : commande `dev` générée selon l'OS | `choix` (machine du dev) |
| `srcDir` | bool · `true` | *code* : tout sous `src/` ; préfixe tous les chemins générés | `fixe` (kit Next : `src/`) |
| `importAlias` | string · `@/*` | *code* : `paths` du tsconfig | `fixe` |
| `agentsFilename` | `AGENTS.md\|AI_GUIDE.md\|README-IA.md` · `AGENTS.md` | nom du guide IA racine | `fixe` |
| `nextDevToolsMcp` | bool · `true` | *code* : écrit `.mcp.json` (next-devtools-mcp) | `choix` |
| `docsTool` | bool · `false` | *code* : docs-tool (documentation auto, `genealogy.config.ts`, scripts `generate:docs`/`check:docs`, ajoutés au tsconfig/package.json de l'app par le générateur) | `choix` |
| `eslintInBuild` | bool · `true` | *code* : `false` ⇒ `eslint.ignoreDuringBuilds` | `fixe` |
| `reactStrictMode` | bool · `true` | *code* : `next.config.ts` | `fixe` |
| `imagesUnoptimized` | bool · `false` | *code* : `images.unoptimized` | `choix` (hébergement) |
| `allowedImageDomains` | string[] · `[]` | *code* : `images.remotePatterns` ; URL complète ou hostname (https, `/**` par défaut) | `scaf` (hôtes d'images des contrats/`servers.yml`) ou `choix` |
| `allowedDevOrigins` | string[] · `[]` | *code* : `allowedDevOrigins` + `serverActions.allowedOrigins` | `choix` |
| `bodySizeLimit` | string · `5mb` | *code* : `serverActions.bodySizeLimit` | `fixe` (monter si upload) |

### Architecture et code applicatif
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `architecture` | `mvvm\|mvc\|clean_architecture` · `mvvm` | *code* : arbre d'`api-modules/`, `di/`, actions, contexts selon le pattern | `choix` |
| `apiLayer` | `server_actions\|route_handlers\|trpc\|graphql` · `server_actions` | *brief* : mécanisme client-serveur annoncé à l'agent | `choix` |
| `stateManagement` | `zustand\|jotai\|redux_toolkit\|tanstack\|none` · `zustand` | *brief* | `choix` |
| `httpClient` | `ky\|axios\|fetch` · `ky` | *code* : dépendance + `lib/api-client` correspondant | `choix` |
| `logger` | `pino\|winston\|none` · `pino` | *code* : dépendance ; `pino` ⇒ `serverExternalPackages` (pino, pino-pretty) | `choix` |
| `orm` | `prisma\|drizzle\|typeorm\|mongoose\|none` · `prisma` | *code* : dépendances ; sert aussi de backend au push. **`none` si le front consomme l'API scaf** (règle EC6) | `scaf` (front = `none`) |
| `database` | `postgresql\|mysql\|sqlite\|mongodb\|none` · `postgresql` | *code* : driver du push ; **`none` si front sur API scaf** | `scaf` |
| `rateLimiting` | bool · `false` (ou objet `{default?, endpoints?}`) | *brief* | `choix` |
| `errorMonitoring` | `sentry\|logrocket\|none` · `none` | *code* : `sentry` ⇒ dépendance `@sentry/nextjs` ; logrocket : *brief* | `choix` |
| `analytics` | `vercel\|plausible\|none` · `none` | *code* : branchement dans le layout si ≠ `none` | `choix` |

### Authentification
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `auth` | `nextauth_v5\|clerk\|supabase\|custom_jwt\|none` · `none` | *code* : deps `nextauth_v5` (+ adapter prisma) / `clerk` ; autres : *brief*. `custom_jwt` = auth maison contre l'API scaf : le générateur pose/lit les jetons en **cookies httpOnly** par requête (`lib/auth-token.ts`), selon `session` ci-dessous ; autres valeurs : aucun jeton géré (`getAccessToken()` renvoie `null`, à brancher) | `scaf` (endpoints `auth` des contrats) + `choix` |
| `oauthProviders` | string[] · `[]` | prévision : à renseigner, l'implémentation revient aux devs (pas de génération dédiée) | `scaf` (providers OAuth des contrats `auth`) |

### UI, thème, polices
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `styling` | `tailwind_shadcn\|css_modules\|styled_components\|chakra_ui` · `tailwind_shadcn` | *code* : `tailwind_shadcn` ⇒ deps Tailwind + `globals.css` ; autres : `globals.css` minimal | `choix` |
| `shadcnPreset` | string · `""` | aide au développement : le preset shadcn sert au kit Next (demander à l'utilisateur) ; pas de génération dédiée | `choix` |
| `theme` | `light\|dark\|system` · `system` | *brief* (le thème est posé par le kit Next / next-themes) | `choix` |
| `font` | `geist\|inter\|poppins\|custom` · `geist` | *code* : police dans le layout | `choix` |
| `customFontPath` | string · `""` | *code* : `font: custom` ⇒ fichier copié ; **chemin relatif au dépôt** (`_ui-kits/…`) | `choix` (`_ui-kits/`) |

### Internationalisation et PWA
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `i18n` | bool · `false` | *code* : `next-intl` (plugin, messages, routage par locale, SEO multi-locales) | `choix` |
| `i18nLanguages` | string[] ⊂ `fr en es de it pt nl ja ko zh ar ru pl tr vi th sv da fi no` · `[]` | *code* : locales générées ; non vide si `i18n` ; contient `seo.defaultLocale` | `choix` |
| `pwa` | bool · `false` | *code* : Serwist (service worker, manifest, `~offline`) posés par le générateur dès L2 (fichiers `preserve` + patchs de l'app) ; le push reste manuel | `choix` |
| `pushNotifications` | objet (ci-dessous) · `enabled:false` | *code* : Web Push (SW, VAPID, store, Server Actions). Exige `pwa: true` | `choix` |

`pushNotifications` : `enabled` bool · `vapidPublicKey` / `vapidPrivateKey` (**`$var:`**, générées par `pnpm web-push:keys`) · `vapidSubject` `mailto:` (`mailto:admin@example.com`) · `defaultTitle` (`Nouvelle notification`) · `icon` / `badge` (`/icons/icon-192x192.png`, badge Android seulement) · `tag` (`push-default` ; vide = pas de regroupement, renseigné = remplace la notif du même tag) · `deepLink` (`/`, URL au clic) · `actions[]` `{action,title,url?}` **max 2** (Safari les ignore) · `ttl` secondes **max 2419200** (défaut max) · `urgency` `very-low|low|normal|high` (`normal`) · `iosGate` (`true`, consigne « installer en PWA » sur iOS) · `includeTestPage` (`true`, page `/push-demo`).

### SEO / GEO / AEO / LLMO
`seo` (*code*, master toggle `enabled`) : `siteName` (défaut = projectName ; `scaf`) · `description` (`scaf`) · `baseUrl` (URL de déploiement : canonical, sitemap, robots ; `scaf`) · `defaultLocale` · `locales` (**dérivé à la génération** : i18n actif ⇒ `i18nLanguages`, sinon `[defaultLocale]`) · `robots` → `robots.ts` · `sitemap` → `sitemap.ts` · `openGraph` → metadata OG/Twitter · `jsonLd` → données structurées (Organization, WebSite, SoftwareApplication, FAQPage) · `llms{enabled,index,full,llmsPage}` → `llms.txt`, `llms-full.txt`, page `/llms` · `legal{privacy,terms,license,credits}` → pages `/privacy` `/terms` `/license` `/credits` · `footerLinks` → liens legal + `/llms` en pied de page · `google.searchConsoleVerification` (meta `google-site-verification`) · `bing.siteVerification` (meta `msvalidate.01`). Les valeurs `siteName/description/baseUrl/google/bing` sont des *fallbacks* surchargés par `project.parts/apps/<app>.yml`.

### Agents et comportements
`agentLoop` (*code* : dossier `agents/`, protocole Builder/Judge/Manager, tickets MANUAL/UI/FLOW/API/TEST) : `enabled` (`true`) · `maxRevisions` (`3`, révisions avant escalade humaine) · `budgetTokens` / `budgetMinutes` (optionnels, vide = illimité) · `qualityCommands[]` (vérités terrain du Judge ; défaut `pnpm tsc --noEmit`, `pnpm lint`, `pnpm build`, `pnpm test`) · `requireAllPass` (`true` : ticket fini seulement si tous les items PASS) · `roles[]` (`frontend`,`shared`,`qa`) · `includeManualFromStudio` (`false`).

`behaviors` (*code*) : `enabled` (`false`, génère `src/app-behaviors/` : interfaces par feature depuis les usecases, implémentation par défaut `NotImplementedError`) · `includeEvents` (`true`, `src/app-events/` : contrats d'événements dérivés des `calls`/`links`) · `includeProducer` (`false`, ajoute les usecases **producer** : `<feature>.producer.behavior(.impl).ts` + `producerBehaviorRegistry`, pour un Next.js serveur) · `behaviorOnly` (`false`, réservé : une app `api: false` est déjà générée sans client API ; ses usecases consumer se rattachent aux features par `feature: <module>/<feature>`). Comportements dérivés des usecases uniquement (les `atomic_actions` de `project.parts` ne sont pas utilisés). Sous-clés booléennes (EC7). Avec `docsTool: true`, impl/registry/`EventName` sont enveloppés dans `indexDoc` (`@docs/index-doc`).

`session` (*code*, `auth: custom_jwt` seulement) : dit au générateur **quels endpoints ouvrent/ferment la session** et **où lire les jetons** dans leur réponse succès — jamais deviné (un endpoint ne renvoie pas forcément `data.access_token`). `endpoints` : `{ "<endpoint-id>": { "accessToken": "data.access_token", "refreshToken": "data.refresh_token", "expiresIn": "data.expires_in" } }` (`accessToken` requis ; chemins pointés dans la réponse ; `refreshToken`/`expiresIn` optionnels) ; `logout` : ids dont l'appel efface les cookies. L'action générée pose les cookies seulement si le jeton est présent dans la réponse (une étape intermédiaire sans jeton est ignorée). Cookies `<app>_access_token` / `<app>_refresh_token` (préfixés : les cookies ignorent le port), `httpOnly`, `secure` en production, `sameSite: lax`. Une base partagée peut lister les ids de plusieurs apps (ceux d'une autre app sont ignorés ; un id inconnu partout est refusé). `custom_jwt` sans `session` : avertissement avec les endpoints candidats. **Rafraîchissement sur 401** (optionnel) : `refresh: { "endpoint": "<id>", "bodyField": "refresh_token", "accessToken": "data.access_token", "refreshToken": "data.refresh_token", "expiresIn": "data.expires_in" }` — `endpoint` doit exister dans les contrats de l'app (sans paramètre de chemin ; le kit n'invente jamais d'endpoint) ; `bodyField` = champ du corps qui reçoit le refresh token ; les chemins lisent la réponse. Sur un 401, un seul refresh (même avec plusieurs 401 simultanés), puis la requête est rejouée une fois avec le nouveau jeton ; refus → session effacée et le 401 remonte. Hors Server Action la persistance des cookies échoue : le jeton sert au rejeu en cours seulement. **Sans `refresh`** (ex. contrat sans endpoint de refresh) : un 401 efface les cookies (si possible) et remonte à la vue, qui redirige vers le login. Règles EC8 (forme) et EC9 (confrontation aux contrats : endpoints, chemins, types).

## NestJS

### Schéma défini par le kit
Le schéma NestJS est **défini par le kit** (champs et enums : `02 §11`, règles NS : `03`), écrit à partir du backend de référence `miidjoe-core-api`. Il n'existe pas de défaut officiel : les valeurs de `nestjs.json` dans `v0` sont des exemples issus de ce backend, pas des valeurs à reprendre par défaut.

Sens des champs spécifiques : `generator.level` = profondeur de `tools/nestjs/gen_nestjs.ts` (N0 socle, N1 endpoints, N2 accès base : schéma Drizzle de scaf + connexion + un repository par table, `--database` et `--db-provider` surchargent `database`/`databaseProvider`) · `architecture` = organisation des fichiers générés (`ddd_layered`, `modular_simple`) · `e2e` / `testFramework` = génération des tests e2e depuis les mocks (`test/e2e/`, jest seul géré, niveau N1+) · `envFile` / `generateSecrets` = environnement généré (`example_and_file` : `.env.example` + `.env` créé s'il n'existe pas, `example` : modèle seul, `none` : rien ; secrets aléatoires si `generateSecrets`) ; noms des variables = `databaseUrl`/`authSecret`/`authBaseUrl` (`$var:NOM`) · `usecaseBase` = enveloppe d'exécution des usecases (`none`, ou `template_method` : `BaseUsecase` avec `run()`) · `bodyParser: false` = exigence de l'adaptateur `better_auth` (pas du socle) · `responseEnvelope` = contrat `{ success, message, data }` · `authPlugins` = plugins Better Auth (`admin`, `username`, `apiKey`, `customSession`…) · `swagger{enabled,path}` = exposition de la doc OpenAPI **de chaque app** (l'OpenAPI déjà dérivé par scaf, `contracts_to_openapi.rb --doc` à lancer avant ; `enabled` par app ; `path` = base de segments simples, ex. `docs` : plusieurs docs servies → `<path>/<app>`, une seule → `<path>`, JSON sur `<chemin>-json` ; `type` = `ui`, Swagger UI ; `--swagger [path]` active toutes les apps servies, `--no-swagger` aucune) · `databaseProvider` = pilote de connexion du N2 (`neon`|`pg` ⇒ postgresql, `mysql2` ⇒ mysql, `better_sqlite3` ⇒ sqlite ; règle NS4 si incohérent avec `database`) · `authUserTable` / `authUserFields` = table du visuel qui EST l'utilisateur Better Auth (+ mapping champ Better Auth → colonne ; N2 better_auth) · `rls` = `none`|`session` : `session` génère le contexte RLS par requête (postgresql + drizzle, policies déclarées dans le visuel) · `migrations: drizzle_kit` = migrations générées depuis le schéma Drizzle. `authDefaultRole` = rôle écrit par le plugin admin à l'inscription (avec `authUserTable`, plugin `admin` requis ; doit exister dans l'enum de la colonne `role`).

**NestJS — `rateLimiting`** (bool · `false`, ou objet) : `true` ⇒ *code* : `@nestjs/throttler`, `ThrottlerGuard` global (avant `AccessGuard`, donc appels anonymes inclus) et le filtre d'exceptions renvoie `429 RATE_LIMITED` ; fenêtre et plafond lus dans `RATE_LIMIT_TTL_MS` (60000) et `RATE_LIMIT_MAX` (100), par IP, présents dans `.env.example`. Plafond par endpoint : `rateLimiting` peut être un objet `{ "default": {"limit": 100, "ttlMs": 60000}, "endpoints": { "<endpoint-id>": {"limit": 3, "ttlMs": 60000} } }` ⇒ `@Throttle` généré sur ces seuls endpoints (valeurs en dur) ; `default` remplace `RATE_LIMIT_*` (plus de variables d'env) ; les autres endpoints gardent la limite globale. Les limites sont des choix de produit : elles vivent ici, pas dans les contrats ; chaque id doit exister (NS11).

**NestJS — options non générées** : le générateur ne produit que la valeur par défaut de `packageManager`, `httpAdapter`, `validation`, `logger`, `cache`, `queue`, `mailer`, `errorMonitoring`, `testFramework`, `usecaseStyle`, `moduleGranularity`, `exceptionFilter`, `pagination`, `srcDir`, `swagger.type` ; une autre valeur est un *brief* (lue par l'agent) et déclenche l'avertissement NS10.

Source des valeurs : `projectName`, `moduleGranularity`, secrets (`$var:`) et `authBaseUrl` se déduisent du projet (`scaf`) ; le reste est un `choix` à demander. Ne rien inventer hors de ce schéma.

### Schéma de base de données généré
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `database` | `postgresql\|mysql\|sqlite\|none` | *code* : driver/ORM du backend ; ne pilote pas `visual_to_sql.rb` (moteur = `--dialect`, défaut postgresql) ; règle NS6 si ≠ moteurs générés | `choix` |
| `schemaKeyStyle` | `snake\|camel` · `snake` | *code* : clés TypeScript du Drizzle généré (`camel` = style du backend de référence) | `choix` |
| `tablesNames` | bool · `false` | *code* : génère `drizzle/tables-names.ts` (`DB_TABLES_NAMES`, constantes `*_TABLE`) | `choix` |
| `schemaDir` | string · `""` | dossier du schéma Drizzle du backend, lu par `db_compare.rb` (lecture seule) | `choix` (chemin du backend) |
