#!/usr/bin/env bash
# Golden NestJS : architecture × auth → génération, tsc, idempotence, preserve, architectures côte à côte, test HTTP.
set -euo pipefail
cd "$(dirname "$0")"
V=../../../v0 G=.golden BIN=node_modules/.bin
ok() { echo "ok  $*"; }
ko() { echo "KO  $*"; exit 1; }
gen() { $BIN/tsx gen_nestjs.ts $V "$@" >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération $*"; }; }
rm -rf $G && mkdir -p $G
$BIN/tsc -p . && ok "tsc du générateur"

for a in ddd_layered modular_simple; do for u in none jwt better_auth; do
  d=$G/$a-$u
  h=; [ "$a-$u" = modular_simple-jwt ] && h=--health-check
  gen --out $d --architecture $a --auth $u $h
  (cd $d && ../../$BIN/tsc --noEmit -p .) || ko "tsc $a-$u"
  before=$(find $d -type f | sort | xargs shasum | shasum)
  gen --out $d --architecture $a --auth $u $h
  [ "$before" = "$(find $d -type f | sort | xargs shasum | shasum)" ] || ko "idempotence $a-$u"
  ok "$a × $u : généré, tsc, idempotent"
done; done

# e2e : tests générés depuis les mocks, exécutés pour chaque adaptateur (none : sans 401/403 ; jwt : jeton HS256 ; better_auth : AuthPort factice)
for u in none jwt better_auth; do
  d=$G/ddd_layered-$u
  [ -f $d/test/e2e/contracts.e2e-spec.ts ] && grep -q '"test:e2e"' $d/package.json || ko "e2e $u : fichiers/script absents"
  (cd $d && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -40 $d/e2e.log; ko "e2e $u"; }
  grep -q "non évalué(s)" $d/e2e.log && ok "e2e × $u : $(grep -E '^Tests:' $d/e2e.log | sed 's/Tests: *//')" || ko "e2e $u : résumé NOT_READY absent"
  rm -f $d/e2e.log
done

# environnement : .env.example + .env (créé si absent, secrets, jamais réécrit), validation au démarrage, env:init, fusion de package.json, db:setup, README
d=$G/ddd_layered-jwt; e=$G/envtest; rm -rf $e && mkdir -p $e
grep -q '^JWT_SECRET=$' $d/.env.example && [ -n "$(sed -n 's/^JWT_SECRET=//p' $d/.env)" ] && [ -f $d/README.md ] && grep -q '"env:init"' $d/package.json || ko "env : .env.example/.env/README/script"
sed -i.bak 's/^JWT_SECRET=.*/JWT_SECRET=mien/' $d/.env && rm $d/.env.bak; gen --out $d --architecture ddd_layered --auth jwt
grep -q '^JWT_SECRET=mien$' $d/.env || ko "env : .env réécrit"
(cd $e && ../../$BIN/tsx ../ddd_layered-jwt/src/core/env.ts >env.log 2>&1) && ko "env : démarrage sans variable accepté"
grep -q 'JWT_SECRET' $e/env.log && (cd $e && JWT_SECRET=x ../../$BIN/tsx ../ddd_layered-jwt/src/core/env.ts) || ko "env : validation au démarrage"
sed -i.bak '/JWT_SECRET/d' $d/.env && rm $d/.env.bak; (cd $d && node scripts/env-init.mjs >/dev/null) && grep -q '^JWT_SECRET=.\+' $d/.env && grep -q '^PORT=' $d/.env || ko "env:init"
sed -i.bak 's/"env:init": "[^"]*",\?//; s/"typecheck"/"mon-script": "echo ok", "typecheck"/' $d/package.json && rm $d/package.json.bak
gen --out $d --architecture ddd_layered --auth jwt
grep -q '"env:init"' $d/package.json && grep -q '"mon-script"' $d/package.json || ko "package.json : fusion"
ok "environnement : .env.example, .env créé/conservé, validation, env:init, package.json fusionné, README"
# usecaseBase none : usecases sans BaseUsecase, tsc OK ; template_method : tous étendent BaseUsecase
for a in ddd_layered modular_simple; do
  d=$G/$a-nobase; gen --out $d --architecture $a --auth jwt --usecase-base none
  (cd $d && ../../$BIN/tsc --noEmit -p .) || ko "tsc $a nobase"
  [ ! -f $d/src/core/base-usecase.ts ] && ! grep -rq BaseUsecase $d/src/modules && grep -rq BaseUsecase $G/$a-jwt/src/modules && ok "$a : usecaseBase none / template_method" || ko "usecaseBase $a"
done

# preserve : un usecase édité survit à la régénération ; un fichier utilisateur non suivi n'est pas écrasé
d=$G/ddd_layered-none
uc=$(find $d/src -name '*.usecase.ts' | sed -n 1p)
echo "// édité" >> $uc; echo "// perso" > $d/src/perso.ts
gen --out $d --architecture ddd_layered --auth none
grep -q "// édité" $uc && [ "$(cat $d/src/perso.ts)" = "// perso" ] && ok "preserve" || ko "preserve"

# fichier généré modifié à la main : conservé + warning ; --force le réécrit
d=$G/ddd_layered-jwt; c=$(find $d/src -name '*.controller.ts' | sed -n 1p)
echo "// main" >> $c; gen --out $d --architecture ddd_layered --auth jwt
grep -q "// main" $c && grep -q "modifié à la main" $G/last.log && ok "généré modifié conservé + warning" || ko "écrasé"
gen --out $d --architecture ddd_layered --auth jwt --force
grep -q "// main" $c && ko "--force sans effet" || ok "--force réécrit"

# swagger : une doc OpenAPI par app (endpoints de l'app), servie sur <base>/<app> si plusieurs, <base> si une seule
sd=$G/ms-swagger; gen --out $sd --architecture modular_simple --auth none --swagger docs
gen --out $G/sw-off --architecture modular_simple --auth none --no-swagger
nep=$(grep -rhoE '@(Get|Post|Put|Patch|Delete)\(' $sd/src/modules | wc -l | tr -d ' ')
ndoc=$(cat $sd/src/docs/openapi.*.json | grep -o '"operationId"' | wc -l | tr -d ' ')
[ -f $sd/src/docs/openapi.admin.json ] && [ -f $sd/src/docs/openapi.user.json ] && [ "$nep" = "$ndoc" ] && [ ! -e $G/sw-off/src/docs ] && ! grep -q 'SwaggerModule' $G/sw-off/src/main.ts && grep -q '"@nestjs/swagger"' $sd/package.json && grep -q 'setup("docs/admin"' $sd/src/main.ts && grep -q 'setup("docs/user"' $sd/src/main.ts && ok "swagger : 1 doc par app ($ndoc opérations = $nep endpoints), absent si désactivé" || ko "swagger fichiers ($nep endpoints, $ndoc opérations)"
gen --out $G/sw-app --architecture modular_simple --auth none --swagger docs --app admin
grep -q '/api/v1/admin/' $G/sw-app/src/docs/openapi.admin.json && ! grep -q '/api/v1/me/' $G/sw-app/src/docs/openapi.admin.json && [ ! -e $G/sw-app/src/docs/openapi.user.json ] && grep -q 'setup("docs"' $G/sw-app/src/main.ts && ok "swagger : --app = une doc servie sur <base>" || ko "swagger --app"
# OpenAPI scaf absent : avertissement, aucune doc partielle
cp -R $V $G/v0x && rm -rf $G/v0x/output/openapi
$BIN/tsx gen_nestjs.ts $G/v0x --out $G/sw-miss --architecture modular_simple --auth none --swagger docs >$G/last.log 2>&1
grep -q "contracts_to_openapi.rb" $G/last.log && [ ! -e $G/sw-miss/src/docs ] && ok "swagger : OpenAPI scaf absent → warning, pas de doc" || ko "swagger yml absent"
(cd $sd && ../../$BIN/tsc --noEmit -p .) || ko "tsc swagger"
(cd $sd && ../../$BIN/tsc -p .) || ko "build swagger"
ln -sfn "$PWD/node_modules" $sd/node_modules; echo '{"type":"commonjs"}' > $sd/package.json
PORT=3918 node $sd/dist/main.js >$G/swagger.log 2>&1 & swpid=$!
for i in $(seq 30); do curl -s localhost:3918/x >/dev/null 2>&1 && break; sleep 0.3; done
[ "$(curl -s -o $G/doc.json -w '%{http_code}' localhost:3918/docs/admin-json)" = 200 ] && grep -q '"openapi"' $G/doc.json && grep -q '/api/v1/' $G/doc.json && [ "$(curl -s -o /dev/null -w '%{http_code}' localhost:3918/docs/user)" = 200 ] && ok "swagger servi : /docs/admin(-json), /docs/user" || { cat $G/swagger.log; ko "swagger HTTP"; }
kill $swpid 2>/dev/null || true

# N2 : schéma Drizzle de scaf copié, un repository par table, connexion neon | pg, tsc, idempotence, DI au démarrage
for p in neon pg; do
  n2=$G/n2-$p; gen --out $n2 --architecture ddd_layered --auth none --level N2 --db-provider $p
  (cd $n2 && ../../$BIN/tsc --noEmit -p .) || ko "tsc N2 $p"
  before=$(find $n2 -type f | sort | xargs shasum | shasum); gen --out $n2 --architecture ddd_layered --auth none --level N2 --db-provider $p
  [ "$before" = "$(find $n2 -type f | sort | xargs shasum | shasum)" ] || ko "idempotence N2 $p"
done
nt=$(cat $V/output/database/postgresql/drizzle/*.ts | grep -c '= pgTable(') nr=$(ls $G/n2-neon/src/database/repositories | grep -vc base)
grep -q 'drizzle-orm/neon-serverless' $G/n2-neon/src/database/db.ts && grep -q 'drizzle-orm/node-postgres' $G/n2-pg/src/database/db.ts && grep -q '"drizzle-kit"' $G/n2-neon/package.json && grep -q '"@types/pg"' $G/n2-pg/package.json && grep -q '"db:generate"' $G/n2-neon/package.json && grep -q 'DatabaseModule' $G/n2-neon/src/app.module.ts && [ "$nt" = "$nr" ] && ok "N2 : $nt tables = $nr repositories (neon, pg), tsc, idempotent" || ko "N2 fichiers ($nt tables, $nr repositories)"
r=$(ls $G/n2-neon/src/database/repositories/*.repository.ts | grep -v /base.repository | sed -n 1p); echo "// perso" >> $r
gen --out $G/n2-neon --architecture ddd_layered --auth none --level N2 --db-provider neon
grep -q "// perso" $r && ok "N2 : repository édité conservé" || ko "N2 repository écrasé"
# schéma Drizzle scaf absent : échec clair
cp -R $V $G/v0y && rm -rf $G/v0y/output/database
$BIN/tsx gen_nestjs.ts $G/v0y --out $G/n2-miss --level N2 >$G/last.log 2>&1 && ko "N2 sans schéma accepté"
grep -q "visual_to_sql.rb" $G/last.log && ok "N2 : schéma absent → échec avec la commande à lancer" || ko "N2 message schéma"
# le module de base de données se résout au démarrage (pool paresseux : aucune connexion tentée)
n2=$G/n2-pg; (cd $n2 && ../../$BIN/tsc -p .) || ko "build N2"
ln -sfn "$PWD/node_modules" $n2/node_modules; echo '{"type":"commonjs"}' > $n2/package.json
NEON_DATABASE_CONNEXION_STRING=postgres://u:p@127.0.0.1:1/db PORT=3919 node $n2/dist/main.js >$G/n2.log 2>&1 & n2pid=$!
for i in $(seq 30); do curl -s localhost:3919/x >/dev/null 2>&1 && break; sleep 0.3; done
curl -s localhost:3919/x >/dev/null 2>&1 && ok "N2 : l'API démarre, DatabaseModule + repositories injectés" || { cat $G/n2.log; ko "N2 démarrage"; }
kill $n2pid 2>/dev/null || true

# intent.tables : repositories injectés à la création du usecase, dérive signalée ensuite, rien hors N2
uc=$(find $n2/src/modules -name patch-admin-settings.usecase.ts)
grep -q 'private readonly platformSettingsRepository: PlatformSettingsRepository' $uc && ! grep -q 'AdminAuditLogRepository' $uc && grep -q 'emitRecordAdminAudit' $uc && grep -q '@table platform_settings (write)' $uc && ok "N2 intent.tables : repositories injectés dans le usecase" || ko "N2 intent.tables injection"
grep -q 'Repositories (intent.tables)' $uc && grep -q 'Enregistre les nouvelles valeurs' $uc && grep -q 'findAll(limit = 50, offset = 0)' $uc && grep -q 'update(id, values)' $uc && ok "N2 intent.tables : guide des repositories (why, méthodes)" || ko "guide repositories"
cp -R $V $G/v0z && perl -0pi -e 's/  tables:\n(    - \{ table:[^\n]*\n)+//' $G/v0z/input/usecases/producer/admin/delete-admin-cities-by-cityid.usecase.yml
$BIN/tsx gen_nestjs.ts $G/v0z --out $G/n2-notables --architecture ddd_layered --auth none --level N2 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération sans tables"; }
u0=$(find $G/n2-notables/src/modules -name delete-admin-cities-by-cityid.usecase.ts); [ -f "$u0" ] && ! grep -q 'Repository' "$u0" && ok "N2 : un usecase sans intent.tables n'injecte rien" || ko "usecase sans intent.tables ne doit rien injecter"
perl -pi -e 's/PlatformSettingsRepository/Retire/g' $uc; gen --out $n2 --architecture ddd_layered --auth none --level N2
grep -q 'à injecter à la main PlatformSettingsRepository' $G/last.log && ok "N2 intent.tables : dérive signalée sur usecase existant" || ko "N2 intent.tables dérive"
gen --out $G/n1-tables --architecture ddd_layered --auth none --level N1
grep -q "rien injecté hors niveau N2" $G/last.log && ! grep -rq 'PlatformSettingsRepository' $G/n1-tables/src && ok "N1 : intent.tables sans effet (warn)" || ko "N1 intent.tables"

# rateLimiting: true : ThrottlerGuard global avant AccessGuard, 429 RATE_LIMITED dans le filtre, variables d'env ; false : aucun changement
rl=$G/v0rl; cp -R $V $rl; perl -0pi -e 's/"rateLimiting":\s*(\{.*?\}\s*\}\s*\}|false|true)/"rateLimiting": true/s' $rl/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rl --out $G/n1-rl --architecture ddd_layered --auth jwt >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération rateLimiting"; }
(cd $G/n1-rl && ../../$BIN/tsc --noEmit -p .) || ko "tsc rateLimiting"
grep -q '"@nestjs/throttler"' $G/n1-rl/package.json && grep -q 'ThrottlerModule.forRoot' $G/n1-rl/src/core/core.module.ts && grep -q 'RATE_LIMITED' $G/n1-rl/src/core/global-exception.filter.ts && grep -q '^RATE_LIMIT_MAX=100' $G/n1-rl/.env.example && [ "$(grep -n 'useExisting: ThrottlerGuard' $G/n1-rl/src/core/core.module.ts | cut -d: -f1)" -lt "$(grep -n 'useClass: AccessGuard' $G/n1-rl/src/core/core.module.ts | cut -d: -f1)" ] && ! grep -q 'NS10\|rateLimiting' $G/last.log && ok "rateLimiting : throttler, guard avant AccessGuard, 429 RATE_LIMITED, .env.example, tsc" || ko "rateLimiting"
rf=$G/v0rf; cp -R $V $rf; perl -0pi -e 's/"rateLimiting":\s*(\{.*?\}\s*\}\s*\}|false|true)/"rateLimiting": false/s' $rf/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rf --out $G/n1-rf --architecture ddd_layered --auth jwt >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération rateLimiting false"; }
! grep -rq 'throttler\|Throttler' $G/n1-rf/package.json $G/n1-rf/src && ok "rateLimiting false : aucun throttler généré" || ko "rateLimiting false"

# rateLimiting objet { endpoints } : @Throttle seulement sur les endpoints listés (v0 en déclare 3), id inconnu → NS11
ro=$G/v0ro; cp -R $V $ro
$BIN/tsx gen_nestjs.ts $ro --out $G/n1-ro --architecture ddd_layered --auth jwt >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération rateLimiting objet"; }
(cd $G/n1-ro && ../../$BIN/tsc --noEmit -p .) || ko "tsc rateLimiting objet"
[ "$(grep -rh '@Throttle(' $G/n1-ro/src | wc -l | tr -d ' ')" = "$(grep -c '"ttlMs"' $ro/input/export-configs/nestjs.json)" ] && grep -rq 'ThrottlerGuard' $G/n1-ro/src/core/core.module.ts && ok "rateLimiting objet : @Throttle par endpoint" || ko "rateLimiting objet"
perl -0pi -e 's/"post-auth-otp-request"/"endpoint-inconnu"/' $ro/input/export-configs/nestjs.json
[[ "$(ruby ../export_configs.rb $ro 2>&1)" == *NS11*endpoint-inconnu* ]] && ok "rateLimiting : id inconnu signalé (NS11)" || ko "NS11 id inconnu"

# better_auth : auth.ts généré depuis nestjs.json (N2 : drizzleAdapter + plugins, routes montées, schéma via auth:generate), stateless hors N2, auth.ts édité conservé
ba=$G/n2-ba; gen --out $ba --architecture ddd_layered --auth better_auth --level N2
(cd $ba && ../../$BIN/tsc --noEmit -p .) || ko "tsc better_auth N2"
grep -q 'drizzleAdapter(createDb(), { provider: "pg", schema })' $ba/src/better-auth/auth.ts && grep -q 'admin({' $ba/src/better-auth/auth.ts && grep -q 'username(' $ba/src/better-auth/auth.ts && grep -q 'apiKey()' $ba/src/better-auth/auth.ts && grep -q 'requireEmailVerification: true' $ba/src/better-auth/auth.ts && ok "better_auth N2 : auth.ts (drizzleAdapter, plugins, options de nestjs.json)" || ko "better_auth N2 auth.ts"
grep -q 'toNodeHandler(auth)' $ba/src/main.ts && grep -q 'auth:generate' $ba/package.json && grep -q 'better-auth/schema.ts' $ba/drizzle.config.ts && ok "better_auth N2 : routes montées, script auth:generate, drizzle.config" || ko "better_auth N2 wiring"
grep -q 'db:setup' $ba/package.json && grep -q '"auth": ' $ba/package.json && grep -q 'auth generate' $ba/package.json && grep -q '^BETTER_AUTH_SECRET=.\+' $ba/.env || ko "better_auth N2 : db:setup / CLI épinglée / .env"
ok "better_auth N2 : db:setup (auth:generate → db:generate → db:migrate), CLI auth épinglée, .env"
echo '// édité' >> $ba/src/better-auth/auth.ts; gen --out $ba --architecture ddd_layered --auth better_auth --level N2
grep -q '// édité' $ba/src/better-auth/auth.ts && ok "better_auth : auth.ts édité conservé" || ko "better_auth auth.ts preserve"
gen --out $G/n1-ba --architecture ddd_layered --auth better_auth --level N1
! grep -q drizzleAdapter $G/n1-ba/src/better-auth/auth.ts && [ ! -f $G/n1-ba/src/better-auth/schema.ts ] && ok "better_auth N1 : sans base (stateless)" || ko "better_auth N1"

# RLS : visuel `rls` → SQL (FORCE opt-in), audit A13, projet rls: session (tsc, fichiers, proxy), sans rls = aucun fichier, identité Better Auth, isolation réelle (Docker)
r=$G/v0r; cp -R $V $r; cp golden/_visual_rlstest.yml $r/input/database/visual/
perl -0pi -e 's/"rls": "[a-z]+"/"rls": "session"/; s/("agentLoop")/"rls": "session",\n    $1/ unless /"rls"/' $r/input/export-configs/nestjs.json
ruby ../visual_to_sql.rb $r >/dev/null 2>&1 || ko "visual_to_sql rls"
s=$r/output/database/postgresql/sql
grep -q 'ENABLE ROW LEVEL SECURITY' $s/90_rls.sql && grep -q 'app_user_id()' $s/05_rls_setup.sql && ! grep -q 'FORCE' $s/90_rls.sql && ok "RLS SQL : policies, helpers, sans FORCE par défaut" || ko "RLS SQL"
sed -i.bak 's/^      enabled: true/      enabled: true\n      force: true/' $r/input/database/visual/_visual_rlstest.yml; ruby ../visual_to_sql.rb $r >/dev/null 2>&1; grep -q 'FORCE ROW LEVEL SECURITY' $s/90_rls.sql && ok "RLS SQL : force: true → FORCE" || ko "RLS force"
mv $r/input/database/visual/_visual_rlstest.yml.bak $r/input/database/visual/_visual_rlstest.yml 2>/dev/null; sed -i.bak '/^      force: true/d' $r/input/database/visual/_visual_rlstest.yml; rm -f $r/input/database/visual/*.bak; ruby ../visual_to_sql.rb $r >/dev/null 2>&1
vf=$r/input/database/visual/_visual_rlstest.yml
for c in 's/for: select/for: bogus/' 's/owner: \[owner_id\]/owner: [nope]/' 's/^\(        - { name: notes_public_read.*\)$/\1\n\1/' 's/      admin: \[admin\]/      admin: [1]/'; do
  cp $vf $vf.keep; sed -i.bak "$c" $vf; rm -f $vf.bak
  au=$(ruby ../audit.rb $r 2>&1 || true); grep -q 'A13' <<<"$au" && ok "audit A13 : $c" || ko "audit A13 non détecté : $c"
  mv $vf.keep $vf
done
au=$(ruby ../audit.rb $r 2>&1 || true); grep -q '^E A13' <<<"$au" && ko "audit A13 faux positif" || ok "audit A13 : spec valide acceptée"
rg=$G/n2-rls; gen_r() { $BIN/tsx gen_nestjs.ts $r "$@" >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération $*"; }; }
gen_r --out $rg --architecture ddd_layered --auth none --level N2 --db-provider pg
(cd $rg && ../../$BIN/tsc --noEmit -p .) || ko "tsc rls"
grep -q 'withRls(createDb())' $rg/src/database/database.module.ts && grep -q 'APP_INTERCEPTOR' $rg/src/database/database.module.ts && [ -f $rg/rls/90_rls.sql ] && [ -f $rg/scripts/apply-rls.mjs ] && grep -q '"db:rls"' $rg/package.json && grep -q 'db:rls' $rg/package.json && ok "rls session : proxy DRIZZLE, interceptor, rls/*.sql, apply-rls, db:rls" || ko "rls wiring"
rn=$G/v0n; cp -R $V $rn; perl -0pi -e 's/"rls": "session"/"rls": "none"/' $rn/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rn --out $G/n2-norls --architecture ddd_layered --auth none --level N2 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération sans rls"; }
[ ! -e $G/n2-norls/rls ] && [ ! -e $G/n2-norls/src/database/db-context.ts ] && ! grep -q 'db:rls' $G/n2-norls/package.json && ok "sans rls : aucun fichier RLS" || ko "sans rls : fichiers RLS inattendus"
# identité Better Auth : modelName/fields/generateId, auth-schema.mjs
ri=$G/v0i; cp -R $V $ri; perl -0pi -e 's/("agentLoop")/"authUserTable": "users",\n    "authUserFields": { "name": "full_name", "image": "avatar_url" },\n    $1/' $ri/input/export-configs/nestjs.json
gi=$G/n2-ident; $BIN/tsx gen_nestjs.ts $ri --out $gi --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération identité"; }
grep -q 'modelName: "users"' $gi/src/better-auth/auth.ts && grep -q 'generateId' $gi/src/better-auth/auth.ts && [ -f $gi/scripts/auth-schema.mjs ] && grep -q 'auth-schema.mjs' $gi/package.json && grep -q '"emailVerified": "email_verified"' $gi/src/better-auth/auth.ts && grep -q 'banReason.*ban_reason' $gi/src/better-auth/auth.ts && grep -q 'defaultRole: "PASSENGER"' $gi/src/better-auth/auth.ts && ok "identité : auth.ts (modelName, fields, generateId), auth-schema.mjs, mapping snake_case auto, defaultRole" || ko "identité Better Auth"
# défaut fonctionnel (sql``), niveau inférieur bloqué, rls session sans authUserTable
grep -q "default(sql\`CURRENT_DATE\`)" $gi/src/database/schema/auth.ts && grep -q "import { sql } from 'drizzle-orm'" $gi/src/database/schema/auth.ts && ok "défaut CURRENT_DATE rendu en sql\`\`" || ko "défaut CURRENT_DATE"
$BIN/tsx gen_nestjs.ts $ri --out $gi --architecture ddd_layered --auth better_auth --level N1 >$G/last.log 2>&1 && ko "niveau inférieur non bloqué" || { grep -q 'supprimerait ses fichiers N2' $G/last.log && ok "régénération en N1 sur projet N2 : bloquée" || ko "message garde niveau"; }
rn=$G/v0rn; cp -R $V $rn; perl -0pi -e 's/"authUserTable": "[^"]*",?//; s/"authDefaultRole": "[^"]*",?//; s/"authUserFields": \{[^}]*\},?//' $rn/input/export-configs/nestjs.json
rb=$(ruby ../audit.rb $rn 2>&1 || true); echo "$rb" | grep -q 'rls session exige authUserTable' && ok "NS4 : rls session sans authUserTable = erreur" || ko "NS4 rls sans authUserTable"
# garde-fous Better Auth × visuel : conflit de noms, dérive d'identité, db-guard, scripts périmés
cx=$G/v0c; cp -R $V $cx; perl -0pi -e 's/(  - name: users\n)/  - name: session\n    kind: entity\n    description: Conflit.\n    columns:\n      - { name: id, type: uuid, nullable: false, primary: true, description: Id. }\n$1/' $cx/input/database/visual/_visual_auth.yml
ruby ../visual_to_sql.rb $cx --format drizzle >/dev/null 2>&1
$BIN/tsx gen_nestjs.ts $cx --out $G/n2-clash --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 && ko "conflit de nom non détecté" || { grep -q 'conflit avec les tables natives Better Auth (session)' $G/last.log && ok "conflit visuel ↔ table Better Auth : échec explicite" || { cat $G/last.log; ko "conflit message"; }; }
gd=$G/n2-guard; gen --out $gd --architecture ddd_layered --auth better_auth --level N2
[ -f $gd/.scaf-identity.json ] && grep -q 'db:guard' $gd/package.json && grep -q 'db:generate && pnpm db:guard && pnpm db:migrate' $gd/package.json && ok "better_auth N2 : db:guard dans db:setup, empreinte d'identité" || ko "db:guard"
mkdir -p $gd/drizzle/meta; echo '{"entries":[{"tag":"0001_x"}]}' > $gd/drizzle/meta/_journal.json; echo 'DROP TABLE "user" CASCADE;--> statement-breakpoint
ALTER TABLE "account" ALTER COLUMN "id" SET DATA TYPE uuid;' > $gd/drizzle/0001_x.sql
(cd $gd && node scripts/db-guard.mjs >/dev/null 2>$OLDPWD/$G/guard.log) && ko "db-guard n'a pas bloqué" || grep -q 'destructive' $G/guard.log && ok "db-guard : migration destructive refusée" || ko "db-guard message"
(cd $gd && SCAF_ALLOW_DESTRUCTIVE=1 node scripts/db-guard.mjs >/dev/null 2>&1 && node scripts/db-guard.mjs >/dev/null 2>&1) && ok "db-guard : autorisation explicite mémorisée" || ko "db-guard ack"
echo 'ALTER TABLE "t" ADD COLUMN "x" text;' > $gd/drizzle/0001_x.sql; rm -f $gd/drizzle/.guard-ack; (cd $gd && node scripts/db-guard.mjs >/dev/null 2>&1) && ok "db-guard : migration sans risque acceptée" || ko "db-guard faux positif"
# identité changée sur projet déjà migré ⇒ blocage, --force passe
rj=$G/v0j; cp -R $ri $rj; perl -0pi -e 's/"idStrategy": "uuid"/"idStrategy": "serial"/' $rj/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rj --out $gd --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 && ko "dérive d'identité non bloquée" || { grep -q 'identité Better Auth modifiée' $G/last.log && ok "dérive d'identité sur projet migré : bloquée avec guide" || ko "dérive message"; }
$BIN/tsx gen_nestjs.ts $rj --out $gd --architecture ddd_layered --auth better_auth --level N2 --force >$G/last.log 2>&1 && ok "dérive d'identité : --force passe" || { cat $G/last.log; ko "--force identité"; }
# scripts périmés / auth.ts sans modelName
sed -i.bak 's#"db:setup": "[^"]*"#"db:setup": "pnpm db:migrate"#' $gd/package.json; rm $gd/package.json.bak
$BIN/tsx gen_nestjs.ts $ri --out $gd --architecture ddd_layered --auth better_auth --level N2 --force >$G/last.log 2>&1
grep -q 'script db:setup périmé' $G/last.log && ok "package.json : script périmé signalé" || ko "script périmé"
sed -i.bak '/modelName/d' $gd/src/better-auth/auth.ts; rm $gd/src/better-auth/auth.ts.bak
$BIN/tsx gen_nestjs.ts $ri --out $gd --architecture ddd_layered --auth better_auth --level N2 --force >$G/last.log 2>&1
grep -q 'user.modelName "users" absent' $G/last.log && ok "auth.ts conservé sans modelName : signalé" || ko "dérive auth.ts"

# auth-schema.mjs sur un faux schéma `auth generate` : table retirée, importée ET réexportée (le drizzleAdapter la cherche dans ce module)
mkdir -p $gi/src/better-auth; printf 'import { pgTable, text } from "drizzle-orm/pg-core";\nexport const users = pgTable("users", {\n  id: text("id").primaryKey(),\n});\nexport const usersRelations = relations(users, ({ many }) => ({ s: many(session) }));\nexport const session = pgTable("session", { id: text("id") });\n' > $gi/src/better-auth/schema.ts
(cd $gi && node scripts/auth-schema.mjs >/dev/null) && grep -q 'export { users }' $gi/src/better-auth/schema.ts && ! grep -q 'pgTable("users"' $gi/src/better-auth/schema.ts && grep -q 'pgTable("session"' $gi/src/better-auth/schema.ts && ok "auth-schema.mjs : identité importée + réexportée, reste du schéma Better Auth conservé" || ko "auth-schema.mjs"
# isolation réelle (Postgres jetable via Docker ; ignorée sans Docker)
if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
  c=golden-rls-pg; docker rm -f $c >/dev/null 2>&1; docker run -d --rm --name $c -e POSTGRES_PASSWORD=pw -e POSTGRES_DB=t -p 54339:5432 postgres:16 >/dev/null
  for i in $(seq 40); do docker exec $c pg_isready -U postgres -d t >/dev/null 2>&1 && break; sleep 1; done; sleep 2
  var=$(grep -o '^[A-Z_]*=' $rg/.env | head -1 | tr -d '='); ln -sfn "$PWD/node_modules" $rg/node_modules
  (cd $rg && export $var=postgres://postgres:pw@localhost:54339/t && ../../$BIN/drizzle-kit push --force >/dev/null 2>&1 && node scripts/apply-rls.mjs >/dev/null && node scripts/apply-rls.mjs >/dev/null && cp ../../golden/rls-isolation.ts.tpl ./rls-test.ts && ../../$BIN/tsx rls-test.ts >$OLDPWD/$G/rls.log 2>&1) && grep -q 'rls : tout est ok' $G/rls.log && ok "RLS isolation réelle (Postgres 16) : A/B/admin/anonyme, WITH CHECK, rollback, concurrence, idempotence" || { cat $G/rls.log; docker rm -f $c >/dev/null; ko "RLS isolation"; }
  docker rm -f $c >/dev/null 2>&1
else echo "--  RLS isolation : Docker absent, ignorée"; fi

# N2 mysql / sqlite : schéma du moteur, un repository par table, tsc ; mysql sans returning() ; sqlite : aller-retour réel sur un fichier (DDL scaf)
for e in mysql sqlite; do
  m=$G/n2-$e; gen --out $m --architecture ddd_layered --auth none --level N2 --database $e
  (cd $m && ../../$BIN/tsc --noEmit -p .) || ko "tsc N2 $e"
  nt=$(cat $V/output/database/$e/drizzle/*.ts | grep -c "= ${e}Table(") nr=$(ls $m/src/database/repositories | grep -vc base)
  [ "$nt" = "$nr" ] && grep -q "dialect: \"$e\"" $m/drizzle.config.ts && ok "N2 $e : $nt tables = $nr repositories, tsc" || ko "N2 $e ($nt tables, $nr repositories)"
done
grep -rq "en-tête du pilote" $G/n2-mysql/src/modules && ok "N2 mysql : guide mentionne l'en-tête du pilote" || ko "guide mysql"
grep -q 'affectedRows' $G/n2-mysql/src/database/repositories/base.repository.ts && ! grep -q '\.returning()' $G/n2-mysql/src/database/repositories/base.repository.ts && ok "N2 mysql : repositories sans returning()" || ko "N2 mysql returning"
m=$G/n2-sqlite; (cd $m && ../../$BIN/tsc -p .) || ko "build N2 sqlite"
ln -sfn "$PWD/node_modules" $m/node_modules; echo '{"type":"commonjs"}' > $m/package.json
cat > $m/rt.js <<'JS'
require("reflect-metadata");
const Database = require("better-sqlite3");
const f = process.env.NEON_DATABASE_CONNEXION_STRING;
const raw = new Database(f); raw.exec(require("fs").readFileSync(process.argv[2], "utf8")); raw.close();
const { createDb } = require("./dist/database/db");
const { CitiesRepository } = require("./dist/database/repositories/cities.repository");
(async () => {
  const r = new CitiesRepository(createDb());
  const row = await r.insert({ name: "Abidjan", slug: "abidjan" });
  const ok = [(await r.findAll()).length === 1, (await r.findById(row.id)).name === "Abidjan", (await r.update(row.id, { name: "Bouaké" })).name === "Bouaké", (await r.delete(row.id)) === true, (await r.findAll()).length === 0];
  console.log(JSON.stringify(ok)); process.exit(ok.every(Boolean) ? 0 : 1);
})().catch(e => { console.error(e); process.exit(1); });
JS
rm -f $G/rt.db; (cd $m && NEON_DATABASE_CONNEXION_STRING=../rt.db node rt.js ../../$V/output/database/sqlite/schema.sql) && ok "N2 sqlite : insert, findById, update, delete sur un vrai fichier" || ko "N2 sqlite aller-retour"

# côte à côte : une 2e architecture dans la même sortie n'efface pas la 1re
gen --out $d --architecture modular_simple --auth none
[ -d $d/src/modules/ddd_layered ] && [ -d $d/src/modules/modular_simple ] && ok "architectures côte à côte" || ko "côte à côte"

# obsolète : un fichier généré non modifié, plus produit, est supprimé ; modifié, il est gardé
gen --out $d --architecture modular_simple --level N0 --force
[ -z "$(find $d/src/modules/modular_simple -name '*.dto.ts' -o -name '*.controller.ts')" ] && ok "obsolètes supprimés (N0), usecases preserve gardés" || ko "obsolète non supprimé"
[ -f $uc ] && ok "usecase édité gardé" || ko "usecase édité supprimé"

# un controller par feature (plus de controller de module), préfixe/version posés une fois
d=$G/modular_simple-jwt
[ ! -f $d/src/modules/modular_simple/booking/booking.controller.ts ] && [ -f $d/src/modules/modular_simple/booking/trip-lifecycle.controller.ts ] && grep -q 'version: "1"' $d/src/modules/modular_simple/booking/trip-lifecycle.controller.ts && ! grep -rq '"api/v1' $d/src/modules && grep -q 'enableVersioning' $d/src/main.ts && ok "controllers par feature, préfixe api + version uri" || ko "controllers par feature"

# HTTP : 401 sans jeton, 403 non admin, 501 enveloppé avec jeton admin, 400 enveloppé sur query invalide
d=$G/modular_simple-jwt
# usecase de test : handlers sur critical/high, skip (medium), todo (low) → exécuté + warn
uc=$(find $d/src -name 'get-admin-rides.usecase.ts')
perl -0pi -e 's|"admin.verify_admin_session": todo\(.*?\n    \}\),|"admin.verify_admin_session": async (c) => { c.state.t = ["v"]; },|s; s|"rides.validate_filters": todo\(.*?\n    \}\),|"rides.validate_filters": async (c) => c.skip("golden"),|s; s|"rides.search_rides": todo\(.*?\n    \}\),|"rides.search_rides": async (c) => { (c.state.t as string[]).push("s"); c.output = result((c.state.t as string[]).join(">")).message("golden-msg").warn({ title: "w", description: "d", tips: [] }).withHeaders({ "x-golden": "1" }).paged(paginate(1, 10, 1)) as never; },|s' $uc
rel=$(node -e 'console.log(require("path").relative(require("path").dirname(process.argv[1]), process.argv[2]+"/src/core"))' "$uc" "$d")
{ echo "import { result } from \"$rel/api-result\"; import { paginate } from \"$rel/pagination\";"; cat $uc; } > $uc.new && mv $uc.new $uc
(cd $d && ../../$BIN/tsc -p .) || ko "tsc usecase de test"
# steps ET run() → erreur claire ; run() seul → ok
uc2=$(find $d/src -name 'get-admin-cities.usecase.ts')
perl -0pi -e 's|\n  \};\n|\n  };\n  protected async run(): Promise<never> { return "RUN" as never; }\n|' $uc2
(cd $d && ../../$BIN/tsc -p .) || ko "tsc steps+run"
ln -sfn "$PWD/node_modules" $d/node_modules; echo "{\"type\":\"commonjs\"}" > $d/package.json
export JWT_SECRET=golden PORT=3917
tok() { node -e 'const c=require("crypto"),b=x=>Buffer.from(JSON.stringify(x)).toString("base64url"),h=b({alg:"HS256"}),p=b({sub:"u1",role:process.argv[1]});console.log(h+"."+p+"."+c.createHmac("sha256","golden").update(h+"."+p).digest("base64url"))' "$1"; }
(cd $d && exec node dist/main.js >../http.log 2>&1) & pid=$!
trap 'kill $pid 2>/dev/null || true' EXIT
for i in $(seq 30); do curl -s localhost:3917/x >/dev/null 2>&1 && break; sleep 0.3; done
code() { curl -s -o "$G/body.json" -w '%{http_code}' "$@"; }
A=localhost:3917/api/v1/admin/rides
[ "$(code localhost:3917/health)" = 200 ] && grep -q '"ok"' $G/body.json && ok "health enveloppé" || ko "health"
[ "$(code $A)" = 401 ] && grep -q '"UNAUTHORIZED"' $G/body.json && ok "401 enveloppé" || ko "401"
[ "$(code -H "Authorization: Bearer $(tok user)" $A)" = 403 ] && grep -q '"FORBIDDEN"' $G/body.json && ok "403 enveloppé" || ko "403"
[ "$(code -H "Authorization: Bearer $(tok admin)" "$A?status=NOPE")" = 400 ] && grep -q '"VALIDATION_ERROR"' $G/body.json && ok "400 validation enveloppée" || { cat $G/body.json; ko "400"; }
[ "$(curl -s -D $G/hdr.txt -o $G/body.json -w '%{http_code}' -H "Authorization: Bearer $(tok admin)" "$A")" = 200 ] && grep -q 'v>s' $G/body.json && grep -q '"golden-msg"' $G/body.json && grep -q '"warnings":\[{"title":"w"' $G/body.json && grep -q '"pagination":{"current_page":1' $G/body.json && grep -qi '^x-golden: 1' $G/hdr.txt && ok "enveloppe ApiResult : message, warnings, pagination, en-têtes" && ok "handlers exécutés dans l'ordre, skip = fait" || { cat $G/body.json; ko "pipeline"; }
grep -q 'rides.paginate_results' $G/http.log && ok "étape low manquante → warn, exécution" || { cat $G/http.log; ko "warn low"; }
B=localhost:3917/api/v1/admin/bookings
[ "$(code -H "Authorization: Bearer $(tok admin)" "$B")" = 501 ] && grep -q '"NOT_READY"' $G/body.json && grep -q 'étapes manquantes' $G/body.json && ok "usecase neuf → 501 NOT_READY enveloppé" || { cat $G/body.json; ko "NOT_READY"; }
grep -Eq '[0-9]+/[0-9]+ usecases prêts' $G/http.log && ok "rapport de démarrage" || { cat $G/http.log; ko "reporter"; }

[ "$(code -H "Authorization: Bearer $(tok admin)" localhost:3917/api/v1/admin/cities)" = 500 ] && ok "steps + run() → 500 explicite" || { cat $G/body.json; ko "steps+run"; }
grep -q 'steps ET run()' $G/http.log && ok "message steps ET run() journalisé" || ko "log steps+run"

# guide d'utilisation placé après la classe
g=$(find $d/src -name 'get-admin-rides.usecase.ts'); [ "$(grep -n "^export class" $g | cut -d: -f1)" -lt "$(grep -n "GUIDE D'UTILISATION" $g | cut -d: -f1)" ] && ok "guide d'utilisation après la classe" || ko "guide"
# endpoint paginé sans .paged() → tsc échoue
cp $uc $uc.keep
dto=$(find $d/src -name 'get-admin-rides.dto.ts'); r=$(node -e 'console.log(require("path").relative(require("path").dirname(process.argv[1]), process.argv[2]).replace(/\.ts$/,""))' "$uc" "$dto")
echo "const _np: import(\"$r\").GetAdminRidesOutput = result(null as any);" >> $uc
(cd $d && ../../$BIN/tsc --noEmit -p . >/dev/null 2>&1) && ko "pagination non exigée" || ok "endpoint paginé sans .paged() → tsc échoue"
mv $uc.keep $uc

# dérive : un step ajouté à la spec casse la compilation du stub
sed -i.bak 's|^export const GetAdminRidesSteps = \[|&{ code: "x.new", order: 99, severity: "low", description: "d" },|' $(find $d/src -name 'get-admin-rides.dto.ts')
(cd $d && ../../$BIN/tsc --noEmit -p . >/dev/null 2>&1) && ko "dérive non détectée" || ok "step manquant dans le stub → tsc échoue"
echo "golden NestJS : tout est ok"
