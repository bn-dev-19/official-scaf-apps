# Fixture du golden : 2 ressources (offers, articles) dont 3 endpoints partagent un `data` identique.
# Usage : ruby golden-names-fixture.rb <dossier-version> [title]   (title : `title: Offer` posé sur le `data` d'offers)
require 'fileutils'
root, with_title = ARGV
c = File.join(root, 'input', 'contracts')
FileUtils.mkdir_p(File.join(c, 'apps/pro/main'))
File.write(File.join(c, '_index.yml'), "version: 1\napps:\n  - slug: pro\n    label: pro\n    modules:\n      - slug: main\n        name: Main\n        features: [offers, articles]\n")
File.write(File.join(c, 'servers.yml'), "servers:\n  - url: http://localhost:3000\n    description: local\n")

def endpoint(id, method, path, fields, title)
  data = ['type: object', *(title ? ["title: #{title}"] : []), 'properties:', *fields.map { |k| "  #{k}: {type: string, description: champ #{k}}" }]
  spec = [
    'endpoint:', "  id: #{id}", "  name: #{id}", '  description: d',
    'http:', "  method: #{method}", "  path: \"#{path}\"", '  auth: {type: none}', '  request:', '    query: []',
    '  response:', '    status: 200', '    body:', '      type: object', '      properties:',
    '        success: {type: boolean}', '        message: {type: string}', '        data:',
    *data.map { |l| "          #{l}" },
    '    errors:',
    '    - {status: 500, code: INTERNAL_SERVER_ERROR, description: x, message: x, cause: x, resolution: x}',
    'usecase:', '  description: d'
  ]
  # `errors` est au niveau de `response` (frère de body)
  spec = spec.map { |l| l.start_with?('    errors:', '    - {status') ? "  #{l}" : l }
  ["  - id: #{id}", "    name: #{id}", "    method: #{method}", "    path: #{path}", '    spec: |',
   *spec.map { |l| "      #{l}" }, '    mocks: |-', "      {\"endpoint\": \"#{id}\", \"mocks\": []}"].join("\n") + "\n"
end

{ 'offers' => [%w[offer_id offer_slug booking_mode], with_title && 'Offer'],
  'articles' => [%w[article_id article_status cta_type], nil] }.each do |res, (fields, title)|
  s = "slug: #{res}\nname: #{res}\nendpoints:\n"
  s += endpoint("post-#{res}", 'POST', "/api/v1/#{res}", fields, title)
  s += endpoint("get-#{res}", 'GET', "/api/v1/#{res}/{id}", fields, title)
  s += endpoint("put-#{res}", 'PUT', "/api/v1/#{res}/{id}", fields, title)
  File.write(File.join(c, "apps/pro/main/#{res}.yml"), s)
end
