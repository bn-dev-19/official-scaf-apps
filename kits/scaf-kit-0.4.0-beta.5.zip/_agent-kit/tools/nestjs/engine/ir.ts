// Modèle neutre : contrats scaf → modules/endpoints, indépendant de toute architecture, ORM ou auth.
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { load as yamlLoad } from "js-yaml";
import type { SpecBody, SpecProp, SpecContext, MockScenario } from "../../_shared/_lib/spec-types";
import { kebabToCamel, kebabToPascal } from "../../_shared/_lib/naming";

export interface Param { name: string; type: string; format?: string; required: boolean; enum?: string[]; description?: string }
export interface Intent { purpose?: string; actors?: string[]; actorDescriptions?: Record<string, string>; preconditions?: string[]; effects?: string[]; depends_on?: { endpoint: string; when?: string; why?: string }[]; consumer_notes?: string | string[]; tables?: { table: string; access?: "read" | "write"; why?: string; description?: string }[] }
export interface StepIR { code: string; order: number; severity: string; description: string }
export interface EndpointIR {
  id: string; app: string; name: string; description: string; method: string;
  feature: string; version?: string;
  path: string; nestPath: string; pascal: string; camel: string;
  guard: string | null; pathParams: string[]; pathSpecs: Record<string, { type: string; format?: string; enum?: string[]; description?: string }>; query: Param[]; body?: SpecBody; data?: SpecProp; paginated: boolean;
  status: number; errors: { status: number; code: string; message: string }[];
  intent?: Intent; steps: string[]; stepList: StepIR[]; usecaseDescription?: string; mocks: MockScenario[];
  calls: CallIR[];
}
/** `calls` d'un usecase producer : appel direct (sync) ou événement émis après succès (event). */
export interface CallIR { usecase: string; mode: "sync" | "event"; when?: string; after?: string }
/** Usecase producer sans HTTP (sans `openapi`, rattaché par `feature: <module>/<feature>`) : appelé par un autre usecase ou par un événement. */
export interface InternalIR { id: string; app: string; pascal: string; camel: string; feature: string; description: string; input?: SpecBody; intent?: Intent; steps: string[]; stepList: StepIR[]; calls: CallIR[] }
export interface ModuleIR { key: string; pascal: string; endpoints: EndpointIR[]; internals: InternalIR[] }

const DEFAULT_MSG: Record<number, string> = { 400: "Requête invalide.", 401: "Jeton manquant ou invalide.", 403: "Accès refusé.", 404: "Ressource introuvable.", 409: "Conflit avec l'état actuel de la ressource.", 422: "Les données envoyées sont invalides.", 429: "Trop de requêtes, réessayez plus tard.", 500: "Erreur interne du serveur." };

interface LoadedUc { intent?: Intent; steps: string[]; stepList: StepIR[]; description?: string; calls: CallIR[] }
const callsOf = (u: any): CallIR[] => (u.calls ?? []).filter((c: any) => c?.usecase).map((c: any) => ({ usecase: c.usecase, mode: c.mode === "event" ? "event" : "sync", when: c.when, after: c.after }));
const stepsOf = (u: any): StepIR[] => { const seen = new Set<string>(); return (u.steps ?? []).filter((s: any) => s.code && !seen.has(s.code) && seen.add(s.code))
  .map((s: any, i: number) => ({ code: s.code, order: Number.isInteger(s.order) ? s.order : i + 1, severity: s.severity ?? "medium", description: s.stepDescription ?? s.description ?? "" })); };
const stepTexts = (u: any): string[] => (u.steps ?? []).map((s: any) => [s.code && `[${s.code}]`, s.stepDescription ?? s.description].filter(Boolean).join(" "));

/** Usecases producer sans `openapi` mais rattachés à une feature : usecases internes (sans route). */
function loadInternals(versionDir: string, app: string): (InternalIR & { module: string })[] {
  const dir = join(versionDir, "input", "usecases", "producer", app);
  if (!existsSync(dir)) return [];
  const out: (InternalIR & { module: string })[] = [];
  for (const f of readdirSync(dir).filter(x => x.endsWith(".usecase.yml")).sort()) {
    const u = yamlLoad(readFileSync(join(dir, f), "utf8")) as any;
    if (!u?.id || u.openapi?.operationId || typeof u.feature !== "string" || !u.feature.includes("/")) continue;
    const input = u.input?.schema && Object.keys(u.input.schema).length ? { type: "object", properties: u.input.schema, required: Object.entries(u.input.schema).filter(([, v]: any) => v?.required).map(([k]) => k) } as SpecBody : undefined;
    out.push({ id: u.id, app, module: u.feature.split("/")[0], pascal: kebabToPascal(u.id), camel: kebabToCamel(u.id), feature: u.feature.split("/")[1], description: u.description ?? u.name ?? u.id, input, intent: u.intent, steps: stepTexts(u), stepList: stepsOf(u), calls: callsOf(u) });
  }
  return out;
}

function loadIntents(versionDir: string, app: string): Map<string, LoadedUc> {
  const m = new Map<string, LoadedUc>();
  const dir = join(versionDir, "input", "usecases", "producer", app);
  if (!existsSync(dir)) return m;
  for (const f of readdirSync(dir).filter(x => x.endsWith(".usecase.yml")).sort()) {
    const u = yamlLoad(readFileSync(join(dir, f), "utf8")) as any;
    const id = u?.openapi?.operationId;
    if (id) m.set(id, { intent: u.intent, description: u.description, stepList: stepsOf(u), steps: stepTexts(u), calls: callsOf(u) });
  }
  return m;
}

/** `description` de chaque table du visuel DB (nom SQL → texte), pour le guide des usecases. */
function loadActorDescriptions(versionDir: string): Map<string, string> {
  const m = new Map<string, string>(), f = join(versionDir, "input", "project.parts", "actors.yml");
  if (existsSync(f)) for (const a of (yamlLoad(readFileSync(f, "utf8")) as any[]) ?? []) if (a?.id && a.description) m.set(a.id, String(a.description).replace(/\s+/g, " ").trim());
  return m;
}
function loadTableDescriptions(versionDir: string): Map<string, string> {
  const m = new Map<string, string>(), dir = join(versionDir, "input", "database", "visual");
  if (!existsSync(dir)) return m;
  for (const f of readdirSync(dir).filter(x => /^_visual_.*\.yml$/.test(x) && x !== "_visual_enums.yml")) {
    const d = yamlLoad(readFileSync(join(dir, f), "utf8")) as any;
    for (const t of d?.tables ?? []) if (t?.name && t.description) m.set(t.name, String(t.description));
  }
  return m;
}

/** Modules Nest à partir des apps. Un slug de module présent dans plusieurs apps (mode fusionné) est préfixé `<app>-`. */
export function buildModules(apps: Map<string, SpecContext>, versionDir: string, opts: { globalPrefix?: string; versioning?: string } = {}): { modules: ModuleIR[]; warnings: string[]; validationStatus: number } {
  const warnings: string[] = [];
  const owners = new Map<string, Set<string>>();
  for (const [app, ctx] of apps) for (const e of ctx.endpoints) (owners.get(e.module) ?? owners.set(e.module, new Set()).get(e.module)!).add(app);
  const byKey = new Map<string, ModuleIR>();
  const seen = new Set<string>();
  const valStatus = new Map<number, number>();
  const tableDesc = loadTableDescriptions(versionDir), actorDesc = loadActorDescriptions(versionDir);
  for (const [app, ctx] of apps) {
    const intents = loadIntents(versionDir, app);
    for (const u of intents.values()) { for (const t of u.intent?.tables ?? []) t.description = tableDesc.get(t.table); if (u.intent?.actors?.length) u.intent.actorDescriptions = Object.fromEntries(u.intent.actors.filter(a => actorDesc.has(a)).map(a => [a, actorDesc.get(a)!])); }
    for (const e of ctx.endpoints) {
      if (seen.has(e.id)) { warnings.push(`endpoint ${e.id} dupliqué (${app}) : ignoré`); continue; }
      seen.add(e.id);
      const http = e.spec.http!;
      const auth = http.auth;
      const errors = (http.response?.errors ?? []).map(x => ({ status: Number(x.status), code: x.code, message: (x as any).message ?? x.description ?? DEFAULT_MSG[Number(x.status)] ?? "Erreur." }));
      for (const x of errors) if (x.code === "VALIDATION_ERROR") valStatus.set(x.status, (valStatus.get(x.status) ?? 0) + 1);
      const key = owners.get(e.module)!.size > 1 ? `${app}-${e.module}` : e.module;
      const mod = byKey.get(key) ?? byKey.set(key, { key, pascal: kebabToPascal(key), endpoints: [], internals: [] }).get(key)!;
      const uc = intents.get(e.id);
      // chemin du contrat → préfixe global (api) et version (vN) retirés quand ils sont déclarés : posés une fois (main.ts / @Controller), plus répétés
      let rest = e.path.replace(/^\//, ""), version: string | undefined;
      const gp = (opts.globalPrefix ?? "").replace(/^\/|\/$/g, "");
      if (gp) { if (!rest.startsWith(gp + "/")) throw new Error(`${e.id} : le chemin ${e.path} ne commence pas par /${gp}/ (globalPrefix)`); rest = rest.slice(gp.length + 1); }
      if (opts.versioning === "uri") { const v = /^v([^/{}]+)\//.exec(rest); if (!v) throw new Error(`${e.id} : le chemin ${e.path} n'a pas de segment /v<version>/ (versioning uri)`); version = v[1]; rest = rest.slice(v[0].length); }
      mod.endpoints.push({
        id: e.id, app, name: e.name, description: e.spec.endpoint?.description ?? "", method: e.method.toUpperCase(),
        feature: e.feature, version, path: e.path, nestPath: rest.replace(/\{(\w+)\}/g, ":$1"), pascal: kebabToPascal(e.id), camel: kebabToCamel(e.id),
        guard: auth?.type === "required" ? (auth.guard || "RequireAuth") : null,
        pathParams: [...e.path.matchAll(/\{(\w+)\}/g)].map(m => m[1]),
        pathSpecs: Object.fromEntries((http.request?.path ?? []).map(p => [p.name, { type: p.type, format: p.format, enum: p.enum, description: p.description }])),
        query: (http.request?.query ?? []).map(q => ({ name: q.name, type: q.type, format: q.format, required: !!q.required, enum: q.enum, description: q.description })),
        body: http.request?.body && http.request.body.type ? http.request.body : undefined,
        data: http.response?.body?.properties?.data, paginated: !!http.response?.body?.properties?.pagination,
        status: http.response?.status ?? 200, errors, intent: uc?.intent, steps: uc?.steps ?? [], stepList: uc?.stepList ?? [],
        mocks: e.scenarios ?? [], calls: uc?.calls ?? [],
        usecaseDescription: uc?.description || (e.spec as any).usecase?.description || undefined,
      });
    }
  }
  // usecases internes (sans route) : dans le module de leur feature
  for (const [app] of apps) for (const u of loadInternals(versionDir, app)) {
    if (seen.has(u.id)) { warnings.push(`usecase interne ${u.id} dupliqué (${app}) : ignoré`); continue; }
    seen.add(u.id);
    const key = (owners.get(u.module)?.size ?? 0) > 1 ? `${app}-${u.module}` : u.module;
    const mod = byKey.get(key) ?? byKey.set(key, { key, pascal: kebabToPascal(key), endpoints: [], internals: [] }).get(key)!;
    for (const t of u.intent?.tables ?? []) t.description = tableDesc.get(t.table);
    mod.internals.push(u);
  }
  // statiques avant paramétrés : `/x/search` doit précéder `/x/:id` dans le contrôleur
  const rank = (p: string) => p.replace(/:\w+/g, "~");
  for (const m of byKey.values()) m.endpoints.sort((a, b) => rank(a.nestPath).localeCompare(rank(b.nestPath)) || a.method.localeCompare(b.method));
  const top = [...valStatus.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? 400;
  return { modules: [...byKey.values()].sort((a, b) => a.key.localeCompare(b.key)), warnings, validationStatus: top };
}
