/** Propriété de tableau d'un décorateur : sur une ligne si court (≤ 3 éléments et ≤ 80 car.), sinon un élément par ligne. Vide → "". */
export function listProp(name: string, items: string[]): string {
  if (!items.length) return "";
  const one = `  ${name}: [${items.join(", ")}],\n`;
  return items.length <= 3 && one.length <= 80 ? one : `  ${name}: [\n${items.map(i => `    ${i},`).join("\n")}\n  ],\n`;
}

/** Coupe un texte aux espaces en lignes ≤ width (un mot plus long reste entier). */
export function wrap(text: string, width = 100): string[] {
  const out: string[] = [];
  let cur = "";
  for (const w of text.split(/\s+/).filter(Boolean)) {
    if (cur && cur.length + 1 + w.length > width) { out.push(cur); cur = w; } else cur = cur ? `${cur} ${w}` : w;
  }
  return cur ? [...out, cur] : out;
}

/** Commentaire JSDoc indenté : une ligne si court, sinon un bloc multiligne (le texte ne doit pas contenir la fin de commentaire). */
export function jsdoc(text: string, ind = "  ", width = 100): string {
  const lines = wrap(text, width - ind.length - 6);
  return lines.length <= 1 ? `${ind}/** ${lines[0] ?? ""} */\n` : `${ind}/**\n${lines.map(l => `${ind} * ${l}`).join("\n")}\n${ind} */\n`;
}

/** Coupe une ligne de commentaire/bloc trop longue à `width` : retrait suspendu (colonne de description si ligne en tableau « terme   description »). */
export function wrapLine(line: string, width = 110): string[] {
  if (line.length <= width) return [line];
  const [, lead, text] = /^(\s*\*?\s*)(.*)$/.exec(line)!;
  const star = /^\s*\*?/.exec(lead)![0];
  const col = /\S( {3,})\S/.exec(text);
  const idx = col && lead.length + col.index + 1 + col[1].length < width / 2 ? col.index + 1 + col[1].length : 0;
  const hang = lead.length + (idx ? idx : /^\d+\. /.test(text) ? 3 : lead.length > 8 ? 0 : 2);
  const pad = star + " ".repeat(Math.max(0, hang - star.length));
  const [head, rest] = idx ? [lead + text.slice(0, idx), text.slice(idx)] : ["", text];
  const parts = wrap(rest, Math.max(30, width - hang));
  return parts.map((w, i) => (i ? pad : head || lead) + w);
}

/** Objet littéral `{ a, b }` : sur une ligne si le tout tient dans `width`, sinon un champ par ligne (`head` = texte avant l'accolade, `ind` = indentation de la ligne). */
export function obj(head: string, props: string[], tail: string, ind = "  ", width = 100): string {
  const one = `${ind}${head}{ ${props.join(", ")} }${tail}`;
  return one.length <= width ? one : `${ind}${head}{\n${props.map(x => `${ind}  ${x},`).join("\n")}\n${ind}}${tail}`;
}

/** `import { A, B, C } from "x";` trop long (> width) → un nom par ligne ; un import à nom unique reste sur une ligne (chemin incassable). */
export function fmtImports(src: string, width = 110): string {
  return src.replace(/^import (type )?\{ ([^}\n]+) \} from ("[^"\n]+");$/gm, (m, t = "", names: string, from: string) => {
    const list = names.split(", ");
    return m.length <= width || list.length < 2 ? m : `import ${t}{\n${list.map(n => `  ${n},`).join("\n")}\n} from ${from};`;
  });
}

/** `head` + `tail` sur une ligne si ≤ width, sinon `tail` à la ligne, indenté de 4 car. de plus que `head`. */
export function brk(head: string, tail: string, width = 120): string {
  if (`${head} ${tail}`.length <= width) return `${head} ${tail}`;
  return `${head}\n${/^ */.exec(head)![0]}  ${tail}`;
}

/** Liste d'éléments entre `open` et `close` (génériques, paramètres) : une ligne si ≤ width, sinon un élément par ligne à `ind` + 2. */
export function list(open: string, items: string[], close: string, ind = "", width = 120): string {
  const one = `${open}${items.join(", ")}${close}`;
  return one.length + ind.length <= width ? one : `${open}\n${items.map(i => `${ind}  ${i}`).join(",\n")}${close.startsWith(")") ? "," : ""}\n${ind}${close}`;
}
