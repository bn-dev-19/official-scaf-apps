// Registre unique des variables d'environnement du projet généré : alimente .env.example, .env (créé s'il n'existe pas), la validation au démarrage,
// le script env:init, les placeholders e2e et les notes. Les noms viennent de nestjs.json (`$var:NOM`), sinon des défauts.
import { randomBytes } from "node:crypto";
import type { GeneratedFile } from "../../_shared/generated-file";

export interface EnvVar {
  name: string; doc: string;
  /** secret : valeur aléatoire générée ; url / literal : `value` (défaut) ou vide, à fournir. */
  kind: "secret" | "url" | "literal";
  required: boolean; value?: string;
  /** Valeur factice posée par les tests e2e avant l'import de l'app. */
  e2e?: string;
}
export interface EnvCtx { auth: string; db?: { dialect: string }; databaseUrl?: string; authSecret?: string; authBaseUrl?: string; oauthProviders: string[]; port: number; rateLimiting?: boolean }

const nameOf = (v: string | undefined, d: string) => (v?.startsWith("$var:") ? v.slice(5) : v) || d;
const E2E_DB: Record<string, string> = { postgresql: "postgres://e2e:e2e@localhost:5432/e2e", mysql: "mysql://e2e:e2e@localhost:3306/e2e", sqlite: ":memory:" };

export function envVars(c: EnvCtx): EnvVar[] {
  const v: EnvVar[] = [];
  if (c.db) v.push({ name: nameOf(c.databaseUrl, "DATABASE_URL"), kind: "url", required: true, doc: c.db.dialect === "sqlite" ? "Chemin du fichier SQLite" : "Chaîne de connexion à la base (migrations : préférer l'URL directe, sans pooler)", value: c.db.dialect === "sqlite" ? "./local.db" : undefined, e2e: E2E_DB[c.db.dialect] });
  if (c.auth === "jwt") v.push({ name: "JWT_SECRET", kind: "secret", required: true, doc: "Secret de signature des jetons (HS256)", e2e: "e2e-secret" });
  if (c.auth === "better_auth") {
    v.push({ name: nameOf(c.authSecret, "BETTER_AUTH_SECRET"), kind: "secret", required: true, doc: "Secret Better Auth (32+ caractères aléatoires)", e2e: "e2e-secret-e2e-secret-e2e-secret!!" });
    v.push({ name: nameOf(c.authBaseUrl, "BETTER_AUTH_URL"), kind: "literal", required: true, doc: "URL de base publique de l'API", value: `http://localhost:${c.port}`, e2e: "http://localhost:3000" });
    for (const p of c.oauthProviders) for (const k of ["CLIENT_ID", "CLIENT_SECRET"]) v.push({ name: `${p.toUpperCase()}_${k}`, kind: "literal", required: true, doc: `OAuth ${p} (${k === "CLIENT_ID" ? "identifiant" : "secret"} de l'application)`, e2e: "e2e" });
  }
  if (c.rateLimiting) { v.push({ name: "RATE_LIMIT_TTL_MS", kind: "literal", required: false, doc: "Limitation de débit : fenêtre en millisecondes (429 RATE_LIMITED au-delà)", value: "60000" }); v.push({ name: "RATE_LIMIT_MAX", kind: "literal", required: false, doc: "Limitation de débit : requêtes max par fenêtre et par IP", value: "100" }); }
  v.push({ name: "PORT", kind: "literal", required: false, doc: "Port d'écoute de l'API", value: String(c.port) });
  return v;
}

/** Valeur de départ d'une variable : secret aléatoire (si autorisé), sinon défaut, sinon vide. */
export const initial = (x: EnvVar, secrets: boolean) => x.kind === "secret" && secrets ? randomBytes(32).toString("base64") : x.value ?? "";
const block = (x: EnvVar, value: string) => `# ${x.doc}${x.required ? "" : " (optionnel)"}\n${x.name}=${value}\n`;

/** `file` : .env.example + .env (créé si absent) + env:init ; `example` : .env.example seul ; `none` : rien. */
export function envFiles(vars: EnvVar[], mode: string, secrets: boolean): { files: GeneratedFile[]; scripts: Record<string, string> } {
  if (mode === "none") return { files: [], scripts: {} };
  const head = "# Variables d'environnement (voir .env.example). Ne pas committer .env.\n\n";
  const files: GeneratedFile[] = [{ path: ".env.example", content: head + vars.map(x => block(x, x.kind === "secret" ? "" : x.value ?? "")).join("\n") }];
  if (mode === "example") return { files, scripts: {} };
  files.push({ path: ".env", preserve: true, content: head + vars.map(x => block(x, initial(x, secrets))).join("\n") });
  // env:init : ajoute à .env les clés absentes (secrets générés), sans toucher aux valeurs existantes.
  const spec = vars.map(x => ({ n: x.name, d: x.doc, s: x.kind === "secret" && secrets, v: x.value ?? "" }));
  files.push({ path: "scripts/env-init.mjs", content: `// Ajoute à .env les variables absentes (secrets aléatoires), sans modifier l'existant. Généré : ne pas éditer.
import { existsSync, readFileSync, appendFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
const vars = ${JSON.stringify(spec)};
const cur = existsSync(".env") ? readFileSync(".env", "utf8") : "";
const add = vars.filter(x => !new RegExp("^" + x.n + "=", "m").test(cur));
appendFileSync(".env", (cur && !cur.endsWith("\\n") ? "\\n" : "") + add.map(x => \`# \${x.d}\\n\${x.n}=\${x.s ? randomBytes(32).toString("base64") : x.v}\\n\`).join("\\n"));
console.log(add.length ? \`.env : ajouté \${add.map(x => x.n).join(", ")}\` : ".env : complet");
` });
  return { files, scripts: { "env:init": "node scripts/env-init.mjs" } };
}

/** src/core/env.ts : charge .env puis vérifie les variables requises avant tout autre import (échec immédiat, liste complète). */
export const envGuardFile = (vars: EnvVar[]): GeneratedFile => ({ path: "src/core/env.ts", content: `// Importé en premier par main.ts : charge .env puis vérifie les variables requises (une seule erreur, liste complète).
try { process.loadEnvFile(); } catch { /* pas de .env : variables d'environnement du shell */ }

const required: string[] = ${JSON.stringify(vars.filter(x => x.required).map(x => x.name))};
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error(\n    \`Variables d'environnement manquantes : \${missing.join(", ")}\\n\` +\n      "Voir .env.example (pnpm env:init crée les absentes de .env).",\n  );
  process.exit(1);
}
` });

/** README.md du projet (créé une fois) : étapes de mise en route dans l'ordre, selon la config. */
export function setupReadme(o: { name: string; vars: EnvVar[]; envMode: string; db: boolean; betterAuth: boolean; e2e: boolean; migrations: boolean; rls?: boolean }): GeneratedFile {
  const steps = [
    "`pnpm install`",
    ...(o.envMode === "none" ? [] : ["`pnpm env:init` : crée/complète `.env` (secrets générés) ; renseigner ensuite les variables vides (voir ci-dessous)"]),
    ...(o.db && o.migrations ? [`\`pnpm db:setup\` : ${o.betterAuth ? "`auth:generate` (tables Better Auth) → " : ""}\`db:generate\`${o.betterAuth ? " → `db:guard` (refuse une migration destructive)" : ""} → \`db:migrate\`${o.rls ? " → `db:rls` (policies RLS)" : ""} (dans cet ordre)`] : []),
    "`pnpm dev` (ou `pnpm build && pnpm start:prod`)",
    ...(o.e2e ? ["`pnpm test:e2e` : tests des mocks des contrats"] : []),
  ];
  return { path: "README.md", preserve: true, content: `# ${o.name}

API NestJS générée par scaf (\`gen_nestjs\`). Fichiers utilisateur (jamais réécrits) : \`*.usecase.ts\`, \`src/database/repositories/\`, \`src/better-auth/\`, \`.env\`, \`package.json\`, ce README.

## Mise en route
${steps.map((x, i) => `${i + 1}. ${x}`).join("\n")}

## Variables d'environnement
${o.envMode === "none" ? "" : "Modèle : `.env.example`. "}Le démarrage échoue avec la liste des variables requises manquantes.

| Variable | Requise | Rôle |
|---|---|---|
${o.vars.map(x => `| \`${x.name}\` | ${x.required ? "oui" : "non"} | ${x.doc} |`).join("\n")}
` };
}
