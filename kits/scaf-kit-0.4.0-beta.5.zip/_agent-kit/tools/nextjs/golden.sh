#!/usr/bin/env bash
# Test d'or L2–L4 : pour chaque architecture, génère depuis une copie de scaf/v0 dont le config nextjs
# est forcé sur cette architecture, puis typecheck chaque app. + idempotence, fichiers utilisateur préservés, safeAction.
set -euo pipefail
cd "$(dirname "$0")"
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
V=${1:-../../../v0}
pnpm exec tsc -p .

for arch in clean_architecture mvvm mvc; do
  # copie de la version avec l'architecture forcée (config de base + overrides par app)
  mkdir -p "$W/$arch"; cp -R "$V" "$W/$arch/ver"; V2="$W/$arch/ver"
  sed -i.bak -E "s/\"architecture\": \"[a-z_]+\"/\"architecture\": \"$arch\"/" "$V2"/input/export-configs/nextjs*.json
  pnpm exec tsx gen_nextjs.ts "$V2" --level L4 --out "$W/$arch/a" | grep architecture | sort -u
  if [ "$arch" = clean_architecture ]; then
    pnpm exec tsx gen_nextjs.ts "$V2" --level L4 --out "$W/$arch/b" >/dev/null
    diff -r "$W/$arch/a" "$W/$arch/b" >/dev/null && echo "idempotent: ok"
  fi
  for app in $(ls "$W/$arch/a"); do
    F="$W/$arch/fx-$app"; mkdir -p "$F/src/lib"
    cp -R "$W/$arch/a/$app/src/." "$F/src/"
    [ -d "$W/$arch/a/$app/docs-tool" ] && cp -R "$W/$arch/a/$app/docs-tool" "$F/docs-tool"
    ln -s "$PWD/node_modules" "$F/node_modules"
    [ -f "$F/src/lib/logger.ts" ] || echo 'import pino from "pino"; export const logger = pino();' > "$F/src/lib/logger.ts"
    echo '{"compilerOptions":{"strict":true,"noEmit":true,"skipLibCheck":true,"jsx":"preserve","module":"esnext","moduleResolution":"bundler","target":"es2022","paths":{"@/*":["./src/*"],"@docs/*":["./docs-tool/src/*"]}},"include":["src"]}' > "$F/tsconfig.json"
    pnpm exec tsc -p "$F" && echo "tsc $arch/$app: ok"
  done
done

# producer activé : typecheck + fichiers producer en preserve
P="$W/prod"; mkdir -p "$P"; cp -R "$V" "$P/ver"
sed -i.bak -E 's/"includeProducer": false/"includeProducer": true/' "$P"/ver/input/export-configs/nextjs*.json
pnpm exec tsx gen_nextjs.ts "$P/ver" --level L4 --app admin --out "$P/a" | grep -i "warn\|erreur" || true
PF="$P/fx"; mkdir -p "$PF/src/lib"; cp -R "$P/a/src/." "$PF/src/"; cp -R "$P/a/docs-tool" "$PF/docs-tool"; ln -s "$PWD/node_modules" "$PF/node_modules"
echo 'import pino from "pino"; export const logger = pino();' > "$PF/src/lib/logger.ts"
echo '{"compilerOptions":{"strict":true,"noEmit":true,"skipLibCheck":true,"jsx":"preserve","module":"esnext","moduleResolution":"bundler","target":"es2022","paths":{"@/*":["./src/*"],"@docs/*":["./docs-tool/src/*"]}},"include":["src"]}' > "$PF/tsconfig.json"
pnpm exec tsc -p "$PF" && echo "tsc producer: ok"
ls "$P"/a/src/app-behaviors/v1/producer-behavior-registry.ts >/dev/null && echo "producer registry: ok"
echo "// MINE" >> "$(ls "$P"/a/src/app-behaviors/v1/*/*/*.producer.behavior.impl.ts | head -1)"
pnpm exec tsx gen_nextjs.ts "$P/ver" --level L4 --app admin --out "$P/a" >/dev/null
grep -q "// MINE" "$(ls "$P"/a/src/app-behaviors/v1/*/*/*.producer.behavior.impl.ts | head -1)" && echo "producer impl preserve: ok"

# changement d'architecture par-dessus un dossier existant : coexistence (chaque architecture n'écrase que la sienne)
S="$W/switch/app"; C=src/api-modules/v1/clean_architecture/admin/account/auth
pnpm exec tsx gen_nextjs.ts "$W/clean_architecture/ver" --level L2 --app admin --out "$S" >/dev/null
echo "// MINE" >> "$S/$C/auth.adapter.ts"
pnpm exec tsx gen_nextjs.ts "$W/mvvm/ver" --level L2 --app admin --out "$S" >/dev/null
pnpm exec tsx gen_nextjs.ts "$W/mvc/ver" --level L2 --app admin --out "$S" >/dev/null
for d in clean_architecture mvvm mvc; do [ -d "$S/src/api-modules/v1/$d/admin" ] || { echo "FAIL: $d absent"; exit 1; }; done
grep -q "// MINE" "$S/$C/auth.adapter.ts" && grep -q "mvc" "$S/src/di/api_di.ts" && echo "coexistence mvvm/mvc/clean: ok"
# régénérer la même architecture écrase son existant, supprime ses obsolètes
rm "$W/mvc/ver/input/contracts/apps/admin/account/auth.yml" 2>/dev/null || true
echo "// X" >> "$S/src/api-modules/v1/mvvm/admin/account/auth/model/auth.model.ts"
pnpm exec tsx gen_nextjs.ts "$W/mvvm/ver" --level L2 --app admin --out "$S" >/dev/null
grep -q "// X" "$S/src/api-modules/v1/mvvm/admin/account/auth/model/auth.model.ts" && { echo "FAIL: pas écrasé"; exit 1; } || echo "écrasement de sa propre architecture: ok"

# architecture non supportée -> refus explicite (jamais ignorée)
cp -R "$V" "$W/bad"; sed -i.bak -E 's/"architecture": "[a-z_]+"/"architecture": "hexagonal"/' "$W/bad"/input/export-configs/nextjs*.json
if pnpm exec tsx gen_nextjs.ts "$W/bad" --level L2 --app admin --out "$W/badout" 2>/dev/null; then echo "FAIL: architecture inconnue acceptée"; exit 1; else echo "architecture inconnue refusée: ok"; fi

# preserve : une régénération par-dessus un dossier existant ne touche pas action-registry.overrides.ts
O="$W/clean_architecture/a/admin/src/api-actions/action-registry.overrides.ts"
echo "// MINE" >> "$O"
pnpm exec tsx gen_nextjs.ts "$W/clean_architecture/ver" --level L2 --app admin --out "$W/clean_architecture/a/admin" >/dev/null
grep -q "// MINE" "$O" && echo "preserve: ok"

# safeAction : ApiClientError -> enveloppe d'erreur avec code conservé
F="$W/clean_architecture/fx-admin"
cat > "$F/check.mts" <<'T'
import { safeAction } from "@/lib/actions/safe-action";
import { ApiClientError } from "@/lib/api-client";
import assert from "node:assert";
const r: any = await safeAction("t", async () => { throw new ApiClientError(403, "FORBIDDEN", { success: false, message: "no", error: { code: "FORBIDDEN", message: "no" } }); });
assert.equal(r.success, false); assert.equal(r.error.code, "FORBIDDEN");
const o: any = await safeAction("t", async () => ({ success: true, message: "", data: 1 }));
assert.equal(o.data, 1);
T
(cd "$F" && "$OLDPWD/node_modules/.bin/tsx" --tsconfig tsconfig.json check.mts >/dev/null 2>&1) && echo "safeAction: ok"

# docs-tool : le générateur complète tsconfig.json / package.json de l'app (idempotent)
D="$W/docs"; mkdir -p "$D"; echo '{"compilerOptions":{}}' > "$D/tsconfig.json"; echo '{"name":"x"}' > "$D/package.json"
pnpm exec tsx gen_nextjs.ts "$V" --level L4 --app admin --out "$D" >/dev/null
grep -q '"@docs/\*"' "$D/tsconfig.json" && grep -q '"check:docs"' "$D/package.json" && grep -q '"tsx"' "$D/package.json" && echo "docs prérequis app: ok"
cp "$D/package.json" "$D/p1"; pnpm exec tsx gen_nextjs.ts "$V" --level L4 --app admin --out "$D" >/dev/null
cmp -s "$D/package.json" "$D/p1" && echo "docs prérequis idempotent: ok"

# ── couverture étendue ──
# fx <app-dir> <tsconfig-extra> : fixture tsc minimale (sans @docs si docs-tool absent)
fx() { local F; F=$(mktemp -d -p "$W"); mkdir -p "$F/src/lib"; cp -R "$1/src/." "$F/src/"; rm -rf "$F/src/app"; [ -d "$1/docs-tool" ] && cp -R "$1/docs-tool" "$F/docs-tool"; ln -s "$PWD/node_modules" "$F/node_modules"
  [ -f "$F/src/lib/logger.ts" ] || echo 'import pino from "pino"; export const logger = pino();' > "$F/src/lib/logger.ts"
  echo '{"compilerOptions":{"strict":true,"noEmit":true,"skipLibCheck":true,"jsx":"preserve","module":"esnext","moduleResolution":"bundler","target":"es2022","paths":{"@/*":["./src/*"],"@docs/*":["./docs-tool/src/*"]}},"include":["src"]}' > "$F/tsconfig.json"
  pnpm exec tsc -p "$F"; }

# chaque niveau compile seul (L2, L3), sur les deux apps ; L0/L1 refusés (niveau minimum L2 : api-actions importe `@/di/api_di`)
for lv in L0 L1; do pnpm exec tsx gen_nextjs.ts "$V" --level $lv --app admin --out "$W/x" 2>/dev/null && { echo "FAIL: $lv accepté"; exit 1; } || echo "niveau $lv refusé (min L2): ok"; done
for lv in L2 L3; do
  for app in admin user; do
    pnpm exec tsx gen_nextjs.ts "$V" --level $lv --app $app --out "$W/lv/$lv/$app" >/dev/null
    fx "$W/lv/$lv/$app" || { echo "FAIL: tsc $lv/$app"; exit 1; }; echo "tsc $lv/$app: ok"
  done
done

# erreurs typées : code ∈ ErrorCode de l'endpoint, fields disponibles ; un code inconnu doit casser tsc
E="$W/errtype"; cp -R "$W/lv/L2/user" "$E"
cat > "$E/src/zz-err.ts" <<'TS'
import { handleGetCitiesAction } from "@/api-actions/v1/user/search/reference-data/get-cities";
export async function f() {
  const r = await handleGetCitiesAction();
  if (r.success) return r.data;
  if (r.error.code === "UNAUTHORIZED" || r.error.code === "UNKNOWN_ERROR") return r.error.fields?.length;
  // @ts-expect-error code hors contrat
  if (r.error.code === "NOPE") return 0;
}
TS
fx "$E" || { echo "FAIL: erreurs typées"; exit 1; }; echo "erreurs typées (code par endpoint, fields): ok"
# runtime : code hors contrat -> UNKNOWN_ERROR ; code du contrat inchangé
cat > "$E/src/zz-rt.ts" <<'TS'
import { safeAction } from "@/lib/actions/safe-action";
import { ApiClientError } from "@/lib/api-client";
const run = (code: string) => safeAction("t", async () => { throw new ApiClientError(400, code, { error: { code, message: "m" } }); }, {}, { KNOWN: 1 }) as Promise<any>;
(async () => {
const [a, b, c] = await Promise.all([run("KNOWN"), run("X"), run("VALIDATION_ERROR")]);
if (a.error.code !== "KNOWN" || b.error.code !== "UNKNOWN_ERROR" || b.message === "" || c.error.code !== "VALIDATION_ERROR") { console.error(a, b, c); process.exit(1); }
})();
TS
ln -sfn "$PWD/node_modules" "$E/node_modules"
echo '{"compilerOptions":{"paths":{"@/*":["./src/*"]}}}' > "$E/tsconfig.json"
[ -f "$E/src/lib/logger.ts" ] || echo 'import pino from "pino"; export const logger = pino();' > "$E/src/lib/logger.ts"
pnpm exec tsx --tsconfig "$E/tsconfig.json" "$E/src/zz-rt.ts" >/dev/null || { echo "FAIL: UNKNOWN_ERROR runtime"; exit 1; }; echo "code hors contrat -> UNKNOWN_ERROR: ok"

# session par cookie (custom_jwt) : seulement les endpoints du mapping `session`, logout, cookies préfixés par l'app
L="$W/lv/L3"
[ "$(grep -rl 'applySession(' "$L/user/src/api-actions" | wc -l | tr -d ' ')" = 3 ] && [ "$(grep -rl 'applySession(' "$L/admin/src/api-actions" | wc -l | tr -d ' ')" = 1 ] \
  && grep -rq 'clearSession()' "$L/admin/src/api-actions" && ! grep -rq 'clearSession()' "$L/user/src/api-actions" \
  && grep -q '"user_access_token"' "$L/user/src/lib/auth-token.ts" && grep -q '"admin_access_token"' "$L/admin/src/lib/auth-token.ts" \
  && [ -f "$L/user/src/lib/actions/session-actions.ts" ] && echo "session cookie (mapping explicite, préfixe app): ok" || { echo "FAIL: session"; exit 1; }
# applySession : pose les cookies si le jeton est présent, ignore sinon (étape intermédiaire d'un login)
SES="$W/ses"; mkdir -p "$SES/node_modules/next" "$SES/src/lib"
echo 'const jar=globalThis.__jar??=new Map();exports.cookies=async()=>({get:k=>jar.has(k)?{value:jar.get(k)}:undefined,set:(k,v)=>jar.set(k,v),delete:k=>jar.delete(k)});' > "$SES/node_modules/next/headers.js"
cp "$L/user/src/lib/auth-token.ts" "$SES/src/lib/auth-token.ts"
cat > "$SES/t.ts" <<'EOT'
import assert from "node:assert";
import { applySession, getAccessToken, clearSession } from "./src/lib/auth-token";
const P = { accessToken: "data.access_token", refreshToken: "data.refresh_token", expiresIn: "data.expires_in" };
(async () => {
  await applySession({ data: { is_new_user: true } }, P);
  assert.equal(await getAccessToken(), null);
  await applySession({ data: { token: "x" } }, P);
  assert.equal(await getAccessToken(), null);
  await applySession({ data: { access_token: "A", refresh_token: "R", expires_in: 60 } }, P);
  assert.equal(await getAccessToken(), "A");
  await clearSession();
  assert.equal(await getAccessToken(), null);
})().catch(e => { console.error(e); process.exit(1); });
EOT
(cd "$SES" && "$OLDPWD/node_modules/.bin/tsx" t.ts) && echo "applySession (pose / ignore sans jeton / clear): ok" || { echo "FAIL: applySession"; exit 1; }
# clampPage (pagination) : bornes
sed -n '/^export const clampPage/p' "$L/user/src/api-contexts/use-api-call.ts" | sed 's/^export //' > "$W/cp.ts"
echo 'if (clampPage(0,5)!==1||clampPage(9,5)!==5||clampPage(3,5)!==3||clampPage(9)!==9) process.exit(1);' >> "$W/cp.ts"
pnpm exec tsx "$W/cp.ts" && echo "clampPage: ok" || { echo "FAIL: clampPage"; exit 1; }
# pagination : seulement les GET avec page + page_size
grep -q usePager "$L/user/src/api-contexts/v1/wrappers/user/search/ride-search/get-rides-wrapper.tsx" && ! grep -q usePager "$L/user/src/api-contexts/v1/wrappers/user/wallet/balance/get-wallet-wrapper.tsx" && echo "pagination (wrapper des listes seulement): ok" || { echo "FAIL: pagination wrapper"; exit 1; }
# auth ≠ custom_jwt : aucun cookie, aucun next/headers, tsc vert
cp -R "$V" "$W/noauth"; sed -i.bak -E 's/"auth": "custom_jwt"/"auth": "none"/' "$W/noauth"/input/export-configs/nextjs*.json
pnpm exec tsx gen_nextjs.ts "$W/noauth" --level L3 --out "$W/noauth-out" >/dev/null 2>&1
! grep -rq 'next/headers\|applySession\|clearSession' "$W/noauth-out"/*/src && fx "$W/noauth-out/user" && fx "$W/noauth-out/admin" && echo "auth none (sans cookie): ok" || { echo "FAIL: auth none"; exit 1; }
# id inconnu dans session : refusé
cp -R "$V" "$W/badses"; sed -i.bak -E 's/"post-admin-auth-logout"/"nope-endpoint"/' "$W/badses"/input/export-configs/nextjs.json
pnpm exec tsx gen_nextjs.ts "$W/badses" --level L2 --app admin --out "$W/badses-out" >/dev/null 2>&1 && { echo "FAIL: id inconnu accepté"; exit 1; } || echo "session : id inconnu refusé: ok"
# EC9 : `session` confrontée aux contrats (chemin absent / mauvais type / id inconnu -> erreur ; v0 valide)
ruby ../export_configs.rb "$V" --quiet >/dev/null || { echo "FAIL: v0 doit être valide (EC9)"; exit 1; }
ec9() { # <nom> <sed> : doit échouer avec EC9
  cp -R "$V" "$W/ec9-$1"; sed -i.bak -E "$2" "$W/ec9-$1"/input/export-configs/nextjs.json
  out=$(ruby ../export_configs.rb "$W/ec9-$1" --quiet 2>&1 || true)
  grep -q "EC9" <<<"$out" && echo "EC9 $1: ok" || { echo "FAIL: EC9 $1"; exit 1; }
}
ec9 chemin 's#"accessToken": "data.access_token"#"accessToken": "data.nope"#'
ec9 type 's#"expiresIn": "data.expires_in"#"expiresIn": "data.access_token"#'
ec9 id 's#"post-auth-register"#"nope-endpoint"#'
# refresh sur 401 : vrai serveur HTTP, ky réel, cookies stubbés (rejoue 1 fois ; 1 seul refresh en concurrence ; refus -> session effacée)
cp -R "$V" "$W/rf"
python3 - "$W/rf/input/export-configs/nextjs.json" <<'PY'
import json,sys
p=sys.argv[1]; d=json.load(open(p))
d["config"]["session"]["refresh"]={"endpoint":"post-auth-otp-verify","bodyField":"code","accessToken":"data.access_token","refreshToken":"data.refresh_token","expiresIn":"data.expires_in"}
json.dump(d,open(p,"w"))
PY
ruby ../export_configs.rb "$W/rf" --quiet >/dev/null || { echo "FAIL: config refresh invalide"; exit 1; }
pnpm exec tsx gen_nextjs.ts "$W/rf" --level L2 --app user --out "$W/rf-out" >/dev/null
# sans `session.refresh` (v0 en porte un : copie dont on le retire) : aucun refreshSession généré
cp -R "$V" "$W/nr"
python3 - "$W/nr/input/export-configs/nextjs.json" <<'PY'
import json,sys
p=sys.argv[1]; d=json.load(open(p)); d["config"]["session"].pop("refresh",None); json.dump(d,open(p,"w"))
PY
pnpm exec tsx gen_nextjs.ts "$W/nr" --level L2 --app user --out "$W/nr-out" >/dev/null
grep -q "refreshSession" "$W/rf-out/src/lib/api-client.ts" && grep -q "export async function refreshSession" "$W/rf-out/src/lib/auth-token.ts" && ! grep -q refreshSession "$W/nr-out/src/lib/api-client.ts" && echo "refresh: généré seulement si configuré: ok" || { echo "FAIL: refresh généré"; exit 1; }
fx "$W/rf-out" && echo "tsc refresh: ok" || { echo "FAIL: tsc refresh"; exit 1; }
RF="$W/rf-run"; mkdir -p "$RF/node_modules/next" "$RF/src/lib"
ln -s "$PWD/node_modules/ky" "$RF/node_modules/ky"
echo 'const jar=globalThis.__jar??=new Map();exports.cookies=async()=>({get:k=>jar.has(k)?{value:jar.get(k)}:undefined,set:(k,v)=>jar.set(k,v),delete:k=>jar.delete(k)});' > "$RF/node_modules/next/headers.js"
cp "$W/rf-out/src/lib/api-client.ts" "$W/rf-out/src/lib/auth-token.ts" "$RF/src/lib/"
cat > "$RF/t.ts" <<'EOT'
import assert from "node:assert";
import http from "node:http";
const jar = ((globalThis as any).__jar ??= new Map()) as Map<string, string>;
let refreshCalls = 0; const used = new Set<string>();
const srv = http.createServer((req, res) => {
  let b = ""; req.on("data", d => (b += d)); req.on("end", () => {
    const send = (st: number, o: unknown) => { res.writeHead(st, { "content-type": "application/json" }); res.end(JSON.stringify(o)); };
    if (req.url === "/api/v1/auth/otp/verify") {
      refreshCalls++; const code = JSON.parse(b).code;
      if (code === "R1" && !used.has(code)) { used.add(code); return send(200, { data: { access_token: "A2", refresh_token: "R2", expires_in: 60 } }); }
      return send(401, { success: false });
    }
    if (req.headers.authorization === "Bearer A2") return send(200, { ok: true, echo: b ? JSON.parse(b) : null });
    send(401, { success: false });
  });
});
srv.listen(0, async () => {
  process.env.NEXT_PUBLIC_API_URL = `http://127.0.0.1:${(srv.address() as any).port}`;
  const { apiClient } = await import("./src/lib/api-client");
  try {
    jar.set("user_access_token", "A1"); jar.set("user_refresh_token", "R1");
    const r = await Promise.all([1, 2, 3].map(() => apiClient.get("protected").json<{ ok: boolean }>()));
    assert.ok(r.every(x => x.ok)); assert.equal(refreshCalls, 1, "un seul refresh en concurrence");
    assert.equal(jar.get("user_access_token"), "A2"); assert.equal(jar.get("user_refresh_token"), "R2");
    jar.set("user_access_token", "A1");
    jar.set("user_refresh_token", "R-bad"); refreshCalls = 0;
    const e = await apiClient.post("echo", { json: { a: 1 } }).json().catch(x => x);
    assert.equal(e.response?.status, 401); assert.equal(refreshCalls, 1);
    assert.equal(jar.has("user_access_token"), false, "session effacée après refus");
    jar.set("user_access_token", "A1"); jar.set("user_refresh_token", "R3"); used.add("R1");
    // corps rejoué : refresh accepté pour un nouveau refresh token
    used.delete("R1"); jar.set("user_refresh_token", "R1");
    const p = await apiClient.post("echo", { json: { a: 1 } }).json<{ echo: { a: number } }>();
    assert.deepEqual(p.echo, { a: 1 });
    console.log("ok"); process.exit(0);
  } catch (err) { console.error(err); process.exit(1); }
});
EOT
(cd "$RF" && "$OLDPWD/node_modules/.bin/tsx" t.ts) | grep -q '^ok$' && echo "refresh 401 (rejoue, 1 refresh concurrent, refus -> clear, corps rejoué): ok" || { echo "FAIL: refresh 401"; exit 1; }
# variantes de config L4 : behaviors off, events off, docsTool off
variant() { # <nom> <sed>
  cp -R "$V" "$W/var-$1"; sed -i.bak -E "$2" "$W/var-$1"/input/export-configs/nextjs*.json
  pnpm exec tsx gen_nextjs.ts "$W/var-$1" --level L4 --out "$W/var-$1-out" >/dev/null
  for app in admin user; do fx "$W/var-$1-out/$app" || { echo "FAIL: tsc variante $1/$app"; exit 1; }; echo "tsc variante $1/$app: ok"; done
}
variant nobehaviors 's/"enabled": true/"enabled": false/'
[ -d "$W/var-nobehaviors-out/admin/src/app-behaviors" ] && { echo "FAIL: behaviors off mais app-behaviors émis"; exit 1; } || echo "behaviors off: ok"
variant noevents 's/"includeEvents": true/"includeEvents": false/'
[ -d "$W/var-noevents-out/admin/src/app-events" ] && { echo "FAIL: includeEvents off mais app-events émis"; exit 1; } || echo "includeEvents off: ok"
variant nodocs 's/"docsTool": true/"docsTool": false/'
O="$W/var-nodocs-out/admin"
{ [ ! -d "$O/docs-tool" ] && [ ! -f "$O/genealogy.config.ts" ] && ! grep -rq "@docs/" "$O/src"; } && echo "docsTool off (rien émis/importé): ok" || { echo "FAIL: docsTool off"; exit 1; }

# sans --app : une sous-arborescence par app
[ -f "$W/var-nodocs-out/admin/.scaf-generated.json" ] && [ -f "$W/var-nodocs-out/user/.scaf-generated.json" ] && echo "sans --app (out/<slug>): ok"

# --dry-run n'écrit rien ; niveau / app inconnus refusés
pnpm exec tsx gen_nextjs.ts "$V" --level L4 --app admin --out "$W/dry" --dry-run >/dev/null
[ ! -e "$W/dry" ] && echo "dry-run: ok"
pnpm exec tsx gen_nextjs.ts "$V" --level L9 --out "$W/x" 2>/dev/null && { echo "FAIL: niveau inconnu accepté"; exit 1; } || echo "niveau inconnu refusé: ok"
pnpm exec tsx gen_nextjs.ts "$V" --level L2 --app nope --out "$W/x" 2>/dev/null && { echo "FAIL: app inconnue acceptée"; exit 1; } || echo "app inconnue refusée: ok"

# obsolètes : app-events retirés (includeEvents on -> off) : non modifié supprimé, modifié conservé + signalé
R="$W/obs"
pnpm exec tsx gen_nextjs.ts "$V" --level L4 --app admin --out "$R" >/dev/null
KEEP="$R/src/app-events/v1/carpool/rides.events.ts"; GONE="$R/src/app-events/v1/carpool/cities.events.ts"
echo "// MINE" >> "$KEEP"
pnpm exec tsx gen_nextjs.ts "$W/var-noevents" --level L4 --app admin --out "$R" 2>&1 | grep -q "obsolète mais modifié" || { echo "FAIL: pas d'avertissement"; exit 1; }
{ [ ! -f "$GONE" ] && [ -f "$KEEP" ]; } && echo "obsolètes (supprimé / modifié conservé): ok" || { echo "FAIL: obsolètes"; exit 1; }

# override par app (nextjs.admin.json) : admin = mvc sans docs-tool, user = config de base
cp -R "$V" "$W/ovr"; echo '{ "technology": "nextjs", "app": "admin", "config": { "architecture": "mvc", "docsTool": false } }' > "$W/ovr/input/export-configs/nextjs.admin.json"
ruby ../export_configs.rb "$W/ovr" --quiet >/dev/null || { echo "FAIL: override invalide"; exit 1; }
pnpm exec tsx gen_nextjs.ts "$W/ovr" --level L4 --out "$W/ovr-out" >/dev/null
{ [ -d "$W/ovr-out/admin/src/api-modules/v1/mvc" ] && [ ! -d "$W/ovr-out/admin/docs-tool" ] \
  && [ -d "$W/ovr-out/user/src/api-modules/v1/clean_architecture" ] && [ -d "$W/ovr-out/user/docs-tool" ]; } || { echo "FAIL: override par app"; exit 1; }
for app in admin user; do fx "$W/ovr-out/$app" || { echo "FAIL: tsc override $app"; exit 1; }; done; echo "override par app (admin mvc/sans docs, user base): ok"

# docs sur impls existantes : false -> true n'enveloppe pas l'impl utilisateur ; true -> false avertit et garde docs-tool/
DD="$W/docsflip"; cp -R "$V" "$W/df-off"; sed -i.bak -E 's/"docsTool": true/"docsTool": false/' "$W/df-off"/input/export-configs/nextjs*.json
pnpm exec tsx gen_nextjs.ts "$W/df-off" --level L4 --app user --out "$DD" >/dev/null
IMPL=$(find "$DD/src/app-behaviors" -name "*.behavior.impl.ts" | head -1)
pnpm exec tsx gen_nextjs.ts "$V" --level L4 --app user --out "$DD" >/dev/null
{ ! grep -q "indexDoc" "$IMPL" && grep -q "indexDoc" "$DD/src/app-behaviors/v1/behavior-registry.ts"; } && echo "docs off->on (impl préservée non enveloppée, registre enveloppé): ok" || { echo "FAIL: docs off->on"; exit 1; }
echo 'import "@docs/index-doc";' >> "$IMPL"
pnpm exec tsx gen_nextjs.ts "$W/df-off" --level L4 --app user --out "$DD" 2>&1 | grep -q 'importe "@docs/' || { echo "FAIL: pas d'avertissement docs on->off"; exit 1; }
[ -d "$DD/docs-tool" ] && echo "docs on->off (avertit, docs-tool conservé): ok" || { echo "FAIL: docs-tool supprimé"; exit 1; }

# socle de dossiers de base : posé s'il n'existe pas, jamais touché s'il existe, hors manifeste
B="$W/base"; mkdir -p "$B/src/ui-contexts"; echo 'export const mine = 1;' > "$B/src/ui-contexts/custom.ts"
pnpm exec tsx gen_nextjs.ts "$V" --level L2 --app user --out "$B" >/dev/null
{ [ -f "$B/src/app-actions/.gitkeep" ] && [ -f "$B/src/external-modules/.gitkeep" ] && [ -f "$B/src/app-scripts/.gitkeep" ] && [ -f "$B/src/app-contexts/providers.tsx" ] && [ -f "$B/src/app-contexts/compose-wrappers.tsx" ] && [ -d "$B/src/app-contexts/contexts" ] && [ -d "$B/src/app-contexts/wrappers" ]; } || { echo "FAIL: socle non posé"; exit 1; }
[ "$(ls "$B/src/ui-contexts")" = "custom.ts" ] || { echo "FAIL: socle écrase un dossier existant"; exit 1; }
! grep -q 'app-contexts\|app-actions' "$B/.scaf-generated.json" || { echo "FAIL: socle dans le manifeste"; exit 1; }
fx "$B" && echo "socle (créé si absent, dossier existant intact, tsc ok): ok" || { echo "FAIL: tsc socle"; exit 1; }
rm "$B/src/app-contexts/index.ts"; pnpm exec tsx gen_nextjs.ts "$V" --level L2 --app user --out "$B" >/dev/null
[ ! -e "$B/src/app-contexts/index.ts" ] && echo "socle (dossier existant incomplet non recréé): ok" || { echo "FAIL: socle recréé"; exit 1; }

# PWA (pwa: true) : fichiers `preserve` + patchs idempotents de l'app ; pwa false (admin) : rien
P="$W/pwa"; mkdir -p "$P/src/app/[locale]"
echo '{"name":"x"}' > "$P/package.json"; printf 'allowBuilds:\n  esbuild: set this to true or false\n' > "$P/pnpm-workspace.yaml"
printf 'import type { NextConfig } from "next";\nconst nextConfig: NextConfig = {};\nexport default nextConfig;\n' > "$P/next.config.ts"
printf 'import { NextIntlClientProvider } from "next-intl";\nexport default function L({ children }: { children: React.ReactNode }) {\n  return (<NextIntlClientProvider locale="fr">{children}</NextIntlClientProvider>);\n}\n' > "$P/src/app/[locale]/layout.tsx"
printf 'export const config = {\n  matcher: ["/((?!api|trpc|_next|.*\\\\..*).*)"],\n};\n' > "$P/src/proxy.ts"
pnpm exec tsx gen_nextjs.ts "$V" --level L2 --app user --out "$P" >/dev/null
{ [ -f "$P/src/app/sw.ts" ] && [ -f "$P/src/app/serwist/[path]/route.ts" ] && [ -f "$P/src/app/manifest.ts" ] && [ -f "$P/src/app/~offline/layout.tsx" ] && [ -f "$P/src/app/~offline/page.tsx" ]; } || { echo "FAIL: fichiers pwa"; exit 1; }
{ grep -q '"@serwist/turbopack"' "$P/package.json" && grep -q '"esbuild"' "$P/package.json" && grep -q 'withSerwist(nextConfig)' "$P/next.config.ts" && grep -q '<SerwistProvider swUrl="/serwist/sw.js">' "$P/src/app/[locale]/layout.tsx" && grep -q '(?!api|serwist|~offline|' "$P/src/proxy.ts" && grep -q 'esbuild: true' "$P/pnpm-workspace.yaml"; } || { echo "FAIL: patchs pwa"; exit 1; }
! grep -q 'serwist\|~offline' "$P/.scaf-generated.json" || { echo "FAIL: pwa dans le manifeste"; exit 1; }
echo "// mien" >> "$P/src/app/sw.ts"; cp "$P/package.json" "$W/pw.p"; cp "$P/next.config.ts" "$W/pw.n"; cp "$P/src/proxy.ts" "$W/pw.x"
pnpm exec tsx gen_nextjs.ts "$V" --level L2 --app user --out "$P" >/dev/null
{ grep -q '// mien' "$P/src/app/sw.ts" && cmp -s "$P/package.json" "$W/pw.p" && cmp -s "$P/next.config.ts" "$W/pw.n" && cmp -s "$P/src/proxy.ts" "$W/pw.x" && [ "$(grep -c SerwistProvider "$P/src/app/[locale]/layout.tsx")" = 2 ]; } && echo "pwa (fichiers préservés, patchs idempotents, hors manifeste): ok" || { echo "FAIL: pwa idempotence"; exit 1; }
cp -R "$V" "$W/pw-off"; sed -i.bak -E 's/"pwa": true/"pwa": false/' "$W/pw-off"/input/export-configs/nextjs*.json
pnpm exec tsx gen_nextjs.ts "$W/pw-off" --level L2 --app admin --out "$W/pwa-off" >/dev/null
[ ! -e "$W/pwa-off/src/app/sw.ts" ] && echo "pwa false (rien émis): ok" || { echo "FAIL: pwa false émis"; exit 1; }
