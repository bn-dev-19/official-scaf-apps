---
name: scaf-generate-openapi
description: Générer openapi.parts puis les OpenAPI par app (et la version à doc Markdown enrichie) depuis les contrats SCAF avec tools/contracts_to_openapi.rb, lire ses E/W et corriger les contrats/mocks. À utiliser après toute modification de contracts/ ou avant de livrer/importer les OpenAPI (Postman, Redoc, Swagger).
---

# Générer les OpenAPI depuis les contrats

Pipeline : `contracts/` → `input/openapi.parts/` → `scaf/<version>/output/openapi/openapi.<app>.yml` (+ `doc/` enrichie).
Les contrats sont la seule source : **ne jamais éditer `openapi.parts/` ni `output/openapi/` à la main**, corriger le contrat et régénérer.
Détails d'outil : `../04-tooling-map.md` · règles à respecter : `../03-rules-and-validation.md §OA`.

## Lancer

```bash
# test sans rien écraser
ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/v1 --parts-out <tmp>/parts --out <tmp>/out

# génération réelle : parts + OpenAPI brutes + OpenAPI à doc Markdown (scaf/v1/output/openapi/doc/)
ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/v1 --doc --license-url https://mafcv.metalafrique.it
```
Linter la sortie (Redocly ne lit `redocly.yaml` que dans le dossier courant, d'où `--config` depuis la racine) :
```bash
npx @redocly/cli lint --config scaf/redocly.yaml scaf/v1/output/openapi/openapi.*.yml   # cible : 0 warning
```
Les `$ref` (`components.schemas` / `parameters` : Error*, Pagination, Warnings, paramètres et sous-schémas répétés) sont produits à l'étape 2 ; `--no-refs` redonne une sortie 100 % en ligne.

Options : `--app <slug>` (une app), `--parts-only`, `--doc-in-place` (doc directement dans les fichiers bruts), `--no-refs`, `--license-url <url>` (à passer, sinon `info-license-strict` avertit). Code retour 1 s'il y a des E. Cible : **`0 E, 0 W`**.

## Noms des composants
`components.schemas.<Nom>` (sous-schéma objet répété ≥ 3 fois dans une app) : `title:` du schéma du contrat ; sinon, pour une clé générique (`data`, `item`, `block`, `section`, `color`, `slot`, `preference`, `exception`), la ressource de l'endpoint (`/offers/{id}` → `Offer`, `item` → `ThreadItem`) ; sinon la clé. Plusieurs formes sous le même nom → suffixe `2…` + `W … en collision, suffixé` : **ajouter un `title:` distinct dans le contrat** (jamais dans la sortie). Le contrôle « aucun `Data[0-9]*` dans `components.schemas` » fait partie du golden (`tools/nestjs/golden.sh`). Pour les agents : lire les fichiers compacts `output/openapi/openapi.<app>.yml` ; `output/openapi/doc/` (descriptions Markdown complètes) est plus volumineux.

Sortie : 4 fichiers par dossier (`administration`, `candidate`, `public-site`, `recruitment-portal`) ; `doc/` = même contenu avec, dans le `description` de chaque opération, des tableaux Markdown (paramètres, corps, réponse aplatie, erreurs) et des exemples (1 nominal + 1 par code d'erreur).

## Lire les messages et corriger (dans le contrat, pas dans la sortie)

| Message | Cause | Correction |
|---|---|---|
| `E … N mocks mais M examples` | mock sans `expect.status` exploitable | corriger le mock |
| `E … id dupliqué` / `déjà défini par` | id ou `METHOD path` dupliqué | renommer l'endpoint (règle d'or 6) |
| `E … spec illisible` / `mocks illisibles` | YAML/JSON invalide dans `spec` / `mocks` | corriger la syntaxe |
| `W … requis absent` | un mock 2xx n'a pas un champ de la spec | ajouter le champ (valeur plausible ; `null` si `nullable`) ; s'il ne peut pas exister, le déclarer `nullable: true` |
| `W … null non autorisé` | `null` sur un champ non `nullable` | `nullable: true` dans la spec **ou** valeur réelle dans le mock |
| `W … en collision, suffixé` | deux formes différentes veulent le même nom de composant (`Offer2`) | `title:` distinct sur chaque schéma dans le contrat |
| `W … clé non déclarée` | clé de mock absente de la spec (casse, camelCase, vestige) | renommer/supprimer la clé, ou déclarer le champ dans la spec |
| `W … hors enum` / `n'est pas un uuid` / `date` / `date-time` | valeur de mock incompatible | corriger la valeur ou la spec |
| `W … mélange date et date-time` | un champ `date-iso` a des mocks en `AAAA-MM-JJ` et d'autres en horodatage | aligner tous les mocks sur un seul format |
| `W … code non déclaré` / `sans erreur déclarée` | mock d'erreur ≠ `errors` de la spec | ajouter l'erreur à la spec ou corriger le mock |
| `W … absent de request.path` | `{param}` du chemin non décrit | ajouter l'entrée dans `request.path` |

## Boucle

1. Modifier `contracts/…` (skills `scaf-write-endpoint-contract` / `scaf-write-mocks`).
2. Lancer en mode test, corriger jusqu'à `0 E, 0 W`.
3. Lancer `--doc` (génération réelle) puis `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` : aucune nouvelle erreur ni avertissement (baseline v1 : 1 E, cycles).
4. Import Postman : prendre `scaf/<version>/output/openapi/doc/openapi.<app>.yml` ; la doc est dans le panneau « Documentation » de chaque requête.

## Pièges

- Le script **réécrit** `openapi.parts/<app>/` à chaque lancement (utiliser `--parts-out` pour tester).
- Réécrire un bloc `mocks` entier reformate son JSON : relire le diff, pas de modification de sens.
- Valeurs ajoutées à un mock : cohérentes avec le cas (une alerte non résolue a `resolved_at: null`, une société garde son propre secteur).
- Ne pas créer de dossier `v…` dans `scaf/` (sortie = `<version>/output/openapi`).
