# 05 — Référence des configs d'export (sens, défaut, effet, source)

Complète `02-file-formats.md §11` (forme) : ici, **ce que chaque option fait** et **d'où vient sa valeur**. Règle : une option absente de cette référence ne se devine pas — la demander à l'utilisateur ou l'omettre.

Les valeurs et défauts Next.js sont ceux du format de config Next.js que le kit décrit (`02 §11`). NestJS : voir §NestJS.

**Colonne « Source »** : `scaf` = se déduit des fichiers du projet (ne pas redemander) · `choix` = décision de l'utilisateur (le demander) · `fixe` = valeur technique sans choix métier.

**Lecture « Effet »** : *code* = l'option change des fichiers, dépendances ou config générés ; *brief* = l'option est consignée dans le guide IA (`AGENTS.md`) pour orienter celui qui implémente, sans code propre.

## Next.js

### Projet et outillage
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `projectName` | string · `my-next-app` | nom du dossier/projet | `scaf` (= slug de l'app) |
| `description` `tagline` `principe` | string · `""` | métadonnées de l'app (`app-info`, SEO) | `scaf` (`project.parts/apps/<app>.yml`) |
| `packageManager` | `pnpm\|npm\|yarn\|bun` · `pnpm` | gestionnaire des commandes générées | `choix` |
| `targetOs` | `mac_linux\|windows` · `mac_linux` | *code* : commande `dev` générée selon l'OS | `choix` (machine du dev) |
| `srcDir` | bool · `true` | *code* : tout sous `src/` ; préfixe tous les chemins générés | `fixe` (kit Next : `src/`) |
| `importAlias` | string · `@/*` | *code* : `paths` du tsconfig | `fixe` |
| `agentsFilename` | `AGENTS.md\|AI_GUIDE.md\|README-IA.md` · `AGENTS.md` | nom du guide IA racine | `fixe` |
| `nextDevToolsMcp` | bool · `true` | *code* : écrit `.mcp.json` (next-devtools-mcp) | `choix` |
| `docsTool` | bool · `false` | *code* : docs-tool (documentation auto, `genealogy.config.ts`, scripts `generate:docs`/`check:docs`) | `choix` |
| `eslintInBuild` | bool · `true` | *code* : `false` ⇒ `eslint.ignoreDuringBuilds` | `fixe` |
| `reactStrictMode` | bool · `true` | *code* : `next.config.ts` | `fixe` |
| `imagesUnoptimized` | bool · `false` | *code* : `images.unoptimized` | `choix` (hébergement) |
| `allowedImageDomains` | string[] · `[]` | *code* : `images.remotePatterns` ; URL complète ou hostname (https, `/**` par défaut) | `scaf` (hôtes d'images des contrats/`servers.yml`) ou `choix` |
| `allowedDevOrigins` | string[] · `[]` | *code* : `allowedDevOrigins` + `serverActions.allowedOrigins` | `choix` |
| `bodySizeLimit` | string · `5mb` | *code* : `serverActions.bodySizeLimit` | `fixe` (monter si upload) |

### Architecture et code applicatif
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `architecture` | `mvvm\|mvc\|clean_architecture` · `mvvm` | *code* : arbre d'`api-modules/`, `di/`, actions, contexts selon le pattern | `choix` |
| `apiLayer` | `server_actions\|route_handlers\|trpc\|graphql` · `server_actions` | *brief* : mécanisme client-serveur annoncé à l'agent | `choix` |
| `stateManagement` | `zustand\|jotai\|redux_toolkit\|tanstack\|none` · `zustand` | *brief* | `choix` |
| `httpClient` | `ky\|axios\|fetch` · `ky` | *code* : dépendance + `lib/api-client` correspondant | `choix` |
| `logger` | `pino\|winston\|none` · `pino` | *code* : dépendance ; `pino` ⇒ `serverExternalPackages` (pino, pino-pretty) | `choix` |
| `orm` | `prisma\|drizzle\|typeorm\|mongoose\|none` · `prisma` | *code* : dépendances ; sert aussi de backend au push. **`none` si le front consomme l'API scaf** (règle EC6) | `scaf` (front = `none`) |
| `database` | `postgresql\|mysql\|sqlite\|mongodb\|none` · `postgresql` | *code* : driver du push ; **`none` si front sur API scaf** | `scaf` |
| `rateLimiting` | bool · `false` | *brief* | `choix` |
| `errorMonitoring` | `sentry\|logrocket\|none` · `none` | *code* : `sentry` ⇒ dépendance `@sentry/nextjs` ; logrocket : *brief* | `choix` |
| `analytics` | `vercel\|plausible\|none` · `none` | *code* : branchement dans le layout si ≠ `none` | `choix` |

### Authentification
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `auth` | `nextauth_v5\|clerk\|supabase\|custom_jwt\|none` · `none` | *code* : deps `nextauth_v5` (+ adapter prisma) / `clerk` ; autres : *brief*. `custom_jwt` = auth maison contre l'API scaf | `scaf` (endpoints `auth` des contrats) + `choix` |
| `oauthProviders` | string[] · `[]` | prévision : à renseigner, l'implémentation revient aux devs (pas de génération dédiée) | `scaf` (providers OAuth des contrats `auth`) |

### UI, thème, polices
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `styling` | `tailwind_shadcn\|css_modules\|styled_components\|chakra_ui` · `tailwind_shadcn` | *code* : `tailwind_shadcn` ⇒ deps Tailwind + `globals.css` ; autres : `globals.css` minimal | `choix` |
| `shadcnPreset` | string · `""` | aide au développement : le preset shadcn sert au kit Next (demander à l'utilisateur) ; pas de génération dédiée | `choix` |
| `theme` | `light\|dark\|system` · `system` | *brief* (le thème est posé par le kit Next / next-themes) | `choix` |
| `font` | `geist\|inter\|poppins\|custom` · `geist` | *code* : police dans le layout | `choix` |
| `customFontPath` | string · `""` | *code* : `font: custom` ⇒ fichier copié ; **chemin relatif au dépôt** (`_ui-kits/…`) | `choix` (`_ui-kits/`) |

### Internationalisation et PWA
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `i18n` | bool · `false` | *code* : `next-intl` (plugin, messages, routage par locale, SEO multi-locales) | `choix` |
| `i18nLanguages` | string[] ⊂ `fr en es de it pt nl ja ko zh ar ru pl tr vi th sv da fi no` · `[]` | *code* : locales générées ; non vide si `i18n` ; contient `seo.defaultLocale` | `choix` |
| `pwa` | bool · `false` | *code* : Serwist (service worker, manifest), pages PWA | `choix` |
| `pushNotifications` | objet (ci-dessous) · `enabled:false` | *code* : Web Push (SW, VAPID, store, Server Actions). Exige `pwa: true` | `choix` |

`pushNotifications` : `enabled` bool · `vapidPublicKey` / `vapidPrivateKey` (**`$var:`**, générées par `pnpm web-push:keys`) · `vapidSubject` `mailto:` (`mailto:admin@example.com`) · `defaultTitle` (`Nouvelle notification`) · `icon` / `badge` (`/icons/icon-192x192.png`, badge Android seulement) · `tag` (`push-default` ; vide = pas de regroupement, renseigné = remplace la notif du même tag) · `deepLink` (`/`, URL au clic) · `actions[]` `{action,title,url?}` **max 2** (Safari les ignore) · `ttl` secondes **max 2419200** (défaut max) · `urgency` `very-low|low|normal|high` (`normal`) · `iosGate` (`true`, consigne « installer en PWA » sur iOS) · `includeTestPage` (`true`, page `/push-demo`).

### SEO / GEO / AEO / LLMO
`seo` (*code*, master toggle `enabled`) : `siteName` (défaut = projectName ; `scaf`) · `description` (`scaf`) · `baseUrl` (URL de déploiement : canonical, sitemap, robots ; `scaf`) · `defaultLocale` · `locales` (**dérivé à la génération** : i18n actif ⇒ `i18nLanguages`, sinon `[defaultLocale]`) · `robots` → `robots.ts` · `sitemap` → `sitemap.ts` · `openGraph` → metadata OG/Twitter · `jsonLd` → données structurées (Organization, WebSite, SoftwareApplication, FAQPage) · `llms{enabled,index,full,llmsPage}` → `llms.txt`, `llms-full.txt`, page `/llms` · `legal{privacy,terms,license,credits}` → pages `/privacy` `/terms` `/license` `/credits` · `footerLinks` → liens legal + `/llms` en pied de page · `google.searchConsoleVerification` (meta `google-site-verification`) · `bing.siteVerification` (meta `msvalidate.01`). Les valeurs `siteName/description/baseUrl/google/bing` sont des *fallbacks* surchargés par `project.parts/apps/<app>.yml`.

### Agents et comportements
`agentLoop` (*code* : dossier `agents/`, protocole Builder/Judge/Manager, tickets MANUAL/UI/FLOW/API/TEST) : `enabled` (`true`) · `maxRevisions` (`3`, révisions avant escalade humaine) · `budgetTokens` / `budgetMinutes` (optionnels, vide = illimité) · `qualityCommands[]` (vérités terrain du Judge ; défaut `pnpm tsc --noEmit`, `pnpm lint`, `pnpm build`, `pnpm test`) · `requireAllPass` (`true` : ticket fini seulement si tous les items PASS) · `roles[]` (`frontend`,`shared`,`qa`) · `includeManualFromStudio` (`false`).

`behaviors` (*code*) : `enabled` (`false`, génère `src/app-behaviors/` : interfaces par feature depuis les usecases, implémentation par défaut `NotImplementedError`) · `includeEvents` (`true`, `src/app-events/` : contrats d'événements dérivés des `calls`/`links`) · `behaviorOnly` (`false`, génère l'architecture sans specs/mocks, piloté par `project.parts` + usecases : app sans API / event-driven).

## NestJS

### Schéma défini par le kit
Le schéma NestJS est **défini par le kit** (champs et enums : `02 §11`, règles NS : `03`), écrit à partir du backend de référence `miidjoe-core-api`. Il n'existe pas de défaut officiel : les valeurs de `nestjs.json` dans `v0` sont des exemples issus de ce backend, pas des valeurs à reprendre par défaut.

Sens des champs spécifiques : `moduleGenerator` = `tools/nest-module-generator` (blueprint YAML → modules DDD `application/domain/infrastructure/presentation`) · `bodyParser: false` = exigence de Better Auth · `responseEnvelope` = contrat `{ success, message, data }` · `authPlugins` = plugins Better Auth (`admin`, `username`, `apiKey`, `customSession`…) · `swagger{enabled,path}` = exposition de la doc OpenAPI · `migrations: drizzle_kit` = migrations générées depuis le schéma Drizzle.

Source des valeurs : `projectName`, `moduleGranularity`, secrets (`$var:`) et `authBaseUrl` se déduisent du projet (`scaf`) ; le reste est un `choix` à demander. Ne rien inventer hors de ce schéma.

### Schéma de base de données généré
| Option | Valeurs · défaut | Effet | Source |
|---|---|---|---|
| `database` | `postgresql\|mysql\|sqlite\|none` | *code* : driver/ORM du backend ; ne pilote pas `visual_to_sql.rb` (moteur = `--dialect`, défaut postgresql) ; règle NS6 si ≠ moteurs générés | `choix` |
| `schemaKeyStyle` | `snake\|camel` · `snake` | *code* : clés TypeScript du Drizzle généré (`camel` = style du backend de référence) | `choix` |
| `tablesNames` | bool · `false` | *code* : génère `drizzle/tables-names.ts` (`DB_TABLES_NAMES`, constantes `*_TABLE`) | `choix` |
| `schemaDir` | string · `""` | dossier du schéma Drizzle du backend, lu par `db_compare.rb` (lecture seule) | `choix` (chemin du backend) |
