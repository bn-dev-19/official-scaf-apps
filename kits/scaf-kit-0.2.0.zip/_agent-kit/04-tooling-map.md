# 04 — Opérations de l'outillage et équivalent à la main

## Principe

Un projet scaf est un ensemble de fichiers sous `scaf/<version>/input/` (formats décrits dans ce kit). Une application d'édition peut les lire et les écrire (fusion des parts, validation, génération) ; **ce kit permet de faire la même chose directement par fichiers** : un agent écrit les parts et lance les outils `tools/*.rb`.

## Opérations → équivalent à la main

| Opération | Équivalent à la main |
|---|---|
| Valide `project.parts` (§B de `03`) | `tools/audit.rb` (sous-ensemble) + relecture de §B |
| Valide un use case (§C) | `tools/audit.rb` + §C |
| Valide specs et mocks de chaque endpoint (§D) | `tools/audit.rb` + §D |
| Détecte/répare les enveloppes `{success,message,data}` (§E) | respecter la forme canonique à l'écriture |
| Exige le préfixe `/api/vN/` dans `path` **et** `mock.given.path` ; détecte `{param}` dans les mocks ; réparation = `/api/x` → `/api/v1/x` et remplacement dans spec+mocks | `grep -rn "path: /api/[^v]" contracts/` ; remplacer partout (endpoint, spec, mocks) |
| Valide un mock contre sa spec | §D (statuts, `error.code`, `message`) |
| Répare le YAML IA : quote toute valeur `clé: a: b` ; `coerceErrorDefs`, `coerceFieldDefs`, `defaultErrorMessage` | quoter les scalaires contenant `: ` |
| Génère les variantes de mocks (nominal/error/enum/nullable/boolean/empty/critical) à partir de la spec | suivre §F de `03` ; voir `skills/scaf-write-mocks.md` |
| Score de couverture (formule §F) | calculer la formule §F |
| Fusionne une spec/des mocks entrants dans l'existant (erreurs clé = `status\|code`), applique des « deltas » d'enrichissement d'erreurs (message/cause/resolution) et détecte les specs à enrichir (`needsErrorEnrichment`) | s'assurer que chaque erreur de la spec a `message` (+`cause`/`resolution`) et que chaque mock `error-*` reprend `code`+`message` exacts |
| Réécrit `spec.endpoint.id` et `mocks.endpoint` pour qu'ils égalent l'`id` du contrat | invariant A4 |
| Renomme/fusionne des slugs d'app dans les contrats (mapping ancien→nouveau, slugs supprimés) et **régénère les ids d'endpoints** via `generateEndpointId` | voir `skills/scaf-add-structure.md` §Renommer |
| Extrait le payload métier d'un `AppActionResult<T>` / `ApiResponse<T>` | lire `data` |
| Specs (YAML) + mocks (JSON) → OpenAPI 3.0.3 avec `examples` (un exemple par mock, `summary` = nom du mock) | `tools/contracts_to_openapi.rb` (voir ci-dessous) |
| Sens inverse : OpenAPI → specs+mocks (hiérarchie déduite des **tags** `app / module / feature` et de l'`operationId`) | utile pour importer un `openapi.yml` externe : créer un tag par feature |
| Diff entre deux OpenAPI | `diff -r` de deux `openapi.parts/` |
| Déduit `database/visual` des **réponses** des endpoints (voir ci-dessous) | `skills/scaf-database-visual.md` |
| Diff de deux modèles visuels (new/modified/unchanged par table/colonne/enum) | `diff -r database/visual` |
| Visuel → SQL (postgresql\|mysql\|sqlite), schéma Drizzle, docs Markdown | `tools/visual_to_sql.rb` (`ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> [--dialect postgresql|mysql|sqlite] [--keys snake|camel] [--tables-names] [--format sql |
| `project.parts` → Markdown / PDF lisibles | lire `project.parts` |
| Diff de specs projet ; détection des changements de slug d'app | `diff -r` entre deux versions |
| Use cases producer sans endpoint (match `METHOD path`, repli sur slug) | `tools/audit.rb` (A6) + comparer chemins |
| Construit le contexte envoyé à l'IA : formats spec/mocks (`SPEC_YAML_FORMAT`, `MOCK_JSON_FORMAT`), granularité, prompt système de génération d'endpoints | **c'est la source des formats de `02-file-formats.md` §7** |
| Résolution de gabarits `{{ }}` | — |

### `check_mocks.rb` — cohérence champ par champ des mocks

`ruby scaf/_agent-kit/tools/check_mocks.rb scaf/<version> [--app <slug>] [--endpoint <id>] [--quiet]` (stdlib Ruby). Valide tous les mocks (succès, erreurs, requêtes `given`) contre leur spec : types, formats, champs présents, codes/messages d'erreur identiques à la spec, valeurs d'**enum comparées au `enum:` du champ**. Règles M1–M4 : `03-rules-and-validation.md §MK` ; procédure : `skills/scaf-check-mocks.md`. Code retour 1 s'il y a des E. Durée < 1 s.

### `intent_to_md.rb` — blocs `intent` → guide d'implémentation

Option `--check` : n'écrit rien, émet un `W GI:` par page absente, périmée, éditée à la main ou orpheline (appelé par `audit.rb`, règle GI de `03`).

`ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/<version>` (stdlib Ruby) → `scaf/<version>/output/implementation-guide/{README.md,<app>/<endpoint-id>.md}` : une page par endpoint (usecase avec `openapi`) ; sans `intent` (écart signalé par l'audit et en tête du README du guide) la page se limite à description, étapes et erreurs. Avec `intent` : pourquoi, qui, préconditions, étapes, effets, endpoints avant/pendant/après, « appelé par », notes consommateur, erreurs. Ne touche pas l'OpenAPI. Les usecases `consumer` (avec `openapi`) ne génèrent pas de page : leurs écrans/étapes/réactions d'erreur s'affichent dans la section « Côté consommateur » de la page de l'endpoint (`skills/scaf-write-consumer-usecase.md`). À relancer après toute modif d'un `intent` ou d'un usecase consumer.

### `visual_to_sql.rb` — modèle visuel → SQL, Drizzle, docs

`ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> [--dialect postgresql|mysql|sqlite] [--keys snake|camel] [--tables-names] [--format sql|drizzle|docs|all] [--out <dossier>] [--stdout]` (stdlib Ruby) → `scaf/<version>/output/database/<dialect>/{sql/, schema.sql, drizzle/}` (`postgresql`, `mysql`, `sqlite`) et `output/database/docs/` (commun). Moteur par défaut : postgresql ; `--keys`/`--tables-names` ont pour défauts `schemaKeyStyle`/`tablesNames` de `export-configs/nestjs.json`. Écart visuel ↔ backend : `ruby scaf/_agent-kit/tools/db_compare.rb scaf/<version> [--backend-schema <dossier>]` (lecture seule). Valide au passage `enumRef`, FK et index (E → code retour 1). Procédure et moments de régénération : `skills/scaf-database-visual.md` §Générer.

### `contracts_to_openapi.rb` — contrats → `openapi.parts` → OpenAPI par app

`ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/<version> [--app <slug>] [--parts-only] [--parts-out <dir>] [--out <dir>] [--no-refs] [--license-url <url>]` (stdlib Ruby seulement, comme `audit.rb`).
- Étape 1 : `contracts/` → `input/openapi.parts/<app>/<module>/<feature>/<endpoint-id>.yml` (+ squelettes et `_index.yml`) ; le dossier de l'app est recréé à chaque exécution.
- Étape 2 : fusion des parts → `scaf/<version>/output/openapi/openapi.<app>.yml` (`info`, `servers` de `contracts/servers.yml`, `components.securitySchemes.BearerAuth`) puis factorisation en `$ref` (`factorize`) : `components.schemas` = `Error` / `Error<Codes>` (un par jeu de codes, sans `allOf` : Redocly rejetterait les exemples), `Pagination`, `Warnings`, sous-schémas objet identiques (≥ 3 dans l'app, nommés d'après la propriété) ; `components.parameters` = paramètres identiques (≥ 2). `parts/` et `--doc` restent en ligne. `--no-refs` désactive la factorisation.
- Le schema conserve `enum`, `format` (`date-iso` tel quel), `nullable`, `required` (champs marqués `required: true`) ; les erreurs ont un schema `{success,message,error{code,message,cause,resolution}}` ; un example par mock (`summary` = nom du mock).
- Contrôles : E si nb mocks ≠ nb examples, id ou route dupliqués, spec/mocks illisibles ; W si un mock ne respecte pas son schema (type, enum, uuid, date, null non `nullable`), erreur de mock non déclarée, `{param}` absent de `request.path`. Code retour 1 s'il y a des E.
- `--doc` : écrit en plus `scaf/<version>/output/openapi/doc/openapi.<app>.yml` dont le `description` de chaque opération est enrichi en Markdown (accès/auth, tableaux aplatis Paramètres / Corps / Réponse / Erreurs avec type, format, requis, nullable, valeurs d'enum, description, puis exemples : requête + réponse nominale, 1 réponse par code d'erreur ; listes tronquées à 1 élément). `--doc-in-place` enrichit directement `openapi.<app>.yml`. Sans ces options la sortie est inchangée.
- Règles que les contrats doivent respecter pour passer sans E/W : `03-rules-and-validation.md §OA`. Import Postman : choisir `doc/openapi.<app>.yml` ; la doc enrichie s'affiche dans le panneau « Documentation » de chaque requête (Postman n'affiche pas les schemas OpenAPI, d'où les tableaux de champs dans le `description`).
- `--license <nom> [--license-url <url>]` : `info.license` des OpenAPI générées (défaut `Proprietary`, sans url) ; satisfait la règle `info-license` de Redocly (`info-license-strict` demande en plus une `url`). `components.securitySchemes` n'est émis que si une opération l'utilise.
- **Lint Redocly** (config `scaf/redocly.yaml` : `no-server-example.com` off car `servers.yml` garde localhost/example.com ; Redocly ne lit `redocly.yaml` que dans le dossier courant, d'où `--config` depuis la racine). Cible : 0 warning.
  ```bash
  ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/v1 --license-url https://mafcv.metalafrique.it
  npx @redocly/cli lint --config scaf/redocly.yaml scaf/v1/output/openapi/openapi.*.yml
  ```
  Sans `--license-url`, `info-license-strict` avertit (x4) ; sans `--config`, 12 warnings de serveurs.
- Pour tester sans écraser : `--parts-out /tmp/parts --out /tmp/out`. Après régénération, relancer `audit.rb`.

### `generate-openapi` à la main (si besoin — préférer le script ci-dessus)

Pour chaque endpoint, écrire `openapi.parts/<app>/<module>/<feature>/<id>.yml` :
`tags: [{name: "<app> / <module> / <feature>", description: "Module <app> / <module> / <feature>"}]` ;
`paths.<path>.<method en minuscules>` avec `operationId: <id>`, `description`, `responses` (un code par `status`/`errors[].status`),
`content.application/json.schema` (converti depuis `http.response.body`) et `examples` (un par mock, clé et `summary` = nom du mock, `value` = `expect.body`).
Mettre à jour `openapi.parts/_index.yml` (apps → modules → features) et créer les squelettes `<app>/<app>.yml`, `<module>/<module>.yml`, `<feature>/<feature>.yml`.
Si l'outillage est disponible, **régénérer plutôt qu'écrire**.

### `generate-visual-db-from-specs` — règles de déduction

- Un **module** DB par module de contrat (nom = slug), un **table** par endpoint dont la réponse est modélisable (doublons de nom de table ignorés dans un module).
- Nom de table = **dernier segment non-paramètre** du chemin (après `/api/vN`), pluralisé (`y→ies`, `ch|sh|x|z→+es`, déjà en `s` inchangé, sinon `+s`) ; défaut `resources`.
- Colonnes = propriétés de l'objet de réponse (si `data` objet/tableau d'objets, ses propriétés) ; `id` ajouté en `uuid primary` s'il manque.
- Types : `array|object → jsonb` ; `boolean` ; `integer → integer` (`int64 → bigint`) ; `number → decimal` ; `string` : `uuid → uuid`, `email → varchar(255)`, `date-time → datetime`, `date → date`, `uri → text`, `phone → varchar(50)`, `password → varchar(255)`, sinon `text` ; **champ `enum` → type `enum`** + enum `<table>_<champ>`.
- `id` ou `format: uuid` ⇒ `primary: true`.
- Le résultat est un **brouillon** : renommer, ajouter FK/index/colonnes système (`created_at`, `updated_at` en `datetime NOT NULL DEFAULT NOW()`) à la main.
- Le déduit ne couvre que ce que les réponses exposent : compléter à la main par les tables/colonnes de **stockage** sans contrat (pivot, audit, jetons…) ; `kind` les signale (obligatoire sur chaque table ; le brouillon pose `kind: entity`, à corriger pour pivot/internal/audit).

## Configs d'export — `tools/export_configs.rb`

`ruby scaf/_agent-kit/tools/export_configs.rb scaf/<version> [--quiet]` (stdlib Ruby) valide `input/export-configs/` (règles EC pour nextjs, NS pour nestjs : `03` §EC, §NS ; une entrée par techno dans `SCHEMAS`) ; `--resolve <techno> <app>` imprime la config effective d'une app (base ⊕ override, secrets masqués). Appelé par `audit.rb`. nextjs et nestjs sont définis par le kit ; les overrides par app et `$var:` sont une convention du kit.

