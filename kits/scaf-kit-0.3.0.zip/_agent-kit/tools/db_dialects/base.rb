# Aides communes aux dialectes de visual_to_sql.rb (chaque dialecte : `module DbDialect; extend DbBase; ... end`).
module DbBase
  DEC = /\Adecimal\((\d+),\s*(\d+)\)\z/
  KNOWN = /\A(uuid|text|integer|bigint|decimal|boolean|datetime|date|jsonb|enum|varchar\(\d+\)|decimal\(\d+,\s*\d+\))\z/
  LITERAL = /\A(NOW\(\)|-?\d+(\.\d+)?|true|false|NULL|'.*)\z/m
  ACTIONS = { 'cascade' => 'CASCADE', 'set null' => 'SET NULL', 'restrict' => 'RESTRICT', 'no action' => 'NO ACTION' }.freeze

  def known_type?(t); KNOWN.match?(t.to_s); end
  # [précision, échelle] d'un decimal (decimal seul = NUMERIC(18,2)), nil sinon.
  def dec(c); (m = DEC.match(c['type'].to_s)) ? [m[1].to_i, m[2].to_i] : (c['type'] == 'decimal' ? [18, 2] : nil); end
  def esc(s); s.to_s.gsub("'", "''"); end
  # nombres, booléens, NOW(), NULL, littéraux déjà quotés : tels quels ; mot nu (XOF, PENDING) : quoté.
  def bare_default(v); (s = v.to_s) =~ LITERAL ? s : "'#{esc(s)}'"; end
  def strip_cast(s); s.to_s.sub(/::\w+\z/, ''); end
  # id uuid auto-généré : PK simple, sans défaut ni FK (une colonne de clé composite ou une FK ne s'auto-génère pas) ; `_autouuid` posé par visual_to_sql.rb.
  def uuid_pk?(c); c['_autouuid']; end
  def fk_actions(r); [['onDelete', 'DELETE'], ['onUpdate', 'UPDATE']].map { |k, w| r[k] && " ON #{w} #{ACTIONS[r[k]]}" }.compact.join; end
  def fk_name(t, c); "fk_#{t['name']}_#{c['name']}"; end
  def fk_stmt(t, c)
    r = c['references']
    "ALTER TABLE #{q(t['name'])} ADD CONSTRAINT #{fk_name(t, c)} FOREIGN KEY (#{q(c['name'])}) REFERENCES #{q(r['table'])} (#{q(r['column'])})#{fk_actions(r)};"
  end
  def fk_inline(c)
    r = c['references']
    "FOREIGN KEY (#{q(c['name'])}) REFERENCES #{q(r['table'])} (#{q(r['column'])})#{fk_actions(r)}"
  end

  # suffixe Drizzle `.default(...)` ; now:/uuid: = expressions propres au dialecte.
  def dz_default(c, now:, uuid:)
    v = c['default']
    return (uuid_pk?(c) ? uuid : '') if v.nil?
    s = v.to_s
    if s == 'NOW()' then now
    elsif c['type'] == 'jsonb' then ".default(#{s[/\A'(.*)'(::jsonb)?\z/m, 1] || s})"
    elsif dec(c) || s !~ /\A(-?\d+(\.\d+)?|true|false)\z/ then ".default('#{s.gsub("'", "\\\\\\\\'")}')"
    else ".default(#{s})"
    end
  end
  def dz_unique(c); c['unique'] && !c['primary'] ? '.unique()' : ''; end
  def dz_ref_opts(r); (o = %w[onDelete onUpdate].map { |k| r[k] && "#{k}: '#{r[k]}'" }.compact).empty? ? '' : ", { #{o.join(', ')} }"; end
  METHODS = %w[btree hash gin gist brin].freeze
  # Index : raison (String) si le dialecte ne sait pas l'exprimer (index alors ignoré + W), nil sinon.
  def idx_unsupported(_i); nil; end
  def idx_method_pre(_i); ''; end    # PostgreSQL : USING <méthode> avant la liste
  def idx_method_post(_i); ''; end   # MySQL : USING <méthode> après la liste
  # éléments d'index : colonnes puis expressions entre parenthèses
  def idx_parts(i); (i['columns'] || []).map { |c| q(c) } + (i['expressions'] || []).map { |e| "(#{e})" }; end
  def idx_stmt(t, i)
    "CREATE #{'UNIQUE ' if i['unique']}INDEX #{i['name']} ON #{q(t['name'])}#{idx_method_pre(i)} (#{idx_parts(i).join(', ')})#{idx_method_post(i)}#{" WHERE #{i['where']}" if i['where']};"
  end
  # Drizzle : builder d'index (key = proj. nom de colonne -> clé TS)
  def dz_idx(i, key)
    args = (i['columns'] || []).map { |c| "t.#{key.(c)}" } + (i['expressions'] || []).map { |e| "sql`#{e}`" }
    b = "#{i['unique'] ? 'uniqueIndex' : 'index'}('#{i['name']}')"
    b += i['method'] && i['method'] != 'btree' && dz_using? ? ".using('#{i['method']}', #{args.join(', ')})" : ".on(#{args.join(', ')})"
    i['where'] ? "#{b}.where(sql`#{i['where']}`)" : b
  end
  def dz_using?; false; end
  # Transaction par fichier SQL (DDL transactionnel : PostgreSQL) ; banner = en-tête à laisser avant BEGIN.
  def tx_wrap(content, _banner); content; end
  # Valeurs par défaut des hooks (surchargés par les dialectes).
  def enum_ddl(_enums, _dash, _sq); nil; end
  def col_check(_c, _e); nil; end
  def preamble; {}; end
  def table_tail(_desc, _sq); ');'; end
  def col_comment(_desc, _sq); nil; end
  def comment_stmts(_t, _sq); []; end
  def fk_inline?; false; end
  def dz_enum_file?; false; end
  def dz_enum_decl(_e, _camel); nil; end
end
