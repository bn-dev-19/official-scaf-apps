require_relative 'base'
# Dialecte MySQL 8 : enums inline ENUM(...), commentaires inline, uuid CHAR(36), identifiants entre backticks, Drizzle mysql-core.
# Défauts sur TEXT/JSON : expression entre parenthèses (MySQL >= 8.0.13).
module DbDialect
  extend DbBase
  NAME = 'mysql'
  DZ_PKG = 'drizzle-orm/mysql-core'
  DZ_ANY = 'AnyMySqlColumn'
  DZ_IMPORTS = %w[mysqlTable mysqlEnum char varchar text int bigint boolean datetime date decimal json primaryKey index uniqueIndex check].freeze
  DZ_TABLE = 'mysqlTable'
  class << self
    def idx_unsupported(i)
      return 'index partiel (WHERE) non supporté par MySQL' if i['where']
      return "méthode #{i['method']} non supportée par MySQL (btree|hash)" if i['method'] && !%w[btree hash].include?(i['method'])
    end
    def idx_method_post(i); i['method'] ? " USING #{i['method'].upcase}" : ''; end
    def q(n); "`#{n}`"; end
    def type(c, e)
      case c['type']
      when 'uuid' then 'CHAR(36)'
      when 'integer' then 'INT'
      when 'datetime' then 'DATETIME(3)'
      when 'jsonb' then 'JSON'
      when 'enum' then "ENUM(#{e['values'].map { |v| "'#{esc(v['value'])}'" }.join(', ')})"
      else (d = dec(c)) ? "DECIMAL(#{d[0]}, #{d[1]})" : c['type'].upcase
      end
    end
    def default_sql(c)
      return '(UUID())' if uuid_pk?(c)
      return nil if c['default'].nil?
      s = c['default'].to_s
      return 'CURRENT_TIMESTAMP(3)' if s == 'NOW()'
      lit = bare_default(strip_cast(s))
      %w[text jsonb].include?(c['type']) ? "(#{lit})" : lit
    end
    def col_comment(desc, sq); " COMMENT #{sq.(desc)}"; end
    def table_tail(desc, sq); ") COMMENT=#{sq.(desc)};"; end
    def dz_col(c, n, _camel)
      case c['type']
      when 'uuid' then "char('#{n}', { length: 36 })"
      when 'text' then "text('#{n}')"
      when 'integer' then "int('#{n}')"
      when 'bigint' then "bigint('#{n}', { mode: 'number' })"
      when 'boolean' then "boolean('#{n}')"
      when 'datetime' then "datetime('#{n}', { fsp: 3 })"
      when 'date' then "date('#{n}')"
      when 'jsonb' then "json('#{n}')"
      when 'enum' then nil # rempli par le générateur (valeurs d'enum)
      when /\Avarchar\((\d+)\)\z/ then "varchar('#{n}', { length: #{$1} })"
      else (d = dec(c)) && "decimal('#{n}', { precision: #{d[0]}, scale: #{d[1]} })"
      end
    end
    def dz_enum_inline(c, n, e); "mysqlEnum('#{n}', [#{e['values'].map { |v| "'#{v['value']}'" }.join(', ')}])"; end
    def dz_default(c); super(c, now: '.defaultNow()', uuid: '.$defaultFn(() => crypto.randomUUID())'); end
  end
end
