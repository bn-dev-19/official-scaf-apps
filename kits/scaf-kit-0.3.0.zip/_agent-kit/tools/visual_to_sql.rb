#!/usr/bin/env ruby
# Modèle visuel -> SQL (PostgreSQL | MySQL | SQLite), schéma Drizzle (pg-core | mysql-core | sqlite-core), doc Markdown.
#   database/visual/_visual_enums.yml + _visual_<module>.yml  ==>  <out>/schema.sql | drizzle/{enums,<module>,index}.ts | docs/{README,<module>,enums,er}.md
# SQL : sql/00_enums.sql (pg) -> sql/10_<module>.sql (tables, commentaires, index) -> sql/99_foreign_keys.sql (pg, mysql) ; schema.sql = concaténation.
# Dialectes : tools/db_dialects/<dialecte>.rb (types, enums, commentaires, FK, défauts, Drizzle).
# Usage : ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> [--dialect postgresql|mysql|sqlite] [--format sql|drizzle|docs|all]
#                                                  [--keys snake|camel] [--tables-names] [--out <dossier>] [--stdout]
#   --dialect : défaut postgresql (indépendant des export-configs ; le moteur se choisit explicitement).
#   --keys / --tables-names : défauts = `schemaKeyStyle` / `tablesNames` de nestjs.json (sinon snake / non). Drizzle uniquement.
#   Sortie : output/database/<dialecte>/{sql,drizzle,schema.sql} ; docs/ commun dans output/database/docs.
#   --out remplace le dossier de base (tout dedans). --stdout : sql uniquement (schema.sql).
# Tables `external: true` : valides comme cibles de FK, jamais générées (SQL/Drizzle) ; citées dans la doc.
# Formats : ../02-file-formats.md §8-9. Code retour 1 s'il y a des E (enumRef/table/colonne/type inconnus...).
require 'yaml'
require 'json'
require 'fileutils'

DIALECTS = %w[postgresql mysql sqlite].freeze
USAGE = 'usage: visual_to_sql.rb <scaf/vN> [--dialect postgresql|mysql|sqlite] [--format sql|drizzle|docs|all] [--keys snake|camel] [--tables-names] [--out dossier] [--stdout]'
root = ARGV[0] or abort USAGE
opt = ->(name) { i = ARGV.index(name); i && ARGV[i + 1] }
dir = File.join(root, 'input', 'database', 'visual')
abort "introuvable: #{dir}" unless Dir.exist?(dir)
format = opt.('--format') || 'all'
abort "format inconnu: #{format}" unless %w[sql drizzle docs all].include?(format)

# valeurs par défaut lues dans les configs d'export (base, sans override d'app)
cfg = lambda do |techno|
  f = File.join(root, 'input', 'export-configs', "#{techno}.json")
  File.exist?(f) ? (JSON.parse(File.read(f))['config'] || {}) : {}
rescue JSON::ParserError
  {}
end
nest = cfg.('nestjs')
dialect = opt.('--dialect') || 'postgresql'
from = opt.('--dialect') ? '--dialect' : 'défaut'
abort "dialecte inconnu: #{dialect} (#{DIALECTS.join('|')})" unless DIALECTS.include?(dialect)
keys = opt.('--keys') || nest['schemaKeyStyle'] || 'snake'
abort "--keys : snake|camel (reçu #{keys})" unless %w[snake camel].include?(keys)
tn_on = ARGV.include?('--tables-names') || nest['tablesNames'] == true

require_relative "db_dialects/#{dialect}"
D = DbDialect

explicit = opt.('--out')
base = explicit || File.join(root, 'output', 'database')
sub = explicit || File.join(base, dialect)   # sql + drizzle
docs_base = base                                                               # docs : indépendantes du dialecte

E = []
W = []
load_yml = ->(f) { YAML.safe_load(File.read(f)) || {} }
enums_file = File.join(dir, '_visual_enums.yml')
enums = File.exist?(enums_file) ? (load_yml.(enums_file)['enums'] || []) : []
all_tables = Dir[File.join(dir, '_visual_*.yml')].sort.reject { |f| f.end_with?('_visual_enums.yml') }
                                                 .flat_map { |f| m = load_yml.(f); (m['tables'] || []).map { |t| t.merge('_file' => File.basename(f), '_module' => m['name'], '_mdesc' => m['description']) } }
tables = all_tables.reject { |t| t['external'] }   # générées ; les externes ne servent que de cible de FK et à la doc
if tables.empty?
  puts "aucun modèle visuel dans #{dir} (pas de table) : rien à générer"
  exit 0
end

tables.each do |t|
  pk = t['columns'].select { |c| c['primary'] }
  t['columns'].each { |c| c['_autouuid'] = c['default'].nil? && c['primary'] && c['type'] == 'uuid' && pk.size == 1 && !c['references'] }
end

enum_by = enums.to_h { |e| [e['name'], e] }
cols_of = all_tables.to_h { |t| [t['name'], t['columns'].map { |c| c['name'] }] }
E << "E tables en double : #{all_tables.map { |t| t['name'] }.group_by { |n| n }.select { |_, v| v.size > 1 }.keys.join(', ')}" if cols_of.size != all_tables.size
all_tables.each do |t|
  t['columns'].each { |c| E << "E #{t['_file']}:#{t['name']}.#{c['name']} : type inconnu #{c['type']}" unless D.known_type?(c['type']) }
end

# ── SQL : sql/00_enums.sql (pg), sql/10_<module>.sql (tables + commentaires + index), sql/99_foreign_keys.sql (si FK non inline) ──
# Préfixes numériques : `psql -f sql/*.sql` applique dans le bon ordre ; les FK en dernier évitent tout cycle entre modules.
SQL_BANNER = "-- Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n"
sq = ->(s) { "'#{s.to_s.gsub("'", "''").gsub(/\s*\n\s*/, ' ').strip}'" }   # littéral SQL (commentaires)
dash = ->(s) { s.to_s.gsub(/\s*\n\s*/, ' ').strip }                         # commentaire `--` sur une ligne

sql_files = D.preamble.dup
ed = D.enum_ddl(enums, dash, sq)
sql_files['sql/00_enums.sql'] = SQL_BANNER + "\n" + ed if ed

tables.group_by { |t| t['_module'] }.each do |m, ts|
  out_t = ts.map do |t|
    where = "#{t['_file']}:#{t['name']}"
    pk = t['columns'].select { |c| c['primary'] }.map { |c| c['name'] }
    defs = t['columns'].map do |c|
      E << "E #{where}.#{c['name']} : enumRef inconnu (#{c['enumRef'].inspect})" if c['type'] == 'enum' && !enum_by[c['enumRef']]
      d = "  #{D.q(c['name'])} #{D.type(c, enum_by[c['enumRef']])}"
      d += ' NOT NULL' unless c['nullable'] || (c['primary'] && pk.size == 1)
      d += ' PRIMARY KEY' if c['primary'] && pk.size == 1
      d += ' UNIQUE' if c['unique'] && !c['primary']
      df = D.default_sql(c)
      d += " DEFAULT #{df}" if df
      d += D.col_check(c, enum_by[c['enumRef']]).to_s
      d += D.col_comment(c['description'], sq).to_s
      d
    end
    defs << "  PRIMARY KEY (#{pk.map { |c| D.q(c) }.join(', ')})" if pk.size > 1
    (t['checks'] || []).each { |k| defs << "  CONSTRAINT #{k['name']} CHECK (#{k['expression']})" }
    if D.fk_inline?
      t['columns'].select { |c| c['references'] }.each do |c|
        r = c['references']
        E << "E #{t['name']}.#{c['name']} : référence inconnue #{r['table']}.#{r['column']}" unless cols_of[r['table']]&.include?(r['column'])
        defs << "  #{D.fk_inline(c)}"
      end
    end
    idx = (t['indexes'] || []).map do |i|
      ((i['columns'] || []) - cols_of[t['name']]).each { |c| E << "E #{t['name']}.#{i['name']} : colonne inconnue #{c}" }
      if (why = D.idx_unsupported(i))
        W << "W #{t['name']}.#{i['name']} : index ignoré (#{dialect}) — #{why}"
        "-- index #{i['name']} ignoré (#{dialect}) : #{why}"
      else
        D.idx_stmt(t, i)
      end
    end
    cm = D.comment_stmts(t, sq)
    "-- #{t['name']} : #{dash.(t['description'])}\nCREATE TABLE #{D.q(t['name'])} (\n#{defs.join(",\n")}\n#{D.table_tail(t['description'], sq)}\n#{cm.empty? ? '' : cm.join("\n") + "\n"}#{idx.join("\n")}#{"\n" unless idx.empty?}"
  end.join("\n")
  sql_files["sql/10_#{m}.sql"] = SQL_BANNER + "\n-- Module #{m} : #{dash.(ts.first['_mdesc'])}\n\n" + out_t
end

unless D.fk_inline?
  fks = tables.flat_map do |t|
    t['columns'].select { |c| c['references'] }.map do |c|
      r = c['references']
      E << "E #{t['name']}.#{c['name']} : référence inconnue #{r['table']}.#{r['column']}" unless cols_of[r['table']]&.include?(r['column'])
      D.fk_stmt(t, c)
    end
  end
  sql_files['sql/99_foreign_keys.sql'] = SQL_BANNER + "\n" + fks.join("\n") + "\n"
end
sql_files.transform_values! { |v| D.tx_wrap(v, SQL_BANNER) }   # BEGIN/COMMIT par fichier (dialectes à DDL transactionnel)
sql_all = sql_files.sort.map(&:last).join("\n")   # schema.sql = concaténation dans l'ordre lexical (00 < 10 < 99)

# ── Drizzle : drizzle/enums.ts (pg) + drizzle/<module>.ts + drizzle/index.ts [+ drizzle/tables-names.ts] ──
# ponytail: clés de colonnes en snake_case (= noms SQL) par défaut ; --keys camel pour le style du code applicatif.
camel = ->(n) { n.split('_').each_with_index.map { |w, i| i.zero? ? w : w.capitalize }.join }
key = ->(n) { keys == 'camel' ? camel.(n) : n }
tconst = ->(n) { tn_on ? "#{n.upcase}_TABLE" : camel.(n) }
jsdoc = ->(s, ind = '') { "#{ind}/** #{s.to_s.gsub('*/', '* /').gsub(/\s*\n\s*/, ' ').strip} */" }
BANNER = "// Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n"
file_of = ->(t) { t['_module'] }
head = lambda do |body, enum_file_needed, others|
  used = D::DZ_IMPORTS.select { |n| body.match?(/\b#{n}\(/) }
  h = [BANNER, "import { #{used.join(', ')}#{body.include?(D::DZ_ANY) ? ", type #{D::DZ_ANY}" : ''} } from '#{D::DZ_PKG}';"]
  h << "import { sql } from 'drizzle-orm';" if body.include?('sql`')
  h << "import { DB_TABLES_NAMES } from './tables-names';" if tn_on && body.include?('DB_TABLES_NAMES')
  ens = enum_file_needed.select { |n| body.include?("#{n}(") }
  h << "import { #{ens.join(', ')} } from './enums';" unless ens.empty?
  others.each { |m, ns| h << "import { #{ns.uniq.sort.join(', ')} } from './#{m}';" }
  h.join("\n") + "\n\n"
end
drizzle = lambda do
  files = {}
  enum_consts = D.dz_enum_file? ? enums.map { |e| "#{camel.(e['name'])}Enum" } : []
  if D.dz_enum_file?
    body = enums.map do |e|
      vals = e['values'].map { |v| " * - #{v['value']} : #{v['description'].to_s.gsub('*/', '* /').gsub(/\s*\n\s*/, ' ')}" }
      "/**\n * #{e['description'].to_s.gsub('*/', '* /').gsub(/\s*\n\s*/, ' ')}\n#{vals.join("\n")}\n */\n#{D.dz_enum_decl(e, camel)}"
    end.join("\n\n")
    files['enums.ts'] = head.(body, [], {}) + body + "\n"
  end
  mods = tables.group_by { |t| file_of.(t) }
  mods.each do |m, ts|
    others = Hash.new { |h, k| h[k] = [] }
    out_t = ts.map do |t|
      pk = t['columns'].select { |c| c['primary'] }.map { |c| c['name'] }
      cols = t['columns'].map do |c|
        n = c['name']
        d = c['type'] == 'enum' && D.respond_to?(:dz_enum_inline) ? (enum_by[c['enumRef']] && D.dz_enum_inline(c, n, enum_by[c['enumRef']])) : D.dz_col(c, n, camel)
        d ||= (E << "E #{t['name']}.#{n} : type inconnu #{c['type']}"; "text('#{n}')")
        d += '.notNull()' unless c['nullable'] || (c['primary'] && pk.size == 1)
        d += '.primaryKey()' if c['primary'] && pk.size == 1
        d += D.dz_unique(c)
        d += D.dz_default(c)
        desc = c['description']
        if (r = c['references'])
          target = all_tables.find { |x| x['name'] == r['table'] }
          if target&.fetch('external', false)
            desc = "#{desc} — FK vers la table externe #{r['table']}.#{r['column']} (non générée)"
          else
            tm = target&.fetch('_module', nil)
            others[tm] << tconst.(r['table']) if tm && tm != m
            d += ".references((): #{D::DZ_ANY} => #{tconst.(r['table'])}.#{key.(r['column'])}#{D.dz_ref_opts(r)})"
          end
        end
        "#{jsdoc.(desc, '  ')}\n  #{key.(n)}: #{d},"
      end
      extra = []
      extra << "primaryKey({ columns: [#{pk.map { |c| "t.#{key.(c)}" }.join(', ')}] })" if pk.size > 1
      (t['checks'] || []).each { |k| extra << "check('#{k['name']}', sql`#{k['expression']}`)" }
      (t['indexes'] || []).each { |i| extra << D.dz_idx(i, key) unless D.idx_unsupported(i) }
      tname = tn_on ? "DB_TABLES_NAMES.#{t['name'].upcase}" : "'#{t['name']}'"
      "#{jsdoc.(t['description'])}\nexport const #{tconst.(t['name'])} = #{D::DZ_TABLE}(#{tname}, {\n#{cols.join("\n")}\n#{extra.empty? ? '});' : "}, (t) => [#{extra.join(', ')}]);"}"
    end.join("\n\n")
    files["#{m}.ts"] = head.(out_t, enum_consts, others) + out_t + "\n"
  end
  if tn_on
    files['tables-names.ts'] = BANNER + "\nexport const DB_TABLES_NAMES = {\n#{tables.map { |t| "  #{t['name'].upcase}: '#{t['name']}'," }.join("\n")}\n} as const;\n"
  end
  barrel = (tn_on ? ['tables-names'] : []) + (D.dz_enum_file? ? ['enums'] : []) + mods.keys
  files['index.ts'] = BANNER + "\n" + barrel.map { |m| "export * from './#{m}';" }.join("\n") + "\n"
  files
end

# ── Doc Markdown : docs/README.md (index) + docs/<module>.md + docs/enums.md, liens FK/enum cliquables ──
MD_BANNER = "<!-- Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main. -->\n\n"
docs = lambda do
  cell = ->(x) { x.to_s.gsub('|', '\\|').gsub("\n", ' ') }
  mod_of = all_tables.to_h { |t| [t['name'], t['_module']] }
  mods = all_tables.group_by { |t| t['_module'] }
  files = {}
  mods.each do |m, ts|
    l = [MD_BANNER + "# Module #{m}", '', ts.first['_mdesc'].to_s, '', '[← Index](README.md)', '']
    ts.each do |t|
      l << "### #{t['name']}" << '' << t['description'].to_s << ''
      l << "> Type : **#{t['kind']}**." << '' if t['kind']
      l << '> Table **externe** : non générée (gérée ailleurs, ex. Better Auth) ; citée pour les clés étrangères.' << '' if t['external']
      l << '| Colonne | Type | Null | Défaut | Réf. | Description |' << '|---|---|---|---|---|---|'
      t['columns'].each do |c|
        ty = c['type'] == 'enum' ? "[enum `#{c['enumRef']}`](enums.md##{c['enumRef']})" : c['type']
        r = c['references']
        act = r ? [r['onDelete'] && "delete: #{r['onDelete']}", r['onUpdate'] && "update: #{r['onUpdate']}"].compact.join(', ') : ''
        ref = r ? "[#{r['table']}.#{r['column']}](#{mod_of[r['table']] == m ? '' : "#{mod_of[r['table']]}.md"}##{r['table']})#{" (#{act})" unless act.empty?}" : ''
        l << "| #{c['name']}#{' 🔑' if c['primary']}#{' ∪' if c['unique']} | #{ty} | #{c['nullable'] ? 'oui' : 'non'} | #{cell.(c['default'])} | #{ref} | #{cell.(c['description'])} |"
      end
      l << ''
      unless (t['indexes'] || []).empty?
        l << '**Index :**' << ''
        t['indexes'].each do |i|
          parts = (i['columns'] || []) + (i['expressions'] || []).map { |e| "`#{e}`" }
          l << "- `#{i['name']}` (#{parts.join(', ')})#{' — unique' if i['unique']}#{" — méthode #{i['method']}" if i['method']}#{" — partiel : `#{i['where']}`" if i['where']}"
        end
        l << ''
      end
      unless (t['checks'] || []).empty?
        l << '**Contraintes CHECK :**' << ''
        t['checks'].each { |k| l << "- `#{k['name']}` : `#{cell.(k['expression'])}`#{" — #{cell.(k['description'])}" if k['description']}" }
        l << ''
      end
    end
    files["docs/#{m}.md"] = l.join("\n")
  end
  users = Hash.new { |h, k| h[k] = [] }
  tables.each { |t| t['columns'].each { |c| users[c['enumRef']] << "#{t['name']}.#{c['name']}" if c['type'] == 'enum' } }
  l = [MD_BANNER + '# Enums', '', '[← Index](README.md)', '']
  enums.each do |e|
    l << "### #{e['name']}" << '' << e['description'].to_s << ''
    e['values'].each { |v| l << "- `#{v['value']}` — #{v['description']}" }
    l << '' << "Utilisé par : #{users[e['name']].map { |u| "`#{u}`" }.join(', ')}" << ''
  end
  files['docs/enums.md'] = l.join("\n")
  deps = all_tables.flat_map { |t| t['columns'].map { |c| (r = c['references']) && mod_of[r['table']] != t['_module'] ? [t['_module'], mod_of[r['table']]] : nil }.compact }.uniq
  ext = all_tables.count { |t| t['external'] }
  l = [MD_BANNER + '# Modèle de données', '', "#{tables.size} tables · #{enums.size} enums#{" · #{ext} tables externes" if ext > 0} · [Enums](enums.md) · [Diagramme ER](er.md)", '']
  mods.each do |m, ts|
    l << "## [#{m}](#{m}.md)" << '' << ts.first['_mdesc'].to_s << ''
    ts.each { |t| l << "- [`#{t['name']}`](#{m}.md##{t['name']})#{' (externe)' if t['external']}#{" [#{t['kind']}]" if t['kind']} — #{t['description'].to_s.gsub(/\s*\n\s*/, ' ')}" }
    d = deps.select { |x, _| x == m }.map(&:last).uniq.sort
    l << '' << "Références : #{d.map { |x| "[#{x}](#{x}.md)" }.join(', ')}" unless d.empty?
    l << ''
  end
  files['docs/README.md'] = l.join("\n")
  l = [MD_BANNER + '# Diagramme ER', '', '[← Index](README.md)', '']
  mods.each do |m, ts|
    l << "## #{m}" << '' << '```mermaid' << 'erDiagram'
    ts.each do |t|
      fks = t['columns'].select { |c| c['references'] }.map { |c| c['name'] }
      l << "  #{t['name']} {"
      t['columns'].each { |c| l << "    #{c['type'].to_s.sub(/\(.*\)/, '')} #{c['name']}#{c['primary'] ? ' PK' : (fks.include?(c['name']) ? ' FK' : '')}" }
      l << '  }'
    end
    ts.each { |t| t['columns'].each { |c| (r = c['references']) && l << "  #{r['table']} #{c['nullable'] ? '|o' : '||'}--o{ #{t['name']} : \"#{c['name']}\"" } }
    l << '```' << ''
  end
  files['docs/er.md'] = l.join("\n")
  files
end

gens = {
  'sql' => -> { sql_files.merge('schema.sql' => sql_all).map { |k, v| [[sub, k], -> { v }] } },
  'drizzle' => -> { drizzle.call.map { |k, v| [[sub, "drizzle/#{k}"], -> { v }] } },
  'docs' => -> { docs.call.map { |k, v| [[docs_base, k], -> { v + "\n" }] } }
}
todo = format == 'all' ? gens.keys : [format]
files = todo.flat_map { |f| gens[f].call }.to_h
if ARGV.include?('--stdout')
  abort 'E --stdout : sql uniquement' unless format == 'sql'
  puts sql_all
else
  clean = { 'sql' => sub, 'drizzle' => sub, 'docs' => docs_base }
  todo.each { |d| FileUtils.rm_rf(File.join(clean[d], d)) }   # pas de fichier orphelin d'un module supprimé
  FileUtils.rm_f(File.join(sub, 'schema.sql')) if todo.include?('sql')
  files.each { |(dir_, k), v| path = File.join(dir_, k); FileUtils.mkdir_p(File.dirname(path)); File.write(path, v.call) }
  puts "#{dialect} (#{from}) : #{enums.size} enums, #{tables.size} tables, #{tables.sum { |t| t['columns'].size }} colonnes -> #{sub} (#{files.size} fichiers)"
end
E.each { |m| warn m }
W.each { |m| warn m }
exit(E.empty? ? 0 : 1)
