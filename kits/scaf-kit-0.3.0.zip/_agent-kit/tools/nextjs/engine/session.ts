import type { ParsedEndpoint } from "./_lib/spec-types";

/** Où lire les jetons dans la réponse succès (chemins pointés, ex. `data.access_token`). */
export interface SessionEndpoint { accessToken: string; refreshToken?: string; expiresIn?: string }
/** Endpoint de rafraîchissement : `bodyField` = champ du corps qui reçoit le refresh token ; les chemins lisent la réponse. */
export interface SessionRefresh { endpoint: string; bodyField: string; accessToken: string; refreshToken?: string; expiresIn?: string }
export interface SessionCfg { endpoints?: Record<string, SessionEndpoint>; logout?: string[]; refresh?: SessionRefresh }
/** Options de génération issues du config nextjs effectif de l'app. */
export interface GenOpts { app?: string; auth?: string; session?: SessionCfg }

export const isCustomJwt = (o: GenOpts) => o.auth === "custom_jwt";

/** `lib/auth-token.ts` : jeton lu par requête (cookie httpOnly) en custom_jwt, sinon aucun jeton (jamais d'état global serveur). */
export function generateAuthToken(o: GenOpts, refreshEp?: { method: string; path: string }): string {
  const head = [
    "// ============================================================",
    "// Auth Token — jeton d'API (lu à chaque requête, jamais en variable globale)",
    "// AUTO-GENERATED — do not edit manually",
    "// ============================================================",
    "",
  ];
  if (!isCustomJwt(o)) {
    return [...head,
      "/** Pas de session gérée par le générateur (`auth` ≠ custom_jwt) : brancher ici la source du jeton. */",
      "export async function getAccessToken(): Promise<string | null> {",
      "  return null;",
      "}",
      "",
    ].join("\n");
  }
  const p = (o.app ?? "app").replace(/[^a-z0-9]+/gi, "_");
  return [...head,
    'import { cookies } from "next/headers";',
    "",
    "// Nom préfixé par l'app : les cookies ignorent le port, deux apps en localhost se marcheraient dessus.",
    `const ACCESS = "${p}_access_token";`,
    `const REFRESH = "${p}_refresh_token";`,
    "const base = { httpOnly: true, secure: process.env.NODE_ENV === \"production\", sameSite: \"lax\" as const, path: \"/\" };",
    "",
    "/** Jeton de l'utilisateur de la requête courante (ou null). */",
    "export async function getAccessToken(): Promise<string | null> {",
    "  return (await cookies()).get(ACCESS)?.value ?? null;",
    "}",
    "",
    "export async function setSession(s: { accessToken: string; refreshToken?: string; expiresIn?: number }): Promise<void> {",
    "  const jar = await cookies();",
    "  jar.set(ACCESS, s.accessToken, { ...base, ...(s.expiresIn ? { maxAge: s.expiresIn } : {}) });",
    "  if (s.refreshToken) jar.set(REFRESH, s.refreshToken, base);",
    "}",
    "",
    "export async function clearSession(): Promise<void> {",
    "  const jar = await cookies();",
    "  jar.delete(ACCESS);",
    "  jar.delete(REFRESH);",
    "}",
    "",
    "const pick = (o: unknown, path: string): unknown => path.split(\".\").reduce<unknown>((v, k) => (v as Record<string, unknown> | null | undefined)?.[k], o);",
    "",
    "/** Pose la session si la réponse porte un jeton ; sinon rien (ex. étape intermédiaire d'un login). */",
    "export async function applySession(result: unknown, paths: { accessToken: string; refreshToken?: string; expiresIn?: string }): Promise<void> {",
    "  const accessToken = pick(result, paths.accessToken);",
    '  if (typeof accessToken !== "string" || !accessToken) return;',
    "  const refreshToken = paths.refreshToken ? pick(result, paths.refreshToken) : undefined;",
    "  const expiresIn = paths.expiresIn ? pick(result, paths.expiresIn) : undefined;",
    "  await setSession({",
    "    accessToken,",
    '    ...(typeof refreshToken === "string" && refreshToken ? { refreshToken } : {}),',
    '    ...(typeof expiresIn === "number" ? { expiresIn } : {}),',
    "  });",
    "}",
    ...(refreshEp && o.session?.refresh ? refreshSessionCode(o.session.refresh, refreshEp) : []),
    "",
  ].join("\n");
}

/** `refreshSession` : échange le refresh token contre une nouvelle session (fetch brut : jamais via apiClient, pas de boucle). */
function refreshSessionCode(r: SessionRefresh, ep: { method: string; path: string }): string[] {
  return [
    "",
    "const inflight = new Map<string, Promise<string | null>>();",
    "",
    "/** Rafraîchit la session ; renvoie le nouveau jeton d'accès, ou null (pas de refresh token / refus : session effacée). */",
    "export async function refreshSession(baseUrl: string): Promise<string | null> {",
    "  const refresh = (await cookies()).get(REFRESH)?.value;",
    "  if (!refresh) return null;",
    "  // Un seul refresh par jeton, même avec plusieurs 401 simultanés (rotation à usage unique).",
    "  const running = inflight.get(refresh);",
    "  if (running) return running;",
    "  const p = (async () => {",
    "    try {",
    `      const res = await fetch(baseUrl + ${JSON.stringify(ep.path)}, {`,
    `        method: ${JSON.stringify(ep.method)},`,
    '        headers: { "Content-Type": "application/json" },',
    `        body: JSON.stringify({ ${JSON.stringify(r.bodyField)}: refresh }),`,
    "      });",
    "      const body: unknown = res.ok ? await res.json() : null;",
    `      const accessToken = pick(body, ${JSON.stringify(r.accessToken)});`,
    '      if (typeof accessToken !== "string" || !accessToken) throw new Error("refresh refusé");',
    ...(r.refreshToken ? [`      const nextRefresh = pick(body, ${JSON.stringify(r.refreshToken)});`] : []),
    ...(r.expiresIn ? [`      const expiresIn = pick(body, ${JSON.stringify(r.expiresIn)});`] : []),
    "      // Hors Server Action, cookies().set échoue : le jeton sert quand même à rejouer la requête en cours.",
    "      try {",
    "        await setSession({",
    "          accessToken,",
    ...(r.refreshToken ? ['          ...(typeof nextRefresh === "string" && nextRefresh ? { refreshToken: nextRefresh } : {}),'] : []),
    ...(r.expiresIn ? ['          ...(typeof expiresIn === "number" ? { expiresIn } : {}),'] : []),
    "        });",
    "      } catch { /* lecture seule (Server Component) */ }",
    "      return accessToken;",
    "    } catch {",
    "      try { await clearSession(); } catch { /* idem */ }",
    "      return null;",
    "    }",
    "  })().finally(() => inflight.delete(refresh));",
    "  inflight.set(refresh, p);",
    "  return p;",
    "}",
  ];
}

/** Import à ajouter dans une action, et instructions à insérer après l'appel (vide si l'endpoint n'est pas concerné). */
export function sessionHooks(ep: ParsedEndpoint, o: GenOpts): { imports: string[]; after: string[] } {
  if (!isCustomJwt(o)) return { imports: [], after: [] };
  const s = o.session?.endpoints?.[ep.id];
  if (s) return { imports: ["applySession"], after: [`await applySession(result, ${JSON.stringify(s)});`] };
  if (o.session?.logout?.includes(ep.id)) return { imports: ["clearSession"], after: ["await clearSession();"] };
  return { imports: [], after: [] };
}

/** `lib/actions/session-actions.ts` : déconnexion locale (efface les cookies), appelable depuis la vue. */
export function generateSessionActions(): string {
  return [
    "// ============================================================",
    "// Session actions — AUTO-GENERATED — do not edit manually",
    "// ============================================================",
    "",
    '"use server";',
    "",
    'import { clearSession } from "@/lib/auth-token";',
    "",
    "/** Efface la session (cookies) de l'utilisateur courant. */",
    "export async function clearSessionAction(): Promise<void> {",
    "  await clearSession();",
    "}",
    "",
  ].join("\n");
}
