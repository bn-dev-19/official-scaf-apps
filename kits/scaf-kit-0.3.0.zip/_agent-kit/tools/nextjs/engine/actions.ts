import type { GeneratedFile } from "./generated-file";
import type { SpecContext, ParsedEndpoint } from "./_lib/spec-types";
import { HEADER } from "./_lib/header";
import { sessionHooks, generateSessionActions, isCustomJwt, type GenOpts } from "./session";
import { kebabToPascal, kebabToCamel, escapeString, getVersionDir, toIdentifier } from "./_lib/naming";

export function generateActions(context: SpecContext, _architecture: string, docs: boolean = false, versionDir?: string, opts: GenOpts = {}): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const vd = versionDir ?? "v1";

  // safe-action.ts
  files.push({ path: "src/lib/actions/safe-action.ts", content: generateSafeAction() });

  if (isCustomJwt(opts)) files.push({ path: "src/lib/actions/session-actions.ts", content: generateSessionActions() });

  for (const ep of context.endpoints) {
    const content = generateActionFile(ep, docs, vd, opts);
    const path = `src/api-actions/${vd}/${ep.app}/${ep.module}/${ep.feature}/${ep.id}.ts`;
    files.push({ path, content });
  }

  // action-id.ts + action-registry.ts (versioned)
  const { actionIdContent, registryContent } = generateRegistryFiles(context, vd);
  files.push({ path: `src/api-actions/${vd}/action-id.ts`, content: actionIdContent });
  files.push({ path: `src/api-actions/${vd}/action-registry.ts`, content: registryContent });

  // Central barrels (re-export from versioned)
  files.push({ path: "src/api-actions/action-id.ts", content: generateCentralActionId(vd) });
  files.push({ path: "src/api-actions/action-registry.ts", content: generateCentralActionRegistry(vd) });

  // action-registry-ready-to-real.ts + action-registry.overrides.ts (global)
  files.push({ path: "src/api-actions/action-registry-ready-to-real.ts", content: generateReadyToRealHelper() });
  files.push({ path: "src/api-actions/action-registry.overrides.ts", content: generateOverridesFile(), preserve: true });

  return files;
}

function generateCentralActionId(versionDir: string): string {
  const lines = [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// ActionId — central barrel (re-exports from versioned)",
    "// AUTO-GENERATED — do not edit manually",
    "// ────────────────────────────────────────────────────────────",
    "",
    `export * from "./${versionDir}/action-id";`,
    "",
  ];
  return lines.join("\n");
}

function generateCentralActionRegistry(versionDir: string): string {
  const lines = [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// ActionRegistry — central barrel (re-exports from versioned)",
    "// AUTO-GENERATED — do not edit manually",
    "// ────────────────────────────────────────────────────────────",
    "",
    `export * from "./${versionDir}/action-registry";`,
    "",
  ];
  return lines.join("\n");
}

function generateSafeAction(): string {
  const lines = [
    "// ============================================================",
    "// Safe Action — error-safe async wrapper for server actions",
    "// AUTO-GENERATED — do not edit manually",
    "// To regenerate: pnpm generate:all",
    "// ============================================================",
    "",
    'import { logger } from "@/lib/logger";',
    'import { ZodError } from "zod";',
    'import { ApiClientError } from "@/lib/api-client";',
    'import type { ApiErrorResponse } from "@/api-shared/shapes/error-shapes";',
    "",
    'const COMMON_CODES = ["VALIDATION_ERROR", "INTERNAL_ERROR", "NETWORK_ERROR", "UNKNOWN_ERROR"];',
    "",
    "/** Résultat d'une action : enveloppe succès `T` ou enveloppe d'erreur scaf. */",
    "export type AppActionResult<T = unknown, C extends string = string> = T | ApiErrorResponse<C>;",
    "",
    'export async function safeAction<T>(name: string, fn: () => Promise<T>): Promise<T | ApiErrorResponse<any>>;',
    'export async function safeAction<T, P>(name: string, fn: (params: P) => Promise<T>, params: P, known?: Record<string, unknown>): Promise<T | ApiErrorResponse<any>>;',
    "export async function safeAction<T, P>(",
    "  name: string,",
    "  fn: ((params?: P) => Promise<T>),",
    "  params?: P,",
    "  known?: Record<string, unknown>,",
    "): Promise<T | ApiErrorResponse<any>> {",
    '  const log = logger.child({ module: `SAFE-ACTION(${name})` });',
    "  const start = Date.now();",
    "",
    '  log.info({ params }, "\\u2192 start");',
    "",
    "  try {",
    "    const result = params !== undefined",
    "      ? await (fn as (p: P) => Promise<T>)(params)",
    "      : await (fn as () => Promise<T>)();",
    "",
    '    log.info({ duration: Date.now() - start, result }, "\\u2192 ok");',
    "    return result;",
    "  } catch (err) {",
    '    log.error({ err, duration: Date.now() - start }, "\\u2192 fail");',
    "",
    "    if (err instanceof ZodError) {",
    '      log.error({ issues: err.issues }, "ZodError");',
    '      const fields = err.issues.map(i => ({ path: i.path.join("."), message: i.message }));',
    '      const message = "Données invalides.";',
    '      return { success: false, message, error: { code: "VALIDATION_ERROR", message, fields } };',
    "    }",
    "",
    "    if (err instanceof ApiClientError) {",
    "      const body = err.body as Partial<ApiErrorResponse> | undefined;",
    "      // Code absent du contrat de l'endpoint : normalisé, pour que `ErrorCode` dise vrai.",
    "      const declared = err.code in (known ?? {}) || COMMON_CODES.includes(err.code);",
    "      return {",
    "        success: false,",
    "        message: err.message,",
    "        error: {",
    "          ...body?.error,",
    '          code: declared ? err.code : "UNKNOWN_ERROR",',
    "          message: body?.error?.message ?? err.message,",
    "          ...(declared ? {} : { cause: `Code API hors contrat : ${err.code}` }),",
    "        },",
    "      };",
    "    }",
    "",
    "    const message = err instanceof Error ? err.message : \"Une erreur inattendue s'est produite\";",
    '    return { success: false, message, error: { code: "INTERNAL_ERROR", message } };',
    "  }",
    "}",
    "",
  ];
  return lines.join("\n");
}

function hasBodyFields(ep: ParsedEndpoint): boolean {
  return !!(ep.spec.http?.request?.body?.properties && Object.keys(ep.spec.http.request.body.properties).length > 0);
}

function hasQueryFields(ep: ParsedEndpoint): boolean {
  return !!(ep.spec.http?.request?.query && ep.spec.http.request.query.length > 0);
}

function extractPathParams(path: string): string[] {
  const matches = path.match(/\{(\w+)\}/g);
  if (!matches) return [];
  return [...new Set(matches.map(m => m.slice(1, -1)))];
}

function generateActionFile(ep: ParsedEndpoint, docs: boolean, versionDir?: string, gopts: GenOpts = {}): string {
  const vd = versionDir ?? "v1";
  const sess = sessionHooks(ep, gopts);
  const id = ep.id;
  const method = ep.method;
  const pascal = kebabToPascal(id);
  const camelPath = [ep.app, ep.module, ep.feature, id].map(kebabToCamel).join(".");
  const actionName = `handle${pascal}Action`;

  const bodyOk = hasBodyFields(ep);
  const queryOk = hasQueryFields(ep);
  const pathParams = extractPathParams(ep.path);
  const paramsOk = pathParams.length > 0;
  const needsZod = bodyOk || queryOk || paramsOk;

  const destructureParts: string[] = [];
  if (bodyOk) destructureParts.push("body");
  if (queryOk) destructureParts.push("query");
  if (paramsOk) destructureParts.push("params");
  destructureParts.push("...extra");
  const destructureStr = destructureParts.join(", ");

  const sharedImport = `@/api-shared/${vd}/${ep.app}/${ep.module}/${ep.feature}/${id}/${id}`;

  const rawDesc = ep.spec.endpoint?.description ?? `Action pour ${id}`;
  const desc = escapeString(rawDesc);

  const defaultMsg =
    method === "GET" ? "Récupération réussie" :
    method === "POST" ? "Création réussie" :
    method === "PUT" || method === "PATCH" ? "Mise à jour réussie" :
    method === "DELETE" ? "Suppression réussie" :
    "Opération réussie";

  const optsFields: string[] = [];
  if (bodyOk) optsFields.push("body?: z.infer<typeof T.BodySchema>;");
  if (queryOk) optsFields.push("query?: z.infer<typeof T.QuerySchema>;");
  if (paramsOk) optsFields.push("params?: z.infer<typeof T.ParamsSchema>;");
  optsFields.push("headers?: T.Headers;");
  optsFields.push("signal?: AbortSignal;");
  optsFields.push("mock?: T.MockMode;");
  optsFields.push("mockOverrides?: Partial<T.Response>;");
  optsFields.push("errorOverrides?: Partial<T.Errors[keyof T.Errors]>;");

  const diArgs: string[] = [];
  if (bodyOk) diArgs.push("body: parsedBody");
  if (queryOk) diArgs.push("query: parsedQuery");
  if (paramsOk) diArgs.push("params: parsedParams");
  diArgs.push("...effectiveExtra");

  const lines: string[] = [];
  lines.push(HEADER);
  lines.push('"use server";');
  lines.push("");
  if (needsZod) {
    lines.push('import { z } from "zod";');
  }
  if (docs) {
    lines.push('import { indexDoc, DocKind } from "@docs/index-doc";');
  }
  lines.push('import { safeAction, AppActionResult } from "@/lib/actions/safe-action";');
  if (sess.imports.length) lines.push(`import { ${sess.imports.join(", ")} } from "@/lib/auth-token";`);
  lines.push(`import { ApiDi_${toIdentifier(vd)} as ApiDi } from "@/di/api_di";`);
  lines.push(`import * as T from "${sharedImport}";`);
  lines.push('import { ActionId } from "@/api-actions/action-id";');
  lines.push('import { isReadyToReal } from "@/api-actions/action-registry-ready-to-real";');
  lines.push("");

  const actionMeta = {
    slug: `action-${id}`,
    title: `${id} — ${method} ${ep.path}`,
    description: rawDesc,
    tags: ["action", "api", ep.app, ep.module, ep.feature, method.toLowerCase()],
    kind: "DocKind.Function",
  };

  if (docs) {
    lines.push(`export const ${actionName} = indexDoc(`);
    lines.push("  {");
    lines.push(`    slug: ${JSON.stringify(actionMeta.slug)},`);
    lines.push(`    title: ${JSON.stringify(actionMeta.title)},`);
    lines.push(`    description: ${JSON.stringify(actionMeta.description)},`);
    lines.push(`    tags: ${JSON.stringify(actionMeta.tags)},`);
    lines.push(`    kind: DocKind.Function,`);
    lines.push("  },");
    lines.push("  async (opts?: {");
    for (const f of optsFields) lines.push(`    ${f}`);
    lines.push("  }): Promise<AppActionResult<T.Response, T.ErrorCode>> => {");
    lines.push("    return safeAction(");
    lines.push(`      "${actionName}",`);
    lines.push("      async (r) => {");
    lines.push(`        const { ${destructureStr} } = r ?? {};`);
    if (bodyOk) lines.push("        const parsedBody = T.BodySchema.parse(body);");
    if (queryOk) lines.push("        const parsedQuery = T.QuerySchema.parse(query);");
    if (paramsOk) lines.push("        const parsedParams = T.ParamsSchema.parse(params);");
    lines.push(`        const isReady = isReadyToReal(ActionId.${pascal});`);
    lines.push("        let effectiveExtra = extra;");
    lines.push('        if (!isReady && extra?.mock !== "real") {');
    lines.push('          effectiveExtra = { ...extra, mock: "success" };');
    lines.push("        }");
    lines.push(`        const result = await ApiDi.${camelPath}({ ${diArgs.join(", ")} });`);
    for (const l of sess.after) lines.push(`        ${l}`);
    lines.push(`        return result;`);
    lines.push("      },");
    lines.push("      opts,");
    lines.push("      T.errors,");
    lines.push("    );");
    lines.push("  },");
    lines.push(");");
    lines.push("");
    return lines.join("\n");
  }

  lines.push("/**");
  lines.push(` * ${desc}`);
  lines.push(" * @param opts - Données de la requête et options supplémentaires.");
  lines.push(" * @returns AppActionResult avec la réponse typée.");
  lines.push(" */");
  lines.push(`export async function ${actionName}(opts?: {`);
  for (const f of optsFields) lines.push(`  ${f}`);
  lines.push("}): Promise<AppActionResult<T.Response, T.ErrorCode>> {");
  lines.push("  return safeAction(");
  lines.push(`    "${actionName}",`);
  lines.push("    async (r) => {");
  lines.push(`      const { ${destructureStr} } = r ?? {};`);
  if (bodyOk) lines.push("      const parsedBody = T.BodySchema.parse(body);");
  if (queryOk) lines.push("      const parsedQuery = T.QuerySchema.parse(query);");
  if (paramsOk) lines.push("      const parsedParams = T.ParamsSchema.parse(params);");
  lines.push(`      const isReady = isReadyToReal(ActionId.${pascal});`);
  lines.push("      let effectiveExtra = extra;");
  lines.push('      if (!isReady && extra?.mock !== "real") {');
  lines.push('        effectiveExtra = { ...extra, mock: "success" };');
  lines.push("      }");
  lines.push(`      const result = await ApiDi.${camelPath}({ ${diArgs.join(", ")} });`);
  for (const l of sess.after) lines.push(`      ${l}`);
  lines.push(`      return result;`);
  lines.push("    },");
  lines.push("    opts,");
  lines.push("    T.errors,");
  lines.push("  );");
  lines.push("}");
  lines.push("");

  return lines.join("\n");
}

function generateReadyToRealHelper(): string {
  return [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// Helper to check readyToReal flag for each action",
    "// Auto-generated — do not edit manually",
    "// ────────────────────────────────────────────────────────────",
    "",
    'import { actionRegistry } from "./action-registry";',
    'import { actionRegistryOverrides } from "./action-registry.overrides";',
    'import type { ActionId } from "./action-id";',
    "",
    "export function isReadyToReal(actionId: ActionId): boolean {",
    "  const override = actionRegistryOverrides[actionId];",
    "  if (override?.readyToReal !== undefined) {",
    "    return override.readyToReal;",
    "  }",
    "  return actionRegistry[actionId]?.readyToReal ?? false;",
    "}",
    "",
  ].join("\n");
}

function generateOverridesFile(): string {
  return [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// You can edit manually — this file is designed for manual edits",
    "// Uncomment and modify to enable real API calls in dev",
    "// ────────────────────────────────────────────────────────────",
    "",
    'import { ActionId } from "./action-id";',
    "",
    "export const actionRegistryOverrides: Partial<Record<ActionId, { readyToReal: boolean }>> = {",
    "  // [ActionId.Xxx]: { readyToReal: true },",
    "};",
    "",
    "export type ActionRegistryOverrides = typeof actionRegistryOverrides;",
    "",
  ].join("\n");
}

function generateRegistryFiles(context: SpecContext, versionDir?: string): { actionIdContent: string; registryContent: string } {
  const vd = versionDir ?? "v1";
  const sorted = [...context.endpoints].sort((a, b) => a.id.localeCompare(b.id));

  // action-id.ts
  const actionIdLines: string[] = [];
  actionIdLines.push(HEADER);
  actionIdLines.push("// ────────────────────────────────────────────────────────────");
  actionIdLines.push("// ActionId — identifiants de tous les endpoints");
  actionIdLines.push("// Auto-generated — do not edit manually");
  actionIdLines.push("// ────────────────────────────────────────────────────────────");
  actionIdLines.push("");

  for (const ep of sorted) {
    const pascal = kebabToPascal(ep.id);
    actionIdLines.push(`export const ${pascal} = "${ep.id}";`);
  }
  actionIdLines.push("");
  actionIdLines.push("export const ActionId = {");
  for (const ep of sorted) {
    const pascal = kebabToPascal(ep.id);
    actionIdLines.push(`  ${pascal},`);
  }
  actionIdLines.push("} as const;");
  actionIdLines.push("export type ActionId = (typeof ActionId)[keyof typeof ActionId];");
  actionIdLines.push("");

  // action-registry.ts
  const registryLines: string[] = [];
  registryLines.push(HEADER);
  registryLines.push("// ────────────────────────────────────────────────────────────");
  registryLines.push("// ActionRegistry — mappe ActionId vers handler + emplacement");
  registryLines.push("// Auto-generated — do not edit manually");
  registryLines.push("// ────────────────────────────────────────────────────────────");
  registryLines.push("");
  registryLines.push('import { ActionId } from "./action-id";');
  registryLines.push("");

  for (const ep of sorted) {
    const pascal = kebabToPascal(ep.id);
    const actionName = `handle${pascal}Action`;
    const modulePath = `./${ep.app}/${ep.module}/${ep.feature}/${ep.id}`;
    registryLines.push(`import { ${actionName} } from "${modulePath}";`);
  }
  registryLines.push("");
  registryLines.push("export const actionRegistry = {");
  for (const ep of sorted) {
    const pascal = kebabToPascal(ep.id);
    const actionName = `handle${pascal}Action`;
    const location = `api-actions/${vd}/${ep.app}/${ep.module}/${ep.feature}/${ep.id}.ts`;
    registryLines.push(`  [ActionId.${pascal}]: {`);
    registryLines.push(`    handler: ${actionName},`);
    registryLines.push(`    actionLocation: "${location}",`);
    registryLines.push(`    readyToReal: false,`);
    registryLines.push(`  },`);
  }
  registryLines.push("} as const;");
  registryLines.push("export type ActionRegistry = typeof actionRegistry;");
  registryLines.push("");

  return { actionIdContent: actionIdLines.join("\n"), registryContent: registryLines.join("\n") };
}
