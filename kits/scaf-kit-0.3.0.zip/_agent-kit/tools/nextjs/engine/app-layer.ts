// L4 — app-behaviors/ + app-events/, pilotés par les usecases consumer (scaf/<v>/input/usecases/consumer/<app>/).
// Un usecase consumer est rattaché à la feature de l'endpoint désigné par openapi.operationId.
// behaviors : une interface par feature (méthodes typées input/output) + implémentation par défaut (NotImplementedError, fichier utilisateur).
// events    : un contrat par transition `calls`/`links` d'un usecase, payload = son output.
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { load as yamlLoad } from "js-yaml";
import type { GeneratedFile } from "./generated-file";
import type { SpecContext } from "./_lib/spec-types";
import { HEADER } from "./_lib/header";
import { kebabToPascal, kebabToCamel, isTsIdentifier } from "./_lib/naming";

interface Field { type?: string; enum?: unknown[]; nullable?: boolean; items?: Field; properties?: Record<string, Field>; required?: boolean | string[]; description?: string }
interface Usecase {
  id: string; name?: string; description?: string;
  input?: { schema?: Record<string, Field> }; output?: { schema?: Record<string, Field> };
  steps?: { code: string; order: number; stepDescription?: string; description?: string }[];
  errors?: { code: string; status: number }[];
  openapi?: { operationId?: string };
  calls?: { usecase?: string; when?: string }[];
  links?: { usecase?: string; rel?: string; when?: string }[];
}

export type UsecaseType = "consumer" | "producer";
export function loadUsecases(versionDir: string, app: string, type: UsecaseType): Usecase[] {
  const dir = join(versionDir, "input", "usecases", type, app);
  if (!existsSync(dir)) return [];
  return readdirSync(dir).filter(f => f.endsWith(".usecase.yml")).sort()
    .map(f => yamlLoad(readFileSync(join(dir, f), "utf8")) as Usecase);
}

const doc = (s: string) => s.trim().replace(/\*\//g, "*\\/").replace(/\n+/g, " ");
const key = (k: string) => (isTsIdentifier(k) ? k : JSON.stringify(k));

function tsType(f: Field | undefined, indent = 0): string {
  if (!f) return "unknown";
  let base: string;
  if (f.enum?.length) base = f.enum.map(v => JSON.stringify(v)).join(" | ");
  else if (f.type === "string") base = "string";
  else if (f.type === "integer" || f.type === "number") base = "number";
  else if (f.type === "boolean") base = "boolean";
  else if (f.type === "array") { const i = tsType(f.items, indent); base = /[|{]/.test(i) ? `Array<${i}>` : `${i}[]`; }
  else if (f.type === "object") base = fields(f.properties, indent, f.required);
  else base = "unknown";
  return f.nullable ? `${base} | null` : base;
}
function fields(props: Record<string, Field> | undefined, indent: number, req?: boolean | string[]): string {
  const entries = Object.entries(props ?? {});
  if (!entries.length) return "Record<string, unknown>";
  const pad = "  ".repeat(indent + 1);
  const lines = entries.map(([k, p]) => `${pad}${key(k)}${p.required === true || (Array.isArray(req) && req.includes(k)) ? "" : "?"}: ${tsType(p, indent + 1)};`);
  return `{\n${lines.join("\n")}\n${"  ".repeat(indent)}}`;
}
const iface = (name: string, schema: Record<string, Field> | undefined) =>
  Object.keys(schema ?? {}).length ? `export interface ${name} ${fields(schema, 0)}\n` : "";

const NOT_IMPL = `${HEADER}/** Levée par les comportements pas encore implémentés. */
export class NotImplementedError extends Error {
  constructor(what: string) {
    super(\`[not-implemented] \${what} — this behavior must be implemented\`);
    this.name = "NotImplementedError";
  }
}
`;
const SAFE = `${HEADER}import { logger } from "@/lib/logger";

/** Journalise start/ok/fail d'une méthode de comportement, puis relance l'erreur. */
export async function safeBehavior<T>(name: string, fn: () => Promise<T>): Promise<T> {
  const log = logger.child({ module: \`SAFE-BEHAVIOR(\${name})\` });
  const start = Date.now();
  log.info("→ start");
  try {
    const result = await fn();
    log.info({ duration: Date.now() - start }, "→ ok");
    return result;
  } catch (err) {
    log.error({ err, duration: Date.now() - start }, "→ fail");
    throw err;
  }
}
`;

export interface AppLayerCfg { enabled?: boolean; includeEvents?: boolean; includeProducer?: boolean }
interface Feat { module: string; feature: string; ucs: Usecase[] }

function groupByFeature(ctx: SpecContext, app: string, usecases: Usecase[]): Feat[] {
  const epById = new Map(ctx.endpoints.filter(e => e.app === app).map(e => [e.id, e]));
  const byFeature = new Map<string, Feat>();
  for (const uc of usecases) {
    const ep = epById.get(uc.openapi?.operationId ?? "");
    if (!ep) { ctx.warnings.push(`usecase ${uc.id} : operationId sans endpoint dans l'app ${app}, ignoré par L4`); continue; }
    const k = `${ep.module}/${ep.feature}`;
    byFeature.set(k, byFeature.get(k) ?? { module: ep.module, feature: ep.feature, ucs: [] });
    byFeature.get(k)!.ucs.push(uc);
  }
  return [...byFeature.values()];
}

// Mode docs : enveloppe une valeur dans indexDoc (docs-tool, `@docs/index-doc`).
const DOC_IMPORT = `import { indexDoc, DocKind } from "@docs/index-doc";`;
const docMeta = (slug: string, title: string, description: string, tags: string[], kind: string) =>
  `{ slug: ${JSON.stringify(slug)}, title: ${JSON.stringify(title)}, description: ${JSON.stringify(description)}, tags: ${JSON.stringify(tags)}, kind: DocKind.${kind} }`;

interface KindCfg { kind: UsecaseType; docs: boolean }

/** Interface + implémentation utilisateur par feature, registre et barrel d'un type de usecase (consumer | producer). */
function behaviorFiles(app: string, feats: Feat[], vd: string, k: KindCfg): GeneratedFile[] {
  const prod = k.kind === "producer";
  const suffix = prod ? ".producer" : "";
  const tp = prod ? "Producer" : ""; // préfixe des types d'E/S : évite les collisions de noms dans le barrel
  const kindName = `${tp}Behavior`;
  const regName = prod ? "producerBehaviorRegistry" : "behaviorRegistry";
  const regType = prod ? "ProducerBehaviorRegistry" : "BehaviorRegistry";
  const regFile = prod ? "producer-behavior-registry" : "behavior-registry";
  const taken = new Map<string, number>();
  feats.forEach(f => taken.set(f.feature, (taken.get(f.feature) ?? 0) + 1));
  const base = (f: Feat) => (taken.get(f.feature)! > 1 ? kebabToPascal(f.module) : "") + kebabToPascal(f.feature);
  const bdir = (f: Feat) => `src/app-behaviors/${vd}/${f.module}/${f.feature}`;
  const bar = `@/app-behaviors/${vd}`;
  const files: GeneratedFile[] = [];

  for (const f of feats) {
    const I = `${base(f)}${kindName}`;
    const I_ = `${I}Impl`;
    const sig = (uc: Usecase) => {
      const P = tp + kebabToPascal(uc.id);
      const hasIn = Object.keys(uc.input?.schema ?? {}).length > 0;
      const hasOut = Object.keys(uc.output?.schema ?? {}).length > 0;
      return { name: kebabToCamel(uc.id), in: hasIn ? `${P}Input` : undefined, out: hasOut ? `${P}Output` : "void" };
    };
    const types = f.ucs.map(uc => iface(`${tp}${kebabToPascal(uc.id)}Input`, uc.input?.schema) + iface(`${tp}${kebabToPascal(uc.id)}Output`, uc.output?.schema)).filter(Boolean);
    const itf = [HEADER, ...types, `export interface ${I} {`];
    for (const uc of f.ucs) {
      const s = sig(uc);
      itf.push("  /**", `   * ${doc(uc.description ?? uc.name ?? uc.id)}`);
      if (uc.errors?.length) itf.push(`   * Errors: ${uc.errors.map(e => `${e.code} (${e.status})`).join(", ")}`);
      itf.push("   */", `  ${s.name}(${s.in ? `input: ${s.in}` : ""}): Promise<${s.out}>;`, "");
    }
    itf.push("}", "");
    files.push({ path: `${bdir(f)}/${f.feature}${suffix}.behavior.ts`, content: itf.join("\n") });

    const used = new Set<string>([I]);
    f.ucs.forEach(uc => { const s = sig(uc); if (s.in) used.add(s.in); if (s.out !== "void") used.add(s.out); });
    const impl = [HEADER, "// Implémentation par défaut : chaque méthode lève NotImplementedError.",
      "// Fichier utilisateur : créé une fois, jamais réécrit — y mettre l'implémentation réelle.", "",
      `import { NotImplementedError } from "@/app-behaviors/not-implemented-error";`,
      `import { safeBehavior } from "@/app-behaviors/safe-behavior";`,
      ...(k.docs ? [DOC_IMPORT] : []),
      `import type { ${[...used].join(", ")} } from "./${f.feature}${suffix}.behavior";`, "",
      k.docs
        ? `export const ${I_} = indexDoc(${docMeta(`${app}-${f.module}-${f.feature}${suffix ? "-producer" : ""}-behavior`, I_, `Implémentation du comportement ${I}.`, ["behavior", k.kind, app, f.module], "Class")}, class ${I_} implements ${I} {`
        : `export class ${I_} implements ${I} {`];
    for (const uc of f.ucs) {
      const s = sig(uc);
      impl.push(`  async ${s.name}(${s.in ? `_input: ${s.in}` : ""}): Promise<${s.out}> {`,
        `    return safeBehavior("${I_}.${s.name}", async () => {`);
      for (const st of [...(uc.steps ?? [])].sort((a, b) => a.order - b.order))
        impl.push(`      // ${st.order}. ${st.code} — ${doc(st.stepDescription ?? st.description ?? "")}`);
      impl.push(`      throw new NotImplementedError("${I_}.${s.name}");`, "    });", "  }", "");
    }
    impl.pop(); impl.push(k.docs ? "});" : "}", "");
    files.push({ path: `${bdir(f)}/${f.feature}${suffix}.behavior.impl.ts`, content: impl.join("\n"), preserve: true });
  }

  const regBody = [`{`, ...feats.map(f => `  "${app}/${f.module}/${f.feature}": new ${base(f)}${kindName}Impl(),`), "} as const"];
  files.push({
    path: `src/app-behaviors/${vd}/${regFile}.ts`,
    content: [HEADER, ...(k.docs ? [DOC_IMPORT] : []),
      ...feats.map(f => `import { ${base(f)}${kindName}Impl } from "${bar}/${f.module}/${f.feature}/${f.feature}${suffix}.behavior.impl";`), "",
      `/** Feature (app/module/feature) → implémentation du comportement${prod ? " producer" : ""}. */`,
      k.docs
        ? `export const ${regName} = indexDoc(${docMeta(`${app}-${regFile}`, regName, `Registre des comportements ${k.kind} de l'app ${app}.`, ["registry", k.kind, app], "Object")}, ${regBody.join("\n")});`
        : `export const ${regName} = ${regBody.join("\n")};`, "",
      `export type ${regType} = typeof ${regName};`, ""].join("\n"),
  });
  return files;
}

export function generateAppLayer(ctx: SpecContext, app: string, consumer: Usecase[], producer: Usecase[], vd: string, cfg: AppLayerCfg, docs: boolean): GeneratedFile[] {
  if (!cfg.enabled) return [];
  const feats = groupByFeature(ctx, app, consumer);
  const pfeats = cfg.includeProducer ? groupByFeature(ctx, app, producer) : [];
  if (!feats.length && !pfeats.length) return [];

  const files: GeneratedFile[] = [
    { path: "src/app-behaviors/not-implemented-error.ts", content: NOT_IMPL },
    { path: "src/app-behaviors/safe-behavior.ts", content: SAFE },
  ];
  const bar = `@/app-behaviors/${vd}`;
  const barrel = [HEADER, 'export { NotImplementedError } from "@/app-behaviors/not-implemented-error";', 'export { safeBehavior } from "@/app-behaviors/safe-behavior";'];
  for (const [kind, fs] of [["consumer", feats], ["producer", pfeats]] as const) {
    if (!fs.length) continue;
    const suffix = kind === "producer" ? ".producer" : "";
    files.push(...behaviorFiles(app, fs, vd, { kind, docs }));
    barrel.push(`export * from "${bar}/${kind === "producer" ? "producer-behavior-registry" : "behavior-registry"}";`,
      ...fs.flatMap(f => [`export * from "${bar}/${f.module}/${f.feature}/${f.feature}${suffix}.behavior";`, `export * from "${bar}/${f.module}/${f.feature}/${f.feature}${suffix}.behavior.impl";`]));
  }
  files.push({ path: `src/app-behaviors/${vd}/index.ts`, content: [...barrel, ""].join("\n") });

  if (cfg.includeEvents === false) return files;
  // events : source:rel:target, rattaché à la feature du usecase source.
  const evByFeature = new Map<string, { module: string; feature: string; ev: { type: string; key: string; src: string; dst: string; rel: string; when?: string; payload: string }[] }>();
  for (const f of feats) for (const uc of f.ucs) {
    const outs = Object.keys(uc.output?.schema ?? {}).length ? fields(uc.output!.schema, 1) : "Record<string, unknown>";
    const seen = new Set<string>();
    const edges = [...(uc.links ?? []).map(l => ({ dst: l.usecase, rel: l.rel || "next", when: l.when })), ...(uc.calls ?? []).map(c => ({ dst: c.usecase, rel: "calls", when: c.when }))];
    for (const e of edges) {
      if (!e.dst) continue;
      const k = `${uc.id}:${e.rel}:${e.dst}`;
      if (seen.has(k)) continue;
      seen.add(k);
      const g = evByFeature.get(`${f.module}/${f.feature}`) ?? { module: f.module, feature: f.feature, ev: [] };
      g.ev.push({ type: `${kebabToPascal(uc.id)}${kebabToPascal(e.rel)}${kebabToPascal(e.dst)}Event`, key: k, src: uc.id, dst: e.dst, rel: e.rel, when: e.when, payload: outs });
      evByFeature.set(`${f.module}/${f.feature}`, g);
    }
  }
  const evs = [...evByFeature.values()];
  if (!evs.length) return files;
  for (const g of evs) {
    const L = [HEADER, "// Contrats d'événements dérivés des calls/links des usecases.", ""];
    for (const e of g.ev) {
      L.push(`export interface ${e.type} {`, `  source: ${JSON.stringify(e.src)};`, `  target: ${JSON.stringify(e.dst)};`, `  rel: ${JSON.stringify(e.rel)};`,
        ...(e.when ? [`  when?: ${JSON.stringify(e.when)};`] : []), `  payload: ${e.payload};`, "}", "");
    }
    files.push({ path: `src/app-events/${vd}/${g.module}/${g.feature}.events.ts`, content: L.join("\n") });
  }
  const all = evs.flatMap(g => g.ev.map(e => ({ ...e, g })));
  files.push({
    path: `src/app-events/${vd}/events.ts`,
    content: [HEADER, ...(docs ? [DOC_IMPORT] : []), ...evs.map(g => `import type { ${g.ev.map(e => e.type).join(", ")} } from "@/app-events/${vd}/${g.module}/${g.feature}.events";`), "",
      docs ? `export const EventName = indexDoc(${docMeta(`${app}-event-name`, "EventName", `Noms des événements de l'app ${app}.`, ["events", app], "Constant")}, {` : "export const EventName = {",
      ...all.map(e => `  ${e.type}: ${JSON.stringify(e.key)},`), docs ? "} as const);" : "} as const;", "",
      "export type EventName = (typeof EventName)[keyof typeof EventName];", "", "export interface EventMap {",
      ...all.map(e => `  [EventName.${e.type}]: ${e.type};`), "}", ""].join("\n"),
  });
  files.push({
    path: `src/app-events/${vd}/index.ts`,
    content: [HEADER, `export * from "@/app-events/${vd}/events";`, ...evs.map(g => `export * from "@/app-events/${vd}/${g.module}/${g.feature}.events";`), ""].join("\n"),
  });
  return files;
}
