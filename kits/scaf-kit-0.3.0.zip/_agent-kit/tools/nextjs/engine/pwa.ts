// PWA (serwist/turbopack) quand `pwa: true` : sw.ts, route serwist, manifest, ~offline (fichiers `preserve`, à l'équipe ensuite)
// + prérequis côté app (package.json, next.config.ts, layout [locale], proxy) en patchs idempotents.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { GeneratedFile } from "./generated-file";

export interface PwaCfg { projectName?: string; description?: string; seo?: { siteName?: string; defaultLocale?: string } }

const OFFLINE: Record<string, [string, string]> = {
  fr: ["Vous êtes hors ligne", "Vérifiez votre connexion internet puis réessayez."],
  en: ["You are offline", "Check your internet connection and try again."],
};
const ICONS = ["icon-192x192.png", "icon-512x512.png", "icon-maskable.png"];

export function generatePwa(cfg: PwaCfg): GeneratedFile[] {
  const lang = cfg.seo?.defaultLocale ?? "en";
  const name = cfg.seo?.siteName ?? cfg.projectName ?? "App";
  const [title, text] = OFFLINE[lang] ?? OFFLINE.en;
  const f = (path: string, content: string): GeneratedFile => ({ path, content, preserve: true });
  return [
    f("src/app/sw.ts", `/// <reference lib="esnext" />
/// <reference lib="webworker" />
import { defaultCache } from "@serwist/turbopack/worker";
import type { PrecacheEntry, SerwistGlobalConfig } from "serwist";
import { Serwist } from "serwist";

declare global {
  interface WorkerGlobalScope extends SerwistGlobalConfig {
    __SW_MANIFEST: (PrecacheEntry | string)[] | undefined;
  }
}

declare const self: ServiceWorkerGlobalScope;

const serwist = new Serwist({
  precacheEntries: self.__SW_MANIFEST,
  skipWaiting: true,
  clientsClaim: true,
  navigationPreload: true,
  runtimeCaching: defaultCache,
  fallbacks: { entries: [{ url: "/~offline", matcher: ({ request }) => request.destination === "document" }] },
});

serwist.addEventListeners();
`),
    f("src/app/serwist/[path]/route.ts", `import { createSerwistRoute } from "@serwist/turbopack";

const revision = crypto.randomUUID();

export const { dynamic, dynamicParams, revalidate, generateStaticParams, GET } = createSerwistRoute({
  additionalPrecacheEntries: [{ url: "/~offline", revision }],
  swSrc: "src/app/sw.ts",
  useNativeEsbuild: true,
});
`),
    f("src/app/manifest.ts", `import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: ${JSON.stringify(name)},
    short_name: ${JSON.stringify(name)},${cfg.description ? `\n    description: ${JSON.stringify(cfg.description)},` : ""}
    start_url: "/${lang}",
    display: "standalone",
    orientation: "portrait",
    background_color: "#ffffff",
    theme_color: "#000000",
    lang: ${JSON.stringify(lang)},
    icons: [
      { src: "/icons/icon-192x192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512x512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/icon-maskable.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
`),
    f("src/app/~offline/layout.tsx", `export default function OfflineLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang=${JSON.stringify(lang)}>
      <body>{children}</body>
    </html>
  );
}
`),
    f("src/app/~offline/page.tsx", `export const metadata = { title: ${JSON.stringify(title)} };

export default function OfflinePage() {
  return (
    <main style={{ maxWidth: 480, margin: "0 auto", padding: "2rem", textAlign: "center", fontFamily: "sans-serif" }}>
      <h1 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>${title}</h1>
      <p>${text}</p>
    </main>
  );
}
`),
  ];
}

// Prérequis côté app (idempotent, n'écrase rien). Ancre introuvable : on n'écrit rien et on dit quoi ajouter.
export function patchAppForPwa(root: string, dry: boolean): string[] {
  const msgs: string[] = [];
  const read = (name: string, hint: string) => {
    const p = join(root, name);
    if (existsSync(p)) return { p, src: readFileSync(p, "utf8") };
    msgs.push(`${name} absent : ${hint}`);
  };
  const save = (name: string, p: string, src: string) => {
    if (!dry) writeFileSync(p, src);
    msgs.push(`${name} complété (pwa)`);
  };
  const addImport = (src: string, line: string) => src.replace(/^import /m, `${line}\nimport `);

  const pkg = read("package.json", "ajouter @serwist/turbopack, serwist (dependencies) et esbuild (devDependencies)");
  if (pkg) {
    try {
      const j = JSON.parse(pkg.src), before = JSON.stringify(j);
      j.dependencies = { ...j.dependencies }; j.devDependencies = { ...j.devDependencies };
      j.dependencies["@serwist/turbopack"] ??= "^9.5.13";
      j.dependencies.serwist ??= "^9.5.13";
      j.devDependencies.esbuild ??= "^0.28.2";
      if (JSON.stringify(j) !== before) save("package.json", pkg.p, JSON.stringify(j, null, 2) + "\n");
    } catch { msgs.push("package.json non lisible (JSON strict requis) : ajouter @serwist/turbopack, serwist, esbuild"); }
  }

  const cfg = read("next.config.ts", "envelopper l'export par withSerwist(…) (import { withSerwist } from \"@serwist/turbopack\")");
  if (cfg && !cfg.src.includes("withSerwist")) {
    const out = cfg.src.replace(/export default ([^;]+);/, "export default withSerwist($1);");
    if (out === cfg.src) msgs.push('next.config.ts : "export default …;" introuvable : envelopper l\'export par withSerwist(…)');
    else save("next.config.ts", cfg.p, addImport(out, 'import { withSerwist } from "@serwist/turbopack";'));
  }

  const lay = read("src/app/[locale]/layout.tsx", 'envelopper le contenu de NextIntlClientProvider dans <SerwistProvider swUrl="/serwist/sw.js">');
  if (lay && !lay.src.includes("SerwistProvider")) {
    const out = lay.src.replace(/(<NextIntlClientProvider[^>]*>)/, '$1\n<SerwistProvider swUrl="/serwist/sw.js">').replace("</NextIntlClientProvider>", "</SerwistProvider>\n</NextIntlClientProvider>");
    if (!out.includes("</SerwistProvider>")) msgs.push('src/app/[locale]/layout.tsx : NextIntlClientProvider introuvable : envelopper le contenu dans <SerwistProvider swUrl="/serwist/sw.js">');
    else save("src/app/[locale]/layout.tsx", lay.p, addImport(out, 'import { SerwistProvider } from "@serwist/turbopack/react";'));
  }

  const px = read("src/proxy.ts", "exclure serwist et ~offline du matcher");
  if (px && !px.src.includes("serwist")) {
    const out = px.src.replace(/\(\?!api\|/, "(?!api|serwist|~offline|");
    if (out === px.src) msgs.push("src/proxy.ts : matcher « (?!api|… » introuvable : exclure serwist et ~offline");
    else save("src/proxy.ts", px.p, out);
  }

  // pnpm 11 refuse d'installer tant que le script de build d'esbuild n'est pas autorisé (route serwist : useNativeEsbuild).
  const ws = read("pnpm-workspace.yaml", "autoriser esbuild dans allowBuilds (esbuild: true)");
  if (ws && !/^\s+esbuild: true\s*$/m.test(ws.src)) {
    const out = /^\s+esbuild:.*$/m.test(ws.src) ? ws.src.replace(/^(\s+)esbuild:.*$/m, "$1esbuild: true")
      : /^allowBuilds:/m.test(ws.src) ? ws.src.replace(/^allowBuilds:.*$/m, "$&\n  esbuild: true") : ws.src.replace(/\n*$/, "\nallowBuilds:\n  esbuild: true\n");
    save("pnpm-workspace.yaml", ws.p, out);
  }

  const missing = ICONS.filter(i => !existsSync(join(root, "public/icons", i)));
  if (missing.length) msgs.push(`icônes PWA absentes : public/icons/{${missing.join(",")}}`);
  msgs.push("pwa : lancer `pnpm install` ; tester avec `pnpm build && pnpm start` (le service worker est inactif en dev)");
  return msgs;
}
