export interface SpecProp {
  type?: string;
  format?: string;
  enum?: string[];
  nullable?: boolean;
  properties?: Record<string, SpecProp>;
  items?: SpecProp;
  required?: string[];
  additionalProperties?: boolean | { type: string };
  description?: string;
}

export interface SpecBody {
  type: string;
  format?: string;
  nullable?: boolean;
  enum?: string[];
  required?: string[];
  properties?: Record<string, SpecProp>;
  items?: SpecProp;
  additionalProperties?: boolean | { type: string };
  description?: string;
}

export interface IndexSpec {
  endpoint?: { id?: string; name?: string; description?: string };
  http?: {
    method?: string;
    path?: string;
    auth?: { type?: string; guard?: string; description?: string };
    request?: {
      headers?: { name: string; type: string; format?: string; required?: boolean; description?: string; enum?: string[] }[];
      query?: { name: string; type: string; format?: string; required?: boolean; description?: string; enum?: string[] }[];
      body?: SpecBody;
    };
    response?: {
      status?: number;
      body?: SpecBody;
      errors?: { status: number; code: string; description?: string; cause?: string; resolution?: string }[];
    };
  };
  usecase?: { description?: string };
}

export interface MockScenario {
  name: string;
  description?: string;
  given?: Record<string, unknown>;
  expect: {
    status: number;
    body?: unknown;
  };
}

export interface ParsedEndpoint {
  app: string;
  module: string;
  feature: string;
  id: string;
  name: string;
  method: string;
  path: string;
  spec: IndexSpec;
  scenarios: MockScenario[];
  specYaml: string;
  mocksJson: string;
}

export interface SpecContext {
  endpoints: ParsedEndpoint[];
  enumMap: Map<string, string[]>;
  warnings: string[];
}
