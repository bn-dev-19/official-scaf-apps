// Socle de dossiers de base (L2+) : posé seulement si le dossier n'existe pas encore (`scaffoldDir`), jamais réécrit ensuite.
import type { GeneratedFile } from "./generated-file";
import { HEADER } from "./_lib/header";
import { COMPOSE } from "./contexts";

const EMPTY = ["app-actions", "external-modules", "app-scripts"];
const CONTEXTS: [dir: string, providers: string][] = [["ui-contexts", "UiProviders"], ["app-contexts", "AppProviders"]];

export function generateBaseFolders(): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const add = (scaffoldDir: string, rel: string, content = "") => files.push({ path: `${scaffoldDir}/${rel}`, content, scaffoldDir });
  for (const d of EMPTY) add(`src/${d}`, ".gitkeep");
  for (const [d, name] of CONTEXTS) {
    const base = `src/${d}`;
    add(base, "compose-wrappers.tsx", COMPOSE.replace(HEADER, ""));
    add(base, "contexts/.gitkeep");
    add(base, "wrappers/.gitkeep");
    add(base, "providers.tsx", `"use client";\nimport { composeWrappers } from "./compose-wrappers";\n\nexport const ${name} = composeWrappers([]);\n`);
    add(base, "index.ts", "export {};\n");
  }
  return files;
}
