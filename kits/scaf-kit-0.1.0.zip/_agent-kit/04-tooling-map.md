# 04 — Carte de l'outillage (ce que fait l'app, et l'équivalent « à la main »)

Sources : app Next.js `/Users/pc/Desktop/Tools/scaf/ui/scaf-ui` (scripts métier : `src/app-scripts/`),
backend Go `/Users/pc/Desktop/Tools/scaf/cli` (`scaf serve`, `internal/api/`, `internal/schema/`).

## Architecture en une phrase

L'UI parle au backend Go (`scaf serve --port 8080 --mode file`) qui lit/écrit les fichiers de `scaf/<version>/input/` **tels que décrits ici** ;
le backend fusionne les parts en mémoire (GET) et éclate le payload en parts (PUT/POST). Les scripts `app-scripts/` sont les règles métier
(validation, génération, normalisation) exécutées côté UI/server actions. **Ce kit remplace UI + backend** : un agent écrit directement les parts.

## Scripts `src/app-scripts/` → équivalent manuel

| Script | Ce qu'il fait | Équivalent sans l'app |
|---|---|---|
| `validate-project-format.ts` | Valide `project.parts` (§B de `03`) | `tools/audit.rb` (sous-ensemble) + relecture de §B |
| `validate-usecase-format.ts` | Valide un use case (§C) | `tools/audit.rb` + §C |
| `validate-contracts.ts` | Valide specs et mocks de chaque endpoint (§D) | `tools/audit.rb` + §D |
| `validate-response-format.ts` | Détecte/répare les enveloppes `{success,message,data}` (§E) | respecter la forme canonique à l'écriture |
| `validate-version-paths.ts` | Exige le préfixe `/api/vN/` dans `path` **et** `mock.given.path` ; détecte `{param}` dans les mocks ; réparation = `/api/x` → `/api/v1/x` et remplacement dans spec+mocks | `grep -rn "path: /api/[^v]" contracts/` ; remplacer partout (endpoint, spec, mocks) |
| `validate-single-mock.ts` | Valide un mock contre sa spec | §D (statuts, `error.code`, `message`) |
| `spec-normalize.ts` | Répare le YAML IA : quote toute valeur `clé: a: b` ; `coerceErrorDefs`, `coerceFieldDefs`, `defaultErrorMessage` | quoter les scalaires contenant `: ` |
| `mock-variant-generator.ts` | Génère les variantes de mocks (nominal/error/enum/nullable/boolean/empty/critical) à partir de la spec | suivre §F de `03` ; voir `skills/scaf-write-mocks.md` |
| `mock-coverage-calculator.ts` / `calc-coverage.ts` | Score de couverture (formule §F) | calculer la formule §F |
| `merge-error-enrich.ts` | Fusionne une spec/des mocks entrants dans l'existant (erreurs clé = `status\|code`), applique des « deltas » d'enrichissement d'erreurs (message/cause/resolution) et détecte les specs à enrichir (`needsErrorEnrichment`) | s'assurer que chaque erreur de la spec a `message` (+`cause`/`resolution`) et que chaque mock `error-*` reprend `code`+`message` exacts |
| `sync-endpoint-ids.ts` | Réécrit `spec.endpoint.id` et `mocks.endpoint` pour qu'ils égalent l'`id` du contrat | invariant A4 |
| `migrate-app-slugs.ts` | Renomme/fusionne des slugs d'app dans les contrats (mapping ancien→nouveau, slugs supprimés) et **régénère les ids d'endpoints** via `generateEndpointId` | voir `skills/scaf-add-structure.md` §Renommer |
| `unwrap-response.ts` | Extrait le payload métier d'un `AppActionResult<T>` / `ApiResponse<T>` | lire `data` |
| `generate-openapi.ts` | Specs (YAML) + mocks (JSON) → OpenAPI 3.0.3 avec `examples` (un exemple par mock, `summary` = nom du mock) | `tools/contracts_to_openapi.rb` (voir ci-dessous) |
| `openapi-to-specs-mocks.ts` | Sens inverse : OpenAPI → specs+mocks (hiérarchie déduite des **tags** `app / module / feature` et de l'`operationId`) | utile pour importer un `openapi.yml` externe : créer un tag par feature |
| `compare-openapi.ts` | Diff entre deux OpenAPI | `diff -r` de deux `openapi.parts/` |
| `generate-visual-db-from-specs.ts` | Déduit `database/visual` des **réponses** des endpoints (voir ci-dessous) | `skills/scaf-database-visual.md` |
| `compare-visuals-db.ts` | Diff de deux modèles visuels (new/modified/unchanged par table/colonne/enum) | `diff -r database/visual` |
| `generate-sql.ts`, `generate-drizzle.ts`, `generate-db-docs.ts` | Visuel → SQL (postgresql\|mysql\|sqlite), schéma Drizzle, docs Markdown | `tools/visual_to_sql.rb` (PostgreSQL uniquement : `ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> [--format sql|drizzle|docs|all]` → `output/database/schema.{sql,md} + `drizzle/` (enums.ts, un fichier par module, index.ts ; JSDoc depuis les descriptions ; `drizzle.config.ts` : `schema: "./output/database/drizzle"`)`) |
| `generate-project-markdown.ts`, `project-to-pdf.ts` | `project.parts` → Markdown / PDF lisibles | lire `project.parts` |
| `diff-project-specs.ts`, `diff-app-slugs.ts` | Diff de specs projet ; détection des changements de slug d'app | `diff -r` entre deux versions |
| `find-usecases-without-endpoint.ts` | Use cases producer sans endpoint (match `METHOD path`, repli sur slug) | `tools/audit.rb` (A6) + comparer chemins |
| `build-ai-kb.ts`, `ai-format-definitions.ts` | Construit le contexte envoyé à l'IA : formats spec/mocks (`SPEC_YAML_FORMAT`, `MOCK_JSON_FORMAT`), granularité, prompt système de génération d'endpoints | **c'est la source des formats de `02-file-formats.md` §7** |
| `template-resolver.ts` | Résolution de gabarits `{{ }}` | — |

### `check_mocks.rb` — cohérence champ par champ des mocks

`ruby scaf/_agent-kit/tools/check_mocks.rb scaf/<version> [--app <slug>] [--endpoint <id>] [--quiet]` (stdlib Ruby). Valide tous les mocks (succès, erreurs, requêtes `given`) contre leur spec : types, formats, champs présents, codes/messages d'erreur identiques à la spec, valeurs d'**enum comparées au `enum:` du champ**. Règles M1–M4 : `03-rules-and-validation.md §MK` ; procédure : `skills/scaf-check-mocks.md`. Code retour 1 s'il y a des E. Durée < 1 s.

### `intent_to_md.rb` — blocs `intent` → guide d'implémentation

Option `--check` : n'écrit rien, émet un `W GI:` par page absente, périmée, éditée à la main ou orpheline (appelé par `audit.rb`, règle GI de `03`).

`ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/<version>` (stdlib Ruby) → `scaf/<version>/output/implementation-guide/{README.md,<app>/<endpoint-id>.md}` : une page par endpoint (usecase avec `openapi`) ; sans `intent` (écart signalé par l'audit et en tête du README du guide) la page se limite à description, étapes et erreurs. Avec `intent` : pourquoi, qui, préconditions, étapes, effets, endpoints avant/pendant/après, « appelé par », notes consommateur, erreurs. Ne touche pas l'OpenAPI. Les usecases `consumer` (avec `openapi`) ne génèrent pas de page : leurs écrans/étapes/réactions d'erreur s'affichent dans la section « Côté consommateur » de la page de l'endpoint (`skills/scaf-write-consumer-usecase.md`). À relancer après toute modif d'un `intent` ou d'un usecase consumer.

### `visual_to_sql.rb` — modèle visuel → SQL, Drizzle, docs

`ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> [--format sql|drizzle|docs|all] [--out <dossier>] [--stdout]` (stdlib Ruby) → `scaf/<version>/output/database/{sql/, schema.sql, drizzle/, docs/}` (`COMMENT ON` depuis les descriptions). PostgreSQL uniquement. Valide au passage `enumRef`, FK et index (E → code retour 1). Procédure et moments de régénération : `skills/scaf-database-visual.md` §Générer.

### `contracts_to_openapi.rb` — contrats → `openapi.parts` → OpenAPI par app

`ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/<version> [--app <slug>] [--parts-only] [--parts-out <dir>] [--out <dir>] [--no-refs] [--license-url <url>]` (stdlib Ruby seulement, comme `audit.rb`).
- Étape 1 : `contracts/` → `input/openapi.parts/<app>/<module>/<feature>/<endpoint-id>.yml` (+ squelettes et `_index.yml`) ; le dossier de l'app est recréé à chaque exécution.
- Étape 2 : fusion des parts → `scaf/<version>/output/openapi/openapi.<app>.yml` (`info`, `servers` de `contracts/servers.yml`, `components.securitySchemes.BearerAuth`) puis factorisation en `$ref` (`factorize`) : `components.schemas` = `Error` / `Error<Codes>` (un par jeu de codes, sans `allOf` : Redocly rejetterait les exemples), `Pagination`, `Warnings`, sous-schémas objet identiques (≥ 3 dans l'app, nommés d'après la propriété) ; `components.parameters` = paramètres identiques (≥ 2). `parts/` et `--doc` restent en ligne. `--no-refs` désactive la factorisation.
- Le schema conserve `enum`, `format` (`date-iso` tel quel), `nullable`, `required` (champs marqués `required: true`) ; les erreurs ont un schema `{success,message,error{code,message,cause,resolution}}` ; un example par mock (`summary` = nom du mock).
- Contrôles : E si nb mocks ≠ nb examples, id ou route dupliqués, spec/mocks illisibles ; W si un mock ne respecte pas son schema (type, enum, uuid, date, null non `nullable`), erreur de mock non déclarée, `{param}` absent de `request.path`. Code retour 1 s'il y a des E.
- `--doc` : écrit en plus `scaf/<version>/output/openapi/doc/openapi.<app>.yml` dont le `description` de chaque opération est enrichi en Markdown (accès/auth, tableaux aplatis Paramètres / Corps / Réponse / Erreurs avec type, format, requis, nullable, valeurs d'enum, description, puis exemples : requête + réponse nominale, 1 réponse par code d'erreur ; listes tronquées à 1 élément). `--doc-in-place` enrichit directement `openapi.<app>.yml`. Sans ces options la sortie est inchangée.
- Règles que les contrats doivent respecter pour passer sans E/W : `03-rules-and-validation.md §OA`. Import Postman : choisir `doc/openapi.<app>.yml` ; la doc enrichie s'affiche dans le panneau « Documentation » de chaque requête (Postman n'affiche pas les schemas OpenAPI, d'où les tableaux de champs dans le `description`).
- `--license <nom> [--license-url <url>]` : `info.license` des OpenAPI générées (défaut `Proprietary`, sans url) ; satisfait la règle `info-license` de Redocly (`info-license-strict` demande en plus une `url`). `components.securitySchemes` n'est émis que si une opération l'utilise.
- **Lint Redocly** (config `scaf/redocly.yaml` : `no-server-example.com` off car `servers.yml` garde localhost/example.com ; Redocly ne lit `redocly.yaml` que dans le dossier courant, d'où `--config` depuis la racine). Cible : 0 warning.
  ```bash
  ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/v1 --license-url https://mafcv.metalafrique.it
  npx @redocly/cli lint --config scaf/redocly.yaml scaf/v1/output/openapi/openapi.*.yml
  ```
  Sans `--license-url`, `info-license-strict` avertit (x4) ; sans `--config`, 12 warnings de serveurs.
- Pour tester sans écraser : `--parts-out /tmp/parts --out /tmp/out`. Après régénération, relancer `audit.rb`.

### `generate-openapi` à la main (si besoin — préférer le script ci-dessus)

Pour chaque endpoint, écrire `openapi.parts/<app>/<module>/<feature>/<id>.yml` :
`tags: [{name: "<app> / <module> / <feature>", description: "Module <app> / <module> / <feature>"}]` ;
`paths.<path>.<method en minuscules>` avec `operationId: <id>`, `description`, `responses` (un code par `status`/`errors[].status`),
`content.application/json.schema` (converti depuis `http.response.body`) et `examples` (un par mock, clé et `summary` = nom du mock, `value` = `expect.body`).
Mettre à jour `openapi.parts/_index.yml` (apps → modules → features) et créer les squelettes `<app>/<app>.yml`, `<module>/<module>.yml`, `<feature>/<feature>.yml`.
Si l'outillage est disponible, **régénérer plutôt qu'écrire**.

### `generate-visual-db-from-specs` — règles de déduction

- Un **module** DB par module de contrat (nom = slug), un **table** par endpoint dont la réponse est modélisable (doublons de nom de table ignorés dans un module).
- Nom de table = **dernier segment non-paramètre** du chemin (après `/api/vN`), pluralisé (`y→ies`, `ch|sh|x|z→+es`, déjà en `s` inchangé, sinon `+s`) ; défaut `resources`.
- Colonnes = propriétés de l'objet de réponse (si `data` objet/tableau d'objets, ses propriétés) ; `id` ajouté en `uuid primary` s'il manque.
- Types : `array|object → jsonb` ; `boolean` ; `integer → integer` (`int64 → bigint`) ; `number → decimal` ; `string` : `uuid → uuid`, `email → varchar(255)`, `date-time → datetime`, `date → date`, `uri → text`, `phone → varchar(50)`, `password → varchar(255)`, sinon `text` ; **champ `enum` → type `enum`** + enum `<table>_<champ>`.
- `id` ou `format: uuid` ⇒ `primary: true`.
- Le résultat est un **brouillon** : renommer, ajouter FK/index/colonnes système (`created_at`, `updated_at` en `datetime NOT NULL DEFAULT NOW()`) à la main.

## Backend Go — endpoints utiles (si `scaf serve` tourne)

Routes enregistrées dans `cli/internal/api/server.go` et `handlers_v1.go` (lignes ~1765-1835). Familles :
`/api/v1/project` (+ `DELETE .../modules/{slug}`, `.../apps/{slug}`, `.../features/{featureSlug}`), `/api/v1/contracts` (+ `servers`, `variables`, `granularity`,
`import`, `apps/{app}/modules/{module}/features/{feature}/endpoints/{endpoint}`, `generate-openapi`, `generate-openapi-parts`, `openapi-parts/...`),
`/api/v1/usecases` (+ `{id}`, `config`, `validate`), `/api/v1/database/{visual,generate-sql,validate}`, `/api/v1/tickets`, `/api/v1/export-configs/{technology}`,
`/api/versions` (liste, `activate`, `fork {from,to}`, `DELETE {name}`), `/api/project/select`, `/api/isolated-nodes`.
Fichiers additionnels écrits par ces routes dans `contracts/` : `variables.yml` (`variables: [{key, value, sensitive?}]`) et
`granularity.yml` (`defaultLevel`, `levels?`, `overrides[{module, level}]`, `validation{per_module, ask_user}`) — optionnels, absents de `v1`.
Sans serveur, tout se fait par fichiers (c'est l'objet de ce kit).

## Configs d'export — `tools/export_configs.rb`

`ruby scaf/_agent-kit/tools/export_configs.rb scaf/<version> [--quiet]` (stdlib Ruby) valide `input/export-configs/` (règles EC, `03` §EC) ; `--resolve <techno> <app>` imprime la config effective d'une app (base ⊕ override, secrets masqués). Appelé par `audit.rb`. Reflète l'export scaf-ui (`export-configs/*`, `generators/nextjs/index.ts`) ; les overrides par app et `$var:` sont une convention du kit, pas encore lue par scaf-ui.

## CLI Go `scaf` (cli/)

`scaf init <name>`, `scaf run` (exécute des scénarios `.scn.yml` sur OpenAPI+usecases), `scaf validate` (scénarios), `scaf embed`,
`scaf guidelines`, `scaf project register|list|select|remove`, `scaf view-spec validate|list|explore|import`, `scaf serve`.
Le CLI valide les **scénarios** et **view-specs**, pas les contrats : pour les contrats, utiliser `tools/audit.rb` + §D.
Skill existant pour les scénarios : `/Users/pc/Desktop/Tools/scaf/cli/skills/scenario-generation-skill.md`.
