---
name: scaf-database-visual
description: Créer ou modifier le modèle de données SCAF (database/visual/_visual_<module>.yml et _visual_enums.yml) à partir des endpoints et des use cases, avec types, clés, index et enums cohérents. À utiliser pour toute nouvelle entité ou colonne.
---

# Modéliser la base de données (visual)

Formats : `../02-file-formats.md §8-9` · déduction automatique : `../04-tooling-map.md` (« generate-visual-db-from-specs »).

## Où et comment

- Un fichier par **module de contrat** : `database/visual/_visual_<module-slug>.yml` (`name:` = slug du module).
- Un seul fichier d'enums : `database/visual/_visual_enums.yml`.
- Le backend, à l'enregistrement, **supprime tous les `_visual*`** puis réécrit un fichier par module ⇒ le nom de fichier doit rester `_visual_<name>.yml`.

## Procédure

1. **Inventaire** : pour chaque endpoint du module, lire `http.response.body.properties.data` et `http.request.body` ; pour chaque use case, `input/output.schema`.
   Regrouper par **entité métier** (pas par endpoint) : plusieurs endpoints lisent/écrivent souvent la même table.
2. **Brouillon automatique (règles de l'app)** : table = dernier segment non-paramètre du chemin, pluralisé ; colonnes = propriétés de la réponse ;
   `id uuid primary` ajouté si absent ; `array|object → jsonb`. C'est un point de départ — **relire et corriger**.
3. **Écrire la table** :
   ```yaml
   - name: <table_pluriel_snake>
     description: <ce que la table stocke, français>
     columns:
       - { name: id, type: uuid, nullable: false, primary: true, description: Identifiant unique. }
       - { name: <fk>_id, type: uuid, nullable: false, references: { table: <autre_table>, column: id }, description: ... }
       - { name: <champ>, type: varchar(255), nullable: false, description: ... }
       - { name: <statut>, type: enum, nullable: false, enumRef: <table>_<statut>, description: ... }
       - { name: payload, type: jsonb, nullable: false, default: '''{}''::jsonb', description: ... }
       - { name: created_at, type: datetime, nullable: false, default: NOW(), description: ... }
       - { name: updated_at, type: datetime, nullable: false, default: NOW(), description: ... }
     indexes:
       - { name: idx_<table>_<colonne>, columns: [<colonne>], unique: false }
   ```
4. **Types autorisés** : `uuid text varchar(n) integer bigint decimal boolean datetime date jsonb enum`.
   Correspondances : spec `uuid→uuid`, `email→varchar(255)`, `password→varchar(255)` (stocker un hash), `uri→text`, `date-iso/date-time→datetime`, `integer→integer`, `number→decimal`, `boolean→boolean`, `array|object→jsonb`.
5. **Colonnes système** : `created_at`/`updated_at` (`datetime`, `NOT NULL`, `default: NOW()`) sur toute table modifiable.
6. **Clés** : `primary: true` sur la/les colonnes de clé (plusieurs ⇒ composite) ; `references` pour chaque clé étrangère (la table cible doit exister, éventuellement dans un autre module).
7. **Index** : un index par colonne de filtre/tri fréquent (statuts, FK, email) ; `unique: true` pour les unicités métier (`email`).
8. **Enums** : pour chaque colonne `type: enum`, ajouter dans `_visual_enums.yml` :
   ```yaml
   - name: <table>_<colonne>
     description: ...
     values:
       - { value: <VALEUR_EXACTE_DE_LA_SPEC>, description: ... }
   ```
   Les valeurs **reprennent exactement** l'`enum:` de la spec (MAJUSCULES) ; si la spec change, mettre à jour les deux.
9. **Cohérence données ↔ API** : chaque champ de réponse persistant a une colonne ; types/nullabilité alignés (`nullable: true` dans la spec ⇒ `nullable: true` en base) ;
   les secrets (mot de passe, jetons) ne sortent jamais dans une réponse mais ont une colonne hashée.
10. Vérifier : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` (règles DB : enumRef existant, index sur colonnes existantes, tables uniques par module), puis **régénérer** SQL/Drizzle/docs (§ ci-dessous).

## Générer SQL / Drizzle / docs (à chaque modification du modèle)

Outil : [`../tools/visual_to_sql.rb`](../tools/visual_to_sql.rb) (Ruby stdlib, PostgreSQL/Neon). Entrée = `_visual_*.yml` + `_visual_enums.yml`.

```bash
ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version>                      # tout : sql + drizzle + docs
ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> --format drizzle     # sql | drizzle | docs | all
ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version> --format sql --stdout  # un seul fichier, sur la sortie standard (sql uniquement)
```

Sortie (dérivée, **ne jamais éditer**) dans `scaf/<version>/output/database/` :

| Fichier | Contenu |
|---|---|
| `sql/00_enums.sql`, `sql/10_<module>.sql`, `sql/99_foreign_keys.sql` | SQL partitionné : `CREATE TYPE` → tables du module (`CREATE TABLE`, `COMMENT ON TABLE/COLUMN` depuis les `description`, `CREATE INDEX`) → toutes les FK en dernier. Appliquer : `psql -f sql/*.sql` (ordre lexical) |
| `schema.sql` | Concaténation de `sql/*.sql` dans l'ordre : une seule commande `psql -f schema.sql` |
| `drizzle/enums.ts`, `drizzle/<module>.ts`, `drizzle/index.ts` | Schéma Drizzle pg-core, un fichier par module, JSDoc depuis les `description` ; `drizzle.config.ts` : `schema: './output/database/drizzle'` |
| `docs/README.md`, `docs/<module>.md`, `docs/enums.md` | Doc Markdown partitionnée : index (tables par module, modules référencés), un fichier par module (tables, colonnes, index ; FK et enums en liens cliquables), enums avec « utilisé par » |

**Quand régénérer** (obligatoire, dans la même tâche) :
- après toute modification de `database/visual/` (table, colonne, index, enum) ;
- après un changement de contrat qui touche un champ persistant (réponse/requête d'endpoint, enum de spec) : **d'abord** mettre à jour le visuel (étape 9), **ensuite** régénérer ;
- sur demande (« génère la base / le SQL / le Drizzle / la doc DB »).

**Lecture du résultat** : code 1 + lignes `E` = `enumRef` inconnu, FK vers table/colonne inexistante, index sur colonne inexistante, type inconnu → corriger le **visuel**, pas la sortie. Ensuite `audit.rb`.
Limites : PostgreSQL uniquement ; `decimal` → `NUMERIC(18, 2)` (le visuel n'a pas de précision) ; clés Drizzle en snake_case. Le SQL n'est pas testé par l'outil : l'appliquer sur une branche jetable avant migration.
