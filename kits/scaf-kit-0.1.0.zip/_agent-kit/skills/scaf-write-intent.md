---
name: scaf-write-intent
description: Renseigner le bloc `intent` d'un usecase producer (pourquoi l'endpoint existe, qui l'appelle, préconditions, effets, endpoints liés, notes consommateur) à partir de la compréhension du projet, valider les intentions incertaines auprès de l'utilisateur, puis régénérer output/implementation-guide/. À utiliser pour donner à un agent d'implémentation le contexte métier d'un endpoint, ou pour combler les « Intent à renseigner » du guide.
---

# Renseigner les `intent` et générer le guide d'implémentation

Format : `../02-file-formats.md §5` (bloc `intent`) · règles : `../03-rules-and-validation.md §C` · outil : `../tools/intent_to_md.rb`.

## Principe
`steps` dit **comment** implémenter ; `intent` dit **pourquoi** l'endpoint existe, **qui** peut l'appeler, **ce qu'il doit garantir** et **comment il s'enchaîne** avec les autres.
Un agent qui implémente le producteur doit pouvoir lire la page de l'endpoint et comprendre son rôle dans tout le projet.
Les rôles sont `producer` (fournit) → `consumer` (appelle) ; ne pas lire « backend/frontend » littéralement.

## Procédure
1. **Comprendre avant d'écrire** (dans cet ordre, sans deviner) : `project.parts/info.yml`, `actors.yml`, le module et la feature de l'endpoint
   (`project.parts/modules/<app>.<module>.yml`), les `journeys/` qui citent l'endpoint (`grep -l "<endpoint-id>" journeys/*`), `constraints.yml`,
   `enums.yml` (états), `database/visual/` (tables touchées), puis le contrat et le usecase. Les journeys donnent déjà `needs`/`produces` → source directe de `preconditions`, `effects` et `depends_on`.
2. **Rédiger par lot cohérent** (un module ou une feature à la fois, jamais les 200 d'un coup) :
   - `purpose` : la raison d'être métier, pas une paraphrase de `description` ;
   - `actors` : ids de `actors.yml` réellement autorisés (déduits de l'app, des gardes `verify_*`/`check_session` des steps et des journeys) ;
   - `preconditions` : états/droits requis (valeurs d'`enums.yml`) ; `effects` : changements d'état, écritures, notifications, séquestres ;
   - `depends_on` : endpoints appelés avant/pendant/après, avec `why` ; uniquement des ids existants ;
   - `consumer_notes` : usage conseillé et impact côté consommateur.
3. **Valider les intentions incertaines — ne pas inventer.** Poser les questions avec `AskUserQuestion` (groupées, 1 à 4 par appel, options concrètes + recommandation) quand :
   - plusieurs acteurs plausibles pour une même action (ex. admin seul ou support-agent aussi) ;
   - une règle métier n'est écrite nulle part (délais, montants, qui rembourse, quand une suppression est refusée) ;
   - l'ordre ou la dépendance entre endpoints est ambigu ; ou un effet de bord (notification, journal, séquestre) n'est pas confirmé.
   Ne pas demander ce qu'on peut vérifier dans les fichiers. Les réponses reçues deviennent des faits dans l'`intent` (et, si elles changent le contrat, dans la spec/enums : ne pas laisser les deux diverger).
4. **Écrire** le bloc `intent:` à la fin du fichier `usecases/producer/<app>/<id>.usecase.yml` (guillemets si une valeur contient `: `).
   Format : texte ≤ 100 caractères sur une ligne entre guillemets JSON ; au-delà, scalaire replié `>-` coupé à ~90 caractères (voir `02-file-formats.md` §5).
5. **Régénérer et vérifier** :
   ```
   ruby scaf/_agent-kit/tools/audit.rb scaf/<version>          # 0 E attendu (acteurs, depends_on, purpose)
   ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/<version>   # → output/implementation-guide/{README.md,<app>/<endpoint-id>.md}
   ```
   Le README du guide indique la progression (✦ = intent renseigné, `N / total`). Relire une page générée avant de rendre la main.

## Génération (`intent_to_md.rb`)
- Une page par endpoint (usecase avec `openapi.operationId`) ; l'app vient des **contrats** (`contracts/apps/<app>/…`), pas du dossier du usecase (qui doit toutefois lui être égal : règle C).
- Sans `intent` : page dégradée (description, étapes, erreurs, mention « Intent à renseigner »). Avec `intent` : pourquoi, qui, préconditions, étapes, effets, endpoints avant/pendant/après, « Appelé par » (calculé à l'envers depuis `depends_on`), notes consommateur, erreurs.
- Dérivé : ne jamais éditer `output/implementation-guide/`. N'altère pas l'OpenAPI. Régénérer après toute modif d'`intent`, de `steps` ou d'`errors`.

## Pièges
- `depends_on` ne décrit pas un enchaînement UI vague : n'y mettre que des appels nécessaires à produire/consommer la réponse.
- Ne pas dupliquer `description`/`steps` dans `intent` ; ne pas remplir en masse avec du texte générique (l'audit ne détecte pas la qualité).
- Un `intent` sur un usecase `consumer`/`shared` n'apparaît pas dans le guide (pas de `openapi`) mais reste validé.
