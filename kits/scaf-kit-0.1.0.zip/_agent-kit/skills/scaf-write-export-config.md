---
name: scaf-write-export-config
description: Écrire ou modifier la config de génération de l'app cible d'un projet SCAF (export-configs/nextjs.json, override par app nextjs.<app>.json, secrets via $var: dans variables.yml) et la valider avec tools/export_configs.rb. À utiliser quand on change une option Next.js (auth, i18n, pwa, seo…), qu'une app doit différer d'une autre, ou qu'un secret apparaît dans la config.
---

# Écrire une config d'export

Format : `../02-file-formats.md §11` · règles : `../03-rules-and-validation.md §EC` · outil : `../tools/export_configs.rb`.

## Principe
`nextjs.json` = valeurs **communes** à toutes les apps. Ce qui diffère pour une app (ex. back-office sans PWA ni push) va dans `nextjs.<app>.json` : un patch partiel, pas une copie. `projectName`, description, tagline, `seo.siteName/baseUrl` viennent de `project.parts/apps/<app>.yml`, pas de la config.

## Procédure
1. Option commune → `nextjs.json`. Option propre à une app → `nextjs.<slug>.json` (`{technology, app, config:{…seulement les clés qui changent…}}`).
2. Secret ou clé générée (VAPID…) : jamais en clair. L'ajouter à `contracts/variables.yml` (`sensitive: true` pour une clé privée) et écrire `"$var:NOM"` dans la config.
3. `customFontPath` : chemin relatif au dépôt (`_ui-kits/…`), jamais absolu.
4. Vérifier : `ruby scaf/_agent-kit/tools/export_configs.rb scaf/<v>` puis `--resolve nextjs <app>` pour lire le résultat fusionné ; enfin `audit.rb`.

## Pièges
Un tableau dans un override **remplace** celui de la base (pas de concaténation) · `pushNotifications.enabled: true` exige `pwa: true` dans la config **effective** · scaf-ui ne lit pas encore les overrides ni `$var:` : ne pas les attendre de son export tel quel · NestJS : pas encore géré.
