#!/usr/bin/env ruby
# Modèle visuel -> SQL PostgreSQL (Neon), schéma Drizzle (pg-core), doc Markdown.
#   database/visual/_visual_enums.yml + _visual_<module>.yml  ==>  <out>/schema.sql | drizzle/{enums,<module>,index}.ts | docs/{README,<module>,enums}.md
# SQL : sql/00_enums.sql -> sql/10_<module>.sql (tables, COMMENT ON, index) -> sql/99_foreign_keys.sql ; schema.sql = concaténation.
# Usage : ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/v0 [--format sql|drizzle|docs|all] [--out <dossier>] [--stdout]
#   défaut : --format all, --out scaf/<version>/output/database. --stdout : sql uniquement (schema.sql).
# Formats : ../02-file-formats.md §8-9. Code retour 1 s'il y a des E (enumRef/table/colonne inconnus).
require 'yaml'
require 'fileutils'

root = ARGV[0] or abort 'usage: visual_to_sql.rb <scaf/vN> [--format sql|drizzle|docs|all] [--out dossier] [--stdout]'
opt = ->(name) { i = ARGV.index(name); i && ARGV[i + 1] }
dir = File.join(root, 'input', 'database', 'visual')
abort "introuvable: #{dir}" unless Dir.exist?(dir)
out = opt.('--out') || File.join(root, 'output', 'database')
format = opt.('--format') || 'all'
abort "format inconnu: #{format}" unless %w[sql drizzle docs all].include?(format)

E = []
load_yml = ->(f) { YAML.safe_load(File.read(f)) || {} }
enums = (load_yml.(File.join(dir, '_visual_enums.yml'))['enums'] || [])
tables = Dir[File.join(dir, '_visual_*.yml')].sort.reject { |f| f.end_with?('_visual_enums.yml') }
                                            .flat_map { |f| m = load_yml.(f); (m['tables'] || []).map { |t| t.merge('_file' => File.basename(f), '_module' => m['name'], '_mdesc' => m['description']) } }

enum_names = enums.map { |e| e['name'] }
cols_of = tables.to_h { |t| [t['name'], t['columns'].map { |c| c['name'] }] }
E << "E tables en double : #{tables.map { |t| t['name'] }.group_by { |n| n }.select { |_, v| v.size > 1 }.keys.join(', ')}" if cols_of.size != tables.size

# decimal sans précision dans le visuel : NUMERIC(18,2) (ponytail: monnaie XOF/EUR ; ajouter decimal(p,s) au visuel si besoin)
def sql_type(c)
  case c['type']
  when 'datetime' then 'TIMESTAMPTZ'
  when 'decimal' then 'NUMERIC(18, 2)'
  when 'enum' then c['enumRef']
  else c['type'].upcase.sub('DECIMAL', 'NUMERIC')
  end
end

# NOW(), nombres, booléens, littéraux déjà quotés ('...'::jsonb) : tels quels ; mot nu (XOF, PENDING) : quoté.
def sql_default(v)
  s = v.to_s
  return s if s =~ /\A(NOW\(\)|-?\d+(\.\d+)?|true|false|NULL|'.*)\z/m
  "'#{s.gsub("'", "''")}'"
end

# ── SQL : sql/00_enums.sql, sql/10_<module>.sql (tables + COMMENT ON + index), sql/99_foreign_keys.sql ──
# Préfixes numériques : `psql -f sql/*.sql` applique dans le bon ordre ; les FK en dernier évitent tout cycle entre modules.
SQL_BANNER = "-- Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n"
sq = ->(s) { "'#{s.to_s.gsub("'", "''").gsub(/\s*\n\s*/, ' ').strip}'" }   # littéral SQL (COMMENT ON)
dash = ->(s) { s.to_s.gsub(/\s*\n\s*/, ' ').strip }                         # commentaire `--` sur une ligne

sql_files = {}
sql_files['sql/00_enums.sql'] = SQL_BANNER + "\n" + enums.map do |e|
  "-- #{e['name']} : #{dash.(e['description'])}\nCREATE TYPE #{e['name']} AS ENUM (#{e['values'].map { |v| "'#{v['value']}'" }.join(', ')});\n" \
  "COMMENT ON TYPE #{e['name']} IS #{sq.(e['description'])};\n"
end.join("\n")

tables.group_by { |t| t['_module'] }.each do |m, ts|
  out_t = ts.map do |t|
    where = "#{t['_file']}:#{t['name']}"
    pk = t['columns'].select { |c| c['primary'] }.map { |c| c['name'] }
    defs = t['columns'].map do |c|
      E << "E #{where}.#{c['name']} : enumRef inconnu (#{c['enumRef'].inspect})" if c['type'] == 'enum' && !enum_names.include?(c['enumRef'])
      d = "  #{c['name']} #{sql_type(c)}"
      d += ' NOT NULL' unless c['nullable'] || (c['primary'] && pk.size == 1)
      d += ' PRIMARY KEY' if c['primary'] && pk.size == 1
      if c['default'].nil? && c['primary'] && c['type'] == 'uuid' then d += ' DEFAULT gen_random_uuid()'
      elsif !c['default'].nil? then d += " DEFAULT #{sql_default(c['default'])}"
      end
      d
    end
    defs << "  PRIMARY KEY (#{pk.join(', ')})" if pk.size > 1
    idx = (t['indexes'] || []).map do |i|
      (i['columns'] - cols_of[t['name']]).each { |c| E << "E #{t['name']}.#{i['name']} : colonne inconnue #{c}" }
      "CREATE #{'UNIQUE ' if i['unique']}INDEX #{i['name']} ON #{t['name']} (#{i['columns'].join(', ')});"
    end
    cm = ["COMMENT ON TABLE #{t['name']} IS #{sq.(t['description'])};"] +
         t['columns'].map { |c| "COMMENT ON COLUMN #{t['name']}.#{c['name']} IS #{sq.(c['description'])};" }
    "-- #{t['name']} : #{dash.(t['description'])}\nCREATE TABLE #{t['name']} (\n#{defs.join(",\n")}\n);\n#{cm.join("\n")}\n#{idx.join("\n")}#{"\n" unless idx.empty?}"
  end.join("\n")
  sql_files["sql/10_#{m}.sql"] = SQL_BANNER + "\n-- Module #{m} : #{dash.(ts.first['_mdesc'])}\n\n" + out_t
end

fks = tables.flat_map do |t|
  t['columns'].select { |c| c['references'] }.map do |c|
    r = c['references']
    E << "E #{t['name']}.#{c['name']} : référence inconnue #{r['table']}.#{r['column']}" unless cols_of[r['table']]&.include?(r['column'])
    "ALTER TABLE #{t['name']} ADD CONSTRAINT fk_#{t['name']}_#{c['name']} FOREIGN KEY (#{c['name']}) REFERENCES #{r['table']} (#{r['column']});"
  end
end
sql_files['sql/99_foreign_keys.sql'] = SQL_BANNER + "\n" + fks.join("\n") + "\n"
sql_all = sql_files.sort.map(&:last).join("\n")   # schema.sql = concaténation dans l'ordre lexical (00 < 10 < 99)

# ── Drizzle (pg-core) : drizzle/enums.ts + drizzle/<module>.ts + drizzle/index.ts ──
# ponytail: clés de colonnes en snake_case (= noms SQL) ; camelCase si le code applicatif le demande.
camel = ->(n) { n.split('_').each_with_index.map { |w, i| i.zero? ? w : w.capitalize }.join }
jsdoc = ->(s, ind = '') { "#{ind}/** #{s.to_s.gsub('*/', '* /').gsub(/\s*\n\s*/, ' ').strip} */" }
BANNER = "// Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n"
PG_CORE = %w[pgTable pgEnum uuid varchar text integer bigint boolean timestamp date numeric jsonb primaryKey index uniqueIndex].freeze
file_of = ->(t) { t['_module'] }
head = lambda do |body, enum_file_needed, others|
  used = PG_CORE.select { |n| body.match?(/\b#{n}\(/) }
  h = [BANNER, "import { #{used.join(', ')}#{body.include?('AnyPgColumn') ? ', type AnyPgColumn' : ''} } from 'drizzle-orm/pg-core';"]
  ens = enum_file_needed.select { |n| body.include?("#{n}(") }
  h << "import { #{ens.join(', ')} } from './enums';" unless ens.empty?
  others.each { |m, ns| h << "import { #{ns.uniq.sort.join(', ')} } from './#{m}';" }
  h.join("\n") + "\n\n"
end
drizzle = lambda do
  files = {}
  enum_consts = enums.map { |e| "#{camel.(e['name'])}Enum" }
  body = enums.map do |e|
    vals = e['values'].map { |v| " * - #{v['value']} : #{v['description'].to_s.gsub('*/', '* /').gsub(/\s*\n\s*/, ' ')}" }
    "/**\n * #{e['description'].to_s.gsub('*/', '* /').gsub(/\s*\n\s*/, ' ')}\n#{vals.join("\n")}\n */\nexport const #{camel.(e['name'])}Enum = pgEnum('#{e['name']}', [#{e['values'].map { |v| "'#{v['value']}'" }.join(', ')}]);"
  end.join("\n\n")
  files['enums.ts'] = head.(body, [], {}) + body + "\n"
  mods = tables.group_by { |t| file_of.(t) }
  mods.each do |m, ts|
    others = Hash.new { |h, k| h[k] = [] }
    out_t = ts.map do |t|
      pk = t['columns'].select { |c| c['primary'] }.map { |c| c['name'] }
      cols = t['columns'].map do |c|
        n = c['name']
        d = case c['type']
            when 'uuid' then "uuid('#{n}')"
            when 'text' then "text('#{n}')"
            when 'integer' then "integer('#{n}')"
            when 'bigint' then "bigint('#{n}', { mode: 'number' })"
            when 'boolean' then "boolean('#{n}')"
            when 'datetime' then "timestamp('#{n}', { withTimezone: true })"
            when 'date' then "date('#{n}')"
            when 'decimal' then "numeric('#{n}', { precision: 18, scale: 2 })"
            when 'jsonb' then "jsonb('#{n}')"
            when 'enum' then "#{camel.(c['enumRef'])}Enum('#{n}')"
            when /\Avarchar\((\d+)\)\z/ then "varchar('#{n}', { length: #{$1} })"
            else (E << "E #{t['name']}.#{n} : type inconnu #{c['type']}"; "text('#{n}')")
            end
        d += '.notNull()' unless c['nullable'] || (c['primary'] && pk.size == 1)
        d += '.primaryKey()' if c['primary'] && pk.size == 1
        v = c['default']
        if v.nil? then d += '.defaultRandom()' if c['primary'] && c['type'] == 'uuid'
        else
          s = v.to_s
          d += if s == 'NOW()' then '.defaultNow()'
               elsif c['type'] == 'jsonb' then ".default(#{s[/\A'(.*)'(::jsonb)?\z/m, 1] || s})"
               elsif c['type'] == 'decimal' || s !~ /\A(-?\d+(\.\d+)?|true|false)\z/ then ".default('#{s.gsub("'", "\\\\\\\\'")}')"
               else ".default(#{s})"
               end
        end
        if (r = c['references'])
          tm = tables.find { |x| x['name'] == r['table'] }&.fetch('_module', nil)
          others[tm] << camel.(r['table']) if tm && tm != m
          d += ".references((): AnyPgColumn => #{camel.(r['table'])}.#{r['column']})"
        end
        "#{jsdoc.(c['description'], '  ')}\n  #{n}: #{d},"
      end
      extra = []
      extra << "primaryKey({ columns: [#{pk.map { |c| "t.#{c}" }.join(', ')}] })" if pk.size > 1
      (t['indexes'] || []).each { |i| extra << "#{i['unique'] ? 'uniqueIndex' : 'index'}('#{i['name']}').on(#{i['columns'].map { |c| "t.#{c}" }.join(', ')})" }
      "#{jsdoc.(t['description'])}\nexport const #{camel.(t['name'])} = pgTable('#{t['name']}', {\n#{cols.join("\n")}\n#{extra.empty? ? '});' : "}, (t) => [#{extra.join(', ')}]);"}"
    end.join("\n\n")
    files["#{m}.ts"] = head.(out_t, enum_consts, others) + out_t + "\n"
  end
  files['index.ts'] = BANNER + "\n" + (['enums'] + mods.keys).map { |m| "export * from './#{m}';" }.join("\n") + "\n"
  files
end

# ── Doc Markdown : docs/README.md (index) + docs/<module>.md + docs/enums.md, liens FK/enum cliquables ──
MD_BANNER = "<!-- Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main. -->\n\n"
docs = lambda do
  cell = ->(x) { x.to_s.gsub('|', '\\|').gsub("\n", ' ') }
  mod_of = tables.to_h { |t| [t['name'], t['_module']] }
  mods = tables.group_by { |t| t['_module'] }
  files = {}
  mods.each do |m, ts|
    l = [MD_BANNER + "# Module #{m}", '', ts.first['_mdesc'].to_s, '', '[← Index](README.md)', '']
    ts.each do |t|
      l << "### #{t['name']}" << '' << t['description'].to_s << '' << '| Colonne | Type | Null | Défaut | Réf. | Description |' << '|---|---|---|---|---|---|'
      t['columns'].each do |c|
        ty = c['type'] == 'enum' ? "[enum `#{c['enumRef']}`](enums.md##{c['enumRef']})" : c['type']
        r = c['references']
        ref = r ? "[#{r['table']}.#{r['column']}](#{mod_of[r['table']] == m ? '' : "#{mod_of[r['table']]}.md"}##{r['table']})" : ''
        l << "| #{c['name']}#{' 🔑' if c['primary']} | #{ty} | #{c['nullable'] ? 'oui' : 'non'} | #{cell.(c['default'])} | #{ref} | #{cell.(c['description'])} |"
      end
      l << ''
      unless (t['indexes'] || []).empty?
        l << '**Index :**' << ''
        t['indexes'].each { |i| l << "- `#{i['name']}` (#{i['columns'].join(', ')})#{' — unique' if i['unique']}" }
        l << ''
      end
    end
    files["docs/#{m}.md"] = l.join("\n")
  end
  users = Hash.new { |h, k| h[k] = [] }
  tables.each { |t| t['columns'].each { |c| users[c['enumRef']] << "#{t['name']}.#{c['name']}" if c['type'] == 'enum' } }
  l = [MD_BANNER + '# Enums', '', '[← Index](README.md)', '']
  enums.each do |e|
    l << "### #{e['name']}" << '' << e['description'].to_s << ''
    e['values'].each { |v| l << "- `#{v['value']}` — #{v['description']}" }
    l << '' << "Utilisé par : #{users[e['name']].map { |u| "`#{u}`" }.join(', ')}" << ''
  end
  files['docs/enums.md'] = l.join("\n")
  deps = tables.flat_map { |t| t['columns'].map { |c| (r = c['references']) && mod_of[r['table']] != t['_module'] ? [t['_module'], mod_of[r['table']]] : nil }.compact }.uniq
  l = [MD_BANNER + '# Modèle de données', '', "#{tables.size} tables · #{enums.size} enums · [Enums](enums.md)", '']
  mods.each do |m, ts|
    l << "## [#{m}](#{m}.md)" << '' << ts.first['_mdesc'].to_s << ''
    ts.each { |t| l << "- [`#{t['name']}`](#{m}.md##{t['name']}) — #{t['description'].to_s.gsub(/\s*\n\s*/, ' ')}" }
    d = deps.select { |x, _| x == m }.map(&:last).uniq.sort
    l << '' << "Références : #{d.map { |x| "[#{x}](#{x}.md)" }.join(', ')}" unless d.empty?
    l << ''
  end
  files['docs/README.md'] = l.join("\n")
  files
end

gens = {
  'sql' => -> { sql_files.merge('schema.sql' => sql_all).transform_values { |v| -> { v } } },
  'drizzle' => -> { drizzle.call.transform_keys { |k| "drizzle/#{k}" }.transform_values { |v| -> { v } } },
  'docs' => -> { docs.call.transform_values { |v| -> { v + "\n" } } }
}
todo = format == 'all' ? gens.keys : [format]
files = todo.flat_map { |f| g = gens[f]; (g.is_a?(Proc) ? g.call : g).to_a }.to_h
if ARGV.include?('--stdout')
  abort 'E --stdout : sql uniquement' unless files.key?('schema.sql')
  puts files.fetch('schema.sql', files.values.first).call
else
  %w[sql drizzle docs].each { |d| FileUtils.rm_rf(File.join(out, d)) if todo.include?(d) }   # pas de fichier orphelin d'un module supprimé
  files.each { |k, v| path = File.join(out, k); FileUtils.mkdir_p(File.dirname(path)); File.write(path, v.call) }
  puts "#{enums.size} enums, #{tables.size} tables, #{tables.sum { |t| t['columns'].size }} colonnes -> #{out} (#{files.size} fichiers)"
end
E.each { |m| warn m }
exit(E.empty? ? 0 : 1)
