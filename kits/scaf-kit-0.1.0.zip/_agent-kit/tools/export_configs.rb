#!/usr/bin/env ruby
# Validation des configs d'export (génération de l'app cible) : base <techno>.json + overrides par app <techno>.<app>.json.
# Usage : ruby scaf/_agent-kit/tools/export_configs.rb scaf/v1 [--quiet]
#         ruby scaf/_agent-kit/tools/export_configs.rb scaf/v1 --resolve <techno> <app>   # config effective (secrets masqués)
# --quiet : une ligne E/W par écart (utilisé par audit.rb). Format : ../02-file-formats.md §11 · règles : ../03-rules-and-validation.md §EC.
# Code retour 1 s'il y a des E. Seul nextjs est connu pour l'instant (nestjs : à ajouter dans TECHS).
require 'yaml'
require 'json'

root = ARGV[0] or abort 'usage: export_configs.rb <scaf/vN> [--quiet | --resolve <techno> <app>]'
quiet = ARGV.include?('--quiet')
inp = File.join(root, 'input'); dir = File.join(inp, 'export-configs')
abort "introuvable: #{inp}" unless Dir.exist?(inp)
exit 0 unless Dir.exist?(dir)

# ── schéma Next.js (miroir de scaf-ui : src/app-shared/export/types.ts) ──
ENUMS = {
  'styling' => %w[tailwind_shadcn css_modules styled_components chakra_ui],
  'theme' => %w[light dark system],
  'font' => %w[geist inter poppins custom],
  'architecture' => %w[mvvm mvc clean_architecture],
  'apiLayer' => %w[server_actions route_handlers trpc graphql],
  'orm' => %w[prisma drizzle typeorm mongoose none],
  'database' => %w[postgresql mysql sqlite mongodb none],
  'auth' => %w[nextauth_v5 clerk supabase custom_jwt none],
  'stateManagement' => %w[zustand jotai redux_toolkit tanstack none],
  'httpClient' => %w[ky axios fetch],
  'logger' => %w[pino winston none],
  'packageManager' => %w[pnpm npm yarn bun],
  'targetOs' => %w[mac_linux windows],
  'errorMonitoring' => %w[sentry logrocket none],
  'analytics' => %w[vercel plausible none],
  'agentsFilename' => %w[AGENTS.md AI_GUIDE.md README-IA.md]
}.freeze
BOOLS = %w[i18n pwa rateLimiting srcDir eslintInBuild imagesUnoptimized reactStrictMode nextDevToolsMcp docsTool].freeze
ARRAYS = %w[oauthProviders i18nLanguages allowedImageDomains allowedDevOrigins].freeze
STRINGS = %w[projectName description shadcnPreset customFontPath importAlias bodySizeLimit tagline principe].freeze
OBJECTS = %w[seo pushNotifications agentLoop behaviors].freeze
REQUIRED = (%w[projectName seo packageManager architecture auth apiLayer styling] ).freeze
KNOWN = (ENUMS.keys + BOOLS + ARRAYS + STRINGS + OBJECTS + %w[version]).freeze
TECHS = { 'nextjs' => 1 }.freeze
SECRETS = [%w[pushNotifications vapidPrivateKey], %w[pushNotifications vapidPublicKey]].freeze
VAR = /\A\$var:([A-Za-z0-9_]+)\z/

E = []; W = []
add = ->(sev, rule, msg) { (sev == 'E' ? E : W) << "#{sev} #{rule}: #{msg}" }

load_json = lambda do |f|
  JSON.parse(File.read(f))
rescue JSON::ParserError => e
  add.('E', 'EC0', "#{File.basename(f)}: JSON invalide (#{e.message[0, 60]})"); nil
end

deep = lambda do |a, b|
  next b unless a.is_a?(Hash) && b.is_a?(Hash)
  a.merge(b) { |_, x, y| deep.(x, y) }
end

pi = YAML.safe_load(File.read(File.join(inp, 'project.parts', '_index.yml'))) || {}
apps = (pi['apps'] || []).map { |a| a['slug'] }
vf = File.join(inp, 'contracts', 'variables.yml')
vars = File.exist?(vf) ? ((YAML.safe_load(File.read(vf)) || {})['variables'] || []) : []
varkeys = vars.map { |v| v['key'] }

# ── lecture : base par techno, overrides par (techno, app) ──
bases = {}; overrides = {}
Dir.children(dir).sort.grep(/\.json\z/).each do |fn|
  name = fn.sub(/\.json\z/, ''); tech, app = name.split('.', 2)
  unless TECHS.key?(tech)
    add.('E', 'EC0', "#{fn}: technologie inconnue (#{TECHS.keys.join(', ')})"); next
  end
  d = load_json.(File.join(dir, fn)) or next
  add.('E', 'EC0', "#{fn}: technology doit valoir #{tech}") unless d['technology'] == tech
  add.('E', 'EC0', "#{fn}: config doit être un objet") unless d['config'].is_a?(Hash)
  next unless d['config'].is_a?(Hash)
  if app
    add.('E', 'EC3', "#{fn}: app #{app} absente de project.parts") unless apps.include?(app)
    add.('E', 'EC3', "#{fn}: champ app doit valoir #{app}") unless d['app'] == app
    add.('E', 'EC3', "#{fn}: projectName n'est pas surchargeable (= slug de l'app)") if d['config'].key?('projectName')
    (d['config'].keys - KNOWN).each { |k| add.('E', 'EC3', "#{fn}: clé inconnue #{k}") }
    overrides[[tech, app]] = d['config']
  else
    bases[tech] = d['config']
  end
end
overrides.each_key { |t, a| add.('E', 'EC3', "#{t}.#{a}.json: pas de base #{t}.json") unless bases.key?(t) }

# ── validation d'une config effective ──
check = lambda do |label, c|
  REQUIRED.each { |k| add.('E', 'EC2', "#{label}: champ requis #{k}") unless c.key?(k) }
  ENUMS.each do |k, vals|
    add.('E', 'EC1', "#{label}: #{k}=#{c[k].inspect} (valeurs : #{vals.join('|')})") if c.key?(k) && !vals.include?(c[k])
  end
  BOOLS.each { |k| add.('E', 'EC2', "#{label}: #{k} doit être un booléen") if c.key?(k) && ![true, false].include?(c[k]) }
  ARRAYS.each { |k| add.('E', 'EC2', "#{label}: #{k} doit être un tableau") if c.key?(k) && !c[k].is_a?(Array) }
  STRINGS.each { |k| add.('E', 'EC2', "#{label}: #{k} doit être une chaîne") if c.key?(k) && !c[k].is_a?(String) }
  OBJECTS.each { |k| add.('E', 'EC2', "#{label}: #{k} doit être un objet") if c.key?(k) && !c[k].is_a?(Hash) }
  (c.keys - KNOWN).each { |k| add.('W', 'EC2', "#{label}: clé inconnue #{k} (ignorée par scaf-ui ?)") }
  push = c['pushNotifications'].is_a?(Hash) ? c['pushNotifications'] : {}
  seo = c['seo'].is_a?(Hash) ? c['seo'] : {}
  langs = c['i18nLanguages'].is_a?(Array) ? c['i18nLanguages'] : []
  add.('E', 'EC4', "#{label}: pushNotifications.enabled exige pwa: true") if push['enabled'] && !c['pwa']
  add.('E', 'EC4', "#{label}: i18n exige i18nLanguages non vide") if c['i18n'] && langs.empty?
  add.('E', 'EC4', "#{label}: seo.defaultLocale #{seo['defaultLocale'].inspect} ∉ i18nLanguages") if c['i18n'] && seo['defaultLocale'] && !langs.include?(seo['defaultLocale'])
  add.('E', 'EC4', "#{label}: font custom exige customFontPath") if c['font'] == 'custom' && c['customFontPath'].to_s.empty?
  add.('E', 'EC5', "#{label}: customFontPath absolu (#{c['customFontPath']}) — chemin relatif au dépôt (_ui-kits/…)") if c['customFontPath'].to_s.start_with?('/', '~') || c['customFontPath'].to_s =~ /\A[A-Za-z]:[\\\/]/
  SECRETS.each do |path|
    v = c.dig(*path); next if v.nil? || v == ''
    if (m = v.to_s.match(VAR))
      add.('E', 'EC5', "#{label}: #{path.join('.')} → $var:#{m[1]} absent de contracts/variables.yml") unless varkeys.include?(m[1])
    else
      add.('W', 'EC5', "#{label}: #{path.join('.')} en clair — le déplacer dans contracts/variables.yml et référencer $var:NOM")
    end
  end
  add.('W', 'EC6', "#{label}: orm/database ≠ none alors que le front consomme l'API scaf") if %w[orm database].any? { |k| c.key?(k) && c[k] != 'none' }
end

# variables sensibles : une clé privée référencée doit être marquée sensitive
SECRETS.first(1).each do |path|
  bases.each_value do |c|
    m = c.dig(*path).to_s.match(VAR) or next
    v = vars.find { |x| x['key'] == m[1] }
    add.('W', 'EC5', "variables.yml: #{m[1]} devrait être sensitive: true") if v && !v['sensitive']
  end
end

effective = lambda do |tech, app|
  deep.(bases[tech] || {}, overrides[[tech, app]] || {}).merge('projectName' => app)
end

if (i = ARGV.index('--resolve'))
  tech, app = ARGV[i + 1], ARGV[i + 2]
  abort 'usage: --resolve <techno> <app>' unless tech && app
  abort "base #{tech}.json introuvable" unless bases.key?(tech)
  abort "app inconnue: #{app}" unless apps.include?(app)
  c = effective.(tech, app)
  SECRETS.each { |p| c.dig(*p) && (c[p[0]][p[1]] = c[p[0]][p[1]].to_s.match?(VAR) ? c[p[0]][p[1]] : '***') }
  puts JSON.pretty_generate(c)
  exit 0
end

body = ->(m) { m.sub(/\A(\w) (\w+): \S+: /, '\1 \2: ') }
bases.each do |tech, base|
  check.(tech, base)
  inherited = (E + W).map(&body)
  overrides.each_key do |t, a|
    next unless t == tech
    n = [E.size, W.size]; check.("#{tech}[#{a}]", effective.(tech, a))
    # un écart hérité de la base n'est pas répété pour l'app
    E.slice!(n[0]..-1).each { |m| E << m unless inherited.include?(body.(m)) }
    W.slice!(n[1]..-1).each { |m| W << m unless inherited.include?(body.(m)) }
  end
end
E.uniq!; W.uniq!
puts E, W
puts "\nexport-configs: #{bases.size} base(s), #{overrides.size} override(s) — #{E.size} erreur(s), #{W.size} avertissement(s)" unless quiet
exit(E.empty? ? 0 : 1)
