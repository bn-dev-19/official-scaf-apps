---
name: scaf-write-usecase
description: Écrire ou modifier un fichier usecases/<type>/<app>/<id>.usecase.yml SCAF (flux métier : input/output, steps, errors, openapi, intent, links) et le relier à son endpoint par operationId. À utiliser pour tout nouveau flux métier ou toute atomic action producer/consumer.
---

# Écrire un use case

Format de référence : `../02-file-formats.md §5` · règles : `../03-rules-and-validation.md §C`.

## Quand créer un use case ?

Un use case décrit **un flux métier** (≈ une atomic action de `project.parts`), de l'entrée à la sortie, en étapes ordonnées.
- `type: producer` : exposé par un endpoint HTTP → **bloc `openapi` obligatoire**.
- `type: consumer` : comportement purement UI (ex. « saisir le code confidentiel ») → pas de `openapi`.
- `type: shared` : logique partagée UI/back (validation, formatage) → pas de `openapi`.

## Procédure

1. **Lire le contexte** : la feature dans `project.parts/modules/<app>.<module>.yml` (atomic_actions, acteurs), les use cases voisins
   (`ls usecases/ | grep <mot-clé>`), et l'endpoint s'il existe déjà (`grep -rn "id: <operationId>" contracts/`).
2. **Choisir l'`id`** : kebab-case, verbe d'abord (`create-user`, `list-public-offers`, `login-candidate`) ; fichier = `usecases/<type>/<app>/<id>.usecase.yml` (dossiers = `type` puis app du contrat) ; `name` unique (français, « Connecter un candidat »).
3. **Écrire le fichier** avec ce gabarit :
   ```yaml
   id: <id>
   usecase: ""
   name: <Verbe à l'infinitif + objet, français>
   type: producer           # producer | consumer | shared (= dossier parent)
   description: <3-4 phrases : ce que ça fait, vérifications, effets de bord, cas refusés>
   input:
     schema:
       <champ>: { type: string, required: true }        # types: string number boolean integer object array any
   output:
     schema:
       <champ>: { type: string }
   steps:
     - { code: <domaine>.<action_snake_case>, order: 1, severity: medium }   # critical|high|medium|low
   errors:
     - { code: <SCREAMING_SNAKE>, status: 4xx, description: <phrase française> }
   openapi:                 # uniquement producer
     operationId: <id d'un endpoint de contracts/>
     method: POST
     path: /api/v1/...      # IDENTIQUE au path du contrat (avec /v1)
   intent:                  # à renseigner pour tout endpoint (W sévère d'audit sinon ; voir skills/scaf-write-intent.md) : pourquoi l'endpoint existe, pour guider l'implémentation
     purpose: <raison d'être métier, >= 10 caractères>
     actors: [<id de actors.yml>]          # qui peut l'appeler
     preconditions: [<état/droit requis>]
     effects: [<ce que le producteur doit garantir>]
     depends_on:            # endpoints à appeler avant/pendant/après
       - { endpoint: <id existant>, when: before, why: <raison> }
     consumer_notes: <impact et usage conseillé côté consommateur>
   links:                   # optionnel : enchaînements probables
     - { rel: next, usecase: <autre-id>, when: <condition> }
   ```
4. **Steps** : 5 à 9 étapes, ordre croissant continu depuis 1, code `domaine.verbe_objet` (ex. `auth.verify_password`).
   Sévérité : `critical` = sécurité/intégrité (mot de passe, génération de jeton), `high` = accès aux données, `medium` = validation/journal, `low` = cosmétique.
   Une étape = une action vérifiable, pas une phrase vague.
5. **Errors** : reprendre les statuts/codes de l'endpoint (`http.response.errors[]`) ; ajouter les erreurs métier (`ACCOUNT_DISABLED` 403, `EMAIL_ALREADY_EXISTS` 409…).
   Chaque code d'erreur du use case doit exister (même status+code) dans la spec de l'endpoint relié — sinon aligner la spec.
6. **Input/Output** : cohérents avec `http.request.body` et `http.response.body.properties.data` de l'endpoint (mêmes noms de champs, mêmes `enum` en MAJUSCULES, mêmes `format`).
   Les `required`/`nullable` sont des booléens.
7. **intent** : suivre `scaf-write-intent.md` (comprendre le projet, demander validation si doute). Écrire le « pourquoi » (jamais une paraphrase de `description`), les acteurs réels, les `depends_on` réellement nécessaires. Puis `ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/<version>` régénère `output/implementation-guide/` (une page par endpoint, enrichie par `intent`).
8. **links / calls** : ne référencer que des use cases existants (`ls usecases/`). Côté producer, `calls[].mode: event` (défaut `sync`, `when` en prose, `after: <code de step>` pour placer l'appel) cible un usecase interne (sans `openapi`, `feature: <module>/<feature>`, `intent.purpose` requis en pratique).
   Un usecase interne d'une app `api: false` sans `calls` entrant déclare son déclencheur : `trigger: { cron: "*/5 * * * *" }` | `{ queue: "send-digest" }` | `{ event: "user.created" }` | `{ command: "x" }` (un seul ; `command` accepté, non généré ; incompatible avec `openapi`).
9. Si l'endpoint n'existe pas encore : l'écrire d'abord (`scaf-write-endpoint-contract.md`) pour connaître l'`operationId`, **puis** le use case.
10. Vérifier : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>` — attendu : pas de E (A6, A11, C).

## Pièges

- `operationId` = **id d'endpoint**, pas une opération inventée (A6).
- `openapi.path` sans `/v1` → l'outil « use cases sans endpoint » ne retrouvera pas la correspondance (comparaison `METHOD path` exacte). Données historiques : 42 use cases dans ce cas — ne pas copier ce défaut.
- Le champ `usecase: ""` est un vestige : le conserver vide.
- Ne pas mettre de `id` différent du nom de fichier (A11).
- YAML : une `description` contenant `: ` doit être entre guillemets.
- Le type `object` sans `properties` déclenche un avertissement ; décrire les propriétés.
