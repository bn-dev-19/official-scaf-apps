---
name: scaf-bootstrap-from-sources
description: Créer, refaire, compléter ou confronter le contenu de scaf/ à partir de sources d'information (cahier des charges, description du projet, maquettes, code/API/DB existants). À utiliser dès qu'une tâche demande de « gérer le scaf », de le découper ou de le mettre à jour par rapport au projet, que l'utilisateur ait précisé un dossier de ressources ou non : l'agent DEMANDE d'abord sur quelles bases partir et comment.
---

# Partir de sources pour créer ou confronter le scaf

`scaf/` est la traduction structurée (app → module → feature → endpoint, usecases, tables) d'un besoin. Le besoin vit ailleurs : cahier des charges, description du projet, maquettes, code ou API existants, schéma de base, brief oral. **L'agent ne devine jamais d'où partir.**

## 1. Demander les bases d'information (obligatoire, même sans dossier précisé)

Avant de lire ou d'écrire quoi que ce soit dans `scaf/`, poser la question (outil de question de l'agent s'il existe, sinon texte) :

- **Sources** : quels dossiers/fichiers font foi (chemins exacts) ? Types : cahier des charges, description du projet, maquettes/inspirations, code existant, OpenAPI/API existante, schéma DB, notes orales. « Aucune source écrite » est une réponse valable : l'utilisateur décrit alors le besoin à l'oral.
- **Priorité** : en cas de contradiction entre sources, laquelle l'emporte ?
- **Périmètre** : toutes les apps/modules, ou lesquels ?

Interdits : parcourir le dépôt en silence pour choisir soi-même les sources, partir du seul scaf présent sans l'avoir demandé, inventer ce qu'aucune source ne dit. Si l'utilisateur a déjà donné un chemin, le reprendre et demander seulement ce qui manque (mode, priorité, périmètre).

## 2. Demander le mode

| Mode | Quand | Effet |
|---|---|---|
| **Repartir de zéro** | scaf vide ou à refaire | nouvelle version vierge (`skills/scaf-version-fork.md` si l'actuelle doit être conservée) |
| **Confronter** | un scaf existe | rapport d'écarts uniquement, **aucune édition sans accord** |
| **Compléter** | le scaf est bon mais incomplet | ajouts ciblés, l'existant n'est pas réécrit |

## 3. Inventaire

Lire les sources désignées, puis restituer en quelques lignes : ce qu'elles contiennent (acteurs, parcours, fonctionnalités, données, contraintes), ce qui est flou ou absent. Attendre la confirmation de l'utilisateur.

## 4. Proposer le découpage

Soumettre à validation : apps → modules → features → endpoints, usecases principaux, tables, énumérations, avec pour chaque élément la source d'où il vient. **Rien n'est écrit avant l'accord.**

En mode *confronter*, produire à la place un tableau d'écarts : `source → scaf` : **absent** (dans la source, pas dans le scaf) · **divergent** · **en trop** (dans le scaf, pas dans la source). L'utilisateur choisit quoi corriger.

## 5. Écrire

Avec les skills existants, dans cet ordre : `scaf-add-structure` → `scaf-write-endpoint-contract` / `scaf-write-enums` → `scaf-write-mocks` → `scaf-write-usecase` / `scaf-write-intent` → `scaf-database-visual` (+ `scaf-write-journey`, `scaf-write-constraints` si pertinents). Ce qu'une source ne tranche pas : question à l'utilisateur, ou écart (`gap`, règle d'or 12), jamais une valeur inventée. Respecter les règles d'or du `README.md` (version active, sources ≠ dérivés, index synchrones).

## 6. Vérifier

`ruby scaf/_agent-kit/tools/audit.rb scaf/<version>`, puis régénérer les dérivés concernés (`04-tooling-map.md`). Rendre compte : ce qui vient de quelle source, les questions restées ouvertes, les écarts. Ne rien commiter sans demande.
