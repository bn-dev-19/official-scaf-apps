---
name: scaf-write-endpoint-contract
description: Écrire ou modifier un endpoint dans contracts/apps/<app>/<module>/<feature>.yml (champs id/name/method/path + spec YAML). À utiliser pour créer une route d'API, ajouter des erreurs, changer un schéma de requête/réponse. Les mocks se font avec scaf-write-mocks.
---

# Écrire le contrat d'un endpoint (spec)

Formats : `../02-file-formats.md §7` · règles : `../03-rules-and-validation.md §D, §E, §G`.

## Procédure

1. **Localiser la feature** : `contracts/apps/<app>/<module>/<feature>.yml` (la créer via `scaf-add-structure.md` si besoin).
   Lire 1-2 endpoints voisins du même fichier : copier leur style (nommage des champs, messages, erreurs).
2. **Choisir la granularité** (`contracts/granularity.yml` si présent, sinon `use-case`) : un endpoint par cas d'usage métier
   (regroupe plusieurs atomic actions) ; `atomic` = un endpoint par action CRUD. Rester homogène dans le module.
3. **Décider méthode + chemin** :
   - `GET` lecture, `POST` création/action, `PUT` remplacement/mise à jour, `PATCH` partiel, `DELETE` suppression (majuscules).
   - Chemin : `/api/v1/<app-ou-domaine>/<ressource>[/{param_snake}][/<sous-ressource-ou-action>]`, **toujours `/api/v1`**, ressources au pluriel, params `{cv_id}`.
4. **Choisir l'`id`** : `<méthode>-<chemin sans /api/vN>` en kebab-case ; `{cv_id}` → `by-cvid`
   (`GET /api/v1/candidate/cv/{cv_id}/summary` → `get-candidate-cv-by-cvid-summary`). Unique **globalement** (`grep -rn "id: <id>" contracts/`) et ≠ slug de la feature.
5. **Ajouter l'entrée** dans `endpoints:` du fichier feature :
   ```yaml
   - id: <id>
     name: <Nom court en français>
     method: <METHOD>
     path: /api/v1/...
     spec: |
       endpoint:
         id: <id>
         name: <phrase>
         description: <phrase>
       http:
         method: <METHOD>
         path: /api/v1/...
         auth: { type: required, guard: RequireAuth }   # ou { type: none } pour public/login
         request:
           headers:
             - { name: Authorization, type: string, format: "Bearer {token}", required: true }
           path:  [ ... ]      # un FieldDef par {param}
           query: [ ... ]
           body:  { type: object, properties: { ... } }     # POST/PUT/PATCH
         response:
           status: 200          # 201 pour création, 204 interdit (on garde l'enveloppe)
           body:
             type: object
             properties:
               success: { type: boolean }
               message: { type: string }
               data:    { type: object, properties: { ... } }
           errors:
             - { status: 401, code: UNAUTHORIZED, description: ..., message: ..., cause: ..., resolution: ... }
             - { status: 500, code: INTERNAL_SERVER_ERROR, description: ..., message: ..., cause: ..., resolution: ... }
       usecase:
         description: <même phrase que le use case relié>
     mocks: |-
       { "endpoint": "<id>", "mocks": [] }     # compléter avec scaf-write-mocks
     coverage: { totalMocks: 0, nominalCount: 0, errorCount: 0, errorCodes: [], coverageScore: 0 }   # optionnel, dérivé
   ```
   Indentation : `spec` et `mocks` sont des blocs littéraux ; l'indentation du contenu doit être cohérente (≥ 1 espace de plus que `spec:`).
6. **Schéma (SchemaField)** : `type` ∈ `string integer number boolean object array` ; `object` ⇒ `properties`, `array` ⇒ `items`.
   - formats : `uuid`, `email`, `uri`, `date-iso`, `password` ; dates `"2026-08-15T10:24:37Z"`.
   - **enum** : `enum: [PENDING, DONE]` en MAJUSCULES — jamais `format: enum: ...`.
   - champ optionnel/nullable : `nullable: true` (valeur `null` possible) ou `required: false` (peut être absent) — c'est ce qui alimente la couverture de mocks.
   - descriptions de champ en français.
   - **`title`** (objet réutilisé) : nom du composant OpenAPI généré. Le poser, identique, sur le `data` de toutes les réponses d'une même ressource (créer / lire / modifier) en PascalCase singulier : `title: Offer`, `Appointment`. Éviter les noms génériques (`Data`, `Item`, `Exception`).
   - **Réponse toujours enveloppée** `{success, message, data}` ; pour une liste : `data` = objet contenant le tableau (ex. `data.offers`) + `pagination: { current_page, page_size, total_items, total_pages }` **au même niveau que `data`** si paginé (jamais dans `data`) ; `warnings` (tableau `{title, description, tips[]}`) idem, **à déclarer dans toute réponse de succès** (optionnel, non requis) ; `data: null` autorisé (`nullable: true`). **Exemples de chaque forme : `02-file-formats.md §7.3`.**
7. **Erreurs** : au minimum `401` (si `auth.required`), `500`. Ajouter : `400 VALIDATION_ERROR` (body présent), `403 FORBIDDEN` (rôle),
   `404 NOT_FOUND` (param `{id}`), `409 CONFLICT` (unicité), `422`, `429 RATE_LIMITED`. Chaque erreur :
   `status`, `code` (SCREAMING_SNAKE), `description`, **`message`** (court, exposé au client), `cause`, `resolution`.
   Les erreurs métier du use case relié doivent y figurer (même status + code).
   **Un `code` = un cas, unique par endpoint** : c'est l'identifiant runtime côté client et la clé de l'objet `errors` généré. Deux cas distincts (ex. `FORBIDDEN` rôle sans permission **et** suppression refusée pour traçabilité) ⇒ deux codes (`FORBIDDEN`, `SESSION_DELETION_FORBIDDEN`). Si le contrat déclare quand même deux fois le même code, le générateur Next les **fusionne** (1er statut, description/cause/resolution concaténées) avec un avertissement, et l'audit signale `erreur-doublon` : le backend ne peut pas les distinguer, donc préférer un code distinct (changement de contrat à valider avec le backend).
8. **Cohérence** : `method`/`path` du niveau endpoint = `spec.http.method/path` ; `spec.endpoint.id` = `id`.
9. **Relier** : créer/mettre à jour le use case (`openapi.operationId = <id>`, mêmes erreurs) ; ajouter l'atomic action si absente.
10. **Propager** : mocks (`scaf-write-mocks`), puis régénérer `openapi.parts/<app>/<module>/<feature>/<id>.yml` ; DB (`scaf-database-visual`) si nouvelle entité.
11. `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>`.

## Modifier un endpoint existant

- Changement de schéma de réponse ⇒ mettre à jour **tous** les mocks nominaux/empty/critical + l'`openapi.parts` + les colonnes DB concernées + `output.schema` du use case.
- Ajout d'une erreur ⇒ ajouter le mock `error-<code>` + la ligne dans le use case.
- Ajout d'une valeur d'enum ⇒ un mock `enum-<champ>-<VALEUR>` de plus + enum DB.
- Ne changer l'`id` qu'en cascade (spec, mocks, use cases, openapi part).

## Après l'écriture

`contracts_to_openapi.rb scaf/<version> --doc` (OpenAPI) ; si un champ persistant change, mettre à jour `database/visual/` puis `visual_to_sql.rb scaf/<version>` (`skills/scaf-database-visual.md`).

## Anti-patterns (détectés par l'audit / l'app)

Côté réponse, **tout champ est requis** à la génération OpenAPI : un champ qui peut manquer ou être vide doit être `nullable: true` (et présent à `null` dans les mocks). Une date = `format: date-iso` ; un lien = `format: url` ; une IP = `format: ip`. Détails : `../03-rules-and-validation.md §OA`.

`data.data` · erreur dans `data` · mock d'erreur sans `error.message` · `format: enum:` · enum en minuscules · chemin sans `/v1` ·
`{param}` dans `mock.given.path` · id d'endpoint dupliqué · `spec.endpoint.id` ≠ `id` · statut de mock absent de la spec · scalaire YAML contenant `: ` non quoté.

## Upload de fichier

Champ fichier = `type: string` + `format: binary` ; déclarer le header `Content-Type` avec `description: multipart/form-data` : le convertisseur émet alors `multipart/form-data` (sinon `application/json`). Dans les mocks, le fichier est décrit par son nom (voir `scaf-write-mocks`).
