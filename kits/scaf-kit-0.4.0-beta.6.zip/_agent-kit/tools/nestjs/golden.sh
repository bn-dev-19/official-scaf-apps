#!/usr/bin/env bash
# Golden NestJS : architecture × auth → génération, tsc, idempotence, preserve, architectures côte à côte, test HTTP.
set -euo pipefail
cd "$(dirname "$0")"
V=.golden/v0 G=.golden BIN=node_modules/.bin
ok() { echo "ok  $*"; }
ko() { echo "KO  $*"; exit 1; }
gen() { $BIN/tsx gen_nestjs.ts $V "$@" >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération $*"; }; }
rm -rf $G && mkdir -p $G
# base = copie de scaf/v0 ramenée aux défauts (logger nest, swagger sans type) : le golden ne dépend pas des choix de la config réelle
cp -R ../../../v0 $V; perl -0pi -e 's/"logger": "\w+"/"logger": "nest"/; s/, "type": "(scalar|redoc|swagger)"//' $V/input/export-configs/nestjs.json
$BIN/tsc -p . && ok "tsc du générateur"

for a in ddd_layered modular_simple; do for u in none jwt better_auth; do
  d=$G/$a-$u
  h=; [ "$a-$u" = modular_simple-jwt ] && h=--health-check
  gen --out $d --architecture $a --auth $u $h
  (cd $d && ../../$BIN/tsc --noEmit -p .) || ko "tsc $a-$u"
  before=$(find $d -type f | sort | xargs shasum | shasum)
  gen --out $d --architecture $a --auth $u $h
  [ "$before" = "$(find $d -type f | sort | xargs shasum | shasum)" ] || ko "idempotence $a-$u"
  ok "$a × $u : généré, tsc, idempotent"
done; done

# e2e : tests générés depuis les mocks, exécutés pour chaque adaptateur (none : sans 401/403 ; jwt : jeton HS256 ; better_auth : AuthPort factice)
for u in none jwt better_auth; do
  d=$G/ddd_layered-$u
  [ -f $d/test/e2e/contracts.e2e-spec.ts ] && grep -q '"test:e2e"' $d/package.json || ko "e2e $u : fichiers/script absents"
  (cd $d && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -40 $d/e2e.log; ko "e2e $u"; }
  grep -q "non évalué(s)" $d/e2e.log && ok "e2e × $u : $(grep -E '^Tests:' $d/e2e.log | sed 's/Tests: *//')" || ko "e2e $u : résumé NOT_READY absent"
  rm -f $d/e2e.log
done

# environnement : .env.example + .env (créé si absent, secrets, jamais réécrit), validation au démarrage, env:init, fusion de package.json, db:setup, README
d=$G/ddd_layered-jwt; e=$G/envtest; rm -rf $e && mkdir -p $e
grep -q '^JWT_SECRET=$' $d/.env.example && [ -n "$(sed -n 's/^JWT_SECRET=//p' $d/.env)" ] && [ -f $d/README.md ] && grep -q '"env:init"' $d/package.json || ko "env : .env.example/.env/README/script"
sed -i.bak 's/^JWT_SECRET=.*/JWT_SECRET=mien/' $d/.env && rm $d/.env.bak; gen --out $d --architecture ddd_layered --auth jwt
grep -q '^JWT_SECRET=mien$' $d/.env || ko "env : .env réécrit"
(cd $e && ../../$BIN/tsx ../ddd_layered-jwt/src/core/env.ts >env.log 2>&1) && ko "env : démarrage sans variable accepté"
grep -q 'JWT_SECRET' $e/env.log && (cd $e && JWT_SECRET=x ../../$BIN/tsx ../ddd_layered-jwt/src/core/env.ts) || ko "env : validation au démarrage"
sed -i.bak '/JWT_SECRET/d' $d/.env && rm $d/.env.bak; (cd $d && node scripts/env-init.mjs >/dev/null) && grep -q '^JWT_SECRET=.\+' $d/.env && grep -q '^PORT=' $d/.env || ko "env:init"
sed -i.bak 's/"env:init": "[^"]*",\?//; s/"typecheck"/"mon-script": "echo ok", "typecheck"/' $d/package.json && rm $d/package.json.bak
gen --out $d --architecture ddd_layered --auth jwt
grep -q '"env:init"' $d/package.json && grep -q '"mon-script"' $d/package.json || ko "package.json : fusion"
ok "environnement : .env.example, .env créé/conservé, validation, env:init, package.json fusionné, README"
# usecaseBase none : usecases sans BaseUsecase, tsc OK ; template_method : tous étendent BaseUsecase
for a in ddd_layered modular_simple; do
  d=$G/$a-nobase; gen --out $d --architecture $a --auth jwt --usecase-base none
  (cd $d && ../../$BIN/tsc --noEmit -p .) || ko "tsc $a nobase"
  [ ! -f $d/src/core/base-usecase.ts ] && ! grep -rq BaseUsecase $d/src/modules && grep -rq BaseUsecase $G/$a-jwt/src/modules && ok "$a : usecaseBase none / template_method" || ko "usecaseBase $a"
done

# preserve : un usecase édité survit à la régénération ; un fichier utilisateur non suivi n'est pas écrasé
d=$G/ddd_layered-none
uc=$(find $d/src -name '*.usecase.ts' | sed -n 1p)
echo "// édité" >> $uc; echo "// perso" > $d/src/perso.ts
gen --out $d --architecture ddd_layered --auth none
grep -q "// édité" $uc && [ "$(cat $d/src/perso.ts)" = "// perso" ] && ok "preserve" || ko "preserve"

# fichier généré modifié à la main : conservé + warning ; --force le réécrit
d=$G/ddd_layered-jwt; c=$(find $d/src -name '*.controller.ts' | sed -n 1p)
echo "// main" >> $c; gen --out $d --architecture ddd_layered --auth jwt
grep -q "// main" $c && grep -q "modifié à la main" $G/last.log && ok "généré modifié conservé + warning" || ko "écrasé"
gen --out $d --architecture ddd_layered --auth jwt --force
grep -q "// main" $c && ko "--force sans effet" || ok "--force réécrit"

# swagger : une doc OpenAPI par app (endpoints de l'app), servie sur <base>/<app> si plusieurs, <base> si une seule
sd=$G/ms-swagger; gen --out $sd --architecture modular_simple --auth none --swagger docs
gen --out $G/sw-off --architecture modular_simple --auth none --no-swagger
nep=$(grep -rhoE '@(Get|Post|Put|Patch|Delete)\(' $sd/src/modules | wc -l | tr -d ' ')
ndoc=$(cat $sd/src/docs/openapi.*.json | grep -o '"operationId"' | wc -l | tr -d ' ')
[ -f $sd/src/docs/openapi.admin.json ] && [ -f $sd/src/docs/openapi.user.json ] && [ "$nep" = "$ndoc" ] && [ ! -e $G/sw-off/src/docs ] && ! grep -q 'SwaggerModule' $G/sw-off/src/main.ts && grep -q '"@nestjs/swagger"' $sd/package.json && grep -q 'setup("docs/admin"' $sd/src/main.ts && grep -q 'setup("docs/user"' $sd/src/main.ts && ok "swagger : 1 doc par app ($ndoc opérations = $nep endpoints), absent si désactivé" || ko "swagger fichiers ($nep endpoints, $ndoc opérations)"
gen --out $G/sw-app --architecture modular_simple --auth none --swagger docs --app admin
grep -q '/api/v1/admin/' $G/sw-app/src/docs/openapi.admin.json && ! grep -q '/api/v1/me/' $G/sw-app/src/docs/openapi.admin.json && [ ! -e $G/sw-app/src/docs/openapi.user.json ] && grep -q 'setup("docs"' $G/sw-app/src/main.ts && ok "swagger : --app = une doc servie sur <base>" || ko "swagger --app"
# OpenAPI scaf absent : avertissement, aucune doc partielle
cp -R $V $G/v0x && rm -rf $G/v0x/output/openapi
$BIN/tsx gen_nestjs.ts $G/v0x --out $G/sw-miss --architecture modular_simple --auth none --swagger docs >$G/last.log 2>&1
grep -q "contracts_to_openapi.rb" $G/last.log && [ ! -e $G/sw-miss/src/docs ] && ok "swagger : OpenAPI scaf absent → warning, pas de doc" || ko "swagger yml absent"
(cd $sd && ../../$BIN/tsc --noEmit -p .) || ko "tsc swagger"
(cd $sd && ../../$BIN/tsc -p .) || ko "build swagger"
ln -sfn "$PWD/node_modules" $sd/node_modules; echo '{"type":"commonjs"}' > $sd/package.json
PORT=3918 node $sd/dist/main.js >$G/swagger.log 2>&1 & swpid=$!
for i in $(seq 30); do curl -s localhost:3918/x >/dev/null 2>&1 && break; sleep 0.3; done
[ "$(curl -s -o $G/doc.json -w '%{http_code}' localhost:3918/docs/admin-json)" = 200 ] && grep -q '"openapi"' $G/doc.json && grep -q '/api/v1/' $G/doc.json && [ "$(curl -s -o /dev/null -w '%{http_code}' localhost:3918/docs/user)" = 200 ] && ok "swagger servi : /docs/admin(-json), /docs/user" || { cat $G/swagger.log; ko "swagger HTTP"; }
kill $swpid 2>/dev/null || true

# N2 : schéma Drizzle de scaf copié, un repository par table, connexion neon | pg, tsc, idempotence, DI au démarrage
for p in neon pg; do
  n2=$G/n2-$p; gen --out $n2 --architecture ddd_layered --auth none --level N2 --db-provider $p
  (cd $n2 && ../../$BIN/tsc --noEmit -p .) || ko "tsc N2 $p"
  before=$(find $n2 -type f | sort | xargs shasum | shasum); gen --out $n2 --architecture ddd_layered --auth none --level N2 --db-provider $p
  [ "$before" = "$(find $n2 -type f | sort | xargs shasum | shasum)" ] || ko "idempotence N2 $p"
done
nt=$(cat $V/output/database/postgresql/drizzle/*.ts | grep -c '= pgTable(') nr=$(ls $G/n2-neon/src/database/repositories | grep -vc base)
grep -q 'drizzle-orm/neon-serverless' $G/n2-neon/src/database/db.ts && grep -q 'drizzle-orm/node-postgres' $G/n2-pg/src/database/db.ts && grep -q '"drizzle-kit"' $G/n2-neon/package.json && grep -q '"@types/pg"' $G/n2-pg/package.json && grep -q '"db:generate"' $G/n2-neon/package.json && grep -q 'DatabaseModule' $G/n2-neon/src/app.module.ts && [ "$nt" = "$nr" ] && ok "N2 : $nt tables = $nr repositories (neon, pg), tsc, idempotent" || ko "N2 fichiers ($nt tables, $nr repositories)"
r=$(ls $G/n2-neon/src/database/repositories/*.repository.ts | grep -v /base.repository | sed -n 1p); echo "// perso" >> $r
gen --out $G/n2-neon --architecture ddd_layered --auth none --level N2 --db-provider neon
grep -q "// perso" $r && ok "N2 : repository édité conservé" || ko "N2 repository écrasé"
# schéma Drizzle scaf absent : échec clair
cp -R $V $G/v0y && rm -rf $G/v0y/output/database
$BIN/tsx gen_nestjs.ts $G/v0y --out $G/n2-miss --level N2 >$G/last.log 2>&1 && ko "N2 sans schéma accepté"
grep -q "visual_to_sql.rb" $G/last.log && ok "N2 : schéma absent → échec avec la commande à lancer" || ko "N2 message schéma"
# le module de base de données se résout au démarrage (pool paresseux : aucune connexion tentée)
n2=$G/n2-pg; (cd $n2 && ../../$BIN/tsc -p .) || ko "build N2"
ln -sfn "$PWD/node_modules" $n2/node_modules; echo '{"type":"commonjs"}' > $n2/package.json
NEON_DATABASE_CONNEXION_STRING=postgres://u:p@127.0.0.1:1/db PORT=3919 node $n2/dist/main.js >$G/n2.log 2>&1 & n2pid=$!
for i in $(seq 30); do curl -s localhost:3919/x >/dev/null 2>&1 && break; sleep 0.3; done
curl -s localhost:3919/x >/dev/null 2>&1 && ok "N2 : l'API démarre, DatabaseModule + repositories injectés" || { cat $G/n2.log; ko "N2 démarrage"; }
kill $n2pid 2>/dev/null || true

# intent.tables : repositories injectés à la création du usecase, dérive signalée ensuite, rien hors N2
uc=$(find $n2/src/modules -name patch-admin-settings.usecase.ts)
grep -q 'private readonly platformSettingsRepository: PlatformSettingsRepository' $uc && ! grep -q 'AdminAuditLogRepository' $uc && grep -q 'emitRecordAdminAudit' $uc && grep -q '@table platform_settings (write)' $uc && ok "N2 intent.tables : repositories injectés dans le usecase" || ko "N2 intent.tables injection"
grep -q 'Repositories (intent.tables)' $uc && grep -q 'Enregistre les nouvelles valeurs' $uc && grep -q 'findAll(limit = 50, offset = 0)' $uc && grep -q 'update(id, values)' $uc && ok "N2 intent.tables : guide des repositories (why, méthodes)" || ko "guide repositories"
cp -R $V $G/v0z && perl -0pi -e 's/  tables:\n(    - \{ table:[^\n]*\n)+//' $G/v0z/input/usecases/producer/admin/delete-admin-cities-by-cityid.usecase.yml
$BIN/tsx gen_nestjs.ts $G/v0z --out $G/n2-notables --architecture ddd_layered --auth none --level N2 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération sans tables"; }
u0=$(find $G/n2-notables/src/modules -name delete-admin-cities-by-cityid.usecase.ts); [ -f "$u0" ] && ! grep -q 'Repository' "$u0" && ok "N2 : un usecase sans intent.tables n'injecte rien" || ko "usecase sans intent.tables ne doit rien injecter"
perl -pi -e 's/PlatformSettingsRepository/Retire/g' $uc; gen --out $n2 --architecture ddd_layered --auth none --level N2
grep -q 'à injecter à la main PlatformSettingsRepository' $G/last.log && ok "N2 intent.tables : dérive signalée sur usecase existant" || ko "N2 intent.tables dérive"
gen --out $G/n1-tables --architecture ddd_layered --auth none --level N1
grep -q "rien injecté hors niveau N2" $G/last.log && ! grep -rq 'PlatformSettingsRepository' $G/n1-tables/src && ok "N1 : intent.tables sans effet (warn)" || ko "N1 intent.tables"

# rateLimiting: true : ThrottlerGuard global avant AccessGuard, 429 RATE_LIMITED dans le filtre, variables d'env ; false : aucun changement
rl=$G/v0rl; cp -R $V $rl; perl -0pi -e 's/"rateLimiting":\s*(\{.*?\}\s*\}\s*\}|false|true)/"rateLimiting": true/s' $rl/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rl --out $G/n1-rl --architecture ddd_layered --auth jwt >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération rateLimiting"; }
(cd $G/n1-rl && ../../$BIN/tsc --noEmit -p .) || ko "tsc rateLimiting"
grep -q '"@nestjs/throttler"' $G/n1-rl/package.json && grep -q 'ThrottlerModule.forRoot' $G/n1-rl/src/core/core.module.ts && grep -q 'RATE_LIMITED' $G/n1-rl/src/core/global-exception.filter.ts && grep -q '^RATE_LIMIT_MAX=100' $G/n1-rl/.env.example && [ "$(grep -n 'useExisting: ThrottlerGuard' $G/n1-rl/src/core/core.module.ts | cut -d: -f1)" -lt "$(grep -n 'useClass: AccessGuard' $G/n1-rl/src/core/core.module.ts | cut -d: -f1)" ] && ! grep -q 'NS10\|rateLimiting' $G/last.log && ok "rateLimiting : throttler, guard avant AccessGuard, 429 RATE_LIMITED, .env.example, tsc" || ko "rateLimiting"
rf=$G/v0rf; cp -R $V $rf; perl -0pi -e 's/"rateLimiting":\s*(\{.*?\}\s*\}\s*\}|false|true)/"rateLimiting": false/s' $rf/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rf --out $G/n1-rf --architecture ddd_layered --auth jwt >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération rateLimiting false"; }
! grep -rq 'throttler\|Throttler' $G/n1-rf/package.json $G/n1-rf/src && ok "rateLimiting false : aucun throttler généré" || ko "rateLimiting false"

# rateLimiting objet { endpoints } : @Throttle seulement sur les endpoints listés (v0 en déclare 3), id inconnu → NS11
ro=$G/v0ro; cp -R $V $ro
$BIN/tsx gen_nestjs.ts $ro --out $G/n1-ro --architecture ddd_layered --auth jwt >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération rateLimiting objet"; }
(cd $G/n1-ro && ../../$BIN/tsc --noEmit -p .) || ko "tsc rateLimiting objet"
[ "$(grep -rh '@Throttle(' $G/n1-ro/src | wc -l | tr -d ' ')" = "$(grep -c '"ttlMs"' $ro/input/export-configs/nestjs.json)" ] && grep -rq 'ThrottlerGuard' $G/n1-ro/src/core/core.module.ts && ok "rateLimiting objet : @Throttle par endpoint" || ko "rateLimiting objet"
perl -0pi -e 's/"post-auth-otp-request"/"endpoint-inconnu"/' $ro/input/export-configs/nestjs.json
[[ "$(ruby ../export_configs.rb $ro 2>&1)" == *NS11*endpoint-inconnu* ]] && ok "rateLimiting : id inconnu signalé (NS11)" || ko "NS11 id inconnu"

# better_auth : auth.ts généré depuis nestjs.json (N2 : drizzleAdapter + plugins, routes montées, schéma via auth:generate), stateless hors N2, auth.ts édité conservé
ba=$G/n2-ba; gen --out $ba --architecture ddd_layered --auth better_auth --level N2
(cd $ba && ../../$BIN/tsc --noEmit -p .) || ko "tsc better_auth N2"
grep -q 'drizzleAdapter(createDb(), { provider: "pg", schema })' $ba/src/better-auth/auth.ts && grep -q 'admin({' $ba/src/better-auth/auth.ts && grep -q 'username(' $ba/src/better-auth/auth.ts && grep -q 'apiKey()' $ba/src/better-auth/auth.ts && grep -q 'requireEmailVerification: true' $ba/src/better-auth/auth.ts && ok "better_auth N2 : auth.ts (drizzleAdapter, plugins, options de nestjs.json)" || ko "better_auth N2 auth.ts"
grep -q 'toNodeHandler(auth)' $ba/src/main.ts && grep -q 'auth:generate' $ba/package.json && grep -q 'better-auth/schema.ts' $ba/drizzle.config.ts && ok "better_auth N2 : routes montées, script auth:generate, drizzle.config" || ko "better_auth N2 wiring"
grep -q 'db:setup' $ba/package.json && grep -q '"auth": ' $ba/package.json && grep -q 'auth generate' $ba/package.json && grep -q '^BETTER_AUTH_SECRET=.\+' $ba/.env || ko "better_auth N2 : db:setup / CLI épinglée / .env"
ok "better_auth N2 : db:setup (auth:generate → db:generate → db:migrate), CLI auth épinglée, .env"
echo '// édité' >> $ba/src/better-auth/auth.ts; gen --out $ba --architecture ddd_layered --auth better_auth --level N2
grep -q '// édité' $ba/src/better-auth/auth.ts && ok "better_auth : auth.ts édité conservé" || ko "better_auth auth.ts preserve"
gen --out $G/n1-ba --architecture ddd_layered --auth better_auth --level N1
! grep -q drizzleAdapter $G/n1-ba/src/better-auth/auth.ts && [ ! -f $G/n1-ba/src/better-auth/schema.ts ] && ok "better_auth N1 : sans base (stateless)" || ko "better_auth N1"
# mailer / sms : plugins e-mail/SMS branchés sur src/better-auth/notify.ts (resend + twilio : tsc ; smtp : nodemailer + @types), none = console.warn
mn=$G/v0mail; cp -R $V $mn; perl -0pi -e 's/"mailer": "none"/"mailer": "resend"/; s/("emailVerification": )false/$1true/; s/"authPlugins": \[/"sms": "twilio",\n    "authPlugins": ["emailOTP", "magicLink", "phoneNumber", /' $mn/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $mn --out $G/n1-mail --architecture ddd_layered --auth better_auth --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération mailer/sms"; }
(cd $G/n1-mail && ../../$BIN/tsc --noEmit -p .) || ko "tsc mailer/sms"
m=$G/n1-mail; grep -q 'api.resend.com' $m/src/better-auth/notify.ts && grep -q 'api.twilio.com' $m/src/better-auth/notify.ts && grep -q 'void sendMail' $m/src/better-auth/auth.ts && grep -q 'void sendSms' $m/src/better-auth/auth.ts && grep -q 'sendResetPassword' $m/src/better-auth/auth.ts && grep -q 'sendVerificationEmail' $m/src/better-auth/auth.ts && ! grep -q 'non branché' $m/src/better-auth/auth.ts && grep -q '^RESEND_API_KEY=' $m/.env.example && grep -q '^TWILIO_AUTH_TOKEN=' $m/.env.example && ok "mailer resend + sms twilio : notify.ts, plugins branchés, variables" || ko "mailer/sms resend+twilio"
sed -i.bak 's/"mailer": "resend"/"mailer": "smtp"/; s/"sms": "twilio"/"sms": "none"/' $mn/input/export-configs/nestjs.json; rm -f $mn/input/export-configs/nestjs.json.bak
$BIN/tsx gen_nestjs.ts $mn --out $G/n1-smtp --architecture ddd_layered --auth better_auth --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération smtp"; }
m=$G/n1-smtp; grep -q 'nodemailer' $m/src/better-auth/notify.ts && grep -q '"nodemailer"' $m/package.json && grep -q '@types/nodemailer' $m/package.json && grep -q '^SMTP_URL=' $m/.env.example && ! grep -q 'sendSms' $m/src/better-auth/notify.ts && grep -q 'envoi SMS non branché' $m/src/better-auth/auth.ts && ok "mailer smtp : nodemailer, SMS non branché conservé" || ko "mailer smtp"
! grep -rq 'notify' $G/n1-ba/src/better-auth/ && ok "mailer/sms none : pas de notify.ts" || ko "mailer none"
# logger / errorMonitoring / cache / swagger.type : opt-in, dépendances et variables seulement si activés (tsc : voir la validation réelle sous pnpm install)
xo=$G/v0xo; cp -R $V $xo; perl -0pi -e 's/"logger": "nest"/"logger": "pino"/; s/"cache": "none"/"cache": "redis"/; s/"errorMonitoring": "none"/"errorMonitoring": "sentry"/; s/"swagger": \{ "enabled": true, "path": "docs" \}/"swagger": { "enabled": true, "path": "docs", "type": "scalar" }/' $xo/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $xo --out $G/n1-xo --architecture ddd_layered --auth jwt --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération extras"; }
x=$G/n1-xo; grep -q 'nestjs-pino' $x/package.json && grep -q '"@sentry/nestjs"' $x/package.json && grep -q '"@keyv/redis"' $x/package.json && grep -q 'LoggerModule.forRoot' $x/src/core/core.module.ts && grep -q 'redact' $x/src/core/core.module.ts && grep -q 'SentryModule.forRoot()' $x/src/core/core.module.ts && grep -q 'CacheModule.registerAsync' $x/src/core/core.module.ts && grep -q 'bufferLogs: true' $x/src/main.ts && grep -q 'app.useLogger(app.get(PinoLogger))' $x/src/main.ts && grep -q 'import "./instrument"' $x/src/main.ts && grep -q 'Sentry.captureException' $x/src/core/global-exception.filter.ts && grep -q 'mountDocs(app, "docs' $x/src/main.ts && ! grep -q 'SwaggerModule' $x/src/main.ts && [ -f $x/src/docs/docs-ui.ts ] && grep -q '^SENTRY_DSN=' $x/.env.example && grep -q '^LOG_LEVEL=' $x/.env.example && grep -q '^REDIS_URL=' $x/.env.example && ok "extras pino + sentry + redis + scalar : deps, modules, main.ts, filtre, variables" || ko "extras pino/sentry/redis/scalar"
perl -0pi -e 's/"logger": "pino"/"logger": "winston"/; s/"type": "scalar"/"type": "redoc"/' $xo/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $xo --out $G/n1-xo2 --architecture ddd_layered --auth jwt --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération winston/redoc"; }
x=$G/n1-xo2; grep -q 'nest-winston' $x/package.json && ! grep -q 'nestjs-pino' $x/package.json && grep -q 'WinstonModule.forRoot' $x/src/core/core.module.ts && grep -q 'WINSTON_MODULE_NEST_PROVIDER' $x/src/main.ts && grep -q 'redoc' $x/src/docs/docs-ui.ts && ok "extras winston + redoc" || ko "extras winston/redoc"
# queue bullmq : deps + BullModule.forRootAsync + REDIS_URL (sans cache) ; tsc sur le projet généré = voir validation réelle sous pnpm install
perl -0pi -e 's/"queue": "none"/"queue": "bullmq"/; s/"cache": "redis"/"cache": "none"/' $xo/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $xo --out $G/n1-q --architecture ddd_layered --auth jwt --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération queue"; }
x=$G/n1-q; grep -q '"@nestjs/bullmq"' $x/package.json && grep -q '"bullmq"' $x/package.json && ! grep -q 'cache-manager' $x/package.json && grep -q 'BullModule.forRootAsync' $x/src/core/core.module.ts && grep -q '^REDIS_URL=' $x/.env.example && ! grep -q 'NS10.*queue' $G/last.log && ok "queue bullmq : deps, module, REDIS_URL" || ko "queue bullmq"
# usecaseStyle handler : <X>Handler.handle(), *.handler.ts, controllers/modules cohérents, tsc, e2e, les deux architectures ; BaseUsecase.handle
for a in ddd_layered modular_simple; do
  d=$G/$a-handler; gen --out $d --architecture $a --auth jwt --usecase-style handler
  (cd $d && ../../$BIN/tsc --noEmit -p .) || ko "tsc $a handler"
  [ -z "$(find $d/src -name '*.usecase.ts')" ] && [ -n "$(find $d/src -name '*.handler.ts')" ] && ! grep -rE 'Usecase\b|\.execute\(' $d/src/modules | grep -qv BaseUsecase && grep -q 'async handle(' $d/src/core/base-usecase.ts && ok "$a : usecaseStyle handler (tsc, *.handler.ts, handle())" || ko "usecaseStyle handler $a"
done
d=$G/ddd_layered-handler; (cd $d && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -30 $d/e2e.log; ko "e2e handler"; }; ok "e2e × handler : $(grep -E '^Tests:' $d/e2e.log | sed 's/Tests: *//')"; rm -f $d/e2e.log
# testFramework vitest : config + deps vitest/unplugin-swc (pas de jest), e2e exécuté pour chaque adaptateur
for u in none jwt better_auth; do
  d=$G/vitest-$u; gen --out $d --architecture ddd_layered --auth $u --test-framework vitest
  grep -q '"vitest run --config test/vitest-e2e.config.ts"' $d/package.json && grep -q '"unplugin-swc"' $d/package.json && ! grep -q '"ts-jest"' $d/package.json && [ -f $d/test/vitest-e2e.config.ts ] && [ ! -f $d/test/jest-e2e.json ] || ko "vitest $u : fichiers/deps"
  (cd $d && ../../$BIN/vitest run --config test/vitest-e2e.config.ts >e2e.log 2>&1) || { tail -40 $d/e2e.log; ko "e2e vitest $u"; }
  ok "e2e × vitest × $u : $(grep -E '^ +Tests ' $d/e2e.log | sed 's/ *Tests *//')"; rm -f $d/e2e.log
done
# défauts : aucun extra dans un projet généré sans ces options
d=$G/ddd_layered-jwt; ! grep -rqE 'sentry|nestjs-pino|nest-winston|cache-manager|keyv|docs-ui|LOG_LEVEL|REDIS_URL' $d/package.json $d/src $d/.env.example && [ ! -f $d/src/instrument.ts ] && ok "défauts : aucun extra (logger/sentry/cache/docs)" || ko "défauts : extras inattendus"

# RLS : visuel `rls` → SQL (FORCE opt-in), audit A13, projet rls: session (tsc, fichiers, proxy), sans rls = aucun fichier, identité Better Auth, isolation réelle (Docker)
r=$G/v0r; cp -R $V $r; cp golden/_visual_rlstest.yml $r/input/database/visual/
perl -0pi -e 's/"rls": "[a-z]+"/"rls": "session"/; s/("generator")/"rls": "session",\n    $1/ unless /"rls"/' $r/input/export-configs/nestjs.json
ruby ../visual_to_sql.rb $r >/dev/null 2>&1 || ko "visual_to_sql rls"
s=$r/output/database/postgresql/sql
grep -q 'ENABLE ROW LEVEL SECURITY' $s/90_rls.sql && grep -q 'app_user_id()' $s/05_rls_setup.sql && ! grep -q 'FORCE' $s/90_rls.sql && ok "RLS SQL : policies, helpers, sans FORCE par défaut" || ko "RLS SQL"
sed -i.bak 's/^      enabled: true/      enabled: true\n      force: true/' $r/input/database/visual/_visual_rlstest.yml; ruby ../visual_to_sql.rb $r >/dev/null 2>&1; grep -q 'FORCE ROW LEVEL SECURITY' $s/90_rls.sql && ok "RLS SQL : force: true → FORCE" || ko "RLS force"
mv $r/input/database/visual/_visual_rlstest.yml.bak $r/input/database/visual/_visual_rlstest.yml 2>/dev/null; sed -i.bak '/^      force: true/d' $r/input/database/visual/_visual_rlstest.yml; rm -f $r/input/database/visual/*.bak; ruby ../visual_to_sql.rb $r >/dev/null 2>&1
vf=$r/input/database/visual/_visual_rlstest.yml
for c in 's/for: select/for: bogus/' 's/owner: \[owner_id\]/owner: [nope]/' 's/^\(        - { name: notes_public_read.*\)$/\1\n\1/' 's/      admin: \[admin\]/      admin: [1]/'; do
  cp $vf $vf.keep; sed -i.bak "$c" $vf; rm -f $vf.bak
  au=$(ruby ../audit.rb $r 2>&1 || true); grep -q 'A13' <<<"$au" && ok "audit A13 : $c" || ko "audit A13 non détecté : $c"
  mv $vf.keep $vf
done
au=$(ruby ../audit.rb $r 2>&1 || true); grep -q '^E A13' <<<"$au" && ko "audit A13 faux positif" || ok "audit A13 : spec valide acceptée"
rg=$G/n2-rls; gen_r() { $BIN/tsx gen_nestjs.ts $r "$@" >"$G/last.log" 2>&1 || { cat "$G/last.log"; ko "génération $*"; }; }
gen_r --out $rg --architecture ddd_layered --auth none --level N2 --db-provider pg
(cd $rg && ../../$BIN/tsc --noEmit -p .) || ko "tsc rls"
grep -q 'withRls(createDb())' $rg/src/database/database.module.ts && grep -q 'APP_INTERCEPTOR' $rg/src/database/database.module.ts && [ -f $rg/rls/90_rls.sql ] && [ -f $rg/scripts/apply-rls.mjs ] && grep -q '"db:rls"' $rg/package.json && grep -q 'db:rls' $rg/package.json && ok "rls session : proxy DRIZZLE, interceptor, rls/*.sql, apply-rls, db:rls" || ko "rls wiring"
rn=$G/v0n; cp -R $V $rn; perl -0pi -e 's/"rls": "session"/"rls": "none"/' $rn/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rn --out $G/n2-norls --architecture ddd_layered --auth none --level N2 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération sans rls"; }
[ ! -e $G/n2-norls/rls ] && [ ! -e $G/n2-norls/src/database/db-context.ts ] && ! grep -q 'db:rls' $G/n2-norls/package.json && ok "sans rls : aucun fichier RLS" || ko "sans rls : fichiers RLS inattendus"
# identité Better Auth : modelName/fields/generateId, auth-schema.mjs
ri=$G/v0i; cp -R $V $ri; perl -0pi -e 's/("generator")/"authUserTable": "users",\n    "authUserFields": { "name": "full_name", "image": "avatar_url" },\n    $1/' $ri/input/export-configs/nestjs.json
gi=$G/n2-ident; $BIN/tsx gen_nestjs.ts $ri --out $gi --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération identité"; }
grep -q 'modelName: "users"' $gi/src/better-auth/auth.ts && grep -q 'generateId' $gi/src/better-auth/auth.ts && [ -f $gi/scripts/auth-schema.mjs ] && grep -q 'auth-schema.mjs' $gi/package.json && grep -q '"emailVerified": "email_verified"' $gi/src/better-auth/auth.ts && grep -q 'banReason.*ban_reason' $gi/src/better-auth/auth.ts && grep -q 'defaultRole: "PASSENGER"' $gi/src/better-auth/auth.ts && ok "identité : auth.ts (modelName, fields, generateId), auth-schema.mjs, mapping snake_case auto, defaultRole" || ko "identité Better Auth"
# défaut fonctionnel (sql``), niveau inférieur bloqué, rls session sans authUserTable
grep -q "default(sql\`CURRENT_DATE\`)" $gi/src/database/schema/auth.ts && grep -q "import { sql } from 'drizzle-orm'" $gi/src/database/schema/auth.ts && ok "défaut CURRENT_DATE rendu en sql\`\`" || ko "défaut CURRENT_DATE"
$BIN/tsx gen_nestjs.ts $ri --out $gi --architecture ddd_layered --auth better_auth --level N1 >$G/last.log 2>&1 && ko "niveau inférieur non bloqué" || { grep -q 'supprimerait ses fichiers N2' $G/last.log && ok "régénération en N1 sur projet N2 : bloquée" || ko "message garde niveau"; }
rn=$G/v0rn; cp -R $V $rn; perl -0pi -e 's/"authUserTable": "[^"]*",?//; s/"authDefaultRole": "[^"]*",?//; s/"authUserFields": \{[^}]*\},?//' $rn/input/export-configs/nestjs.json
rb=$(ruby ../audit.rb $rn 2>&1 || true); echo "$rb" | grep -q 'rls session exige authUserTable' && ok "NS4 : rls session sans authUserTable = erreur" || ko "NS4 rls sans authUserTable"
# garde-fous Better Auth × visuel : conflit de noms, dérive d'identité, db-guard, scripts périmés
cx=$G/v0c; cp -R $V $cx; perl -0pi -e 's/(  - name: users\n)/  - name: session\n    kind: entity\n    description: Conflit.\n    columns:\n      - { name: id, type: uuid, nullable: false, primary: true, description: Id. }\n$1/' $cx/input/database/visual/_visual_auth.yml
ruby ../visual_to_sql.rb $cx --format drizzle >/dev/null 2>&1
$BIN/tsx gen_nestjs.ts $cx --out $G/n2-clash --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 && ko "conflit de nom non détecté" || { grep -q 'conflit avec les tables natives Better Auth (session)' $G/last.log && ok "conflit visuel ↔ table Better Auth : échec explicite" || { cat $G/last.log; ko "conflit message"; }; }
gd=$G/n2-guard; gen --out $gd --architecture ddd_layered --auth better_auth --level N2
[ -f $gd/.scaf-identity.json ] && grep -q 'db:guard' $gd/package.json && grep -q 'db:generate && pnpm db:guard && pnpm db:migrate' $gd/package.json && ok "better_auth N2 : db:guard dans db:setup, empreinte d'identité" || ko "db:guard"
mkdir -p $gd/drizzle/meta; echo '{"entries":[{"tag":"0001_x"}]}' > $gd/drizzle/meta/_journal.json; echo 'DROP TABLE "user" CASCADE;--> statement-breakpoint
ALTER TABLE "account" ALTER COLUMN "id" SET DATA TYPE uuid;' > $gd/drizzle/0001_x.sql
(cd $gd && node scripts/db-guard.mjs >/dev/null 2>$OLDPWD/$G/guard.log) && ko "db-guard n'a pas bloqué" || grep -q 'destructive' $G/guard.log && ok "db-guard : migration destructive refusée" || ko "db-guard message"
(cd $gd && SCAF_ALLOW_DESTRUCTIVE=1 node scripts/db-guard.mjs >/dev/null 2>&1 && node scripts/db-guard.mjs >/dev/null 2>&1) && ok "db-guard : autorisation explicite mémorisée" || ko "db-guard ack"
echo 'ALTER TABLE "t" ADD COLUMN "x" text;' > $gd/drizzle/0001_x.sql; rm -f $gd/drizzle/.guard-ack; (cd $gd && node scripts/db-guard.mjs >/dev/null 2>&1) && ok "db-guard : migration sans risque acceptée" || ko "db-guard faux positif"
# identité changée sur projet déjà migré ⇒ blocage, --force passe
rj=$G/v0j; cp -R $ri $rj; perl -0pi -e 's/"idStrategy": "uuid"/"idStrategy": "serial"/' $rj/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $rj --out $gd --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 && ko "dérive d'identité non bloquée" || { grep -q 'identité Better Auth modifiée' $G/last.log && ok "dérive d'identité sur projet migré : bloquée avec guide" || ko "dérive message"; }
$BIN/tsx gen_nestjs.ts $rj --out $gd --architecture ddd_layered --auth better_auth --level N2 --force >$G/last.log 2>&1 && ok "dérive d'identité : --force passe" || { cat $G/last.log; ko "--force identité"; }
# scripts périmés / auth.ts sans modelName
sed -i.bak 's#"db:setup": "[^"]*"#"db:setup": "pnpm db:migrate"#' $gd/package.json; rm $gd/package.json.bak
$BIN/tsx gen_nestjs.ts $ri --out $gd --architecture ddd_layered --auth better_auth --level N2 --force >$G/last.log 2>&1
grep -q 'script db:setup périmé' $G/last.log && ok "package.json : script périmé signalé" || ko "script périmé"
sed -i.bak '/modelName/d' $gd/src/better-auth/auth.ts; rm $gd/src/better-auth/auth.ts.bak
$BIN/tsx gen_nestjs.ts $ri --out $gd --architecture ddd_layered --auth better_auth --level N2 --force >$G/last.log 2>&1
grep -q 'user.modelName "users" absent' $G/last.log && ok "auth.ts conservé sans modelName : signalé" || ko "dérive auth.ts"

# auth-schema.mjs sur un faux schéma `auth generate` : table retirée, importée ET réexportée (le drizzleAdapter la cherche dans ce module)
mkdir -p $gi/src/better-auth; printf 'import { pgTable, text } from "drizzle-orm/pg-core";\nexport const users = pgTable("users", {\n  id: text("id").primaryKey(),\n});\nexport const usersRelations = relations(users, ({ many }) => ({ s: many(session) }));\nexport const session = pgTable("session", { id: text("id") });\n' > $gi/src/better-auth/schema.ts
(cd $gi && node scripts/auth-schema.mjs >/dev/null) && grep -q 'export { users }' $gi/src/better-auth/schema.ts && ! grep -q 'pgTable("users"' $gi/src/better-auth/schema.ts && grep -q 'pgTable("session"' $gi/src/better-auth/schema.ts && ok "auth-schema.mjs : identité importée + réexportée, reste du schéma Better Auth conservé" || ko "auth-schema.mjs"
# isolation réelle (Postgres jetable via Docker ; ignorée sans Docker)
if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
  c=golden-rls-pg; docker rm -f $c >/dev/null 2>&1; docker run -d --rm --name $c -e POSTGRES_PASSWORD=pw -e POSTGRES_DB=t -p 54339:5432 postgres:16 >/dev/null
  for i in $(seq 40); do docker exec $c pg_isready -U postgres -d t >/dev/null 2>&1 && break; sleep 1; done; sleep 2
  var=$(grep -o '^[A-Z_]*=' $rg/.env | head -1 | tr -d '='); ln -sfn "$PWD/node_modules" $rg/node_modules
  (cd $rg && export $var=postgres://postgres:pw@localhost:54339/t && ../../$BIN/drizzle-kit push --force >/dev/null 2>&1 && node scripts/apply-rls.mjs >/dev/null && node scripts/apply-rls.mjs >/dev/null && cp ../../golden/rls-isolation.ts.tpl ./rls-test.ts && ../../$BIN/tsx rls-test.ts >$OLDPWD/$G/rls.log 2>&1) && grep -q 'rls : tout est ok' $G/rls.log && ok "RLS isolation réelle (Postgres 16) : A/B/admin/anonyme, WITH CHECK, rollback, concurrence, idempotence" || { cat $G/rls.log; docker rm -f $c >/dev/null; ko "RLS isolation"; }
  docker rm -f $c >/dev/null 2>&1
else echo "--  RLS isolation : Docker absent, ignorée"; fi

# N2 mysql / sqlite : schéma du moteur, un repository par table, tsc ; mysql sans returning() ; sqlite : aller-retour réel sur un fichier (DDL scaf)
for e in mysql sqlite; do
  m=$G/n2-$e; gen --out $m --architecture ddd_layered --auth none --level N2 --database $e
  (cd $m && ../../$BIN/tsc --noEmit -p .) || ko "tsc N2 $e"
  nt=$(cat $V/output/database/$e/drizzle/*.ts | grep -c "= ${e}Table(") nr=$(ls $m/src/database/repositories | grep -vc base)
  [ "$nt" = "$nr" ] && grep -q "dialect: \"$e\"" $m/drizzle.config.ts && ok "N2 $e : $nt tables = $nr repositories, tsc" || ko "N2 $e ($nt tables, $nr repositories)"
done
grep -rq "en-tête du pilote" $G/n2-mysql/src/modules && ok "N2 mysql : guide mentionne l'en-tête du pilote" || ko "guide mysql"
grep -q 'affectedRows' $G/n2-mysql/src/database/repositories/base.repository.ts && ! grep -q '\.returning()' $G/n2-mysql/src/database/repositories/base.repository.ts && ok "N2 mysql : repositories sans returning()" || ko "N2 mysql returning"
m=$G/n2-sqlite; (cd $m && ../../$BIN/tsc -p .) || ko "build N2 sqlite"
ln -sfn "$PWD/node_modules" $m/node_modules; echo '{"type":"commonjs"}' > $m/package.json
cat > $m/rt.js <<'JS'
require("reflect-metadata");
const Database = require("better-sqlite3");
const f = process.env.NEON_DATABASE_CONNEXION_STRING;
const raw = new Database(f); raw.exec(require("fs").readFileSync(process.argv[2], "utf8")); raw.close();
const { createDb } = require("./dist/database/db");
const { CitiesRepository } = require("./dist/database/repositories/cities.repository");
(async () => {
  const r = new CitiesRepository(createDb());
  const row = await r.insert({ name: "Abidjan", slug: "abidjan" });
  const ok = [(await r.findAll()).length === 1, (await r.findById(row.id)).name === "Abidjan", (await r.update(row.id, { name: "Bouaké" })).name === "Bouaké", (await r.delete(row.id)) === true, (await r.findAll()).length === 0];
  console.log(JSON.stringify(ok)); process.exit(ok.every(Boolean) ? 0 : 1);
})().catch(e => { console.error(e); process.exit(1); });
JS
rm -f $G/rt.db; (cd $m && NEON_DATABASE_CONNEXION_STRING=../rt.db node rt.js ../../$V/output/database/sqlite/schema.sql) && ok "N2 sqlite : insert, findById, update, delete sur un vrai fichier" || ko "N2 sqlite aller-retour"

# côte à côte : une 2e architecture dans la même sortie n'efface pas la 1re
gen --out $d --architecture modular_simple --auth none
[ -d $d/src/modules/ddd_layered ] && [ -d $d/src/modules/modular_simple ] && ok "architectures côte à côte" || ko "côte à côte"

# obsolète : un fichier généré non modifié, plus produit, est supprimé ; modifié, il est gardé
gen --out $d --architecture modular_simple --level N0 --force
[ -z "$(find $d/src/modules/modular_simple -name '*.dto.ts' -o -name '*.controller.ts')" ] && ok "obsolètes supprimés (N0), usecases preserve gardés" || ko "obsolète non supprimé"
[ -f $uc ] && ok "usecase édité gardé" || ko "usecase édité supprimé"

# un controller par feature (plus de controller de module), préfixe/version posés une fois
d=$G/modular_simple-jwt
[ ! -f $d/src/modules/modular_simple/booking/booking.controller.ts ] && [ -f $d/src/modules/modular_simple/booking/trip-lifecycle.controller.ts ] && grep -q 'version: "1"' $d/src/modules/modular_simple/booking/trip-lifecycle.controller.ts && ! grep -rq '"api/v1' $d/src/modules && grep -q 'enableVersioning' $d/src/main.ts && ok "controllers par feature, préfixe api + version uri" || ko "controllers par feature"

# HTTP : 401 sans jeton, 403 non admin, 501 enveloppé avec jeton admin, 400 enveloppé sur query invalide
d=$G/modular_simple-jwt
# usecase de test : handlers sur critical/high, skip (medium), todo (low) → exécuté + warn
uc=$(find $d/src -name 'get-admin-rides.usecase.ts')
perl -0pi -e 's|"admin.verify_admin_session": todo\(.*?\n    \}\),|"admin.verify_admin_session": async (c) => { c.state.t = ["v"]; },|s; s|"rides.validate_filters": todo\(.*?\n    \}\),|"rides.validate_filters": async (c) => c.skip("golden"),|s; s|"rides.search_rides": todo\(.*?\n    \}\),|"rides.search_rides": async (c) => { (c.state.t as string[]).push("s"); c.output = result((c.state.t as string[]).join(">")).message("golden-msg").warn({ title: "w", description: "d", tips: [] }).withHeaders({ "x-golden": "1" }).paged(paginate(1, 10, 1)) as never; },|s' $uc
rel=$(node -e 'console.log(require("path").relative(require("path").dirname(process.argv[1]), process.argv[2]+"/src/core"))' "$uc" "$d")
{ echo "import { result } from \"$rel/api-result\"; import { paginate } from \"$rel/pagination\";"; cat $uc; } > $uc.new && mv $uc.new $uc
(cd $d && ../../$BIN/tsc -p .) || ko "tsc usecase de test"
# steps ET run() → erreur claire ; run() seul → ok
uc2=$(find $d/src -name 'get-admin-cities.usecase.ts')
perl -0pi -e 's|\n  \};\n|\n  };\n  protected async run(): Promise<never> { return "RUN" as never; }\n|' $uc2
(cd $d && ../../$BIN/tsc -p .) || ko "tsc steps+run"
ln -sfn "$PWD/node_modules" $d/node_modules; echo "{\"type\":\"commonjs\"}" > $d/package.json
export JWT_SECRET=golden PORT=3917
tok() { node -e 'const c=require("crypto"),b=x=>Buffer.from(JSON.stringify(x)).toString("base64url"),h=b({alg:"HS256"}),p=b({sub:"u1",role:process.argv[1]});console.log(h+"."+p+"."+c.createHmac("sha256","golden").update(h+"."+p).digest("base64url"))' "$1"; }
(cd $d && exec node dist/main.js >../http.log 2>&1) & pid=$!
trap 'kill $pid 2>/dev/null || true' EXIT
for i in $(seq 30); do curl -s localhost:3917/x >/dev/null 2>&1 && break; sleep 0.3; done
code() { curl -s -o "$G/body.json" -w '%{http_code}' "$@"; }
A=localhost:3917/api/v1/admin/rides
[ "$(code localhost:3917/health)" = 200 ] && grep -q '"ok"' $G/body.json && ok "health enveloppé" || ko "health"
[ "$(code $A)" = 401 ] && grep -q '"UNAUTHORIZED"' $G/body.json && ok "401 enveloppé" || ko "401"
[ "$(code -H "Authorization: Bearer $(tok user)" $A)" = 403 ] && grep -q '"FORBIDDEN"' $G/body.json && ok "403 enveloppé" || ko "403"
[ "$(code -H "Authorization: Bearer $(tok admin)" "$A?status=NOPE")" = 400 ] && grep -q '"VALIDATION_ERROR"' $G/body.json && ok "400 validation enveloppée" || { cat $G/body.json; ko "400"; }
[ "$(curl -s -D $G/hdr.txt -o $G/body.json -w '%{http_code}' -H "Authorization: Bearer $(tok admin)" "$A")" = 200 ] && grep -q 'v>s' $G/body.json && grep -q '"golden-msg"' $G/body.json && grep -q '"warnings":\[{"title":"w"' $G/body.json && grep -q '"pagination":{"current_page":1' $G/body.json && grep -qi '^x-golden: 1' $G/hdr.txt && ok "enveloppe ApiResult : message, warnings, pagination, en-têtes" && ok "handlers exécutés dans l'ordre, skip = fait" || { cat $G/body.json; ko "pipeline"; }
grep -q 'rides.paginate_results' $G/http.log && ok "étape low manquante → warn, exécution" || { cat $G/http.log; ko "warn low"; }
# contraintes du contrat appliquées par les DTO : @Min/@Max (query), rejet 400 enveloppé
rv=$(find $d/src -name 'get-admin-reviews.dto.ts'); grep -q '@Min(1)' $rv && grep -q '@Max(5)' $rv && ok "DTO : minimum/maximum → @Min/@Max" || ko "DTO min/max"
[ "$(code -H "Authorization: Bearer $(tok admin)" "localhost:3917/api/v1/admin/reviews?rating=9")" = 400 ] && grep -q '"VALIDATION_ERROR"' $G/body.json && ok "rating=9 > maximum → 400 VALIDATION_ERROR" || { cat $G/body.json; ko "maximum non appliqué"; }
grep -rqE '@(MinLength|MaxLength|Matches)\(' $d/src && ok "DTO : minLength/maxLength/pattern appliqués" || ko "DTO longueurs/pattern"
grep -rq '@ArrayMinSize(1)' $d/src && grep -rq '@ArrayMaxSize(' $d/src && ok "DTO : minItems/maxItems → @ArrayMinSize/@ArrayMaxSize" || ko "DTO minItems/maxItems"
B=localhost:3917/api/v1/admin/bookings
[ "$(code -H "Authorization: Bearer $(tok admin)" "$B")" = 501 ] && grep -q '"NOT_READY"' $G/body.json && grep -q 'étapes manquantes' $G/body.json && ok "usecase neuf → 501 NOT_READY enveloppé" || { cat $G/body.json; ko "NOT_READY"; }
grep -Eq '[0-9]+/[0-9]+ usecases prêts' $G/http.log && ok "rapport de démarrage" || { cat $G/http.log; ko "reporter"; }

[ "$(code -H "Authorization: Bearer $(tok admin)" localhost:3917/api/v1/admin/cities)" = 500 ] && ok "steps + run() → 500 explicite" || { cat $G/body.json; ko "steps+run"; }
grep -q 'steps ET run()' $G/http.log && ok "message steps ET run() journalisé" || ko "log steps+run"

# guide d'utilisation placé après la classe
g=$(find $d/src -name 'get-admin-rides.usecase.ts'); [ "$(grep -n "^export class" $g | cut -d: -f1)" -lt "$(grep -n "GUIDE D'UTILISATION" $g | cut -d: -f1)" ] && ok "guide d'utilisation après la classe" || ko "guide"
# endpoint paginé sans .paged() → tsc échoue
cp $uc $uc.keep
dto=$(find $d/src -name 'get-admin-rides.dto.ts'); r=$(node -e 'console.log(require("path").relative(require("path").dirname(process.argv[1]), process.argv[2]).replace(/\.ts$/,""))' "$uc" "$dto")
echo "const _np: import(\"$r\").GetAdminRidesOutput = result(null as any);" >> $uc
(cd $d && ../../$BIN/tsc --noEmit -p . >/dev/null 2>&1) && ko "pagination non exigée" || ok "endpoint paginé sans .paged() → tsc échoue"
mv $uc.keep $uc

# dérive : un step ajouté à la spec casse la compilation du stub
sed -i.bak 's|^export const GetAdminRidesSteps = \[|&{ code: "x.new", order: 99, severity: "low", description: "d" },|' $(find $d/src -name 'get-admin-rides.dto.ts')
(cd $d && ../../$BIN/tsc --noEmit -p . >/dev/null 2>&1) && ko "dérive non détectée" || ok "step manquant dans le stub → tsc échoue"
# OpenAPI : noms des composants factorisés = ressource (jamais Data, Data2…), `title` du contrat honoré
for t in none title; do
  nv=$G/names-$t; ruby golden-names-fixture.rb $nv $([ $t = title ] && echo Offer)
  ruby ../contracts_to_openapi.rb $nv --parts-out $nv/p --out $nv/o >$G/last.log 2>&1 || { cat $G/last.log; ko "openapi noms ($t)"; }
  names=$(ruby -ryaml -e 'puts YAML.load(File.read(ARGV[0]))["components"]["schemas"].keys.join(" ")' $nv/o/openapi.pro.yml)
  [[ " $names " == *" Offer "* && " $names " == *" Article "* && ! "$names" =~ Data ]] && ok "openapi noms ($t) : Offer, Article, pas de Data*" || ko "openapi noms ($t) : $names"
done
# versioning header : X-API-Version à la place de /vN dans l'URL, tsc + e2e (mocks traduits)
rm -rf $G/vh && cp -R $V $G/vh && sed -i.bak 's/"versioning": "uri"/"versioning": "header"/' $G/vh/input/export-configs/nestjs.json && rm $G/vh/input/export-configs/nestjs.json.bak
$BIN/tsx gen_nestjs.ts $G/vh --out $G/hdr --architecture ddd_layered --auth jwt >$G/last.log 2>&1 || { cat $G/last.log; ko "génération header"; }
grep -q 'VersioningType.HEADER' $G/hdr/src/main.ts && (cd $G/hdr && ../../$BIN/tsc --noEmit -p . && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -30 $G/hdr/e2e.log; ko "versioning header"; }
ok "versioning header : tsc + e2e"
# validation none : ni ValidationPipe, ni class-validator (DTO sans décorateurs), tsc + e2e
rm -rf $G/vn && cp -R $V $G/vn && sed -i.bak 's/"validation": "class_validator"/"validation": "none"/' $G/vn/input/export-configs/nestjs.json && rm $G/vn/input/export-configs/nestjs.json.bak
$BIN/tsx gen_nestjs.ts $G/vn --out $G/vnone --architecture ddd_layered --auth jwt >$G/last.log 2>&1 || { cat $G/last.log; ko "génération validation none"; }
[ ! -e $G/vnone/src/core/validation.ts ] && ! grep -rq "class-validator" $G/vnone/src $G/vnone/package.json || ko "validation none : traces de class-validator"
(cd $G/vnone && ../../$BIN/tsc --noEmit -p . && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -30 $G/vnone/e2e.log; ko "validation none"; }
ok "validation none : tsc + e2e"
# validation zod : static schema par DTO, pipe zod, pas de class-validator ; tsc + e2e
rm -rf $G/vz && cp -R $V $G/vz && sed -i.bak 's/"validation": "class_validator"/"validation": "zod"/' $G/vz/input/export-configs/nestjs.json && rm $G/vz/input/export-configs/nestjs.json.bak
$BIN/tsx gen_nestjs.ts $G/vz --out $G/vzod --architecture ddd_layered --auth jwt >$G/last.log 2>&1 || { cat $G/last.log; ko "génération validation zod"; }
grep -q '"zod"' $G/vzod/package.json && grep -q 'static schema = z.strictObject' -r $G/vzod/src && ! grep -rq "class-validator\|class-transformer" $G/vzod/src $G/vzod/package.json || ko "validation zod : deps/schemas"
(cd $G/vzod && ../../$BIN/tsc --noEmit -p . && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -30 $G/vzod/e2e.log; ko "validation zod"; }
ok "validation zod : tsc + e2e"
# httpAdapter fastify : platform-fastify (ni express ni @types/express), adaptateur au corps JSON vide tolérant, route Better Auth Fetch ; tsc + e2e × jwt/better_auth
rm -rf $G/hf && cp -R $V $G/hf && sed -i.bak 's/"httpAdapter": "express"/"httpAdapter": "fastify"/' $G/hf/input/export-configs/nestjs.json && rm $G/hf/input/export-configs/nestjs.json.bak
for u in jwt better_auth; do
  d=$G/fastify-$u
  $BIN/tsx gen_nestjs.ts $G/hf --out $d --architecture ddd_layered --auth $u >$G/last.log 2>&1 || { cat $G/last.log; ko "génération fastify $u"; }
  grep -q '"@nestjs/platform-fastify"' $d/package.json && ! grep -rq "platform-express\|@types/express" $d/src $d/test $d/package.json && [ -f $d/src/core/fastify.ts ] || ko "fastify $u : deps/fichiers"
  [ "$u" != better_auth ] || grep -q 'auth.handler(new Request' $d/src/main.ts || ko "fastify : route Better Auth"
  (cd $d && ../../$BIN/tsc --noEmit -p . && ../../$BIN/jest --config test/jest-e2e.json --runInBand >e2e.log 2>&1) || { tail -30 $d/e2e.log; ko "fastify $u"; }
  ok "fastify × $u : tsc + e2e $(grep -E '^Tests:' $d/e2e.log | sed 's/Tests: *//')"; rm -f $d/e2e.log
done
# packageManager npm : plus aucun « pnpm » dans le projet généré, commandes en npm run / npx
rm -rf $G/pmn && cp -R $V $G/pmn && sed -i.bak 's/"packageManager": "pnpm"/"packageManager": "npm"/' $G/pmn/input/export-configs/nestjs.json && rm $G/pmn/input/export-configs/nestjs.json.bak
$BIN/tsx gen_nestjs.ts $G/pmn --out $G/pmn-out --architecture ddd_layered --auth jwt >$G/last.log 2>&1 || { cat $G/last.log; ko "génération packageManager npm"; }
! grep -rqE 'pnpm( |$)' $G/pmn-out --exclude-dir=node_modules && grep -q 'npm run dev' $G/pmn-out/README.md || ko "packageManager npm : traduction"
ok "packageManager npm : commandes traduites"
# yarn / bun : install + tsc + e2e avec le gestionnaire réel (ignoré s'il n'est pas installé sur la machine)
for pm in yarn bun; do
  command -v $pm >/dev/null || { echo "--  packageManager $pm : $pm absent, ignoré"; continue; }
  rm -rf $G/pm-$pm && cp -R $V $G/pm-$pm && sed -i.bak "s/\"packageManager\": \"pnpm\"/\"packageManager\": \"$pm\"/" $G/pm-$pm/input/export-configs/nestjs.json && rm $G/pm-$pm/input/export-configs/nestjs.json.bak
  $BIN/tsx gen_nestjs.ts $G/pm-$pm --out $G/pm-$pm-out --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération packageManager $pm"; }
  (cd $G/pm-$pm-out && $pm install >install.log 2>&1 && $pm run typecheck >tsc.log 2>&1 && $pm run test:e2e >e2e.log 2>&1) || { tail -30 $G/pm-$pm-out/*.log; ko "packageManager $pm : install/tsc/e2e"; }
  ok "packageManager $pm : install, tsc, e2e — $(grep -E '^Tests:' $G/pm-$pm-out/e2e.log | sed 's/Tests: *//')"
done
# exceptionFilter / pagination retirés : une clé restante est signalée « clé inconnue »
rm -rf $G/rm-ef && cp -R $V $G/rm-ef && sed -i.bak 's/"responseEnvelope": true,/"responseEnvelope": true, "exceptionFilter": true,/' $G/rm-ef/input/export-configs/nestjs.json && rm $G/rm-ef/input/export-configs/nestjs.json.bak
[[ "$(ruby ../export_configs.rb $G/rm-ef 2>&1)" == *"clé inconnue exceptionFilter"* ]] && ok "exceptionFilter retiré : clé inconnue signalée" || ko "exceptionFilter clé inconnue"
# app sans API (api: false) : sortie standalone (createApplicationContext), déclencheurs cron/queue/event, refus des options HTTP, fusion avec une app HTTP
wk=$G/wk; cp -R $V $wk; w=$wk/input
perl -0pi -e 's/(  - slug: admin\n    modules: \[[^\]]*\]\n)/$1  - slug: worker\n    modules: [jobs]\n/; s/(modules:\n)/$1  - { app: worker, slug: jobs }\n/' $w/project.parts/_index.yml
perl -0pi -e 's/"authUserTable": "[^"]*",?//; s/"authDefaultRole": "[^"]*",?//; s/"authUserFields": \{[^}]*\},?//; s/"rls": "session"/"rls": "none"/' $w/export-configs/nestjs.json
cp golden/worker/project.parts/apps/* $w/project.parts/apps/; cp golden/worker/project.parts/modules/* $w/project.parts/modules/; cp golden/worker/nestjs.worker.json $w/export-configs/
mkdir -p $w/usecases/producer/worker && cp golden/worker/usecases/* $w/usecases/producer/worker/
$BIN/tsx gen_nestjs.ts $wk --out $G/wk-out --app worker --level N1 >$G/last.log 2>&1 || { cat $G/last.log; ko "génération app sans API"; }
# deps absentes du node_modules du générateur : seuls ces TS2307 sont tolérés (installées en validation réelle)
[ -z "$(cd $G/wk-out && ../../$BIN/tsc --noEmit -p . | grep -vE "TS2307: Cannot find module '(@nestjs/schedule|@nestjs/bullmq|bullmq)'")" ] || ko "tsc app sans API"
m=$G/wk-out/src/main.ts; l=$G/wk-out/src/modules/ddd_layered/jobs/application/listeners
grep -q createApplicationContext $m && ! grep -q 'listen(' $m && ! grep -q platform-express $G/wk-out/package.json && grep -q '@Cron("\*/1' $l/purge-expired-trigger.listener.ts && grep -q '@Processor("send-digest")' $l/send-digest-trigger.listener.ts && grep -q '@OnEvent("user.created")' $l/on-user-created-trigger.listener.ts || ko "app sans API : main/cron/queue/event"
ok "app sans API : standalone, tsc, cron + queue + event"
# fusion (sans --app) : une app api:true dans la sortie => process HTTP, le worker tourne à côté des routes
mx=$G/wk-mx; cp -R $wk $mx; perl -0pi -e 's/"queue": "none"/"queue": "bullmq"/' $mx/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $mx --out $G/wk-mixed --level N1 --auth none >$G/last.log 2>&1 || { cat $G/last.log; ko "génération fusionnée api:true + api:false"; }
grep -q 'listen(' $G/wk-mixed/src/main.ts && ! grep -q createApplicationContext $G/wk-mixed/src/main.ts && ok "fusion api:true + api:false : main.ts HTTP, worker dans le process" || ko "fusion : main.ts"
sed -i.bak 's/"queue": "bullmq", //' $w/export-configs/nestjs.worker.json; rm $w/export-configs/nestjs.worker.json.bak
$BIN/tsx gen_nestjs.ts $wk --out $G/wk-noq --app worker --level N1 >$G/last.log 2>&1 && ko "trigger.queue sans queue: bullmq accepté"
sed -i.bak 's/"auth": "none"/"auth": "jwt"/' $w/export-configs/nestjs.worker.json; rm $w/export-configs/nestjs.worker.json.bak
$BIN/tsx gen_nestjs.ts $wk --out $G/wk-auth --app worker --level N1 >$G/last.log 2>&1 && ko "auth jwt accepté pour une app sans API"
ok "app sans API : queue sans bullmq et auth HTTP refusés"
# orm prisma : schéma dérivé copié (prisma/schema/), adaptateur de pilote, un repository par modèle ; prisma generate réel + tsc, idempotence ; Better Auth + Prisma
pr=$G/v0p; cp -R $V $pr; perl -pi -e 's/"orm": "drizzle"/"orm": "prisma"/; s/"rls": "session"/"rls": "none"/' $pr/input/export-configs/nestjs.json
for dp in postgresql:pg postgresql:neon mysql:mysql2 sqlite:better_sqlite3; do
  d=${dp%%:*} p=${dp##*:}; o=$G/prisma-$d-$p
  $BIN/tsx gen_nestjs.ts $pr --out $o --architecture ddd_layered --auth none --level N2 --database $d --db-provider $p >$G/last.log 2>&1 || { cat $G/last.log; ko "génération prisma $d/$p"; }
  nm=$(grep -c '^model ' $o/prisma/schema/schema.prisma); nr=$(ls $o/src/database/repositories | grep -vc base)
  [ "$nm" = "$nr" ] && [ "$nm" -gt 0 ] || ko "prisma $d/$p : $nr repositories pour $nm modèles"
  (cd $o && ../../$BIN/prisma generate >/dev/null 2>&1 && ../../$BIN/tsc --noEmit -p .) || ko "prisma generate + tsc $d/$p"
  before=$(find $o -type f -not -path '*/generated/*' | sort | xargs shasum | shasum); $BIN/tsx gen_nestjs.ts $pr --out $o --architecture ddd_layered --auth none --level N2 --database $d --db-provider $p >/dev/null 2>&1
  [ "$before" = "$(find $o -type f -not -path '*/generated/*' | sort | xargs shasum | shasum)" ] || ko "idempotence prisma $d/$p"
  ok "orm prisma × $d/$p : $nm repositories, prisma generate, tsc, idempotent"
done
grep -q "PrismaPg" $G/prisma-postgresql-pg/src/database/prisma.ts && grep -q "PrismaNeon" $G/prisma-postgresql-neon/src/database/prisma.ts && grep -q "PrismaMariaDb" $G/prisma-mysql-mysql2/src/database/prisma.ts && grep -q "PrismaBetterSqlite3" $G/prisma-sqlite-better_sqlite3/src/database/prisma.ts && ok "orm prisma : adaptateur de pilote par moteur/provider" || ko "adaptateurs prisma"
ob=$G/prisma-ba; $BIN/tsx gen_nestjs.ts $pr --out $ob --architecture ddd_layered --auth better_auth --level N2 --db-provider pg >$G/last.log 2>&1 || { cat $G/last.log; ko "génération prisma + better_auth"; }
grep -q 'prismaAdapter' $ob/src/better-auth/auth.ts && grep -q 'auth generate --adapter prisma' $ob/package.json && [ -f $ob/scripts/auth-schema.mjs ] && [ ! -f $ob/src/better-auth/schema.ts ] || ko "prisma + better_auth : fichiers"
(cd $ob && ../../$BIN/prisma generate >/dev/null 2>&1 && ../../$BIN/tsc --noEmit -p .) || ko "tsc prisma + better_auth"
ok "orm prisma × better_auth : prismaAdapter, auth:generate prisma, tsc"

# orm typeorm : entités dérivées copiées (src/database/entities.ts), DataSource par moteur/provider, un repository par entité ; tsc, idempotence ; Better Auth + TypeORM (adaptateur Kysely) ; refus authUserTable / rls session
ty=$G/v0t; cp -R $V $ty; perl -pi -e 's/"orm": "drizzle"/"orm": "typeorm"/; s/"rls": "session"/"rls": "none"/; s/"authUserTable": "[^"]*",?//; s/"authDefaultRole": "[^"]*",?//; s/"authUserFields": \{[^}]*\},?//' $ty/input/export-configs/nestjs.json
for dp in postgresql:pg postgresql:neon mysql:mysql2 sqlite:better_sqlite3; do
  d=${dp%%:*} p=${dp##*:}; o=$G/typeorm-$d-$p
  $BIN/tsx gen_nestjs.ts $ty --out $o --architecture ddd_layered --auth none --level N2 --database $d --db-provider $p >$G/last.log 2>&1 || { cat $G/last.log; ko "génération typeorm $d/$p"; }
  ne=$(grep -c '^@Entity(' $o/src/database/entities.ts); nr=$(ls $o/src/database/repositories | grep -vc base)
  [ "$ne" = "$nr" ] && [ "$ne" -gt 0 ] || ko "typeorm $d/$p : $nr repositories pour $ne entités"
  (cd $o && ../../$BIN/tsc --noEmit -p .) || ko "tsc typeorm $d/$p"
  before=$(find $o -type f | sort | xargs shasum | shasum)
  $BIN/tsx gen_nestjs.ts $ty --out $o --architecture ddd_layered --auth none --level N2 --database $d --db-provider $p >$G/last.log 2>&1
  [ "$before" = "$(find $o -type f | sort | xargs shasum | shasum)" ] || ko "idempotence typeorm $d/$p"
  ok "orm typeorm × $d/$p : $ne repositories, tsc, idempotent"
done
grep -q 'type: "postgres"' $G/typeorm-postgresql-pg/src/database/data-source.ts && grep -q 'type: "mysql"' $G/typeorm-mysql-mysql2/src/database/data-source.ts && grep -q 'type: "better-sqlite3"' $G/typeorm-sqlite-better_sqlite3/src/database/data-source.ts || ko "typeorm : type de DataSource par moteur"
ok "orm typeorm : DataSource par moteur/provider"
ob=$G/typeorm-ba; $BIN/tsx gen_nestjs.ts $ty --out $ob --architecture ddd_layered --auth better_auth --level N2 --db-provider pg >$G/last.log 2>&1 || { cat $G/last.log; ko "génération typeorm + better_auth"; }
grep -q 'createAuthDb()' $ob/src/better-auth/auth.ts && grep -q '"auth:migrate"' $ob/package.json && grep -q 'auth:migrate' $ob/package.json && [ -f $ob/src/database/auth-db.ts ] && [ ! -f $ob/src/better-auth/schema.ts ] || ko "typeorm + better_auth : adaptateur Kysely"
(cd $ob && ../../$BIN/tsc --noEmit -p .) || ko "tsc typeorm + better_auth"
ok "orm typeorm × better_auth : adaptateur Kysely, auth:migrate, tsc"
perl -pi -e 's/"orm": "typeorm"/"orm": "typeorm", "authUserTable": "users"/' $ty/input/export-configs/nestjs.json
$BIN/tsx gen_nestjs.ts $ty --out $G/typeorm-aut --architecture ddd_layered --auth better_auth --level N2 >$G/last.log 2>&1 && ko "typeorm : authUserTable accepté"
ok "orm typeorm : authUserTable refusé"

echo "golden NestJS : tout est ok"
