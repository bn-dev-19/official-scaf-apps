// Tests e2e dérivés des mocks des contrats (given/expect) : une donnée JSON par module + un lanceur unique + un harnais d'auth par adaptateur.
import type { GeneratedFile } from "../../_shared/generated-file";
import { HEADER } from "../../_shared/_lib/header";
import { roleOf } from "./architectures";
import type { ModuleIR } from "./ir";

export interface E2eCfg {
  fastify?: boolean; validation?: boolean; auth: string; globalPrefix: string; versioning?: string;
  /** Variables d'environnement lues à l'import de l'app (secret, URL, base) : valeurs factices posées avant le chargement. */
  env: Record<string, string>;
  /** rateLimiting : le throttler est neutralisé dans le harness (les mocks d'un endpoint se rejouent depuis la même IP). */
  rateLimiting?: boolean;
  /** cache redis : `@nestjs/cache-manager` / `@keyv/redis` (ESM seuls) sont transpilés par ts-jest (allowJs + transformIgnorePatterns) : vrais modules sous jest CommonJS, connexion Redis paresseuse (REDIS_URL factice sans Redis = OK). */
  cache?: boolean;
  /** testFramework : jest (défaut, ts-jest) ou vitest (unplugin-swc : metadata de décorateurs pour l'injection Nest). */
  framework?: string;
}
/** Un cas = un mock : requête concrète + attendu minimal (statut, success, code d'erreur). `as` : null = anonyme, sinon rôles du jeton. */
export interface E2eCase { endpoint: string; name: string; method: string; path: string; query?: unknown; body?: unknown; as: string[] | null; status: number; success: boolean; code?: string; g?: true }

export const e2eDevDeps = (fw?: string) => fw === "vitest" ? ["vitest", "unplugin-swc", "@swc/core", "@nestjs/testing"] : ["jest", "ts-jest", "@types/jest", "@nestjs/testing"];
export const e2eScripts = (fw?: string) => ({ "test:e2e": fw === "vitest" ? "vitest run --config test/vitest-e2e.config.ts" : "jest --config test/jest-e2e.json --runInBand" });

/** 5xx / 429 / 413 : non reproductibles depuis l'extérieur. Hors adaptateur `none`, 401/403 sont testables. */
const skipped = (status: number, auth: string) => status >= 500 || status === 429 || status === 413 || (auth === "none" && (status === 401 || status === 403));

export function e2eCases(modules: ModuleIR[], auth: string): { byModule: Map<string, E2eCase[]>; skipped: number } {
  const byModule = new Map<string, E2eCase[]>(); let skip = 0;
  for (const m of modules) {
    const cases: E2eCase[] = [];
    for (const e of m.endpoints) for (const mk of e.mocks) {
      const g = (mk.given ?? {}) as { method?: string; path?: string; headers?: Record<string, string>; query?: unknown; body?: unknown };
      const body = (mk.expect.body ?? {}) as { success?: boolean; error?: { code?: string } };
      if (!g.path || skipped(mk.expect.status, auth)) { skip++; continue; }
      const authed = !!g.headers?.Authorization || !!g.headers?.authorization;
      const role = e.guard ? roleOf(e.guard) ?? "user" : "user";
      cases.push({
        endpoint: e.id, name: mk.name, method: (g.method ?? e.method).toUpperCase(), path: g.path,
        ...(g.query && Object.keys(g.query as object).length ? { query: g.query } : {}), ...(g.body != null ? { body: g.body } : {}),
        as: authed && mk.expect.status !== 401 ? [mk.expect.status === 403 ? "__aucun__" : role] : null,
        status: mk.expect.status, success: body.success ?? mk.expect.status < 400, ...(body.error?.code ? { code: body.error.code } : {}),
        // g = garanti par le socle même usecase non prêt : garde d'authentification (401) / de rôle (403)
        ...((mk.expect.status === 401 && e.guard) || (mk.expect.status === 403 && e.guard && e.guard !== "RequireAuth") ? { g: true as const } : {}),
      });
    }
    if (cases.length) byModule.set(m.key, cases);
  }
  return { byModule, skipped: skip };
}

const HARNESS_AUTH: Record<string, { imports: string; setup: string; override: string; bearer: string }> = {
  none: { imports: "", setup: "", override: "", bearer: "  return {};" },
  jwt: {
    imports: 'import { createHmac } from "node:crypto";\n', setup: 'process.env.JWT_SECRET ||= "e2e-secret";\n', override: "",
    bearer: `  if (!roles) return {};
  const b = (x: object) => Buffer.from(JSON.stringify(x)).toString("base64url");
  const h = b({ alg: "HS256", typ: "JWT" }), p = b({ sub: "e2e-user", roles });
  return { authorization: \`Bearer \${h}.\${p}.\${createHmac("sha256", process.env.JWT_SECRET!).update(\`\${h}.\${p}\`).digest("base64url")}\` };`,
  },
  better_auth: {
    imports: "", setup: '// better-auth est ESM-only (jest CommonJS ne le charge pas) et exige une base :\n// l\'instance est remplacée, seul l\'AuthPort compte ici.\njest.mock("../../src/better-auth/auth", () => ({ auth: {} }));\n',
    // Better Auth exige une base et de vraies sessions : l'AuthPort est remplacé par un faux (rôles lus dans le jeton `e2e:<rôles>`), les gardes restent les vrais.
    override: `  builder.overrideProvider(AUTH_PORT).useValue({
    async authenticate(req: any) {
      const m = /^Bearer e2e:(.*)$/.exec(req.headers?.authorization ?? "");
      return m ? { id: "e2e-user", roles: m[1].split(",").filter(Boolean) } : null;
    },
    hasRole: (u: { roles: string[] }, r: string) => u.roles.includes(r),
  });
`,
    bearer: '  return roles ? { authorization: `Bearer e2e:${roles.join(",")}` } : {};',
  },
};

export function e2eFiles(modules: ModuleIR[], c: E2eCfg): GeneratedFile[] {
  const { byModule } = e2eCases(modules, c.auth);
  const vt = c.framework === "vitest";
  const a0 = HARNESS_AUTH[c.auth] ?? HARNESS_AUTH.none;
  // vitest : vi.mock (better-auth n'est plus ESM-only ici, mais exige toujours une base : l'instance est remplacée)
  const a = vt && a0.setup.includes("jest.mock") ? { ...a0, imports: 'import { vi } from "vitest";\n' + a0.imports, setup: a0.setup.replace("jest.mock(", "vi.mock(").replace(/\/\/ better-auth est ESM-only[^\n]*\n/, "// better-auth exige une base :\n") } : a0;
  const env = Object.entries(c.env).map(([k, v]) => `process.env.${k} ||= ${JSON.stringify(v)};\n`).join("");
  const f = (path: string, content: string): GeneratedFile => ({ path, content: HEADER + content });
  return [
    ...[...byModule].map(([k, cases]): GeneratedFile => ({ path: `test/e2e/mocks/${k}.json`, content: JSON.stringify(cases, null, 2) + "\n" })),
    ...(vt ? [f("test/vitest-e2e.config.ts", `import swc from "unplugin-swc";
import { defineConfig } from "vitest/config";

// unplugin-swc : emitDecoratorMetadata (injection de dépendances Nest), lu depuis tsconfig.json.
export default defineConfig({
  plugins: [swc.vite()],
  test: { include: ["test/**/*.e2e-spec.ts"], environment: "node", testTimeout: 120000, hookTimeout: 120000, fileParallelism: false },
});
`)] : [{ path: "test/jest-e2e.json", content: JSON.stringify({
      rootDir: ".", testRegex: "\\.e2e-spec\\.ts$", testEnvironment: "node", testTimeout: 120000, ...(c.cache ? { transformIgnorePatterns: ["node_modules/(?!.*(@nestjs[+/]cache-manager|cache-manager|keyv|@keyv|cacheable|@cacheable|hookified|@redis|cluster-key-slot|generic-pool|redis))"] } : {}), moduleFileExtensions: c.cache ? ["js", "mjs", "json", "ts"] : ["js", "json", "ts"],
      transform: { [c.cache ? "^.+\\.m?[tj]s$" : "^.+\\.ts$"]: ["ts-jest", { tsconfig: { ...(c.cache ? { allowJs: true } : {}), target: "ES2022", module: "commonjs", moduleResolution: "node10", strict: true, strictPropertyInitialization: false, experimentalDecorators: true, emitDecoratorMetadata: true, esModuleInterop: true, resolveJsonModule: true, skipLibCheck: true, types: ["node", "jest"] } }] },
    }, null, 2) + "\n" }]),
    f("test/e2e/harness.ts", `import "reflect-metadata";
import { readFileSync } from "node:fs";
${a.imports}import { VersioningType } from "@nestjs/common";
${c.rateLimiting ? 'import { ThrottlerGuard } from "@nestjs/throttler";\n' : ""}
import { Test } from "@nestjs/testing";
import type { ${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"} } from "@nestjs/platform-${c.fastify ? "fastify" : "express"}";
${c.fastify ? 'import { createFastifyAdapter } from "../../src/core/fastify";\n' : ""}
import { AUTH_PORT } from "../../src/core/auth/auth.port";
${c.validation === false ? "" : 'import { validationPipe } from "../../src/core/validation";\n'}
// .env chargé s'il existe (vraie base : les usecases implémentés interrogent la base) ;
// sinon valeurs factices, lues à l'import de l'app (aucune connexion n'est ouverte
// tant qu'un usecase n'interroge pas la base : usecases pas prêts = 501, non évalués).
// Lecture manuelle : process.loadEnvFile() n'alimente pas le process.env du bac à sable de jest.
try {
  for (const l of readFileSync(".env", "utf8").split(/\\r?\\n/)) {
    const m = /^\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.*?)\\s*$/.exec(l);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^(["'])(.*)\\1$/, "$2");
  }
} catch { /* pas de .env : valeurs factices ci-dessous */ }
${env}${a.setup}
/** Démarre l'app comme main.ts (préfixe, version, validation ; filtre/intercepteur/garde viennent de CoreModule). */
export async function boot(): Promise<{ app: ${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"}; base: string }> {
  const { AppModule } = await import("../../src/app.module");
  const builder = Test.createTestingModule({ imports: [AppModule] });
${a.override}${c.rateLimiting ? "  builder.overrideProvider(ThrottlerGuard).useValue({ canActivate: () => true }); // l'e2e ne teste pas le débit\n" : ""}  const mod = await builder.compile();
  const app = mod.createNestApplication<${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"}>(${c.fastify ? "createFastifyAdapter()" : ""});
${c.globalPrefix ? `  app.setGlobalPrefix(${JSON.stringify(c.globalPrefix)});\n` : ""}${c.versioning === "uri" ? "  app.enableVersioning({ type: VersioningType.URI });\n" : c.versioning === "header" ? '  app.enableVersioning({ type: VersioningType.HEADER, header: "X-API-Version" });\n' : ""}${c.validation === false ? "" : "  app.useGlobalPipes(validationPipe());\n"}  await app.listen(0);
  return { app, base: await app.getUrl() };
}

/** En-tête d'authentification pour des rôles donnés (null = anonyme), selon l'adaptateur ${c.auth}. */
export function bearer(roles: string[] | null): Record<string, string> {
${a.bearer}
}
`),
    f("test/e2e/contracts.e2e-spec.ts", `// Un test par mock des contrats (given → requête, expect → statut / success / code d'erreur).
// Données : test/e2e/mocks/<module>.json.
${vt ? 'import { afterAll, beforeAll, describe, expect, it } from "vitest";\n' : ""}import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { ${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"} } from "@nestjs/platform-${c.fastify ? "fastify" : "express"}";
${c.fastify ? 'import { createFastifyAdapter } from "../../src/core/fastify";\n' : ""}
import { boot, bearer } from "./harness";

interface Case {
  endpoint: string;
  name: string;
  method: string;
  path: string;
  query?: Record<string, unknown>;
  body?: unknown;
  as: string[] | null;
  status: number;
  success: boolean;
  code?: string;
  g?: boolean;
}
const dir = join(__dirname, "mocks");
let app: ${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"}, base: string, notReady = 0, unvalidated = 0;

beforeAll(async () => { ({ app, base } = await boot()); });
afterAll(async () => {
  await app.close();
  if (notReady) console.warn(\`[e2e] \${notReady} mock(s) non évalué(s) : usecase NOT_READY (501), à implémenter\`);
  if (unvalidated) {
    console.warn(
      \`[e2e] \${unvalidated} mock(s) VALIDATION_ERROR non rejeté(s) par les DTO : \` +
        "contrainte non gérée (minItems…) ou non exprimée au contrat, ou mock valide",
    );
  }
});

for (const file of readdirSync(dir).filter(f => f.endsWith(".json")).sort()) {
  describe(file.replace(/\\.json$/, ""), () => {
    for (const c of JSON.parse(readFileSync(join(dir, file), "utf8")) as Case[]) {
      it(\`\${c.endpoint} · \${c.name}\`, async () => {
${c.versioning === "header" ? `        // versioning header : la version du contrat (/vN/) part dans X-API-Version, hors de l'URL
        const vm = /^${c.globalPrefix ? "\\/" + c.globalPrefix : ""}\\/v([^/]+)\\//.exec(c.path);
        const url = new URL(vm ? c.path.replace("/v" + vm[1] + "/", "/") : c.path, base);` : "        const url = new URL(c.path, base);"}
        for (const [k, v] of Object.entries(c.query ?? {})) {
          for (const x of ([] as unknown[]).concat(v)) url.searchParams.append(k, String(x));
        }
        const res = await fetch(url, {
          method: c.method, headers: { "content-type": "application/json", ...bearer(c.as)${c.versioning === "header" ? ', ...(vm ? { "x-api-version": vm[1] } : {})' : ""} },
          body: c.body != null && !["GET", "HEAD"].includes(c.method) ? JSON.stringify(c.body) : undefined,
        });
        const json: any = await res.json().catch(() => null);
        // Usecase pas prêt (501) : seules les gardes (c.g) sont garanties par le socle ;
        // une validation non rejetée est comptée à part, le reste attend l'implémentation.
        if (res.status === 501 && json?.error?.code === "NOT_READY" && !c.g) {
          if (c.code === "VALIDATION_ERROR") unvalidated++;
          else notReady++;
          return;
        }
        expect(res.status).toBe(c.status);
        expect(json?.success).toBe(c.success);
        if (c.code) expect(json?.error?.code).toBe(c.code);
      });
    }
  });
}
`),
  ];
}
