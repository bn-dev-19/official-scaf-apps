// DTO class-validator (query/params/body) + types de réponse + erreurs typées d'un endpoint. Indépendant de l'architecture.
import type { SpecProp } from "../../_shared/_lib/spec-types";
import { requiredFieldNames } from "../../_shared/_lib/yaml-utils";
import { isTsIdentifier } from "../../_shared/_lib/naming";
import type { EndpointIR, Param } from "./ir";
import { brk, jsdoc, obj } from "./fmt";

export function tsType(p: SpecProp | undefined, docs = false, ind = ""): string {
  if (!p) return "unknown";
  let t: string;
  if (p.enum?.length) t = p.enum.map(v => JSON.stringify(v)).join(" | ");
  else if (p.type === "array") t = `(${tsType(p.items, docs, ind)})[]`;
  else if (p.type === "object" && p.properties) {
    const req = requiredFieldNames(p.properties, p.required);
    const ents = Object.entries(p.properties);
    const f = (k: string, v: SpecProp, i: string) => `${key(k)}${req.includes(k) ? "" : "?"}: ${tsType(v, docs, i)}`;
    if (docs && ents.some(([, v]) => v.description)) {
      const i = ind + "  ";
      t = `{\n${ents.map(([k, v]) => `${v.description ? `${i}/** ${oneLine(v.description)} */\n` : ""}${i}${f(k, v, i)};\n`).join("")}${ind}}`;
    } else t = `{ ${ents.map(([k, v]) => f(k, v, ind)).join("; ")} }`;
  } else if (p.type === "object") t = "Record<string, unknown>";
  else t = ({ string: "string", integer: "number", number: "number", boolean: "boolean" } as Record<string, string>)[p.type ?? ""] ?? "unknown";
  return p.nullable ? `${t} | null` : t;
}
const oneLine = (d: string) => d.replace(/\s*\n\s*/g, " ").replace(/\*\//g, "*\\/").trim();
const key = (k: string) => (isTsIdentifier(k) ? k : JSON.stringify(k));

/** Enums longs (> 60 car. en ligne) : constante `export const XValues = [...] as const` multiligne, réutilisée par @IsIn, @ApiProperty et le type union. */
type EnumRef = { arr: string; sw: string; ts: string; named: boolean };
function enumRef(values: unknown[], id: string, consts: Map<string, string>): EnumRef {
  const lits = values.map(v => JSON.stringify(v));
  const inline = lits.join(", ");
  if (inline.length <= 60) return { arr: `[${inline}]`, sw: `[${inline}]`, ts: lits.join(" | "), named: false };
  const name = id + "Values";
  consts.set(name, `export const ${name} = [\n${lits.map(l => `  ${l},`).join("\n")}\n] as const;\n`);
  return { arr: name, sw: `[...${name}]`, ts: `(typeof ${name})[number]`, named: true };
}

/** Décorateurs class-validator/transformer d'une propriété. Contraintes du contrat : minimum/maximum, minLength/maxLength, pattern (@Matches), minItems/maxItems (@ArrayMinSize/@ArrayMaxSize) : toute contrainte déclarée = VALIDATION_ERROR ; une règle à code métier dédié (ex. WEAK_PASSWORD) ne se déclare pas sur le champ. ponytail: objets/tableaux imbriqués non validés en profondeur (@IsObject/@IsArray) */
function decorators(p: SpecProp, required: boolean, fromString: boolean, imp: Set<string>, ref: EnumRef | null): string[] {
  const d: string[] = [];
  const v = (n: string, args = "") => { imp.add(n); d.push(`@${n}(${args})`); };
  if (!required || p.nullable) v("IsOptional");
  if (p.enum?.length) v("IsIn", ref!.arr);
  else if (p.type === "integer" || p.type === "number") {
    if (fromString) { imp.add("Type"); d.push("@Type(() => Number)"); }
    v(p.type === "integer" ? "IsInt" : "IsNumber");
    if (typeof p.minimum === "number") v("Min", String(p.minimum));
    if (typeof p.maximum === "number") v("Max", String(p.maximum));
  }
  else if (p.type === "boolean") { if (fromString) { imp.add("Transform"); d.push(`@Transform(({ value }) => value === "true" || value === true)`); } v("IsBoolean"); }
  else if (p.type === "array") {
    v("IsArray");
    if (typeof p.minItems === "number") v("ArrayMinSize", String(p.minItems));
    if (typeof p.maxItems === "number") v("ArrayMaxSize", String(p.maxItems));
  }
  else if (p.type === "object") v("IsObject");
  else if (p.type === "string") {
    if (p.format === "email") v("IsEmail");
    else if (p.format === "uuid") v("IsUUID");
    else if (p.format === "date-time" || p.format === "date") v("IsISO8601");
    else v("IsString");
    if (typeof p.minLength === "number") v("MinLength", String(p.minLength));
    if (typeof p.maxLength === "number") v("MaxLength", String(p.maxLength));
    if (p.pattern) v("Matches", `new RegExp(${JSON.stringify(p.pattern)})`);
  }
  return d;
}

/** @ApiProperty(Optional) d'un champ décrit (le Swagger servi vient d'openapi.json ; ceci documente aussi les DTO). */
function api(p: SpecProp, required: boolean, imp: Set<string>, ref: EnumRef | null): string {
  if (!p.description) return "";
  const n = required ? "ApiProperty" : "ApiPropertyOptional";
  imp.add(n);
  const o = [`description: ${JSON.stringify(p.description.replace(/\s*\n\s*/g, " ").trim())}`, ref && `enum: ${ref.sw}`, p.nullable && "nullable: true"].filter((x): x is string => !!x);
  return `${obj(`@${n}(`, o, ")")}\n`;
}

const pascal = (s: string) => s.replace(/(^|[^a-zA-Z0-9]+)([a-zA-Z0-9])/g, (_, __, c: string) => c.toUpperCase());
const docLine = (d?: string) => (d ? jsdoc(oneLine(d)) : "");

/**
 * Type TS + options @ApiProperty d'un champ de réponse. Les objets (imbriqués ou éléments de tableau) deviennent des classes
 * poussées dans `out` AVANT leur parent (emitDecoratorMetadata évalue la classe à la déclaration : TDZ sinon).
 */
function outType(p: SpecProp | undefined, name: string, imp: Set<string>, out: string[], consts: Map<string, string>, root = false): { ts: string; sw: string[] } {
  if (!p) return { ts: "unknown", sw: [] };
  let ts: string; const sw: string[] = [];
  if (p.enum?.length) { const r = enumRef(p.enum, name, consts); ts = r.ts; sw.push(`enum: ${r.sw}`); if (p.enum.every(v => typeof v === "string")) sw.push("type: String"); }
  else if (p.type === "array") {
    const it = outType(p.items, root ? `${name}Item` : name, imp, out, consts);
    ts = `(${it.ts})[]`; sw.push(...it.sw.filter(x => x.startsWith("type:") || x.startsWith("enum:")), "isArray: true");
  } else if (p.type === "object" && p.properties) {
    outClass(name, p, imp, out, consts); ts = name; sw.push(`type: () => ${name}`);
  } else if (p.type === "object") { ts = "Record<string, unknown>"; sw.push("type: Object"); }
  else {
    ts = ({ string: "string", integer: "number", number: "number", boolean: "boolean" } as Record<string, string>)[p.type ?? ""] ?? "unknown";
    const t = ({ string: "String", integer: '"integer"', number: "Number", boolean: "Boolean" } as Record<string, string>)[p.type ?? ""];
    if (t) sw.push(`type: ${t}`);
    if (p.format) sw.push(`format: ${JSON.stringify(p.format)}`);
  }
  return { ts: p.nullable ? `${ts} | null` : ts, sw };
}

function outClass(name: string, spec: SpecProp, imp: Set<string>, out: string[], consts: Map<string, string>): void {
  const req = requiredFieldNames(spec.properties!, spec.required);
  const body = Object.entries(spec.properties!).map(([k, v]) => {
    const required = req.includes(k);
    const t = outType(v, name + pascal(k), imp, out, consts);
    const n = required ? "ApiProperty" : "ApiPropertyOptional"; imp.add(n);
    const o = [v.description && `description: ${JSON.stringify(oneLine(v.description))}`, ...t.sw, v.nullable && "nullable: true"].filter((x): x is string => !!x);
    return `${docLine(v.description)}${o.length ? obj(`@${n}(`, o, ")") : `  @${n}()`}\n  ${key(k)}${required ? "!" : "?"}: ${t.ts};\n`;
  }).join("\n");
  out.push(`export class ${name} {\n${body}}\n`);
}

/** validation: none → DTO sans décorateurs class-validator/transformer. ponytail: état de module posé par endpointDto. */
let validate = true;
/** validation: zod → `static schema` (zod) par DTO, lu par le pipe global (core/validation.ts) ; pas de décorateurs class-validator. ponytail: état de module, posé par setZod. */
let zod = false;
export const setZod = (b: boolean) => { zod = b; };

/** Schéma zod d'une propriété (mêmes contraintes que `decorators`). ponytail: objets/tableaux imbriqués non validés en profondeur. */
function zodProp(p: SpecProp, required: boolean, fromString: boolean, ref: EnumRef | null): string {
  let z: string;
  const n = (k: "minimum" | "maximum" | "minLength" | "maxLength" | "minItems" | "maxItems", m: string) => (typeof p[k] === "number" ? `.${m}(${p[k]})` : "");
  if (p.enum?.length) z = p.enum.every(v => typeof v === "string") ? `z.enum(${ref!.arr})` : `z.any().refine(v => (${ref!.arr} as readonly unknown[]).includes(v))`;
  else if (p.type === "integer" || p.type === "number") z = `${fromString ? "z.coerce.number()" : "z.number()"}${p.type === "integer" ? ".int()" : ""}${n("minimum", "min")}${n("maximum", "max")}`;
  else if (p.type === "boolean") z = fromString ? `z.preprocess(v => (v === "true" ? true : v === "false" ? false : v), z.boolean())` : "z.boolean()";
  else if (p.type === "array") z = `z.array(z.unknown())${n("minItems", "min")}${n("maxItems", "max")}`;
  else if (p.type === "object") z = "z.record(z.string(), z.unknown())";
  else {
    z = p.format === "email" ? "z.email()" : p.format === "uuid" ? "z.guid()" : "z.string()";
    if (p.format === "date-time" || p.format === "date") z += `.refine(v => !Number.isNaN(Date.parse(v)), "must be a valid ISO 8601 date string")`;
    z += n("minLength", "min") + n("maxLength", "max");
    if (p.pattern) z += `.regex(new RegExp(${JSON.stringify(p.pattern)}))`;
  }
  return !required ? `${z}.${p.nullable ? "nullish" : "optional"}()` : p.nullable ? `${z}.nullish()` : z;
}

function cls(name: string, props: { name: string; spec: SpecProp; required: boolean }[], fromString: boolean, imp: Set<string>, consts: Map<string, string>): string {
  const doc = (d?: string) => (d ? jsdoc(oneLine(d)) : "");
  const body = props.map(({ name: n, spec, required }) => {
    const ref = spec.enum?.length ? enumRef(spec.enum, name + pascal(n), consts) : null;
    const ts = ref?.named ? ref.ts + (spec.nullable ? " | null" : "") : tsType(spec);
    return `${doc(spec.description)}${api(spec, required, imp, ref)}${(validate && !zod ? decorators(spec, required, fromString, imp, ref) : []).map(x => `  ${x}\n`).join("")}  ${key(n)}${required ? "!" : "?"}: ${ts};\n`;
  }).join("\n");
  if (!zod || !validate) return `export class ${name} {\n${body}}\n`;
  imp.add("z");
  const shape = props.map(({ name: n, spec, required }) => `${key(n)}: ${zodProp(spec, required, fromString, spec.enum?.length ? enumRef(spec.enum, name + pascal(n), consts) : null)},`);
  return `export class ${name} {\n${body}\n  static schema = z.strictObject({\n${shape.map(x => `    ${x}`).join("\n")}\n  });\n}\n`;
}

export function endpointDto(ep: EndpointIR, coreRel: string, validation = true): string {
  validate = validation;
  const imp = new Set<string>();
  const consts = new Map<string, string>();
  const parts: string[] = [];
  if (ep.pathParams.length) {
    parts.push(cls(`${ep.pascal}Params`, ep.pathParams.map(n => ({ name: n, spec: ep.pathSpecs[n] ?? { type: "string" }, required: true })), true, imp, consts));
  }
  if (ep.query.length) parts.push(cls(`${ep.pascal}Query`, ep.query.map(({ required, ...spec }: Param) => ({ name: spec.name, spec, required })), true, imp, consts));
  if (ep.body?.properties) {
    const req = requiredFieldNames(ep.body.properties, ep.body.required);
    parts.push(cls(`${ep.pascal}Body`, Object.entries(ep.body.properties).map(([n, s]) => ({ name: n, spec: s, required: req.includes(n) })), false, imp, consts));
  } else if (ep.body) parts.push(`export type ${ep.pascal}Body = ${tsType(ep.body as SpecProp)};\n`);
  const outCls: string[] = [];
  const out = ep.data ? outType(ep.data, `${ep.pascal}Data`, imp, outCls, consts, true).ts : "void";
  parts.push(...outCls);
  parts.unshift(...consts.values());
  parts.push(jsdoc("Retour du usecase : `result(data)`" + (ep.paginated ? " + `.paged(paginate(...))` (obligatoire, endpoint paginé)" : "") + ", avec .message() / .warn() / .withHeaders() au besoin.", "") + `export type ${ep.pascal}Output = ${ep.paginated ? "PagedApiResult" : "ApiResult"}<${out}>;\n`);
  const input = [
    ep.pathParams.length && `params: ${ep.pascal}Params`, ep.query.length && `query: ${ep.pascal}Query`,
    ep.body && `body: ${ep.pascal}Body`, ep.guard && "user: AuthUser",
  ].filter(Boolean);
  { const one = `export interface ${ep.pascal}Input { ${input.join("; ")} }\n`; parts.push(one.length <= 120 ? one : `export interface ${ep.pascal}Input {\n${input.map(x => `  ${x};`).join("\n")}\n}\n`); }
  if (ep.stepList.length) parts.push(`/** Étapes de la spec (usecase) : un handler par code dans le usecase. */\nexport const ${ep.pascal}Steps = [\n${[...ep.stepList].sort((a, b) => a.order - b.order).map(s => obj("", [`code: ${JSON.stringify(s.code)}`, `order: ${s.order}`, `severity: ${JSON.stringify(s.severity)}`, `description: ${JSON.stringify(s.description)}`], ",")).join("\n")}\n] as const;\n`);
  const seen = new Set<string>();
  const errs = ep.errors.filter(e => !seen.has(e.code) && seen.add(e.code));
  if (errs.length) {
    parts.push(`/** Erreurs du contrat : \`throw ${ep.pascal}Errors.${errs[0].code}()\`. */\nexport const ${ep.pascal}Errors = {\n${errs.map(e =>
      brk(`  ${e.code}: (message = ${JSON.stringify(e.message)}, extra?: ErrorExtra) =>`, `new AppException(${e.status}, "${e.code}", message, extra),`)).join("\n")}\n};\n`);
  }
  const cv = [...imp].filter(n => !["z", "Type", "Transform", "ApiProperty", "ApiPropertyOptional"].includes(n)).sort();
  const head = [
    imp.has("z") && `import { z } from "zod";`,
    cv.length && `import { ${cv.join(", ")} } from "class-validator";`,
    (imp.has("ApiProperty") || imp.has("ApiPropertyOptional")) && `import { ${["ApiProperty", "ApiPropertyOptional"].filter(n => imp.has(n)).join(", ")} } from "@nestjs/swagger";`,
    (imp.has("Type") || imp.has("Transform")) && `import { ${["Transform", "Type"].filter(n => imp.has(n)).join(", ")} } from "class-transformer";`,
    `import type { ${ep.paginated ? "PagedApiResult" : "ApiResult"} } from "${coreRel}/api-result";`,
    errs.length && `import { AppException, type ErrorExtra } from "${coreRel}/app-exception";`,
    ep.guard && `import type { AuthUser } from "${coreRel}/auth/auth.port";`,
  ].filter(Boolean).join("\n");
  return `${head}${head ? "\n\n" : ""}${parts.join("\n")}`;
}
