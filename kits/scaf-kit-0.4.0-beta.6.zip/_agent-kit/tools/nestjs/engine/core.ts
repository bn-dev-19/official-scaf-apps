// N0 : socle commun (enveloppe, filtre d'exceptions, validation, port d'auth + guard) et bootstrap. Indépendant de l'architecture.
import type { GeneratedFile } from "../../_shared/generated-file";
import { HEADER } from "../../_shared/_lib/header";
import { AUTH_ADAPTERS, type AuthCtx } from "./auth";
import { listProp } from "./fmt";
import { S } from "./architectures";
import { coreModuleExtras, mainExtras, extraFiles } from "./extras";

export interface CoreCfg { fastify?: boolean; validation?: boolean; zod?: boolean; description?: string; nodeVersion?: string; events?: boolean; usecaseBase: string; name: string; deps: string[]; auth: string; validationStatus: number; codes: string[]; port: number; globalPrefix: string; versioning?: string; healthCheck?: boolean; rateLimiting?: boolean; rateLimitDefault?: { limit: number; ttlMs: number }; cors?: { origins?: string[]; credentials?: boolean; methods?: string[] }; bodyParser?: boolean; swagger?: { app: string; path: string }[]; devDeps?: string[]; scripts?: Record<string, string>; authCtx?: AuthCtx; envGuard?: boolean; logger?: string; sentry?: boolean; cache?: boolean; queue?: boolean; docsType?: string; standalone?: boolean; schedule?: boolean }

const DEP_VERSIONS: Record<string, string> = { "@nestjs/common": "^11.0.0", "@nestjs/core": "^11.0.0", "@nestjs/platform-express": "^11.0.0", "@nestjs/platform-fastify": "^11.0.0", "@fastify/static": "^8.0.0", "@nestjs/swagger": "^11.0.0", "@nestjs/event-emitter": "^3.0.0", "@nestjs/schedule": "^6.0.0", "@sentry/nestjs": "^11.11.0", "nestjs-pino": "^5.3.1", "pino-http": "^11.0.0", pino: "^10.4.0", "nest-winston": "^2.0.0", winston: "^3.19.0", "@nestjs/cache-manager": "^12.0.4", "cache-manager": "^7.2.9", keyv: "^6.1.0", "@keyv/redis": "^6.1.0", "@nestjs/bullmq": "^11.0.0", bullmq: "^5.0.0", nodemailer: "^10.5.0", "@types/nodemailer": "^8.0.2", "@nestjs/throttler": "^6.0.0", "reflect-metadata": "^0.2.2", rxjs: "^7.8.1", zod: "^4.0.0", "class-validator": "^0.14.1", "class-transformer": "^0.5.1", "better-auth": "^1.7.0", auth: "^1.7.0", "@better-auth/api-key": "^1.7.0", "drizzle-orm": "^0.45.0", typeorm: "^1.1.2", "@nestjs/typeorm": "^12.0.3", "ts-node": "^10.9.2", prisma: "^7.10.1", "@prisma/client": "^7.10.1", "@prisma/adapter-pg": "^7.10.1", "@prisma/adapter-neon": "^7.10.1", "@prisma/adapter-mariadb": "^7.10.1", "@prisma/adapter-better-sqlite3": "^7.10.1", "drizzle-kit": "^0.31.0", "@neondatabase/serverless": "^1.0.0", pg: "^8.13.0", "@types/pg": "^8.11.0", mysql2: "^3.11.0", "better-sqlite3": "^13.0.0", jest: "^29.7.0", "ts-jest": "^29.2.0", "@types/jest": "^29.5.0", vitest: "^5.1.0", "unplugin-swc": "^2.0.0", "@swc/core": "^1.16.0", "@nestjs/testing": "^11.0.0", "@types/better-sqlite3": "^9.6.0" };

const BASE_USECASE = `import { Logger } from "@nestjs/common";
import { AppException } from "./app-exception";

export type StepSeverity = "critical" | "high" | "medium" | "low";
/** Étape de la spec scaf (générée dans le DTO : <Id>Steps). */
export interface StepMeta {
  readonly code: string;
  readonly order: number;
  readonly severity: StepSeverity;
  readonly description: string;
}
const TODO = Symbol("todo");
/**
 * Contexte passé à chaque étape : entrée, état partagé entre étapes, sortie à renseigner,
 * skip() = étape sans objet (compte comme faite).
 */
export interface StepCtx<TInput, TOutput> {
  input: TInput;
  state: Record<string, any>;
  output?: TOutput;
  skip(reason: string): void;
}
export type StepHandler<TInput, TOutput> = (ctx: StepCtx<TInput, TOutput>) => unknown;
/**
 * Marque une étape « à implémenter » : un usecase qui en contient est « pas prêt ».
 * Écrire le corps dans la fonction puis retirer l'enveloppe todo(...).
 */
export const todo = <I, O>(fn: StepHandler<I, O>): StepHandler<I, O> => Object.assign(fn, { [TODO]: true });
const pending = (h: unknown) => typeof h !== "function" || (h as any)[TODO] === true;
/** Un handler (ou todo) par code d'étape de la spec : une étape ajoutée à la spec fait échouer la compilation. */
export type StepHandlers<TSteps extends readonly StepMeta[], TInput, TOutput> = {
  [K in TSteps[number]["code"]]: StepHandler<TInput, TOutput>;
};

/**
 * Enveloppe d'exécution des usecases (template method). Fichier utilisateur : y brancher transactions, métriques, etc.
 *
 * Erreurs : TErrors = fabriques d'erreurs du contrat (<Id>Errors), exposées en this.errors.
 * Une AppException dont le code n'est pas dans le contrat est journalisée (warn "erreur hors contrat")
 * puis relayée telle quelle au client : le contrat n'est pas respecté, l'ajouter à la spec scaf si légitime.
 * ponytail: mode strict possible (convertir en 500 ici) si le client ne doit jamais voir un code hors contrat.
 *
 * Étapes : le usecase déclare "steps" (un handler par étape de la spec, todo = à faire). readiness() dit sans exécuter
 * si tout est implémenté ; execute() répond 501 NOT_READY si une étape critical/high manque (medium/low : warn, étape sautée).
 * Les étapes tournent dans l'ordre de la spec ; une AppException lancée interrompt la chaîne.
 * Un usecase peut aussi surcharger run() (pas de pipeline, pas de contrôle de readiness).
 * Limite : le true/false est déclaratif, rien ne prouve que le handler fait ce que dit la spec.
 */
export abstract class BaseUsecase<
  TInput = unknown,
  TOutput = unknown,
  TErrors extends Record<string, unknown> = Record<string, never>,
  TSteps extends readonly StepMeta[] = readonly [],
> {
  protected readonly logger: Logger;
  readonly name = this.constructor.name;
  /** Handlers d'étapes, déclarés par la sous-classe. */
  protected readonly steps?: StepHandlers<TSteps, TInput, TOutput>;

  constructor(
    readonly description?: string,
    protected readonly errors: TErrors = {} as TErrors,
    protected readonly stepsMeta: TSteps = [] as unknown as TSteps,
  ) {
    this.logger = new Logger(this.name);
  }

  /** Avancement des étapes, sans exécuter. total = 0 : usecase sans étapes dans la spec. */
  readiness(): { ready: boolean; total: number; missing: { code: string; severity: StepSeverity }[] } {
    // run() pris en main : pas d'étapes à suivre
    if (!this.steps && this.customRun()) return { ready: true, total: 0, missing: [] };
    const h = (this.steps ?? {}) as Record<string, unknown>;
    const missing = this.stepsMeta.filter(s => pending(h[s.code])).map(s => ({ code: s.code, severity: s.severity }));
    return { ready: missing.length === 0, total: this.stepsMeta.length, missing };
  }

  private customRun(): boolean { return this.run !== BaseUsecase.prototype.run; }

  /** Pipeline par défaut : les étapes dans l'ordre de la spec. */
  protected async run(input: TInput): Promise<TOutput> {
    const h = this.steps as Record<string, ((c: StepCtx<TInput, TOutput>) => unknown)> | undefined;
    if (!h) throw new Error(this.name + " : déclarer steps ou surcharger run()");
    let skipped: string | undefined;
    const ctx: StepCtx<TInput, TOutput> = { input, state: {}, skip: (r) => { skipped = r; } };
    for (const s of [...this.stepsMeta].sort((a, b) => a.order - b.order)) {
      const fn = h[s.code];
      if (pending(fn)) continue; // medium/low non implémentée (déjà signalée par execute)
      skipped = undefined;
      await fn(ctx);
      this.logger.debug("step " + s.code + (skipped ? " ignorée : " + skipped : " ok"));
    }
    return ctx.output as TOutput;
  }

  async execute(input: TInput): Promise<TOutput> {
    this.logger.log("Executing " + this.name);
    if (this.description) this.logger.debug(this.description);
    // clés seulement : les valeurs (mots de passe, jetons…) ne vont jamais dans les logs
    this.logger.debug("Input keys: " + Object.keys(input ?? {}).join(", "));
    if (this.steps && this.customRun()) {
      throw new Error(this.name + " : steps ET run() déclarés — choisir l'un (supprimer steps, ou retirer run())");
    }
    if (this.steps) {
      const { missing } = this.readiness();
      const blocking = missing.filter(m => m.severity === "critical" || m.severity === "high");
      if (blocking.length) {
        throw new AppException(501, "NOT_READY", "Usecase non prêt : étapes manquantes : " + blocking.map(m => m.code).join(", "));
      }
      if (missing.length) this.logger.warn("étapes non implémentées (ignorées) : " + missing.map(m => m.code).join(", "));
    }
    try {
      return await this.run(input);
    } catch (err) {
      if (err instanceof AppException && err.status < 500) {
        // erreur métier attendue : warn sans stack
        const known = Object.prototype.hasOwnProperty.call(this.errors, err.code);
        this.logger.warn(this.name + ": " + (known ? "" : "erreur hors contrat ") + err.status + " " + err.code);
      } else {
        this.logger.error("Error in " + this.name, err instanceof Error ? err.stack : String(err));
      }
      throw err;
    }
  }
}
`;

const READINESS_REPORTER = `import { Injectable, Logger, OnApplicationBootstrap } from "@nestjs/common";
import { DiscoveryService } from "@nestjs/core";
import { BaseUsecase } from "./base-usecase";

/** Au démarrage : avancement des usecases (étapes implémentées vs spec), sans rien exécuter. */
@Injectable()
export class UsecaseReadinessReporter implements OnApplicationBootstrap {
  private readonly logger = new Logger("Readiness");
  constructor(private readonly discovery: DiscoveryService) {}

  onApplicationBootstrap() {
    const all = this.discovery.getProviders().map(p => p.instance)
      .filter((i): i is BaseUsecase<any, any, any, any> => i instanceof BaseUsecase)
      .map(u => ({ name: u.name, ...u.readiness() })).filter(r => r.total > 0);
    const ready = all.filter(r => r.ready).length;
    this.logger.log(ready + "/" + all.length + " usecases prêts (étapes toutes implémentées)");
    for (const r of all.filter(x => !x.ready)) {
      this.logger.debug(r.name + " : " + (r.total - r.missing.length) + "/" + r.total + " étapes");
    }
  }
}
`;

/** App sans API : contexte Nest sans serveur HTTP (cron, workers de file, écouteurs d'événements). */
const standaloneMain = (c: CoreCfg, mx: ReturnType<typeof mainExtras>) => `import "reflect-metadata";
${c.envGuard ? 'import "./core/env"; // charge .env et vérifie les variables requises avant tout import de l\'app\n' : ""}${mx.sentryImport}import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
${mx.imports}
/** Aucun port : le process reste vivant tant que cron, file (Redis) ou autre connexion est active. */
async function bootstrap() {
  const app = await NestFactory.createApplicationContext(AppModule${mx.createOpts.length ? `, { ${mx.createOpts.join(", ")} }` : ""});
${mx.useLogger}  app.enableShutdownHooks(); // SIGTERM/SIGINT : fermeture propre (files, connexions)
}
bootstrap();
`;

export function generateCore(c: CoreCfg, moduleImports: { cls: string; path: string }[]): GeneratedFile[] {
  const adapter = AUTH_ADAPTERS[c.auth];
  const xm = coreModuleExtras(c), mx = mainExtras(c), docsUi = c.docsType === "scalar" || c.docsType === "redoc";
  const raw = !c.fastify && c.auth === "better_auth" && c.bodyParser === false; // exigence propre à l'adaptateur better_auth
  const user = (path: string, content: string): GeneratedFile => ({ path, content, preserve: true }); // créés une fois, jamais réécrits
  const f = (path: string, content: string): GeneratedFile => ({ path, content: HEADER + content });
  const codes = [...new Set(["INTERNAL_SERVER_ERROR", "VALIDATION_ERROR", "UNAUTHORIZED", "FORBIDDEN", "NOT_FOUND", ...(c.usecaseBase === "template_method" ? ["NOT_READY"] : []), ...c.codes])].sort();
  return [
    user("package.json", JSON.stringify({
      name: c.name, version: "0.0.1", private: true, ...(c.description && { description: c.description }), ...(c.nodeVersion && { engines: { node: `>=${c.nodeVersion}` } }),
      scripts: { build: "nest build", start: "nest start", dev: "nest start --watch", "start:prod": "node dist/main.js", typecheck: "tsc --noEmit", ...c.scripts },
      dependencies: Object.fromEntries(c.deps.map(d => [d, DEP_VERSIONS[d] ?? "latest"])),
      devDependencies: { "@nestjs/cli": "^11.0.0", ...(c.fastify || c.standalone ? {} : { "@types/express": "^5.0.0" }), "@types/node": "^22.0.0", typescript: "^5.6.0", ...Object.fromEntries((c.devDeps ?? []).map(d => [d, DEP_VERSIONS[d] ?? "latest"])) },
    }, null, 2) + "\n"),
    user("tsconfig.json", JSON.stringify({ compilerOptions: { target: "ES2022", module: "commonjs", moduleResolution: "node10", strict: true, strictPropertyInitialization: false, experimentalDecorators: true, emitDecoratorMetadata: true, esModuleInterop: true, resolveJsonModule: true, skipLibCheck: true, outDir: "dist", sourceMap: true, types: ["node"] }, include: ["src"] }, null, 2) + "\n"),
    user("nest-cli.json", JSON.stringify({ $schema: "https://json.schemastore.org/nest-cli", collection: "@nestjs/schematics", sourceRoot: "src", compilerOptions: { deleteOutDir: true } }, null, 2) + "\n"),
    ...(c.deps.some(d => d.startsWith("@prisma/") || d === "better-sqlite3" || d === "typeorm") ? [user("pnpm-workspace.yaml", `# pnpm ≥ 11 : scripts de build autorisés explicitement (moteurs Prisma, binding SQLite natif ; télémétrie @scarf refusée)\nallowBuilds:\n${c.deps.some(d => d.startsWith("@prisma/")) ? "  prisma: true\n  \"@prisma/engines\": true\n" : ""}  "@scarf/scarf": false\n${c.deps.includes("better-sqlite3") ? "  better-sqlite3: true\n" : ""}`)] : []),
    user(".gitignore", "node_modules\ndist\n.env\n" + (c.deps.includes("@prisma/client") ? "src/generated\n" : "")),
    ...(c.usecaseBase === "template_method" ? [user("src/core/base-usecase.ts", BASE_USECASE.replace(/\bexecute\(/g, S.method + "(")), f("src/core/usecase-readiness.reporter.ts", READINESS_REPORTER)] : []),
    f("src/core/error-code.ts", `export type ErrorCode =\n${codes.map(x => `  | "${x}"`).join("\n")};\n`),
    f("src/core/app-exception.ts", `import type { ErrorCode } from "./error-code";

/** Compléments optionnels de l'erreur (format scaf : error.cause / error.resolution ; fields = détail de validation). */
export interface ErrorExtra { cause?: string; resolution?: string; fields?: Record<string, string[]> }

export class AppException extends Error {
  constructor(
    readonly status: number,
    readonly code: ErrorCode,
    message: string,
    readonly extra: ErrorExtra = {},
  ) {
    super(message);
  }
}
`),
    f("src/core/api-response.ts", `import type { Pagination } from "./pagination";

/** Avertissement d'une réponse en succès (format scaf : warnings = [{ title, description, tips }]). */
export interface Warning { title: string; description: string; tips: string[] }
export interface ApiSuccess<T> { success: true; message: string; data: T; pagination?: Pagination; warnings?: Warning[] }
export interface ApiFailure {
  success: false;
  message: string;
  error: { code: string; message: string; cause?: string; resolution?: string; fields?: Record<string, string[]> };
}
`),
    f("src/core/api-result.ts", `import type { ApiSuccess, Warning } from "./api-response";
import type { Pagination } from "./pagination";

/** Résultat paginé : \`.paged()\` a été appelé (exigé par le type de sortie des endpoints paginés du contrat). */
export type PagedApiResult<T> = ApiResult<T> & { readonly __paged: true };

/**
 * Retour typé d'un usecase : \`return result(data).message("…").warn(w).paged(p).withHeaders({ … })\`.
 * L'enveloppe \`{ success, message, data, pagination?, warnings? }\` n'est écrite qu'ici (toEnvelope) et reconnue par instanceof.
 */
export class ApiResult<T> {
  private msg = "OK";
  private warns: Warning[] = [];
  private page?: Pagination;
  private hdrs: Record<string, string> = {};
  private constructor(private readonly data: T) {}

  static of<T = void>(data?: T): ApiResult<T> { return new ApiResult<T>(data as T); }
  message(msg: string): this { this.msg = msg; return this; }
  warn(...w: Warning[]): this { this.warns.push(...w); return this; }
  paged(p: Pagination): PagedApiResult<T> { this.page = p; return this as unknown as PagedApiResult<T>; }
  /** En-têtes HTTP de la réponse (ex. Location, ETag, Set-Cookie). */
  withHeaders(h: Record<string, string>): this { Object.assign(this.hdrs, h); return this; }

  get headers(): Readonly<Record<string, string>> { return this.hdrs; }
  toEnvelope(): ApiSuccess<T | null> {
    return {
      success: true,
      message: this.msg,
      data: this.data ?? null,
      ...(this.page && { pagination: this.page }),
      ...(this.warns.length && { warnings: this.warns }),
    };
  }
}

export const result = <T = void>(data?: T): ApiResult<T> => ApiResult.of(data);
`),
    f("src/core/pagination.ts", `export interface Pagination { current_page: number; page_size: number; total_items: number; total_pages: number }

/** \`return result(data).paged(paginate(page, pageSize, total))\` — total_pages = 0 si liste vide. */
export const paginate = (page: number, pageSize: number, total: number): Pagination =>
  ({ current_page: page, page_size: pageSize, total_items: total, total_pages: Math.ceil(total / pageSize) });
`),
    f("src/core/response.interceptor.ts", `import { CallHandler, ExecutionContext, Injectable, Logger, NestInterceptor } from "@nestjs/common";
import { map } from "rxjs";
import type { ApiSuccess } from "./api-response";
import { ApiResult } from "./api-result";

/**
 * Seul point d'écriture de l'enveloppe : un ApiResult est converti ;
 * toute autre valeur est tolérée (data brute) mais signalée.
 */
@Injectable()
export class ResponseInterceptor implements NestInterceptor {
  private readonly log = new Logger("Response");
  intercept(ctx: ExecutionContext, next: CallHandler) {
    return next.handle().pipe(map((r: unknown): ApiSuccess<unknown> => {
      if (r instanceof ApiResult) {
        const res = ctx.switchToHttp().getResponse();
        for (const [k, v] of Object.entries(r.headers)) res.header(k, v);
        return r.toEnvelope();
      }
      this.log.warn("retour non-ApiResult (" + ctx.getClass().name + "." + ctx.getHandler().name + ") : utiliser result(data)");
      return { success: true, message: "OK", data: r ?? null };
    }));
  }
}
`),
    f("src/core/global-exception.filter.ts", `import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from "@nestjs/common";
${c.sentry ? 'import * as Sentry from "@sentry/nestjs";\n' : ""}import { AppException, type ErrorExtra } from "./app-exception";
import type { ApiFailure } from "./api-response";

const BY_STATUS: Record<number, string> = {\n  400: "VALIDATION_ERROR",\n  401: "UNAUTHORIZED",\n  403: "FORBIDDEN",\n  404: "NOT_FOUND",\n  409: "CONFLICT",${c.rateLimiting ? '\n  429: "RATE_LIMITED",' : ""}\n};

/** Toute erreur sort au format \`{ success:false, message, error:{ code, message } }\`. */
@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly log = new Logger("Exception");
  catch(e: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse();
    let status = 500, code = "INTERNAL_SERVER_ERROR", message = "Erreur interne du serveur.", extra: ErrorExtra = {};
    if (e instanceof AppException) ({ status, code, message, extra } = e);
    else if (e instanceof HttpException) {\n      status = e.getStatus();\n      code = BY_STATUS[status] ?? "INTERNAL_SERVER_ERROR";\n      message = ${c.rateLimiting ? 'status === 429 ? "Trop de requêtes, réessayez plus tard." : e.message' : "e.message"};\n    }
    else ${c.sentry ? "{ this.log.error(e); Sentry.captureException(e); }" : "this.log.error(e);"}
    const body: ApiFailure = { success: false, message, error: { code, message, ...extra } };
    res.status(status).send(body);
  }
}
`),
    ...(c.validation === false ? [] : [f("src/core/validation.ts", c.zod ? `import type { ArgumentMetadata, PipeTransform } from "@nestjs/common";
import type { z } from "zod";
import { AppException } from "./app-exception";

/** Pipe global zod : valide body/query/params avec le \`static schema\` du DTO (coercition query, clés inconnues refusées), erreurs au format du contrat (${c.validationStatus}). */
export const validationPipe = (): PipeTransform => ({
  transform(value: unknown, { type, metatype }: ArgumentMetadata) {
    const schema = (metatype as { schema?: z.ZodType } | undefined)?.schema;
    if (!schema || type === "custom") return value;
    const r = schema.safeParse(value ?? {});
    if (r.success) return r.data;
    const fields: Record<string, string[]> = {};
    for (const i of r.error.issues) {
      const keys = i.code === "unrecognized_keys" ? i.keys.map(String) : [i.path.join(".")];
      for (const k of keys) (fields[k] ??= []).push(i.code === "unrecognized_keys" ? "property " + k + " should not exist" : i.message);
    }
    throw new AppException(${c.validationStatus}, "VALIDATION_ERROR", "Les données envoyées sont invalides.", { fields });
  },
});
` : `import { ValidationError, ValidationPipe } from "@nestjs/common";
import { AppException } from "./app-exception";

const flat = (errs: ValidationError[], prefix = ""): Record<string, string[]> =>
  errs.reduce((acc, e) => {
    const path = prefix + e.property;
    if (e.constraints) acc[path] = Object.values(e.constraints);
    return e.children?.length ? { ...acc, ...flat(e.children, path + ".") } : acc;
  }, {} as Record<string, string[]>);

/** Pipe global : coercition des types (query), propriétés inconnues refusées, erreurs au format du contrat (${c.validationStatus}). */
export const validationPipe = () => new ValidationPipe({
  transform: true, whitelist: true, forbidNonWhitelisted: true,
  exceptionFactory: (errs) =>\n    new AppException(${c.validationStatus}, "VALIDATION_ERROR", "Les données envoyées sont invalides.", { fields: flat(errs) }),
});
`)]),
    ...(c.fastify ? [f("src/core/fastify.ts", `import { FastifyAdapter } from "@nestjs/platform-fastify";

/** Adaptateur Fastify : corps JSON vide accepté (POST sans corps avec content-type json : 400 par défaut sous Fastify, pas sous Express) et formulaires urlencoded. */
export function createFastifyAdapter(): FastifyAdapter {
  const adapter = new FastifyAdapter();
  const json = adapter.getInstance().getDefaultJsonParser("error", "error");
  adapter.useBodyParser("application/json", false, undefined, (req, body, done) => (body.length ? json(req, body as unknown as string, done) : done(null, {})));
  adapter.useBodyParser("application/x-www-form-urlencoded", false, undefined, (_req, body, done) => done(null, Object.fromEntries(new URLSearchParams(body.toString()))));
  return adapter;
}
`)] : []),
    f("src/core/auth/auth.port.ts", `export interface AuthUser { id: string; roles: string[] }

/** Contrat entre les guards des contrats scaf et le fournisseur d'authentification choisi (\`auth\` dans nestjs.json). */
export interface AuthPort {
  authenticate(req: unknown): Promise<AuthUser | null>;
  hasRole(user: AuthUser, role: string): boolean;
}
export const AUTH_PORT = Symbol("AUTH_PORT");
`),
    f("src/core/auth/access.ts", `import { createParamDecorator, ExecutionContext, SetMetadata } from "@nestjs/common";
import type { AuthUser } from "./auth.port";

/** Route protégée : \`@Access()\` = authentifié ; \`@Access("admin")\` = authentifié avec ce rôle. Sans décorateur = publique. */
export const Access = (role?: string) => SetMetadata("scaf:access", { role });
export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext): AuthUser => ctx.switchToHttp().getRequest().user);
`),
    f("src/core/auth/access.guard.ts", `import { CanActivate, ExecutionContext, Inject, Injectable } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { AppException } from "../app-exception";
import { AUTH_PORT, AuthPort } from "./auth.port";

@Injectable()
export class AccessGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, @Inject(AUTH_PORT) private readonly auth: AuthPort) {}
  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const rule = this.reflector.getAllAndOverride<{ role?: string } | undefined>("scaf:access", [ctx.getHandler(), ctx.getClass()]);
    if (!rule) return true;
    const req = ctx.switchToHttp().getRequest();
    const user = await this.auth.authenticate(req);
    if (!user) throw new AppException(401, "UNAUTHORIZED", "Jeton manquant ou invalide.");
    if (rule.role && !this.auth.hasRole(user, rule.role)) throw new AppException(403, "FORBIDDEN", "Accès refusé.");
    req.user = user;
    return true;
  }
}
`),
    ...adapter.files(c.authCtx ?? { plugins: [], oauthProviders: [], secretVar: "", baseUrlVar: "", trustedOrigins: [], emailVerification: false }).map(x => x.preserve ? x : { ...x, content: HEADER + x.content }),
    ...(c.healthCheck ? [f("src/core/health.controller.ts", `import { Controller, Get } from "@nestjs/common";

@Controller("health")
export class HealthController {
  @Get()
  check() {
    return { status: "ok" };
  }
}
`)] : []),
    f("src/core/core.module.ts", `import { Global, Module } from "@nestjs/common";
import { ${c.usecaseBase === "template_method" ? "DiscoveryModule, " : ""}APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from "@nestjs/core";
${c.rateLimiting ? 'import { ThrottlerGuard, ThrottlerModule } from "@nestjs/throttler";\n' : ""}import { AccessGuard } from "./auth/access.guard";
import { AUTH_PORT } from "./auth/auth.port";
import { ${adapter.provider.cls} } from "${adapter.provider.imp}";
import { GlobalExceptionFilter } from "./global-exception.filter";
import { ResponseInterceptor } from "./response.interceptor";
${c.healthCheck ? `import { HealthController } from "./health.controller";\n` : ""}${c.usecaseBase === "template_method" ? `import { UsecaseReadinessReporter } from "./usecase-readiness.reporter";\n` : ""}${xm.imports.map(l => l + "\n").join("")}
@Global()
@Module({
${listProp("imports", [...xm.modules, c.usecaseBase === "template_method" ? "DiscoveryModule" : "", c.rateLimiting ? `ThrottlerModule.forRoot([\n      {\n        ttl: ${c.rateLimitDefault ? c.rateLimitDefault.ttlMs : "Number(process.env.RATE_LIMIT_TTL_MS ?? 60000)"},\n        limit: ${c.rateLimitDefault ? c.rateLimitDefault.limit : "Number(process.env.RATE_LIMIT_MAX ?? 100)"},\n      },\n    ])` : ""].filter(Boolean) as string[])}${c.healthCheck ? "  controllers: [HealthController],\n" : ""}  providers: [
    { provide: AUTH_PORT, useClass: ${adapter.provider.cls} },
${c.rateLimiting ? "    ThrottlerGuard,\n    // avant AccessGuard : les appels anonymes (OTP…) sont limités aussi\n    // (provider nommé : le harness e2e peut le neutraliser)\n    { provide: APP_GUARD, useExisting: ThrottlerGuard },\n" : ""}    { provide: APP_GUARD, useClass: AccessGuard },
    { provide: APP_FILTER, useClass: GlobalExceptionFilter },
    { provide: APP_INTERCEPTOR, useClass: ResponseInterceptor },${c.usecaseBase === "template_method" ? "\n    UsecaseReadinessReporter," : ""}
  ],
  exports: [AUTH_PORT],
})
export class CoreModule {}
`),
    f("src/app.module.ts", `import { Module } from "@nestjs/common";
import { CoreModule } from "./core/core.module";
import { AppExtrasModule } from "./app.extras.module";
${c.events ? 'import { EventEmitterModule } from "@nestjs/event-emitter";\n' : ""}${c.schedule ? 'import { ScheduleModule } from "@nestjs/schedule";\n' : ""}${moduleImports.map(m => `import { ${m.cls} } from "${m.path}";`).join("\n")}

@Module({
${listProp("imports", [...(c.events ? ["EventEmitterModule.forRoot()"] : []), ...(c.schedule ? ["ScheduleModule.forRoot()"] : []), "CoreModule", "AppExtrasModule", ...moduleImports.map(m => m.cls)])}})
export class AppModule {}
`),
    { path: "src/app.extras.module.ts", preserve: true, content: `import { Module } from "@nestjs/common";

/** Fichier utilisateur : modules ajoutés à la main (base de données, config, santé…). Importé par AppModule. */
@Module({ imports: [] })
export class AppExtrasModule {}
` },
    f("src/main.ts", c.standalone ? standaloneMain(c, mx) : `import "reflect-metadata";
${c.envGuard ? 'import "./core/env"; // charge .env et vérifie les variables requises avant tout import de l\'app\n' : ""}${mx.sentryImport}${c.versioning === "uri" || c.versioning === "header" ? 'import { VersioningType } from "@nestjs/common";\n' : ""}import { NestFactory } from "@nestjs/core";
import type { ${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"} } from "@nestjs/platform-${c.fastify ? "fastify" : "express"}";
${c.fastify ? 'import { createFastifyAdapter } from "./core/fastify";\n' : ""}import { AppModule } from "./app.module";
${mx.imports}${c.validation === false ? "" : 'import { validationPipe } from "./core/validation";\n'}${raw && c.auth === "better_auth" ? 'import { toNodeHandler } from "better-auth/node";\nimport { auth } from "./better-auth/auth";\n' : c.fastify && c.auth === "better_auth" ? 'import { auth } from "./better-auth/auth";\n' : ""}${c.swagger ? `${docsUi ? 'import { mountDocs } from "./docs/docs-ui";\n' : 'import { SwaggerModule } from "@nestjs/swagger";\n'}${c.swagger.map(d => `import openapi_${d.app.replace(/\W/g, "_")} from "./docs/openapi.${d.app}.json";`).join("\n")}\n` : ""}
async function bootstrap() {
  const app = await NestFactory.create<${c.fastify ? "NestFastifyApplication" : "NestExpressApplication"}>(AppModule${c.fastify ? ", createFastifyAdapter()" : ""}${(raw ? ["bodyParser: false"] : []).concat(mx.createOpts).length ? `, { ${(raw ? ["bodyParser: false"] : []).concat(mx.createOpts).join(", ")} }` : ""});
${mx.useLogger}${c.fastify && c.auth === "better_auth" ? `  // routes Better Auth : Fastify a déjà lu le JSON, on le re-sérialise dans une Request Fetch.\n  app.getHttpAdapter().getInstance().all("/${c.globalPrefix ? c.globalPrefix + "/" : ""}auth/*", async (req: any, reply: any) => {\n    const headers = new Headers();\n    for (const [k, v] of Object.entries(req.headers)) if (k !== "content-length" && v != null) headers.set(k, String(v));\n    const res = await auth.handler(new Request(new URL(req.url, "http://" + req.headers.host), { method: req.method, headers, body: req.body ? JSON.stringify(req.body) : undefined }));\n    reply.status(res.status);\n    res.headers.forEach((v, k) => { if (k !== "set-cookie") reply.header(k, v); });\n    const cookies = res.headers.getSetCookie();\n    if (cookies.length) reply.header("set-cookie", cookies);\n    return reply.send(res.body ? await res.text() : null);\n  });\n` : ""}${raw ? `${c.auth === "better_auth" ? `  // routes Better Auth (avant le parseur JSON : il lit le corps brut)\n  app.getHttpAdapter().getInstance().all("/${c.globalPrefix ? c.globalPrefix + "/" : ""}auth/*splat", toNodeHandler(auth));\n` : ""}  app.useBodyParser("json"); // adaptateur ${c.auth} : le corps brut est laissé libre, JSON réactivé ici\n` : ""}${c.globalPrefix ? `  app.setGlobalPrefix(${JSON.stringify(c.globalPrefix)}${c.healthCheck ? ', { exclude: ["health"] }' : ""});\n` : ""}${c.versioning === "uri" ? "  app.enableVersioning({ type: VersioningType.URI });\n" : c.versioning === "header" ? '  app.enableVersioning({ type: VersioningType.HEADER, header: "X-API-Version" });\n' : ""}${c.swagger ? c.swagger.map(d => `  // doc OpenAPI des endpoints de ${d.app} : /${d.path} (JSON : /${d.path}-json)\n  ${docsUi ? `mountDocs(app, ${JSON.stringify(d.path)}, openapi_${d.app.replace(/\W/g, "_")});` : `SwaggerModule.setup(${JSON.stringify(d.path)}, app, openapi_${d.app.replace(/\W/g, "_")} as any);`}\n`).join("") : ""}${c.validation === false ? "" : "  app.useGlobalPipes(validationPipe());\n"}  app.enableCors(${JSON.stringify({ origin: c.cors?.origins ?? true, credentials: c.cors?.credentials ?? false, methods: c.cors?.methods }, null, 2).replace(/\n/g, "\n  ")});
  await app.listen(${c.fastify ? `Number(process.env.PORT ?? ${c.port}), "0.0.0.0"` : `process.env.PORT ?? ${c.port}`});
}
bootstrap();
`),
    ...extraFiles(c),
  ];
}
