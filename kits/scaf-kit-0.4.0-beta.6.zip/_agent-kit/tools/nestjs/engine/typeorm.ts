// N2 avec orm typeorm (TypeORM 1.x + @nestjs/typeorm) : les entités sont celles dérivées par scaf (visual_to_sql.rb --format typeorm) ;
// le générateur les copie, branche la connexion (DataSource selon moteur/provider) et crée un repository par entité. Même contrat que database.ts (DbOut).
// Better Auth n'a pas d'adaptateur TypeORM : il utilise son adaptateur intégré (Kysely) sur une connexion de même URL (src/database/auth-db.ts) ; ses tables : `auth migrate`.
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { GeneratedFile } from "../../_shared/generated-file";
import { HEADER } from "../../_shared/_lib/header";
import { listProp } from "./fmt";
import type { DbCfg, DbOut } from "./database";

const kebab = (s: string) => s.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

/** Moteurs/providers TypeORM (mêmes noms de provider que Drizzle) : type de DataSource, options propres, pilote Better Auth (Kysely). */
export const TYPEORM_PROVIDERS: Record<string, Record<string, { type: string; extra: string; doc: string; deps: string[]; devDeps: string[]; auth: { imports: string; create: string } }>> = {
  postgresql: {
    neon: { type: "postgres", extra: `uuidExtension: "pgcrypto"`, doc: "Neon (pilote pg, TCP ; sslmode=require dans l'URL)", deps: ["pg"], devDeps: ["@types/pg"], auth: { imports: `import { Pool } from "pg";`, create: "new Pool({ connectionString: url })" } },
    pg: { type: "postgres", extra: `uuidExtension: "pgcrypto"`, doc: "PostgreSQL (pg)", deps: ["pg"], devDeps: ["@types/pg"], auth: { imports: `import { Pool } from "pg";`, create: "new Pool({ connectionString: url })" } },
  },
  mysql: { mysql2: { type: "mysql", extra: "", doc: "MySQL (mysql2)", deps: ["mysql2"], devDeps: [], auth: { imports: `import { createPool } from "mysql2/promise";`, create: "createPool(url)" } } },
  sqlite: { better_sqlite3: { type: "better-sqlite3", extra: "", doc: "SQLite (better-sqlite3), chemin du fichier", deps: ["better-sqlite3"], devDeps: ["@types/better-sqlite3"], auth: { imports: `import Database from "better-sqlite3";`, create: "new Database(url)" } } },
};

/** Entités = classes `@Entity("table")` ; `idField` = propriété de la clé primaire simple (repository CRUD par id). */
export function parseEntities(src: string): { name: string; sql: string; idField?: string }[] {
  return src.split(/^(?=(?:\/\*\*[^\n]*\n)?(?:@\w+\([^\n]*\n)*@Entity\()/m).flatMap(b => {
    const m = /@Entity\("([^"]+)"\)\nexport class (\w+) \{/.exec(b); if (!m) return [];
    const ids = [...b.matchAll(/@Primary(?:Generated)?Column\([^\n]*\)\n\s+(\w+)!:/g)].map(x => x[1]);
    return [{ name: m[2], sql: m[1], idField: ids.length === 1 ? ids[0] : undefined }];
  });
}

const BASE_REPO = `import type { DeepPartial, FindOptionsWhere, ObjectLiteral, Repository } from "typeorm";

/**
 * Fichier utilisateur : accès générique à une entité TypeORM (lecture, insertion).
 * Y ajouter ce qui est commun à tous les repositories.
 */
export abstract class BaseRepository<E extends ObjectLiteral> {
  constructor(protected readonly repo: Repository<E>) {}
  findAll(limit = 50, offset = 0): Promise<E[]> {
    return this.repo.find({ take: limit, skip: offset });
  }
  insert(values: DeepPartial<E>): Promise<E> {
    return this.repo.save(this.repo.create(values));
  }
}

/** Entité à clé primaire simple : lecture, mise à jour et suppression par identifiant. */
export abstract class IdRepository<E extends ObjectLiteral> extends BaseRepository<E> {
  constructor(repo: Repository<E>, protected readonly idField: string) { super(repo); }
  findById(id: string | number): Promise<E | null> {
    return this.repo.findOneBy({ [this.idField]: id } as FindOptionsWhere<E>);
  }
  async update(id: string | number, values: DeepPartial<E>): Promise<E | undefined> {
    const row = await this.findById(id);
    if (!row) return undefined;
    return this.repo.save(this.repo.merge(row, values));
  }
  async delete(id: string | number): Promise<boolean> {
    return ((await this.repo.delete({ [this.idField]: id } as FindOptionsWhere<E>)).affected ?? 0) > 0;
  }
}
`;

export function typeormFiles(versionDir: string, c: DbCfg): DbOut {
  const entitiesFile = join(versionDir, "output", "database", c.dialect, "typeorm", "entities.ts");
  if (!existsSync(entitiesFile)) throw new Error(`entités TypeORM absentes (${entitiesFile}) : lancer ruby scaf/_agent-kit/tools/visual_to_sql.rb ${versionDir} --dialect ${c.dialect} --format typeorm`);
  const prov = TYPEORM_PROVIDERS[c.dialect]?.[c.provider];
  if (!prov) throw new Error(`N2 typeorm : ${c.dialect}/${c.provider} non géré (${Object.entries(TYPEORM_PROVIDERS).map(([d, p]) => `${d} : ${Object.keys(p).join("|")}`).join(" ; ")})`);
  const env = c.url?.startsWith("$var:") ? c.url.slice(5) : "DATABASE_URL";
  const f = (path: string, content: string): GeneratedFile => ({ path, content: HEADER + content });
  const user = (path: string, content: string): GeneratedFile => ({ path, content, preserve: true });
  const src = readFileSync(entitiesFile, "utf8");
  const models = parseEntities(src);
  const cls = (m: { name: string }) => `${m.name}Repository`;
  const file = (m: { name: string }) => kebab(m.name);
  const sqlite = c.dialect === "sqlite";
  const options = (urlExpr: string) => `{
    type: "${prov.type}",
    ${sqlite ? `database: ${urlExpr}.replace(/^file:/, "")` : `url: ${urlExpr}`},
    entities,
    migrations: [join(__dirname, "migrations", "*.{ts,js}")],
    synchronize: false, // le schéma évolue par migrations (pnpm db:generate puis db:migrate)${prov.extra ? `\n    ${prov.extra},` : ""}
  }`;
  const files: GeneratedFile[] = [
    { path: "src/database/entities.ts", content: src },
    f("src/database/data-source.ts", `import "reflect-metadata";
import { join } from "node:path";
import type { DataSourceOptions } from "typeorm";
import { entities } from "./entities";

/** ${prov.doc} : ${sqlite ? "chemin du fichier" : "chaîne de connexion"} dans ${env}. Partagé par Nest (TypeOrmModule) et la CLI TypeORM (typeorm.config.ts). */
export function dataSourceOptions(url = process.env.${env}): DataSourceOptions {
  if (!url) throw new Error("${env} non définie");
  return ${options("url")};
}
`),
    user("typeorm.config.ts", `import { DataSource } from "typeorm";
import { dataSourceOptions } from "./src/database/data-source";
try { process.loadEnvFile(); } catch { /* pas de .env : variables d'environnement du shell */ }

// CLI TypeORM (migrations) : URL directe (sans pooler) si ${env}_DIRECT est définie
export default new DataSource(dataSourceOptions(process.env.${env}_DIRECT ?? process.env.${env}));
`),
    user("src/database/repositories/base.repository.ts", BASE_REPO),
    ...models.map(m => user(`src/database/repositories/${file(m)}.repository.ts`, `import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { ${m.name} } from "../entities";
import { ${m.idField ? "IdRepository" : "BaseRepository"} } from "./base.repository";

/**
 * Fichier utilisateur : accès à l'entité \`${m.name}\` (table \`${m.sql}\`) ;
 * y ajouter les requêtes propres (jointures, filtres, transactions).
 */
@Injectable()
export class ${cls(m)} extends ${m.idField ? "IdRepository" : "BaseRepository"}<${m.name}> {
  constructor(@InjectRepository(${m.name}) repo: Repository<${m.name}>) { super(repo${m.idField ? `, "${m.idField}"` : ""}); }
}
`)),
    f("src/database/database.module.ts", `import { Global, Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { dataSourceOptions } from "./data-source";
import { entities } from "./entities";
${models.map(m => `import { ${cls(m)} } from "./repositories/${file(m)}.repository";`).join("\n")}

const repositories = [
${models.map(m => `  ${cls(m)},`).join("\n")}
];

/**
 * Connexion TypeORM (DataSource) et un repository par entité,
 * injectables partout.
 */
@Global()
@Module({
${listProp("imports", ["TypeOrmModule.forRoot(dataSourceOptions())", "TypeOrmModule.forFeature(entities)"])}${listProp("providers", ["...repositories"])}${listProp("exports", ["TypeOrmModule", "...repositories"])}})
export class DatabaseModule {}
`),
    ...(c.authSchema ? [f("src/database/auth-db.ts", `${prov.auth.imports}

/** Connexion de Better Auth (adaptateur Kysely intégré, pas d'adaptateur TypeORM) : même base que TypeORM, ${env}. */
export function createAuthDb() {
  const url = process.env.${env};
  if (!url) throw new Error("${env} non définie");
  return ${sqlite ? `new Database(url.replace(/^file:/, ""))` : prov.auth.create};
}
`)] : []),
  ];
  if (c.migrations !== "none") files.push(TYPEORM_GENERATE_SCRIPT);
  const cli = "typeorm-ts-node-commonjs -d typeorm.config.ts";
  return {
    repos: new Map(models.map(m => [m.sql, { cls: cls(m), path: `src/database/repositories/${file(m)}.repository`, hasId: !!m.idField, returning: true }])),
    files, module: { cls: "DatabaseModule", path: "./database/database.module" },
    deps: ["typeorm", "@nestjs/typeorm", ...prov.deps],
    devDeps: ["ts-node", ...prov.devDeps],
    scripts: c.migrations === "none" ? {} : { "db:generate": "node scripts/db-generate.mjs", "db:migrate": `${cli} migration:run`, "db:revert": `${cli} migration:revert` },
    notes: [`N2 typeorm : ${models.length} repositories (src/database/repositories), entités copiées depuis scaf (src/database/entities.ts, régénérées à chaque passe), migrations dans src/database/migrations (db:generate puis db:migrate ; db:revert annule la dernière)`],
  };
}

/** `typeorm migration:generate` échoue (code 1) quand le schéma est à jour : db:setup doit rester rejouable. */
const TYPEORM_GENERATE_SCRIPT: GeneratedFile = { path: "scripts/db-generate.mjs", content: `// Génère la migration TypeORM d'après les entités ; ne fait rien (code 0) si le schéma de la base est déjà à jour.
import { spawnSync } from "node:child_process";
const r = spawnSync("node_modules/.bin/typeorm-ts-node-commonjs", ["-d", "typeorm.config.ts", "migration:generate", "src/database/migrations/scaf"], { shell: true, encoding: "utf8" });
process.stdout.write(r.stdout ?? ""); process.stderr.write(r.stderr ?? "");
if (r.status !== 0 && /No changes in database schema/.test((r.stdout ?? "") + (r.stderr ?? ""))) { console.log("db:generate : schéma à jour, aucune migration"); process.exit(0); }
process.exit(r.status ?? 1);
` };
