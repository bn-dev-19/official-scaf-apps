// Adaptateurs d'authentification : chacun implémente AuthPort. Les guards des contrats n'en dépendent que par ce port.
import type { GeneratedFile } from "../../_shared/generated-file";

/** Config d'auth issue de nestjs.json (adaptateur better_auth) + base N2 si présente. */
export interface AuthCtx {
  plugins: string[]; oauthProviders: string[]; secretVar: string; baseUrlVar: string; trustedOrigins: string[];
  emailVerification: boolean; minPasswordLength?: number; globalPrefix?: string;
  /** Fournisseurs d'envoi : mailer `resend` | `smtp`/`nodemailer` ; sms `twilio` ; sinon `none` (console.warn). */
  mailer?: string; sms?: string;
  db?: { dialect: string; orm?: string };
  /** Table du visuel scaf qui EST la table d'identité (remplace `user` de Better Auth) ; `userFields` : champ Better Auth → colonne ; ids selon `idStrategy`. */
  userTable?: string; userFields?: Record<string, string>; defaultRole?: string; idStrategy?: string;
}

export interface AuthAdapter {
  deps: string[]; notes: string[];
  files: (ctx: AuthCtx) => GeneratedFile[];
  /** Dépendances, scripts et notes qui dépendent de la config (surchargent les statiques). */
  plan?: (ctx: AuthCtx, warn: (m: string) => void) => { deps: string[]; devDeps?: string[]; scripts: Record<string, string>; notes: string[] };
  /** Import + expression du provider AUTH_PORT dans core.module. */
  provider: { imp: string; cls: string };
}

const none: AuthAdapter = {
  deps: [], notes: ["auth: none — tous les guards laissent passer (à remplacer avant mise en production)"],
  provider: { imp: "./auth/none.adapter", cls: "NoneAuthAdapter" },
  files: () => [{ path: "src/core/auth/none.adapter.ts", content: `import { Injectable } from "@nestjs/common";
import type { AuthPort, AuthUser } from "./auth.port";

/** Aucune authentification : tout passe. */
@Injectable()
export class NoneAuthAdapter implements AuthPort {
  async authenticate(): Promise<AuthUser | null> { return { id: "anonymous", roles: [] }; }
  hasRole(): boolean { return true; }
}
` }],
};

const jwt: AuthAdapter = {
  deps: [], notes: ["auth: jwt — définir JWT_SECRET ; le jeton (HS256) porte `sub` et `role`/`roles`"],
  provider: { imp: "./auth/jwt.adapter", cls: "JwtAuthAdapter" },
  files: () => [{ path: "src/core/auth/jwt.adapter.ts", content: `import { Injectable } from "@nestjs/common";
import { createHmac, timingSafeEqual } from "node:crypto";
import type { AuthPort, AuthUser } from "./auth.port";

/** JWT HS256 sans dépendance : \`Authorization: Bearer <jeton>\`, secret dans JWT_SECRET. */
@Injectable()
export class JwtAuthAdapter implements AuthPort {
  async authenticate(req: any): Promise<AuthUser | null> {
    const secret = process.env.JWT_SECRET;
    const token = /^Bearer (.+)$/.exec(req.headers?.authorization ?? "")?.[1];
    if (!secret || !token) return null;
    const [h, p, s] = token.split(".");
    if (!h || !p || !s) return null;
    const good = createHmac("sha256", secret).update(\`\${h}.\${p}\`).digest();
    const got = Buffer.from(s, "base64url");
    if (got.length !== good.length || !timingSafeEqual(got, good)) return null;
    try {
      const c = JSON.parse(Buffer.from(p, "base64url").toString());
      if (c.exp && c.exp * 1000 < Date.now()) return null;
      return { id: String(c.sub), roles: [].concat(c.roles ?? c.role ?? []) };
    } catch { return null; }
  }
  hasRole(user: AuthUser, role: string): boolean { return user.roles.includes(role); }
}
` }],
};

// Plugins Better Auth (v1.7) : nom nestjs.json → import + appel. `todo` = plugin qui exige un callback d'envoi (e-mail/SMS) à brancher.
const BA_PLUGINS: Record<string, { imp: string; call: string; from?: string; todo?: string; dep?: string }> = {
  admin: { imp: "admin", call: "admin()" },
  username: { imp: "username", call: "username()" },
  bearer: { imp: "bearer", call: "bearer()" },
  jwt: { imp: "jwt", call: "jwt()" },
  multiSession: { imp: "multiSession", call: "multiSession()" },
  anonymous: { imp: "anonymous", call: "anonymous()" },
  organization: { imp: "organization", call: "organization()" },
  twoFactor: { imp: "twoFactor", call: "twoFactor()" },
  openAPI: { imp: "openAPI", call: "openAPI()" },
  customSession: { imp: "customSession", call: "customSession(async ({ user, session }) => ({ user, session }))" },
  phoneNumber: { imp: "phoneNumber", call: "phoneNumber({ sendOTP: ({ phoneNumber, code }) => { /* À brancher : envoi SMS */ console.warn(`[auth] OTP ${code} pour ${phoneNumber} (envoi SMS non branché)`); } })", todo: "phoneNumber.sendOTP (SMS)" },
  emailOTP: { imp: "emailOTP", call: "emailOTP({ sendVerificationOTP: async ({ email, otp, type }) => { /* À brancher : envoi e-mail */ console.warn(`[auth] OTP ${otp} (${type}) pour ${email} (envoi e-mail non branché)`); } })", todo: "emailOTP.sendVerificationOTP (e-mail)" },
  magicLink: { imp: "magicLink", call: "magicLink({ sendMagicLink: async ({ email, url }) => { /* À brancher : envoi e-mail */ console.warn(`[auth] lien ${url} pour ${email} (envoi e-mail non branché)`); } })", todo: "magicLink.sendMagicLink (e-mail)" },
  apiKey: { imp: "apiKey", call: "apiKey()", from: "@better-auth/api-key", dep: "@better-auth/api-key" },
};
/** Fournisseur actif : mailer → "resend" | "smtp" ; sms → "twilio" ; sinon undefined. */
const mailOf = (x: AuthCtx) => (x.mailer === "resend" ? "resend" : x.mailer === "smtp" || x.mailer === "nodemailer" ? "smtp" : undefined);
const smsOf = (x: AuthCtx) => (x.sms === "twilio" ? "twilio" : undefined);
/** Appel du plugin branché sur notify.ts (envoi non attendu : pas de fuite par le temps de réponse). */
const NOTIFY_CALLS: Record<string, { via: "mail" | "sms"; call: string }> = {
  phoneNumber: { via: "sms", call: 'phoneNumber({ sendOTP: ({ phoneNumber, code }) => { void sendSms({ to: phoneNumber, body: "Votre code : " + code }); } })' },
  emailOTP: { via: "mail", call: 'emailOTP({ sendVerificationOTP: async ({ email, otp, type }) => { void sendMail({ to: email, subject: "Votre code (" + type + ")", text: "Votre code : " + otp }); } })' },
  magicLink: { via: "mail", call: 'magicLink({ sendMagicLink: async ({ email, url }) => { void sendMail({ to: email, subject: "Votre lien de connexion", text: url }); } })' },
};
const wired = (p: string, x: AuthCtx) => { const n = NOTIFY_CALLS[p]; return n && (n.via === "mail" ? mailOf(x) : smsOf(x)) ? n : undefined; };
const notifyFile = (x: AuthCtx): GeneratedFile[] => {
  const m = mailOf(x), t = smsOf(x);
  if (!m && !t) return [];
  const mail = m === "resend" ? `export async function sendMail(m: { to: string; subject: string; text: string }): Promise<void> {
  try {
    const r = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: \`Bearer \${process.env.RESEND_API_KEY}\`, "Content-Type": "application/json" }, body: JSON.stringify({ from: process.env.MAIL_FROM, ...m }) });
    if (!r.ok) throw new Error(\`resend \${r.status}: \${await r.text()}\`);
  } catch (e) { console.error("[mail]", e); }
}
` : m === "smtp" ? `import { createTransport } from "nodemailer";

export async function sendMail(m: { to: string; subject: string; text: string }): Promise<void> {
  try { await createTransport(process.env.SMTP_URL!).sendMail({ from: process.env.MAIL_FROM, ...m }); } catch (e) { console.error("[mail]", e); }
}
` : "";
  const sms = t ? `export async function sendSms(s: { to: string; body: string }): Promise<void> {
  try {
    const sid = process.env.TWILIO_ACCOUNT_SID, token = process.env.TWILIO_AUTH_TOKEN;
    const r = await fetch(\`https://api.twilio.com/2010-04-01/Accounts/\${sid}/Messages.json\`, { method: "POST", headers: { Authorization: "Basic " + Buffer.from(\`\${sid}:\${token}\`).toString("base64") }, body: new URLSearchParams({ To: s.to, From: process.env.TWILIO_FROM!, Body: s.body }) });
    if (!r.ok) throw new Error(\`twilio \${r.status}: \${await r.text()}\`);
  } catch (e) { console.error("[sms]", e); }
}
` : "";
  return [{ path: "src/better-auth/notify.ts", content: `// Envoi e-mail / SMS de Better Auth (généré depuis nestjs.json : mailer, sms). Les erreurs d'envoi sont journalisées, jamais renvoyées au client.
${mail}${mail && sms ? "\n" : ""}${sms}` }];
};
/** Tables natives Better Auth (SQL) créées par `auth generate` selon les plugins ; sert à détecter un conflit de nom avec le visuel scaf. */
const BA_PLUGIN_TABLES: Record<string, string[]> = { apiKey: ["apikey"], organization: ["organization", "member", "invitation", "team", "team_member"], twoFactor: ["two_factor"], jwt: ["jwks"] };
export const betterAuthTables = (plugins: string[]) => ["user", "session", "account", "verification", ...plugins.flatMap(p => BA_PLUGIN_TABLES[p] ?? [])];
/** Champs `user` ajoutés par un plugin : se mappent via `schema.user.fields` du plugin (pas via `user.fields` du cœur). */
const BA_PLUGIN_USER_FIELDS: Record<string, string[]> = { admin: ["role", "banned", "banReason", "banExpires"], username: ["username", "displayUsername"] };
const pluginCall = (p: string, x: AuthCtx) => {
  const m = Object.fromEntries((BA_PLUGIN_USER_FIELDS[p] ?? []).filter(f => x.userFields?.[f]).map(f => [f, x.userFields![f]]));
  const schema = JSON.stringify({ user: { fields: m } }, null, 2).replace(/\n/g, "\n      ");
  const o = [...(p === "admin" && x.defaultRole ? [`defaultRole: ${JSON.stringify(x.defaultRole)}`] : []), ...(Object.keys(m).length ? [`schema: ${schema}`] : [])];
  const base = wired(p, x)?.call ?? BA_PLUGINS[p].call;
  return x.userTable && o.length ? base.replace("()", `({\n${o.map(l => `      ${l},`).join("\n")}\n    })`) : base;
};
const userLines = (x: AuthCtx) => {
  const f = Object.fromEntries(Object.entries(x.userFields ?? {}).filter(([k]) => !Object.values(BA_PLUGIN_USER_FIELDS).flat().includes(k)));
  const fields = Object.keys(f).length ? `    fields: ${JSON.stringify(f, null, 2).replace(/\n/g, "\n    ")},` : "";
  return ["  user: {", `    modelName: ${JSON.stringify(x.userTable)},`, ...(fields ? [fields] : []), "  },"];
};
const BA_DIALECT: Record<string, string> = { postgresql: "pg", mysql: "mysql", sqlite: "sqlite" };
const envName = (v: string, d: string) => (v?.startsWith("$var:") ? v.slice(5) : v) || d;
const betterAuthFiles = (x: AuthCtx): GeneratedFile[] => {
  const known = x.plugins.filter(p => BA_PLUGINS[p]), unknown = x.plugins.filter(p => !BA_PLUGINS[p]);
  const core = [...new Set(known.map(p => BA_PLUGINS[p]).filter(p => !p.from).map(p => p.imp))];
  const ext = known.map(p => BA_PLUGINS[p]).filter(p => p.from);
  const secret = envName(x.secretVar, "BETTER_AUTH_SECRET"), url = envName(x.baseUrlVar, "BETTER_AUTH_URL");
  const db = x.db ? BA_DIALECT[x.db.dialect] : undefined;
  const social = x.oauthProviders.map(p => `    ${p}: { clientId: process.env.${p.toUpperCase()}_CLIENT_ID!, clientSecret: process.env.${p.toUpperCase()}_CLIENT_SECRET! },`);
  const lines = [
    db ? (x.db?.orm === "prisma" ? `  database: prismaAdapter(createPrisma(), { provider: "${x.db.dialect}" }),` : x.db?.orm === "typeorm" ? "  database: createAuthDb(), // adaptateur Kysely intégré (pas d'adaptateur TypeORM) ; tables : pnpm auth:migrate" : `  database: drizzleAdapter(createDb(), { provider: "${db}", schema }),`) : "  // Sans base (niveau < N2) : sessions stateless (cookie signé) ; fournir une base pour les comptes persistants.",
    `  secret: process.env.${secret},`,
    `  baseURL: process.env.${url},`,
    ...(`/${x.globalPrefix ? x.globalPrefix + "/" : ""}auth` !== "/api/auth" ? [`  basePath: "/${x.globalPrefix ? x.globalPrefix + "/" : ""}auth",`] : []),
    `  trustedOrigins: ${JSON.stringify(x.trustedOrigins)},`,
    `  emailAndPassword: { enabled: true${x.minPasswordLength ? `, minPasswordLength: ${x.minPasswordLength}` : ""}${x.emailVerification ? ", requireEmailVerification: true" : ""}${mailOf(x) ? `, sendResetPassword: async ({ user, url }) => { void sendMail({ to: user.email, subject: "Réinitialisation du mot de passe", text: url }); }` : ""} },`,
    ...(mailOf(x) && x.emailVerification ? [`  emailVerification: { sendOnSignUp: true, sendVerificationEmail: async ({ user, url }) => { void sendMail({ to: user.email, subject: "Confirmez votre adresse e-mail", text: url }); } },`] : []),
    ...(social.length ? ["  socialProviders: {", ...social, "  },"] : []),
    ...(x.db && x.userTable ? [...userLines(x), `  advanced: { database: { generateId: "${x.idStrategy === "serial" ? "serial" : "uuid"}" } },`] : []),
    ...(known.length ? ["  plugins: [", ...known.map(p => `    ${pluginCall(p, x)},`), "  ],"] : ["  plugins: [],"]),
  ];
  return [
    { path: "src/better-auth/auth.ts", preserve: true, content: `// Instance Better Auth du projet (fichier utilisateur, créé une fois) : générée depuis nestjs.json (plugins, secret, origines), à adapter.
// Tables Better Auth : ${x.db?.orm === "typeorm" ? "`pnpm auth:migrate` (crée/met à jour les tables d'après ce fichier, adaptateur Kysely)." : `\`pnpm auth:generate\` (réécrit ${x.db?.orm === "prisma" ? "prisma/schema/auth.prisma" : "src/better-auth/schema.ts"} d'après ce fichier), puis \`pnpm db:generate\` et \`pnpm db:migrate\`.`}
import { betterAuth } from "better-auth";
${db ? (x.db?.orm === "prisma" ? `import { prismaAdapter } from "better-auth/adapters/prisma";
` : x.db?.orm === "typeorm" ? "" : `import { drizzleAdapter } from "better-auth/adapters/drizzle";
`) : ""}${core.length ? `import { ${core.join(", ")} } from "better-auth/plugins";
` : ""}${ext.map(p => `import { ${p.imp} } from "${p.from}";
`).join("")}${[mailOf(x) && "sendMail", known.some(p => wired(p, x)?.via === "sms") && "sendSms"].filter(Boolean).length ? `import { ${[mailOf(x) && "sendMail", smsOf(x) && "sendSms"].filter(Boolean).join(", ")} } from "./notify";
` : ""}${db ? (x.db?.orm === "prisma" ? `import { createPrisma } from "../database/prisma";
` : x.db?.orm === "typeorm" ? `import { createAuthDb } from "../database/auth-db";
` : `import { createDb } from "../database/db";
import * as schema from "./schema";
`) : ""}
try { process.loadEnvFile(); } catch { /* pas de .env : variables d'environnement du shell */ }

export const auth = betterAuth({
${lines.join("\n")}
});
${unknown.length ? `// Plugins de nestjs.json non gérés par le générateur (à ajouter à la main) : ${unknown.join(", ")}\n` : ""}` },
    ...notifyFile(x),
    ...(db && x.db?.orm !== "prisma" && x.db?.orm !== "typeorm" ? [{ path: "src/better-auth/schema.ts", preserve: true, content: `// Schéma Drizzle de Better Auth : écrit par \`pnpm auth:generate\` (d'après src/better-auth/auth.ts). Placeholder tant que la commande n'a pas été lancée.
export {};
` }] : []),
  ];
};

/** Table d'identité du visuel : `auth generate` la redéclare, on la retire de src/better-auth/schema.ts et on l'importe depuis le schéma scaf. */
const authSchemaScript = (table: string): GeneratedFile => ({ path: "scripts/auth-schema.mjs", content: `// Exécuté après \`auth generate\` : retire de src/better-auth/schema.ts la table ${table} (déjà définie dans le visuel scaf) et l'importe de ../database/schema.
import { readFileSync, writeFileSync } from "node:fs";
const file = "src/better-auth/schema.ts", table = ${JSON.stringify(table)};
let src = readFileSync(file, "utf8");
const cut = (re) => {
  const m = re.exec(src); if (!m) return null;
  let i = src.indexOf("(", m.index), d = 0, j = i;
  for (; j < src.length; j++) { if (src[j] === "(") d++; else if (src[j] === ")" && --d === 0) break; }
  src = src.slice(0, m.index) + src.slice(src.indexOf("\\n", j) + 1);
  return m[1];
};
const v = cut(new RegExp(\`export const ([A-Za-z0-9_]+) = [A-Za-z0-9_]+Table[(][^"]*"\${table}"\`));
if (!v) { console.error(\`auth-schema: table "\${table}" introuvable dans \${file}\`); process.exit(1); }
cut(new RegExp(\`export const (\${v}Relations) = relations[(]\`));
src = \`import { \${v} } from "../database/schema";\\nexport { \${v} }; // le drizzleAdapter résout modelName dans ce module\\n\` + src;
writeFileSync(file, src);
console.log(\`auth-schema: \${table} retiré de \${file} (importé de ../database/schema)\`);
` });

/** Prisma : `auth generate` écrit prisma/schema/auth.prisma ; on retire ses blocs generator/datasource (déjà dans schema.prisma) et, avec authUserTable, le modèle d'identité (défini par le visuel scaf) et les relations vers lui. */
const prismaAuthScript = (table?: string): GeneratedFile => ({ path: "scripts/auth-schema.mjs", content: `// Exécuté après \`auth generate\` : nettoie prisma/schema/auth.prisma (le schéma du visuel scaf est dans prisma/schema/schema.prisma).
import { readFileSync, writeFileSync } from "node:fs";
const file = "prisma/schema/auth.prisma", table = ${JSON.stringify(table ?? null)};
let src = readFileSync(file, "utf8");
const block = (kind) => new RegExp("^" + kind + " \\\\w+ \\\\{[\\\\s\\\\S]*?^\\\\}\\\\n*", "gm");
src = src.replace(block("generator"), "").replace(block("datasource"), "");
if (table) {
  const m = [...src.matchAll(/^model (\\w+) \\{[\\s\\S]*?^\\}\\n*/gm)].find(x => x[0].includes('@@map("' + table + '")'));
  if (!m) { console.error(\`auth-schema: modèle de la table "\${table}" introuvable dans \${file}\`); process.exit(1); }
  src = src.replace(m[0], "");
  src = src.split("\\n").filter(l => !(l.includes("@relation(") && new RegExp("\\\\b" + m[1] + "\\\\b").test(l))).join("\\n"); // FK vers la table d'identité : non exprimée (relation à double sens impossible entre deux fichiers générés)
}
writeFileSync(file, "// Généré par \`pnpm auth:generate\` (Better Auth) — ne pas éditer à la main.\\n" + src.trim() + "\\n");
console.log(\`auth-schema: \${file} nettoyé\`);
` });

const betterAuth: AuthAdapter = {
  deps: ["better-auth"], notes: ["auth: better_auth — src/better-auth/auth.ts généré depuis nestjs.json ; le rôle vient de session.user.role"],
  provider: { imp: "./auth/better-auth.adapter", cls: "BetterAuthAdapter" },
  plan: (x, warn) => {
    const unknown = x.plugins.filter(p => !BA_PLUGINS[p]);
    if (unknown.length) warn(`auth: plugin(s) Better Auth non gérés (${unknown.join(", ")}) : à ajouter à la main dans src/better-auth/auth.ts`);
    const todo = x.plugins.filter(p => !wired(p, x)).map(p => BA_PLUGINS[p]?.todo).filter(Boolean);
    return {
      devDeps: [...(x.db ? ["auth"] : []), ...(mailOf(x) === "smtp" ? ["@types/nodemailer"] : [])], // CLI Better Auth épinglée (auth generate)
      deps: ["better-auth", ...(mailOf(x) === "smtp" ? ["nodemailer"] : []), ...x.plugins.map(p => BA_PLUGINS[p]?.dep).filter((d): d is string => !!d)],
      scripts: x.db ? x.db.orm === "typeorm" ? { "auth:migrate": "auth migrate --config src/better-auth/auth.ts --yes" } : { "auth:generate": x.db.orm === "prisma" ? `auth generate --adapter prisma --dialect ${x.db.dialect} --config src/better-auth/auth.ts --output prisma/schema/auth.prisma --yes && node scripts/auth-schema.mjs` : `auth generate --adapter drizzle --dialect ${BA_DIALECT[x.db.dialect]} --config src/better-auth/auth.ts --output src/better-auth/schema.ts --yes${x.userTable ? " && node scripts/auth-schema.mjs" : ""}` } as Record<string, string> : {},
      notes: [
        ...(x.db ? ["better_auth N2 : pnpm db:setup (auth:generate → db:generate → db:guard → db:migrate[ → db:rls], dans cet ordre ; typeorm : db:generate → db:migrate → auth:migrate) ; variables : voir .env.example"] : ["better_auth sans base (niveau < N2) : sessions stateless"]),
        ...(todo.length ? [`auth: à brancher dans src/better-auth/auth.ts : ${todo.join(", ")}`] : []),
      ],
    };
  },
  files: x => [
    { path: "src/core/auth/better-auth.adapter.ts", content: `import { Injectable } from "@nestjs/common";
import { auth } from "../../better-auth/auth";
import type { AuthPort, AuthUser } from "./auth.port";

/** Better Auth derrière AuthPort : session lue depuis les en-têtes/cookies de la requête. */
@Injectable()
export class BetterAuthAdapter implements AuthPort {
  async authenticate(req: any): Promise<AuthUser | null> {
    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers ?? {})) if (typeof v === "string") headers.set(k, v);
    const session = await auth.api.getSession({ headers });
    const u = session?.user as { id: string; role?: string | null } | undefined;
    return u ? { id: u.id, roles: String(u.role ?? "").split(",").filter(Boolean) } : null;
  }
  hasRole(user: AuthUser, role: string): boolean { return user.roles.includes(role); }
}
` },
    ...betterAuthFiles(x),
    ...(x.db?.orm === "prisma" ? [prismaAuthScript(x.userTable)] : x.db && x.userTable ? [authSchemaScript(x.userTable)] : []),
  ],
};

export const AUTH_ADAPTERS: Record<string, AuthAdapter> = { none, jwt, better_auth: betterAuth };
