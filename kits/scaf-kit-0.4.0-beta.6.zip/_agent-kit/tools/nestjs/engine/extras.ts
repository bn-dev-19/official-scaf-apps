// Options d'infrastructure opt-in (logger, errorMonitoring, cache, queue, swagger.type) : dépendances, imports de core.module / main.ts, fichiers.
// Défauts (logger nest, errorMonitoring none, cache none, swagger ui) : rien n'est généré.
import type { GeneratedFile } from "../../_shared/generated-file";

export interface ExtrasCfg { logger?: string; sentry?: boolean; cache?: boolean; queue?: boolean; docsType?: string; fastify?: boolean; schedule?: boolean }

export const extraDeps = (x: ExtrasCfg): string[] => [
  ...(x.logger === "pino" ? ["nestjs-pino", "pino-http", "pino"] : x.logger === "winston" ? ["nest-winston", "winston"] : []),
  ...(x.sentry ? ["@sentry/nestjs"] : []),
  ...(x.cache ? ["@nestjs/cache-manager", "cache-manager", "keyv", "@keyv/redis"] : []),
  ...(x.queue ? ["@nestjs/bullmq", "bullmq"] : []),
  ...(x.schedule ? ["@nestjs/schedule"] : []),
  ...(x.fastify && x.docsType !== "scalar" && x.docsType !== "redoc" ? ["@fastify/static"] : []), // Swagger UI sous Fastify
];

/** Imports et modules à ajouter à core.module.ts. */
export function coreModuleExtras(x: ExtrasCfg): { imports: string[]; modules: string[] } {
  const imports: string[] = [], modules: string[] = [];
  if (x.logger === "pino") {
    imports.push('import { LoggerModule } from "nestjs-pino";');
    // redact : pino-http journalise les en-têtes de requête, dont le jeton et les cookies de session
    modules.push('LoggerModule.forRoot({ pinoHttp: { level: process.env.LOG_LEVEL ?? "info", redact: ["req.headers.authorization", "req.headers.cookie"] } })');
  }
  if (x.logger === "winston") {
    imports.push('import { WinstonModule } from "nest-winston";', 'import * as winston from "winston";');
    modules.push('WinstonModule.forRoot({ level: process.env.LOG_LEVEL ?? "info", transports: [new winston.transports.Console()] })');
  }
  if (x.sentry) {
    imports.push('import { SentryModule } from "@sentry/nestjs/setup";');
    modules.push("SentryModule.forRoot()");
  }
  if (x.cache) {
    imports.push('import { CacheModule } from "@nestjs/cache-manager";', 'import { createKeyv } from "@keyv/redis";');
    modules.push("CacheModule.registerAsync({ isGlobal: true, useFactory: () => ({ stores: [createKeyv(process.env.REDIS_URL)] }) })");
  }
  if (x.queue) {
    imports.push('import { BullModule } from "@nestjs/bullmq";');
    // BullMQ n'accepte pas d'URL : REDIS_URL est décomposée ; aucune connexion tant qu'aucune file n'est enregistrée (BullModule.registerQueue)
    modules.push('BullModule.forRootAsync({ useFactory: () => { const u = new URL(process.env.REDIS_URL ?? "redis://localhost:6379"); return { connection: { host: u.hostname, port: Number(u.port || 6379), username: decodeURIComponent(u.username) || undefined, password: decodeURIComponent(u.password) || undefined, ...(u.protocol === "rediss:" ? { tls: {} } : {}) } }; } })');
  }
  return { imports, modules };
}

/** main.ts : imports, options de NestFactory.create, appel suivant la création. */
export const mainExtras = (x: ExtrasCfg) => ({
  sentryImport: x.sentry ? 'import "./instrument"; // Sentry : avant tout import de l\'app\n' : "",
  imports: x.logger === "pino" ? 'import { Logger as PinoLogger } from "nestjs-pino";\n' : x.logger === "winston" ? 'import { WINSTON_MODULE_NEST_PROVIDER } from "nest-winston";\n' : "",
  createOpts: x.logger === "pino" || x.logger === "winston" ? ["bufferLogs: true"] : [],
  useLogger: x.logger === "pino" ? "  app.useLogger(app.get(PinoLogger));\n" : x.logger === "winston" ? "  app.useLogger(app.get(WINSTON_MODULE_NEST_PROVIDER));\n" : "",
});

export const extraFiles = (x: ExtrasCfg): GeneratedFile[] => [
  ...(x.sentry ? [{ path: "src/instrument.ts", content: `// Sentry : importé en premier par main.ts. Sans SENTRY_DSN, l'envoi est désactivé (aucun effet).
import * as Sentry from "@sentry/nestjs";

Sentry.init({ dsn: process.env.SENTRY_DSN || undefined });
` }] : []),
  ...(x.docsType === "scalar" || x.docsType === "redoc" ? [{ path: "src/docs/docs-ui.ts", content: `// Page de documentation ${x.docsType} : HTML minimal qui charge le script depuis un CDN (réseau requis côté navigateur) et lit le JSON OpenAPI servi à côté.
import type { ${x.fastify ? "NestFastifyApplication" : "NestExpressApplication"} } from "@nestjs/platform-${x.fastify ? "fastify" : "express"}";

const page = (jsonUrl: string) => ${x.docsType === "scalar"
    ? '`<!doctype html><html><head><meta charset="utf-8"><title>API</title></head><body><script id="api-reference" data-url="${jsonUrl}"></script><script src="https://cdn.jsdelivr.net/npm/@scalar/api-reference@1.78.0"></script></body></html>`'
    : '`<!doctype html><html><head><meta charset="utf-8"><title>API</title></head><body><redoc spec-url="${jsonUrl}"></redoc><script src="https://cdn.redoc.ly/redoc/v2.5.1/bundles/redoc.standalone.js"></script></body></html>`'};

/** Sert \`/<path>\` (page) et \`/<path>-json\` (spécification), comme SwaggerModule.setup. */
export function mountDocs(app: ${x.fastify ? "NestFastifyApplication" : "NestExpressApplication"}, path: string, spec: object) {
  const http = app.getHttpAdapter().getInstance();
  http.get(\`/\${path}-json\`, (_req: unknown, res: any) => res.send(spec));
  http.get(\`/\${path}\`, (_req: unknown, res: any) => res.type("text/html").send(page(\`/\${path}-json\`)));
}
` }] : []),
];
