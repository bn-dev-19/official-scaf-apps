// N2 avec orm prisma (Prisma 7, client `prisma-client` en CommonJS, adaptateur de pilote) : le schéma est celui dérivé par scaf (visual_to_sql.rb --format prisma) ;
// le générateur le copie, branche la connexion (adaptateur selon moteur/provider) et crée un repository par modèle. Même contrat que database.ts (DbOut).
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { GeneratedFile } from "../../_shared/generated-file";
import { HEADER } from "../../_shared/_lib/header";
import { listProp } from "./fmt";
import type { DbCfg, DbOut } from "./database";

const kebab = (s: string) => s.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const lower = (s: string) => s[0].toLowerCase() + s.slice(1);

/** Adaptateurs de pilote Prisma 7 par moteur/provider (mêmes noms de provider que Drizzle). */
export const PRISMA_PROVIDERS: Record<string, Record<string, { imports: string; create: string; doc: string; deps: string[]; devDeps: string[] }>> = {
  postgresql: {
    neon: { imports: `import { PrismaNeon } from "@prisma/adapter-neon";`, create: "new PrismaNeon({ connectionString: url })", doc: "Neon (WebSocket)", deps: ["@prisma/adapter-neon"], devDeps: [] },
    pg: { imports: `import { PrismaPg } from "@prisma/adapter-pg";`, create: "new PrismaPg({ connectionString: url })", doc: "PostgreSQL (pg)", deps: ["@prisma/adapter-pg", "pg"], devDeps: ["@types/pg"] },
  },
  mysql: { mysql2: { imports: `import { PrismaMariaDb } from "@prisma/adapter-mariadb";`, create: "new PrismaMariaDb(url)", doc: "MySQL (pilote mariadb, compatible MySQL)", deps: ["@prisma/adapter-mariadb"], devDeps: [] } },
  sqlite: { better_sqlite3: { imports: `import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";`, create: `new PrismaBetterSqlite3({ url: url.startsWith("file:") ? url : \`file:\${url}\` })`, doc: "SQLite (better-sqlite3), chemin du fichier", deps: ["@prisma/adapter-better-sqlite3", "better-sqlite3"], devDeps: ["@types/better-sqlite3"] } },
};

/** Modèles = blocs `model X { ... @@map("table") }` ; `idField` = champ `@id` simple (repository CRUD par id). */
export function parseModels(src: string): { name: string; sql: string; idField?: string }[] {
  return src.split(/^(?=model )/m).flatMap(b => {
    const m = /^model (\w+) \{/.exec(b); if (!m) return [];
    const sql = /@@map\("([^"]+)"\)/.exec(b)?.[1] ?? m[1];
    const idField = /^\s+(\w+)\s+\S+.*@id\b/m.exec(b)?.[1];
    return [{ name: m[1], sql, idField }];
  });
}

// Dossier prisma/schema/ (multi-fichiers) : schema.prisma = visuel scaf (généré), auth.prisma = tables Better Auth (auth:generate).
const BASE_REPO = `import type { Prisma } from "../../generated/prisma/client";

type Delegate = { findMany(args?: any): any; create(args: any): any };
type IdDelegate = Delegate & { findUnique(args: any): any; update(args: any): any; deleteMany(args: any): any };

/**
 * Fichier utilisateur : accès générique à un modèle Prisma (lecture, insertion).
 * Y ajouter ce qui est commun à tous les repositories.
 */
export abstract class BaseRepository<D extends Delegate> {
  constructor(protected readonly model: D) {}
  findAll(limit = 50, offset = 0): Promise<Awaited<ReturnType<D["findMany"]>>> {
    return this.model.findMany({ take: limit, skip: offset });
  }
  insert(data: Parameters<D["create"]>[0]["data"]): Promise<Awaited<ReturnType<D["create"]>>> {
    return this.model.create({ data });
  }
}

/** Repository d'un modèle à clé primaire simple : lecture, mise à jour et suppression par id. */
export abstract class IdRepository<D extends IdDelegate> extends BaseRepository<D> {
  constructor(model: D, protected readonly idField: string) { super(model); }
  findById(id: string | number): Promise<Awaited<ReturnType<D["findUnique"]>>> {
    return this.model.findUnique({ where: { [this.idField]: id } });
  }
  async update(id: string | number, data: Parameters<D["update"]>[0]["data"]): Promise<Awaited<ReturnType<D["update"]>> | undefined> {
    try { return await this.model.update({ where: { [this.idField]: id }, data }); }
    catch (e) { if ((e as Prisma.PrismaClientKnownRequestError)?.code === "P2025") return undefined; throw e; }
  }
  async delete(id: string | number): Promise<boolean> {
    return (await this.model.deleteMany({ where: { [this.idField]: id } })).count > 0;
  }
}
`;

export function prismaFiles(versionDir: string, c: DbCfg): DbOut {
  const dir = join(versionDir, "output", "database", c.dialect, "prisma");
  const schemaFile = join(dir, "schema.prisma");
  if (!existsSync(schemaFile)) throw new Error(`schéma Prisma absent (${schemaFile}) : lancer ruby scaf/_agent-kit/tools/visual_to_sql.rb ${versionDir} --dialect ${c.dialect} --format prisma`);
  const prov = PRISMA_PROVIDERS[c.dialect]?.[c.provider];
  if (!prov) throw new Error(`N2 prisma : ${c.dialect}/${c.provider} non géré (${Object.entries(PRISMA_PROVIDERS).map(([d, p]) => `${d} : ${Object.keys(p).join("|")}`).join(" ; ")})`);
  const env = c.url?.startsWith("$var:") ? c.url.slice(5) : "DATABASE_URL";
  const f = (path: string, content: string): GeneratedFile => ({ path, content: HEADER + content });
  const user = (path: string, content: string): GeneratedFile => ({ path, content, preserve: true });
  const src = readFileSync(schemaFile, "utf8").replace('"../src/generated/prisma"', '"../../src/generated/prisma"'); // schéma dérivé prévu pour prisma/schema.prisma ; ici dans prisma/schema/
  const models = parseModels(src);
  const cls = (m: { name: string }) => `${m.name}Repository`;
  const file = (m: { name: string }) => kebab(m.name);
  const files: GeneratedFile[] = [
    { path: "prisma/schema/schema.prisma", content: src },
    f("src/database/prisma.ts", `import { PrismaClient } from "../generated/prisma/client";
${prov.imports}

/** ${prov.doc} : ${c.dialect === "sqlite" ? "chemin du fichier" : "chaîne de connexion"} dans ${env}. */
export function createAdapter() {
  const url = process.env.${env};
  if (!url) throw new Error("${env} non définie");
  return ${prov.create};
}

/** Client Prisma hors injection de dépendances (Better Auth, scripts). */
export function createPrisma(): PrismaClient {
  return new PrismaClient({ adapter: createAdapter() });
}
`),
    f("src/database/prisma.service.ts", `import { Injectable, OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { PrismaClient } from "../generated/prisma/client";
import { createAdapter } from "./prisma";

/** Client Prisma injectable (connexion à l'initialisation du module, fermée à l'arrêt). */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  constructor() { super({ adapter: createAdapter() }); }
  async onModuleInit() { await this.$connect(); }
  async onModuleDestroy() { await this.$disconnect(); }
}
`),
    user("src/database/repositories/base.repository.ts", BASE_REPO),
    ...models.map(m => user(`src/database/repositories/${file(m)}.repository.ts`, `import { Injectable } from "@nestjs/common";
import { PrismaService } from "../prisma.service";
import { ${m.idField ? "IdRepository" : "BaseRepository"} } from "./base.repository";

/**
 * Fichier utilisateur : accès au modèle \`${m.name}\` (table \`${m.sql}\`) ;
 * y ajouter les requêtes propres (jointures, filtres, transactions).
 */
@Injectable()
export class ${cls(m)} extends ${m.idField ? "IdRepository" : "BaseRepository"}<PrismaService["${lower(m.name)}"]> {
  constructor(prisma: PrismaService) { super(prisma.${lower(m.name)}${m.idField ? `, "${m.idField}"` : ""}); }
}
`)),
    f("src/database/database.module.ts", `import { Global, Module } from "@nestjs/common";
import { PrismaService } from "./prisma.service";
${models.map(m => `import { ${cls(m)} } from "./repositories/${file(m)}.repository";`).join("\n")}

const repositories = [
${models.map(m => `  ${cls(m)},`).join("\n")}
];

/**
 * Client Prisma (PrismaService) et un repository par modèle,
 * injectables partout.
 */
@Global()
@Module({
${listProp("providers", ["PrismaService", "...repositories"])}${listProp("exports", ["PrismaService", "...repositories"])}})
export class DatabaseModule {}
`),
    user("prisma.config.ts", `import { defineConfig } from "prisma/config";
try { process.loadEnvFile(); } catch { /* pas de .env : variables d'environnement du shell */ }

const raw = process.env.${env}_DIRECT ?? process.env.${env} ?? ""; // migrations : URL directe (sans pooler) si ${env}_DIRECT est définie
export default defineConfig({
  schema: "prisma/schema",
  migrations: { path: "prisma/migrations" },
  datasource: { url: ${c.dialect === "sqlite" ? `raw.startsWith("file:") ? raw : \`file:\${raw}\`` : "raw"} },
});
`),
  ];
  return {
    repos: new Map(models.map(m => [m.sql, { cls: cls(m), path: `src/database/repositories/${file(m)}.repository`, hasId: !!m.idField, returning: true }])),
    files, module: { cls: "DatabaseModule", path: "./database/database.module" },
    deps: ["@prisma/client", ...prov.deps],
    devDeps: ["prisma", ...prov.devDeps],
    scripts: { "db:generate": "prisma generate", ...(c.migrations === "none" ? {} : { "db:migrate": "prisma migrate dev --name scaf", "db:deploy": "prisma migrate deploy" }), "db:studio": "prisma studio", postinstall: "prisma generate" },
    notes: [`N2 prisma : ${models.length} repositories (src/database/repositories), client généré dans src/generated/prisma (pnpm db:generate), migrations dans prisma/migrations (db:migrate en développement, db:deploy en production)`],
  };
}
