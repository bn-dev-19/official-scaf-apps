// Usage : tsx gen_nestjs.ts [<scaf/version>] --out <dir> [--level N0|N1|N2] [--database postgresql|mysql|sqlite] [--db-provider neon|pg|mysql2|better_sqlite3] [--app <slug>] [--architecture <a>] [--auth <a>] [--health-check] [--swagger [path] | --no-swagger] [--dry-run] [--force] [--overwrite <usecase-id|glob*|all>]...
//   --app <slug> : une API pour cette app ; sans --app : toutes les apps fusionnées en une seule API (--out = racine de l'API).
//   Config nestjs effective : celle de l'app (ou de la première app en mode fusionné) ; --architecture/--auth la surchargent.
import { spawnSync } from "node:child_process";
import { existsSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { basename, dirname, join, resolve as abs } from "node:path";
import { fileURLToPath } from "node:url";
import { load as yamlLoad } from "js-yaml";
import { loadContracts, loadProjectApps } from "../_shared/load-contracts";
import { parseContractsToSpecContext, splitSpecContextByApp } from "../_shared/spec-loader";
import { writeTree } from "../_shared/writer";
import { pmFiles, pmText } from "../_shared/package-manager";
import { olderVersionError, resolveVersionDir, scafVersionName } from "../_shared/scaf-version";
import type { GeneratedFile } from "../_shared/generated-file";
import { fmtImports } from "./engine/fmt";
import { buildModules } from "./engine/ir";
import { generateCore } from "./engine/core";
import { setZod } from "./engine/dto";
import { ARCHITECTURES, S, setUsecaseStyle, setDomainDirs, generateModule, orderModules } from "./engine/architectures";
import { AUTH_ADAPTERS, betterAuthTables } from "./engine/auth";
import { extraDeps } from "./engine/extras";
import { swaggerDocs } from "./engine/swagger";
import { e2eCases, e2eFiles, e2eDevDeps, e2eScripts } from "./engine/e2e";
import { envVars, envFiles, envGuardFile, setupReadme } from "./engine/env";
import { databaseFiles, DB_ENGINES, type DbOut } from "./engine/database";
import { prismaFiles, PRISMA_PROVIDERS } from "./engine/prisma";
import { typeormFiles, TYPEORM_PROVIDERS } from "./engine/typeorm";

const argv = process.argv.slice(2);
const opt = (n: string) => { const i = argv.indexOf(`--${n}`); return i >= 0 ? argv[i + 1] : undefined; };
const versionDir = resolveVersionDir(argv[0]), out = opt("out"), onlyApp = opt("app"), dry = argv.includes("--dry-run");
if (!versionDir || !out) { console.error("Usage: gen_nestjs.ts [<scaf/version>] --out <dir> [--level N0|N1|N2] [--database postgresql|mysql|sqlite] [--db-provider neon|pg|mysql2|better_sqlite3] [--app <slug>] [--architecture <a>] [--auth <a>] [--health-check] [--swagger [path] | --no-swagger] [--dry-run] [--force] [--overwrite <usecase-id|glob*|all>]..."); process.exit(1); }
const fail = (m: string): never => { console.error(`[nestjs] ${m}`); process.exit(1); };

const apps = splitSpecContextByApp(parseContractsToSpecContext(loadContracts(versionDir)), loadProjectApps(versionDir));
const slugs = onlyApp ? [onlyApp] : [...apps.keys()];
if (!slugs.length || slugs.some(s => !apps.has(s))) fail(`app inconnue : ${onlyApp} (apps : ${[...apps.keys()].join(", ")})`);

const rb = join(dirname(fileURLToPath(import.meta.url)), "..", "export_configs.rb");
const resolve = (slug: string) => {
  const r = spawnSync("ruby", [rb, versionDir, "--resolve", "nestjs", slug], { encoding: "utf8" });
  if (r.status !== 0) fail(`config nestjs introuvable pour ${slug} : ${r.stderr || r.stdout}`);
  return JSON.parse(r.stdout);
};
// App sans API (`api: false`) : une sortie dont toutes les apps sont sans API est un worker standalone (createApplicationContext, aucun port) ; une seule app api:true fusionnée => process HTTP.
const noApi = (s: string) => { const f = join(versionDir, "input", "project.parts", "apps", `${s}.yml`); return existsSync(f) && (yamlLoad(readFileSync(f, "utf8")) as any)?.api === false; };
const standalone = slugs.every(noApi);
const cfg = resolve(slugs[0]);
for (const k of ["log", "warn"] as const) { const o = console[k].bind(console); console[k] = (...a: unknown[]) => o(...a.map(x => typeof x === "string" ? pmText(x, cfg.packageManager) : x)); } // messages : commandes citées traduites
for (const s of slugs.slice(1)) { const o = resolve(s); for (const k of ["architecture", "auth"]) if (o[k] !== cfg[k]) console.warn(`[nestjs] ${k} diffère pour ${s} (${o[k]}) : config de ${slugs[0]} (${cfg[k]}) appliquée à l'API fusionnée`); }
const architecture: string = opt("architecture") ?? cfg.architecture;
const auth: string = opt("auth") ?? cfg.auth;
const validation = cfg.validation !== "none";
const zod = cfg.validation === "zod";
setZod(zod);
const usecaseBase: string = opt("usecase-base") ?? cfg.usecaseBase ?? "none";
const usecaseStyle: string = opt("usecase-style") ?? cfg.usecaseStyle ?? "service_per_usecase";
if (!["service_per_usecase", "handler"].includes(usecaseStyle)) fail(`usecaseStyle "${usecaseStyle}" non géré (service_per_usecase, handler)`);
setUsecaseStyle(usecaseStyle);
setDomainDirs(cfg.moduleLayout?.domainDirs ?? []);
const testFramework: string = opt("test-framework") ?? cfg.testFramework ?? "jest";
if (!["jest", "vitest"].includes(testFramework)) fail(`testFramework "${testFramework}" non géré (jest, vitest)`);
const level: string = opt("level") ?? cfg.generator?.level ?? "N1";
if (!ARCHITECTURES[architecture]) fail(`architecture "${architecture}" non gérée (${Object.keys(ARCHITECTURES).join(", ")})`);
if (!AUTH_ADAPTERS[auth]) fail(`auth "${auth}" non gérée (${Object.keys(AUTH_ADAPTERS).join(", ")})`);
if (!["none", "template_method"].includes(usecaseBase)) fail(`usecaseBase "${usecaseBase}" non géré (none, template_method)`);
if (!["N0", "N1", "N2"].includes(level)) fail(`niveau ${level} non implémenté (N0, N1, N2)`);
// Régénérer à un niveau inférieur à celui du projet supprimerait ses fichiers (ex. N1 sur N2 : src/database/*) : on bloque.
{ const mf = join(out, ".scaf-generated.json"); const prevLevel = existsSync(mf) ? (() => { try { return JSON.parse(readFileSync(mf, "utf8")).level as string; } catch { return undefined; } })() : undefined;
  if (!dry && !argv.includes("--force") && prevLevel && ["N0", "N1", "N2"].includes(prevLevel) && prevLevel > level) fail(`le projet ${out} a été généré en ${prevLevel} : régénérer en ${level} supprimerait ses fichiers ${prevLevel}. Relancer avec --level ${prevLevel} (ou --force pour rétrograder).`); }
{ const mf = join(out, ".scaf-generated.json"); const prevV = existsSync(mf) ? (() => { try { return JSON.parse(readFileSync(mf, "utf8")).scafVersion as string | undefined; } catch { return undefined; } })() : undefined;
  const e = olderVersionError(prevV, scafVersionName(versionDir), out); if (e && !dry && !argv.includes("--force")) fail(e); }
if (standalone) {
  if (cfg.httpAdapter && cfg.httpAdapter !== "express") fail(`app sans API : httpAdapter ${cfg.httpAdapter} sans objet (aucun serveur HTTP) ; retirer l'option ou la laisser à express`);
  if (auth !== "none") fail(`app sans API : auth ${auth} sans objet (aucune route) ; utiliser auth: none`);
}
const database: string = opt("database") ?? cfg.database;
const ormProviders: Record<string, Record<string, unknown>> = cfg.orm === "prisma" ? PRISMA_PROVIDERS : cfg.orm === "typeorm" ? TYPEORM_PROVIDERS : Object.fromEntries(Object.entries(DB_ENGINES).map(([d, e]) => [d, e.providers]));
function providersOf(d: string) { return Object.keys(ormProviders[d] ?? {}); }
const dbProvider: string = opt("db-provider") ?? (opt("database") ? providersOf(database)[0] : cfg.databaseProvider);
if (level === "N2" && (!["drizzle", "prisma", "typeorm"].includes(cfg.orm) || !providersOf(database).includes(dbProvider))) fail(`N2 : orm drizzle, prisma ou typeorm requis et moteur/provider gérés (${Object.keys(ormProviders).map(d => `${d} : ${providersOf(d).join("|")}`).join(" ; ")}) ; reçu : ${cfg.orm}, ${database}, ${dbProvider}`);
if (level === "N2" && cfg.orm !== "drizzle" && cfg.rls === "session") fail(`N2 : rls session n'est pas géré avec orm ${cfg.orm}`);
if (level === "N2" && cfg.orm === "typeorm" && cfg.authUserTable) fail("N2 : authUserTable n'est pas géré avec orm typeorm (Better Auth garde ses propres tables)");
if (cfg.versioning && !["none", "uri", "header"].includes(cfg.versioning)) console.warn(`[nestjs] versioning=${cfg.versioning} non géré (none, uri, header) : ignoré`);
// Options valides mais non générées : avertissement NS10 (export_configs.rb), pas de doublon ici.
// Swagger : une doc OpenAPI par app (dérivée des endpoints générés de l'app), selon swagger.enabled/path de l'app ; --swagger [path] l'active pour toutes les apps servies.
const swIdx = argv.indexOf("--swagger"), swFlag = swIdx >= 0;
const swArg = swFlag && argv[swIdx + 1] && !argv[swIdx + 1].startsWith("--") ? argv[swIdx + 1] : undefined;
const swTargets = standalone ? [] : slugs.filter(s => !argv.includes("--no-swagger") && (swFlag || resolve(s).swagger?.enabled)).map(app => ({ app, base: swArg ?? resolve(app).swagger?.path ?? "docs" }));

const { modules, warnings, validationStatus } = buildModules(new Map(slugs.map(s => [s, apps.get(s)!])), versionDir, { globalPrefix: cfg.globalPrefix, versioning: cfg.versioning });
warnings.forEach(w => console.warn(`[nestjs] ${w}`));
console.log(`[nestjs] ${slugs.join("+")} → architecture ${architecture}, auth ${auth}, niveau ${level}, ${modules.length} modules`);

const authCtx = { plugins: cfg.authPlugins ?? [], oauthProviders: cfg.oauthProviders ?? [], secretVar: cfg.authSecret ?? "", baseUrlVar: cfg.authBaseUrl ?? "", trustedOrigins: cfg.trustedOrigins ?? [], emailVerification: !!cfg.emailVerification, minPasswordLength: cfg.minPasswordLength, globalPrefix: cfg.globalPrefix, db: level === "N2" ? { dialect: database, orm: cfg.orm } : undefined, userTable: level === "N2" ? cfg.authUserTable || undefined : undefined, userFields: cfg.authUserFields, defaultRole: cfg.authDefaultRole || undefined, idStrategy: cfg.idStrategy, mailer: cfg.mailer, sms: cfg.sms };
const authPlan = AUTH_ADAPTERS[auth].plan?.(authCtx, m => console.warn(`[nestjs] ${m}`));
const xo = { logger: cfg.logger, sentry: cfg.errorMonitoring === "sentry", cache: cfg.cache === "redis", queue: cfg.queue === "bullmq", docsType: standalone ? undefined : cfg.swagger?.type, fastify: !standalone && cfg.httpAdapter === "fastify", schedule: modules.some(m => m.internals.some(u => u.trigger && "cron" in u.trigger)) };
if (modules.some(m => m.internals.some(u => u.trigger && "queue" in u.trigger)) && !xo.queue) fail("trigger.queue : exige queue: bullmq dans la config nestjs");
const DEPS = ["@nestjs/common", "@nestjs/core", ...(standalone ? [] : [cfg.httpAdapter === "fastify" ? "@nestjs/platform-fastify" : "@nestjs/platform-express"]), "reflect-metadata", "rxjs", ...(cfg.validation === "none" ? [] : zod ? ["zod"] : ["class-validator", "class-transformer"]), "@nestjs/swagger", ...(authPlan?.deps ?? AUTH_ADAPTERS[auth].deps), ...extraDeps(xo)];
const files: GeneratedFile[] = [];
const sw = level !== "N0" ? swaggerDocs(versionDir, swTargets, m => console.warn(`[nestjs] ${m}`)) : { files: [], served: [] };
files.push(...sw.files);
let db: DbOut | undefined;
if (level === "N2") try { db = (cfg.orm === "prisma" ? prismaFiles : cfg.orm === "typeorm" ? typeormFiles : databaseFiles)(versionDir, { dialect: database, provider: dbProvider, migrations: cfg.migrations, url: cfg.databaseUrl, authSchema: auth === "better_auth", rls: cfg.rls === "session" }); } catch (e) { fail((e as Error).message); }
if (db) { files.push(...db.files); DEPS.push(...db.deps); }
// Table d'identité (authUserTable) : doit exister dans le visuel et porter les colonnes Better Auth (sinon avertissement, pas d'échec).
const isPrisma = cfg.orm === "prisma", isTypeorm = cfg.orm === "typeorm";
if (db && authCtx.userTable) {
  const src = db.files.filter(f => f.path.startsWith(isPrisma ? "prisma/schema/" : "src/database/schema/")).map(f => f.content).join("\n");
  const at = isPrisma ? src.search(new RegExp(`@@map\\("${authCtx.userTable}"\\)`)) : src.search(new RegExp(`Table\\(\\s*["']${authCtx.userTable}["']`));
  if (at < 0) fail(`authUserTable "${authCtx.userTable}" : table absente du visuel scaf`);
  else {
    const body = isPrisma ? (src.split(/^(?=model )/m).find(b => b.includes(`@@map("${authCtx.userTable}")`)) ?? "") : src.slice(at).split(/Table\(/)[1] ?? "";
    const ALL = { name: "name", email: "email", emailVerified: "email_verified", image: "image", createdAt: "created_at", updatedAt: "updated_at", ...(authCtx.plugins.includes("admin") ? { role: "role", banned: "banned", banReason: "ban_reason", banExpires: "ban_expires" } : {}), ...(authCtx.plugins.includes("username") ? { username: "username", displayUsername: "display_username" } : {}) } as Record<string, string>;
    // Clés Drizzle de la table : Better Auth cherche ses champs par clé de propriété (camelCase) ; le visuel scaf génère des clés snake_case → mapping auto, authUserFields prime.
    const hasKey = (k: string) => new RegExp(isPrisma ? `(^|\\n)\\s*${k}\\s+[A-Z]` : `(^|\\n)\\s*${k}\\s*:`).test(body);
    const auto = Object.fromEntries(Object.entries(ALL).filter(([f, c]) => f !== c && !hasKey(f) && hasKey(c)));
    authCtx.userFields = { ...auto, ...authCtx.userFields };
    const miss = Object.entries(ALL).filter(([f]) => f !== "image").map(([f, c]) => authCtx.userFields?.[f] ?? (hasKey(f) ? f : c)).filter(c => !hasKey(c));
    if (miss.length) console.warn(`[nestjs] authUserTable ${authCtx.userTable} : colonnes Better Auth absentes du visuel (${miss.join(", ")}) : les ajouter ou les mapper via authUserFields`);
    // Better Auth n'écrit que ses champs : toute autre colonne NOT NULL sans défaut fait échouer l'inscription.
    const known = new Set(["id", ...Object.keys(ALL), ...Object.values(ALL), ...Object.values(authCtx.userFields ?? {})]);
    const strict = isPrisma
      ? [...body.matchAll(/(?:^|\n)[ \t]+(\w+)[ \t]+(\w+)([?\[\]]*)([^\n]*)/g)].filter(m => /^(String|Int|BigInt|Boolean|DateTime|Json|Decimal)$/.test(m[2]) && !m[3] && !/@default|@id|@updatedAt/.test(m[4]) && !known.has(m[1])).map(m => m[1])
      : [...body.matchAll(/(?:^|\n)\s*(\w+)\s*:([^\n]*)/g)].filter(m => /\.notNull\(\)/.test(m[2]) && !/\.default|\$default|primaryKey|generated/.test(m[2]) && !known.has(m[1])).map(m => m[1]);
    if (strict.length) console.warn(`[nestjs] authUserTable ${authCtx.userTable} : colonnes NOT NULL sans défaut que Better Auth n'écrit pas (${strict.join(", ")}) : l'inscription échouera ; leur donner un défaut ou les rendre nullables dans le visuel`);
  }
}
// Better Auth × visuel scaf : une table du visuel ne doit pas porter le nom d'une table native Better Auth (sauf authUserTable, qui la remplace).
const identity = db && auth === "better_auth" ? JSON.stringify({ authUserTable: authCtx.userTable ?? null, idStrategy: cfg.idStrategy ?? null, authUserFields: authCtx.userFields ?? {}, plugins: [...authCtx.plugins].sort() }, null, 2) + "\n" : undefined;
if (db && identity) {
  const src = db.files.filter(f => f.path.startsWith(isPrisma ? "prisma/schema/" : isTypeorm ? "src/database/entities" : "src/database/schema/")).map(f => f.content).join("\n");
  const names = [...src.matchAll(isPrisma ? /@@map\("([^"]+)"\)/g : isTypeorm ? /@Entity\("([^"]+)"\)/g : /Table\(\s*["']([^"']+)["']/g)].map(m => m[1]);
  const clash = names.filter(n => betterAuthTables(authCtx.plugins).includes(n) && n !== authCtx.userTable);
  if (clash.length) fail(`tables du visuel en conflit avec les tables natives Better Auth (${clash.join(", ")}) : les renommer dans le visuel${clash.includes("user") ? ", ou désigner cette table comme identité (authUserTable)" : ""}`);
  // L'id de la table d'identité doit suivre idStrategy (sinon les FK session/account sont incohérentes).
  const at = authCtx.userTable && !isPrisma ? src.search(new RegExp(`Table\\(\\s*["']${authCtx.userTable}["']`)) : -1;
  const idType = at >= 0 ? (/\b(\w+)\(\s*["']id["']/.exec(src.slice(at).split(/Table\(/)[1] ?? "") ?? [])[1] : undefined;
  const okTypes = ({ uuid: ["uuid"], serial: ["serial", "integer", "bigint", "bigserial"] } as Record<string, string[]>)[cfg.idStrategy ?? ""];
  if (idType && okTypes && !okTypes.includes(idType)) console.warn(`[nestjs] authUserTable ${authCtx.userTable} : id de type ${idType} incompatible avec idStrategy ${cfg.idStrategy} (attendu : ${okTypes.join("|")})`);
  files.push({ path: ".scaf-identity.json", content: identity });
  // Identité changée sur un projet déjà migré : la migration suivante serait destructive (ids text -> uuid, DROP user) : on bloque, avec le guide.
  const prev = join(out, ".scaf-identity.json"), mig = join(out, isPrisma ? "prisma/migrations" : isTypeorm ? "src/database/migrations" : "drizzle");
  if (!dry && !argv.includes("--force") && existsSync(prev) && readFileSync(prev, "utf8") !== identity && existsSync(mig) && readdirSync(mig).some(x => isPrisma ? !x.endsWith(".toml") : isTypeorm ? x.endsWith(".ts") : x.endsWith(".sql")))
    fail(`identité Better Auth modifiée (authUserTable / idStrategy / authUserFields / plugins) sur un projet déjà migré : db:migrate serait destructif pour les tables Better Auth existantes.\n  Base de test : supprimer les tables Better Auth (et les migrations qui les créent), puis régénérer avec --force.\n  Base avec données : régénérer avec --force, puis écrire la migration à la main (USING id::uuid) ; scripts/db-guard.mjs bloque toute migration destructive (SCAF_ALLOW_DESTRUCTIVE=1 pour l'autoriser).`);
}
// rateLimiting : true | { default?, endpoints? } → ThrottlerGuard global + @Throttle par endpoint
type RL = { limit: number; ttlMs: number };
const rlCfg = (cfg.rateLimiting && typeof cfg.rateLimiting === "object" ? cfg.rateLimiting : {}) as { default?: RL; endpoints?: Record<string, RL> };
const rlOn = cfg.rateLimiting === true || (!!cfg.rateLimiting && typeof cfg.rateLimiting === "object");
const mods = level === "N0" ? [] : modules.map(m => generateModule(architecture, m, usecaseBase, db?.repos, modules, rlOn ? rlCfg.endpoints : undefined, validation));
const events = mods.some(x => x.events);
if (rlOn) DEPS.push("@nestjs/throttler"); // rateLimiting : ThrottlerGuard global (429 RATE_LIMITED)
if (events) DEPS.push("@nestjs/event-emitter"); // calls[].mode: event → EventEmitter2
const codes = modules.flatMap(m => m.endpoints.flatMap(e => e.errors.map(x => x.code)));
// e2e : un test par mock des contrats (jest ou vitest, testFramework). Variables d'environnement factices pour l'import de l'app.
const e2e = level !== "N0" && cfg.e2e === true && modules.some(m => m.endpoints.length > 0); // app sans API : aucun mock, pas d'e2e
const envMode: string = argv.includes("--no-env-file") ? "example" : cfg.envFile ?? "example_and_file";
const vars = envVars({ auth, db: db ? { dialect: database } : undefined, databaseUrl: cfg.databaseUrl, authSecret: cfg.authSecret, authBaseUrl: cfg.authBaseUrl, oauthProviders: cfg.oauthProviders ?? [], port: cfg.port ?? 3000, rateLimiting: rlOn && !rlCfg.default, mailer: cfg.mailer, sms: cfg.sms, logger: cfg.logger, sentry: xo.sentry, cache: xo.cache, queue: xo.queue });
const env = envFiles(vars, envMode, cfg.generateSecrets !== false);
const e2eEnv = Object.fromEntries(vars.filter(x => x.e2e).map(x => [x.name, x.e2e!]));
const dbScripts = { ...db?.scripts, ...authPlan?.scripts };
if (db?.scripts["db:migrate"]) dbScripts["db:setup"] = [...(dbScripts["auth:generate"] ? ["auth:generate"] : []), "db:generate", ...(dbScripts["db:guard"] ? ["db:guard"] : []), "db:migrate", ...(dbScripts["auth:migrate"] ? ["auth:migrate"] : []), ...(dbScripts["db:rls"] ? ["db:rls"] : [])].map(x => `pnpm ${x}`).join(" && ");
files.push(...env.files);
if (envMode !== "none") files.push(envGuardFile(vars));
files.push(setupReadme({ name: basename(abs(out)), vars, envMode, db: !!db, betterAuth: auth === "better_auth", e2e, migrations: !!db?.scripts["db:migrate"], rls: !!db?.scripts["db:rls"] }));
files.push(...generateCore({ validation, zod, description: cfg.description, nodeVersion: cfg.nodeVersion, events, usecaseBase, name: basename(abs(out)), deps: DEPS, auth, validationStatus, codes, port: cfg.port ?? 3000, globalPrefix: cfg.globalPrefix ?? "", versioning: cfg.versioning, healthCheck: !standalone && (argv.includes("--health-check") || !!cfg.healthCheck), standalone, rateLimiting: rlOn, rateLimitDefault: rlCfg.default, cors: cfg.cors, bodyParser: cfg.bodyParser, swagger: sw.served.length ? sw.served : undefined, devDeps: [...(db?.devDeps ?? []), ...(authPlan?.devDeps ?? []), ...(e2e ? e2eDevDeps(testFramework) : [])], scripts: { ...dbScripts, ...env.scripts, ...(e2e ? e2eScripts(testFramework) : {}) }, authCtx, envGuard: envMode !== "none", ...xo }, [...(db ? [db.module] : []), ...(() => { const o = orderModules(modules).map(k => modules.find(m => m.key === k)!.pascal + "Module"); return [...mods].sort((x, y) => o.indexOf(x.moduleClass) - o.indexOf(y.moduleClass)); })().map(m => ({ cls: m.moduleClass, path: "./" + m.modulePath.replace(/^src\//, "").replace(/\.ts$/, "") }))]));
files.push(...mods.flatMap(m => m.files));
if (e2e) { files.push(...e2eFiles(modules, { validation, auth, globalPrefix: cfg.globalPrefix ?? "", versioning: cfg.versioning, env: e2eEnv, rateLimiting: rlOn, cache: xo.cache, fastify: xo.fastify, framework: testFramework })); const n = e2eCases(modules, auth); console.log(`[nestjs] e2e : ${[...n.byModule.values()].reduce((t, c) => t + c.length, 0)} mocks → test/e2e (${n.skipped} ignorés : 5xx/429/413${auth === "none" ? ", 401/403 sans auth" : ""}) ; pnpm test:e2e`); }
if (usecaseBase === "template_method") {
  const stale = files.filter(f => f.preserve && f.path.endsWith(`.${S.ext}.ts`) && existsSync(join(out, f.path)) && !readFileSync(join(out, f.path), "utf8").includes("extends BaseUsecase"));
  if (stale.length) console.warn(`[nestjs] ${stale.length} usecase(s) existant(s) sans BaseUsecase (conservés) : ${stale[0].path}…`);
}
// --overwrite <id|glob*|all> (répétable) : usecases conservés (preserve) que le générateur peut réécrire (le code écrit à la main est perdu)
const owSel = argv.flatMap((a, i) => (a === "--overwrite" && argv[i + 1] ? [argv[i + 1]] : []));
const overwrite = new Set<string>();
for (const sel of owSel) {
  const re = new RegExp(`^${sel.split("*").map(x => x.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join(".*")}$`);
  const hit = files.filter(f => f.preserve && f.path.endsWith(`.${S.ext}.ts`) && existsSync(join(out, f.path)) && (sel === "all" || re.test(basename(f.path, `.${S.ext}.ts`))));
  if (!hit.length) console.warn(`[nestjs] --overwrite ${sel} : aucun usecase existant ne correspond`);
  hit.forEach(f => overwrite.add(f.path));
}
if (overwrite.size) console.warn(`[nestjs] --overwrite : ${overwrite.size} usecase(s) seront réécrits (code manuel perdu)${dry ? " [dry-run]" : ""} : ${[...overwrite].slice(0, 3).join(", ")}${overwrite.size > 3 ? "…" : ""}`);
// JSDoc des usecases conservés (écrits une fois) : signaler ceux qui ne reflètent plus l'intent/les étapes/erreurs actuels
{
  const head = (s: string) => s.match(/\/\*\*\n \* ([\s\S]*?)\n \*\/\n@Injectable\(\)/)?.[1];
  const drift = files.filter(f => f.preserve && !overwrite.has(f.path) && f.path.endsWith(`.${S.ext}.ts`) && existsSync(join(out, f.path)) && typeof f.content === "string" && (() => { const a = head(readFileSync(join(out, f.path), "utf8")), b = head(f.content as string); return a !== undefined && b !== undefined && a !== b; })());
  if (drift.length) console.warn(`[nestjs] ${drift.length} usecase(s) conservé(s) dont le JSDoc diffère de la spec actuelle (intent, étapes, erreurs) : ${drift.slice(0, 3).map(f => f.path).join(", ")}${drift.length > 3 ? "…" : ""} — recopier l'en-tête depuis le guide d'implémentation ou supprimer le fichier pour le régénérer`);
}
mods.flatMap(m => m.unresolved).forEach(w => console.warn(`[nestjs] intent.tables : ${w}`));
if (!db) { const n = modules.flatMap(m => m.endpoints).filter(e => e.intent?.tables?.length).length; if (n) console.warn(`[nestjs] ${n} usecase(s) déclarent intent.tables : rien injecté hors niveau N2`); }
for (const l of mods.flatMap(m => m.links)) { const f = join(out, l.path); if (existsSync(f)) { const src = readFileSync(f, "utf8"), miss = l.classes.filter(c => !src.includes(c)); if (miss.length) console.warn(`[nestjs] ${l.path} (conservé) : à injecter à la main ${miss.join(", ")} (intent.tables)`); } }
const pkgPath = join(out, "package.json"), pkgBefore = existsSync(pkgPath) ? JSON.parse(readFileSync(pkgPath, "utf8")) : undefined;
{ const af = join(out, "src/better-auth/auth.ts"); if (authCtx.userTable && existsSync(af) && !readFileSync(af, "utf8").includes(`modelName: ${JSON.stringify(authCtx.userTable)}`)) console.warn(`[nestjs] src/better-auth/auth.ts (conservé) : user.modelName "${authCtx.userTable}" absent (authUserTable) : l'ajouter ou supprimer le fichier pour le régénérer`); }
for (const f of files) if (f.path.endsWith(".ts") && typeof f.content === "string") f.content = fmtImports(f.content);
const ours = `src/modules/${architecture}/`;
pmFiles(files, cfg.packageManager);
writeTree(files, { root: out, level, scafVersion: scafVersionName(versionDir), dry, force: argv.includes("--force"), overwrite, tag: "nestjs", foreign: p => p.startsWith("src/modules/") && !p.startsWith(ours) });

// package.json (fichier utilisateur) : on y ajoute seulement les scripts/dépendances manquants du plan, sans toucher à l'existant.
if (pkgBefore && !dry) {
  const want = JSON.parse(files.find(f => f.path === "package.json")!.content), added: string[] = [];
  for (const k of ["scripts", "dependencies", "devDependencies"]) {
    const cur = (pkgBefore[k] ??= {});
    for (const [n, v] of Object.entries(want[k] ?? {})) if (!(n in cur) && !(k !== "scripts" && n in (pkgBefore[k === "dependencies" ? "devDependencies" : "dependencies"] ?? {}))) { cur[n] = v; added.push(`${k}.${n}`); }
    if (k !== "scripts") pkgBefore[k] = Object.fromEntries(Object.entries(cur).sort(([a], [b]) => a.localeCompare(b)));
  }
  // Scripts gérés par le générateur : valeur existante ≠ valeur attendue ⇒ signalé (fichier utilisateur, jamais réécrit en silence).
  for (const n of ["auth:generate", "db:setup", "db:guard", "db:rls"]) { const cur = pkgBefore.scripts?.[n], exp = want.scripts?.[n]; if (cur && exp && cur !== exp) console.warn(`[nestjs] package.json (conservé) : script ${n} périmé ; attendu : ${exp}`); }
  if (added.length) { writeFileSync(pkgPath, JSON.stringify(pkgBefore, null, 2) + "\n"); console.warn(`[nestjs] package.json (conservé) : ajouté ${added.join(", ")} ; relancer \`pnpm install\``); }
}
console.log(`[nestjs] package.json, tsconfig.json, nest-cli.json créés s'ils n'existent pas ; \`pnpm install\` dans l'API`);
[...(db?.notes ?? []), ...(authPlan?.notes ?? AUTH_ADAPTERS[auth].notes)].forEach(n => console.log(`[nestjs] ${n}`));
const todoVars = vars.filter(x => x.required && x.kind !== "secret" && !x.value).map(x => x.name);
if (envMode !== "none") console.log(`[nestjs] .env : créé s'il n'existe pas (secrets générés) ; \`pnpm env:init\` ajoute les variables absentes${todoVars.length ? ` ; à renseigner : ${todoVars.join(", ")}` : ""}`);
