# Modèle visuel -> schema.prisma (Prisma 7, datasource postgresql | mysql | sqlite). Appelé par visual_to_sql.rb (--format prisma).
# Exprimé : tables (@@map), colonnes (@map si --keys camel), enums, PK simple/composite, unique, défauts, FK (relations nommées, onDelete/onUpdate), index (colonnes ; méthode pg).
# Non exprimé (W) : CHECK, index sur expressions ou partiels, RLS, FK vers une colonne ni PK ni unique. L'URL de connexion vit dans prisma.config.ts (Prisma 7).
module PrismaSchema
  module_function

  IDENT = /\A[A-Za-z][A-Za-z0-9_]*\z/
  ACTIONS = { 'cascade' => 'Cascade', 'set null' => 'SetNull', 'restrict' => 'Restrict', 'no action' => 'NoAction' }.freeze
  PG_METHODS = { 'hash' => 'Hash', 'gin' => 'Gin', 'gist' => 'Gist', 'brin' => 'Brin' }.freeze

  def pascal(n); n.to_s.split(/[_\W]+/).reject(&:empty?).map { |w| w[0].upcase + w[1..] }.join; end
  def camel(n); p = pascal(n); p.empty? ? p : p[0].downcase + p[1..]; end
  def doc(s, ind = ''); (t = s.to_s.gsub(/\s*\n\s*/, ' ').strip).empty? ? '' : "#{ind}/// #{t}\n"; end

  # [type Prisma, attribut natif] selon le type scaf et le dialecte
  def scalar(c, dialect, enum_name)
    pg, my = dialect == 'postgresql', dialect == 'mysql'
    nat = ->(s) { dialect == 'sqlite' ? '' : " #{s}" }
    case c['type']
    when 'uuid' then ['String', pg ? ' @db.Uuid' : my ? ' @db.Char(36)' : '']
    when 'text' then ['String', my ? ' @db.Text' : '']
    when 'integer' then ['Int', '']
    when 'bigint' then ['BigInt', '']
    when 'boolean' then ['Boolean', '']
    when 'datetime' then ['DateTime', pg ? ' @db.Timestamptz(6)' : '']
    when 'date' then ['DateTime', nat.('@db.Date')]
    when 'jsonb' then ['Json', '']
    when 'enum' then [enum_name, '']
    when /\Avarchar\((\d+)\)\z/ then ['String', nat.("@db.VarChar(#{$1})")]
    else
      m = /\Adecimal(?:\((\d+),\s*(\d+)\))?\z/.match(c['type'].to_s)
      ['Decimal', m ? nat.("@db.Decimal(#{m[1] || 18}, #{m[2] || 2})") : '']
    end
  end

  def default_attr(c, enum_vals, dialect = nil)
    v = c['default']
    return (c['_autouuid'] ? ' @default(uuid())' : '') if v.nil?
    s = v.to_s.sub(/::\w+\z/, '')
    return '' if s.upcase == 'NULL'
    return ' @default(now())' if s =~ /\A(NOW\(\)|CURRENT_TIMESTAMP)\z/i
    dbg = ->(e) { dialect == 'mysql' ? "(#{e})" : e } # MySQL : défaut expression = entre parenthèses
    return " @default(dbgenerated(\"#{dbg.(s.upcase)}\"))" if s =~ /\ACURRENT_(DATE|TIME)\z/i
    str = s =~ /\A'(.*)'\z/m ? $1.gsub("''", "'") : nil
    if c['type'] == 'enum'
      id = enum_vals[str || s]
      return id ? " @default(#{id})" : ''
    end
    if c['type'] == 'jsonb' && str
      return " @default(dbgenerated(\"'#{str.gsub("'", "''").gsub('"', '\\"')}'\"))" if dialect == 'sqlite' # Prisma écrit DEFAULT {} sans guillemets pour Json sur SQLite
      return " @default(\"#{str.gsub('\\', '\\\\\\\\').gsub('"', '\\"')}\")"
    end
    return " @default(#{s})" if str.nil? && s =~ /\A(-?\d+(\.\d+)?|true|false)\z/
    return " @default(dbgenerated(\"#{dbg.(s.gsub('"', '\\"'))}\"))" if str.nil? && s =~ /\A\w+\(.*\)\z/
    val = str || s
    return " @default(#{val})" if c['type'] =~ /\A(decimal|integer|bigint)/ && val =~ /\A-?\d+(\.\d+)?\z/
    " @default(\"#{val.gsub('\\', '\\\\\\\\').gsub('"', '\\"')}\")"
  end

  def generate(dialect:, tables:, all_tables:, enums:, keys:, warn:, error:, unsupported: ->(_i) { nil })
    used = {}
    uniq = ->(n) { n += 'Enum' while used[n]; used[n] = true; n }
    enum_name = enums.to_h { |e| [e['name'], uniq.(pascal(e['name']))] }
    model_name = tables.to_h { |t| [t['name'], uniq.(pascal(t['name']))] }
    key = ->(n) { keys == 'camel' ? camel(n) : n }
    by_table = all_tables.to_h { |t| [t['name'], t] }

    out = +"// Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n"
    out << "generator client {\n  provider            = \"prisma-client\"\n  output              = \"../src/generated/prisma\"\n  moduleFormat        = \"cjs\"\n  importFileExtension = \"\"\n}\n\n"
    out << "datasource db {\n  provider = \"#{dialect}\"\n}\n\n"

    enum_ids = {}
    enums.each do |e|
      ids = {}
      body = e['values'].map do |v|
        raw = v['value'].to_s
        id = raw =~ IDENT ? raw : (raw.gsub(/\W/, '_').sub(/\A(\d|_)/, 'V_\1'))
        ids[raw] = id
        "#{doc(v['description'], '  ')}  #{id}#{id == raw ? '' : %( @map("#{raw.gsub('"', '\\"')}"))}"
      end
      enum_ids[e['name']] = ids
      out << doc(e['description']) << "enum #{enum_name[e['name']]} {\n#{body.join("\n")}\n#{dialect == 'postgresql' ? "  @@map(\"#{e['name']}\")\n" : ''}}\n\n"
    end

    # relations : pour chaque FK, un champ relation côté enfant et un champ inverse côté parent
    child_rel = Hash.new { |h, k| h[k] = {} }   # table => { colonne => ligne }
    parent_back = Hash.new { |h, k| h[k] = [] } # table parente => lignes
    tables.each do |t|
      names = t['columns'].map { |c| key.(c['name']) }
      taken = names.dup
      t['columns'].each do |c|
        r = c['references'] or next
        tgt = by_table[r['table']]
        next if tgt.nil? || tgt['external']   # cible externe : colonne simple (FK hors modèle), comme Drizzle
        tcol = tgt['columns'].find { |x| x['name'] == r['column'] }
        unless tcol && ((tcol['primary'] && tgt['columns'].count { |x| x['primary'] } == 1) || tcol['unique'])
          warn.("W #{t['name']}.#{c['name']} : relation Prisma ignorée — #{r['table']}.#{r['column']} n'est ni clé primaire simple ni unique")
          next
        end
        base = key.(c['name'].sub(/_id\z/, ''))
        base = key.("#{c['name']}_rel") if base.empty? || taken.include?(base)
        taken << base
        rn = "fk_#{t['name']}_#{c['name']}"
        act = %w[onDelete onUpdate].map { |k| ", #{k}: #{ACTIONS[r[k]] || 'NoAction'}" }.join
        child_rel[t['name']][c['name']] = "  #{base} #{model_name[r['table']]}#{c['nullable'] ? '?' : ''} @relation(\"#{rn}\", fields: [#{key.(c['name'])}], references: [#{key.(r['column'])}]#{act})"
        one = c['unique'] || (c['primary'] && t['columns'].count { |x| x['primary'] } == 1)
        parent_back[r['table']] << "  #{key.("#{t['name']}_#{c['name']}")} #{model_name[t['name']]}#{one ? '?' : '[]'} @relation(\"#{rn}\")"
      end
    end

    tables.each do |t|
      pk = t['columns'].select { |c| c['primary'] }
      lines = []
      t['columns'].each do |c|
        n = c['name']
        if c['type'] == 'enum' && !enum_name[c['enumRef']]
          error.("E #{t['name']}.#{n} : enumRef inconnu (#{c['enumRef'].inspect})")
          next
        end
        ty, nat = scalar(c, dialect, enum_name[c['enumRef']])
        opt = c['nullable'] ? '?' : ''
        attrs = +''
        attrs << ' @id' if c['primary'] && pk.size == 1
        attrs << ' @unique' if c['unique'] && !c['primary']
        attrs << default_attr(c, enum_ids[c['enumRef']] || {}, dialect)
        attrs << %( @map("#{n}")) if key.(n) != n
        attrs << nat
        lines << "#{doc(c['description'], '  ')}  #{key.(n)} #{ty}#{opt}#{attrs}"
        lines << child_rel[t['name']][n] if child_rel[t['name']][n]
      end
      lines.concat(parent_back[t['name']])
      lines << "  @@id([#{pk.map { |c| key.(c['name']) }.join(', ')}])" if pk.size > 1
      (t['indexes'] || []).each do |i|
        if (why = unsupported.(i))
          warn.("W #{t['name']}.#{i['name']} : index ignoré (#{dialect}) — #{why}")
          next
        end
        if (i['expressions'] || []).any? || i['where']
          warn.("W #{t['name']}.#{i['name']} : index ignoré (Prisma) — expression ou clause WHERE non exprimable")
          next
        end
        cols = (i['columns'] || []).map { |x| key.(x) }.join(', ')
        meth = dialect == 'postgresql' && PG_METHODS[i['method']] ? ", type: #{PG_METHODS[i['method']]}" : ''
        lines << "  @@#{i['unique'] ? 'unique' : 'index'}([#{cols}]#{meth}, map: \"#{i['name']}\")"
      end
      lines << "  @@map(\"#{t['name']}\")"
      (t['checks'] || []).each { |k| warn.("W #{t['name']}.#{k['name']} : CHECK non exprimé par Prisma (présent dans sql/ seulement)") }
      out << doc(t['description']) << "model #{model_name[t['name']]} {\n#{lines.join("\n")}\n}\n\n"
    end
    out.rstrip + "\n"
  end
end
