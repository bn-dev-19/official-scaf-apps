# Modèle visuel -> entités TypeORM (un seul fichier entities.ts ; postgresql | mysql | sqlite). Appelé par visual_to_sql.rb (--format typeorm).
# Exprimé : tables (@Entity), colonnes (name: si clé camel), enums (type enum | simple-enum), PK simple/composite/uuid auto, unique, défauts, FK (@ManyToOne + @JoinColumn nommée, onDelete/onUpdate), index (colonnes, WHERE, méthode pg), CHECK.
# Non exprimé (W) : index sur expressions, RLS, FK vers une colonne ni PK ni unique. Les migrations viennent de `typeorm migration:generate` (entités = source).
module TypeormSchema
  module_function

  IDENT = /\A[A-Za-z][A-Za-z0-9_]*\z/
  ACTIONS = { 'cascade' => 'CASCADE', 'set null' => 'SET NULL', 'restrict' => 'RESTRICT', 'no action' => 'NO ACTION' }.freeze

  def pascal(n); n.to_s.split(/[_\W]+/).reject(&:empty?).map { |w| w[0].upcase + w[1..] }.join; end
  def camel(n); p = pascal(n); p.empty? ? p : p[0].downcase + p[1..]; end
  def js(s); s.to_s.to_json; end
  def doc(s, ind = ''); (t = s.to_s.gsub(/\s*\n\s*/, ' ').gsub('*/', '* /').strip).empty? ? '' : "#{ind}/** #{t} */\n"; end

  # [type TS, options de colonne (liste de "clé: valeur")] selon le type scaf et le dialecte
  def column(c, dialect, enum_vals)
    pg, my = dialect == 'postgresql', dialect == 'mysql'
    case c['type']
    when 'uuid' then ['string', [pg ? 'type: "uuid"' : my ? 'type: "char", length: 36' : 'type: "varchar", length: 36']]
    when 'text' then ['string', ['type: "text"']]
    when 'integer' then ['number', ['type: "integer"']]
    when 'bigint' then ['string', ['type: "bigint"']]
    when 'boolean' then ['boolean', ['type: "boolean"']]
    when 'datetime' then ['Date', [pg ? 'type: "timestamptz"' : my ? 'type: "datetime", precision: 6' : 'type: "datetime"']]
    when 'date' then ['string', ['type: "date"']]
    when 'jsonb' then ['unknown', [pg ? 'type: "jsonb"' : my ? 'type: "json"' : 'type: "simple-json"']]
    when 'enum'
      ts = enum_vals.map { |v| js(v) }.join(' | ')
      [ts.empty? ? 'string' : ts, [dialect == 'sqlite' ? 'type: "simple-enum"' : 'type: "enum"', "enum: [#{enum_vals.map { |v| js(v) }.join(', ')}]"]]
    when /\Avarchar\((\d+)\)\z/ then ['string', ['type: "varchar"', "length: #{$1}"]]
    else
      m = /\Adecimal(?:\((\d+),\s*(\d+)\))?\z/.match(c['type'].to_s)
      ['string', ['type: "decimal"', "precision: #{m ? (m[1] || 18) : 18}", "scale: #{m ? (m[2] || 2) : 2}"]]
    end
  end

  # option `default:` (nil si aucun)
  def default_opt(c, dialect)
    v = c['default']
    return nil if v.nil?
    s = v.to_s.sub(/::\w+\z/, '')
    return nil if s.upcase == 'NULL'
    return "default: () => \"CURRENT_TIMESTAMP#{dialect == 'mysql' ? '(6)' : ''}\"" if s =~ /\A(NOW\(\)|CURRENT_TIMESTAMP)\z/i
    str = s =~ /\A'(.*)'\z/m ? $1.gsub("''", "'") : nil
    # MySQL relit les défauts-expressions sous une autre forme (curdate(), _utf8mb4'[]') : TypeORM les verrait modifiés à chaque db:generate -> omis (présents dans sql/)
    return nil if dialect == 'mysql' && (s =~ /\ACURRENT_(DATE|TIME)\z/i || (c['type'] == 'jsonb' && str) || (str.nil? && s =~ /\A\w+\(.*\)\z/))
    return "default: () => #{js(s.upcase)}" if s =~ /\ACURRENT_(DATE|TIME)\z/i
    return "default: () => #{js("'#{str.gsub("'", "''")}'")}" if c['type'] == 'jsonb' && str
    return "default: () => #{js(s)}" if str.nil? && s =~ /\A\w+\(.*\)\z/
    val = str || s
    if dialect == 'mysql' && c['type'].to_s =~ /\Adecimal(?:\(\d+,\s*(\d+)\))?\z/ && val =~ /\A-?\d+(\.\d+)?\z/ # MySQL relit 0.00
      return "default: #{js(format("%.#{$1 || 2}f", val.to_f))}"
    end
    return "default: #{val}" if c['type'] =~ /\A(integer|bigint)/ && val =~ /\A-?\d+\z/
    return "default: #{val}" if c['type'] == 'boolean' && val =~ /\A(true|false)\z/
    "default: #{js(val)}"
  end

  def generate(dialect:, tables:, all_tables:, enums:, keys:, warn:, error:, unsupported: ->(_i) { nil })
    used = {}
    uniq = ->(n) { n += 'Entity' while used[n]; used[n] = true; n }
    cls = tables.to_h { |t| [t['name'], uniq.(pascal(t['name']))] }
    key = ->(n) { keys == 'camel' ? camel(n) : n }
    by_table = all_tables.to_h { |t| [t['name'], t] }
    enum_values = enums.to_h { |e| [e['name'], e['values'].map { |v| v['value'].to_s }] }

    rels = Hash.new { |h, k| h[k] = {} } # table => { colonne => [propriété relation, entité cible, nullable, action(s)] }
    tables.each do |t|
      taken = t['columns'].map { |c| key.(c['name']) }
      t['columns'].each do |c|
        r = c['references'] or next
        tgt = by_table[r['table']]
        next if tgt.nil? || tgt['external'] # cible externe : colonne simple (FK hors modèle)
        tcol = tgt['columns'].find { |x| x['name'] == r['column'] }
        unless tcol && ((tcol['primary'] && tgt['columns'].count { |x| x['primary'] } == 1) || tcol['unique'])
          warn.("W #{t['name']}.#{c['name']} : relation TypeORM ignorée — #{r['table']}.#{r['column']} n'est ni clé primaire simple ni unique")
          next
        end
        base = key.(c['name'].sub(/_id\z/, ''))
        base = key.("#{c['name']}_rel") if base.empty? || taken.include?(base)
        taken << base
        rels[t['name']][c['name']] = { prop: base, target: cls[r['table']], ref: key.(r['column']), r: r, nullable: c['nullable'] }
      end
    end

    out = +"// Généré par scaf/_agent-kit/tools/visual_to_sql.rb à partir de database/visual — ne pas éditer à la main.\n"
    out << "import { Check, Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn, PrimaryGeneratedColumn, type Relation } from \"typeorm\";\n\n"
    tables.each do |t|
      pk = t['columns'].select { |c| c['primary'] }
      body = []
      deco = []
      t['columns'].each do |c|
        n = c['name']
        if c['type'] == 'enum' && !enum_values[c['enumRef']]
          error.("E #{t['name']}.#{n} : enumRef inconnu (#{c['enumRef'].inspect})")
          next
        end
        ts, opts = column(c, dialect, enum_values[c['enumRef']] || [])
        opts = ["name: #{js(n)}"] + opts
        opts << 'nullable: true' if c['nullable']
        opts << 'unique: true' if c['unique'] && !c['primary']
        d = c['_autouuid'] ? nil : default_opt(c, dialect)
        opts << d if d
        nul = c['nullable'] ? ' | null' : ''
        dec =
          if c['_autouuid'] && pk.size == 1 then %(@PrimaryGeneratedColumn("uuid", { name: #{js(n)} }))
          elsif c['primary'] then "@PrimaryColumn({ #{opts.join(', ')} })"
          else "@Column({ #{opts.join(', ')} })"
          end
        body << "#{doc(c['description'], '  ')}  #{dec}\n  #{key.(n)}!: #{ts}#{nul};"
        next unless (rel = rels[t['name']][n])
        r = rel[:r]
        ro = ["nullable: #{c['nullable'] ? 'true' : 'false'}"] + %w[onDelete onUpdate].map { |k| r[k] && "#{k}: #{js(ACTIONS[r[k]] || 'NO ACTION')}" }.compact
        body << "  @ManyToOne(() => #{rel[:target]}, { #{ro.join(', ')} })\n  @JoinColumn({ name: #{js(n)}, referencedColumnName: #{js(rel[:ref])}, foreignKeyConstraintName: #{js("fk_#{t['name']}_#{n}")} })\n  #{rel[:prop]}?: Relation<#{rel[:target]}>#{c['nullable'] ? ' | null' : ''};"
      end
      (t['indexes'] || []).each do |i|
        if (why = unsupported.(i))
          warn.("W #{t['name']}.#{i['name']} : index ignoré (#{dialect}) — #{why}")
          next
        end
        if (i['expressions'] || []).any?
          warn.("W #{t['name']}.#{i['name']} : index ignoré (TypeORM) — expression non exprimable")
          next
        end
        props = (i['columns'] || []).map { |x| js(key.(x)) }.join(', ')
        o = []
        o << 'unique: true' if i['unique']
        o << "where: #{js(i['where'])}" if i['where']
        o << "type: #{js(i['method'])}" if dialect == 'postgresql' && i['method'] && i['method'] != 'btree'
        deco << "@Index(#{js(i['name'])}, [#{props}]#{o.empty? ? '' : ", { #{o.join(', ')} }"})"
      end
      (t['checks'] || []).each { |k| deco << "@Check(#{js(k['name'])}, #{js(k['expression'])})" }
      out << doc(t['description']) << deco.join("\n") << (deco.empty? ? '' : "\n") << "@Entity(#{js(t['name'])})\nexport class #{cls[t['name']]} {\n#{body.join("\n\n")}\n}\n\n"
    end
    out << "/** Toutes les entités (DataSource.entities). */\nexport const entities = [\n#{tables.map { |t| "  #{cls[t['name']]}," }.join("\n")}\n];\n"
    out
  end
end
