import type { GeneratedFile } from "../../_shared/generated-file";
import type { SpecContext, ParsedEndpoint, MockScenario } from "../../_shared/_lib/spec-types";
import { HEADER } from "../../_shared/_lib/header";
import { kebabToPascal, kebabToCamel, kebabToScreamingSnake, pathToImportAlias, escapeString, extractPathParams, getVersionDir } from "../../_shared/_lib/naming";
import { coerceErrorDefs, coerceFieldDefs, defaultErrorMessage, type CoercedErrorDef } from "../../_shared/_lib/spec-normalize";
import {
  yamlTypeToTS,
  yamlTypeToZod,
  mockValueToConst,
  generateEnumDef,
  collectEnumTypes,
  buildMockByKey,
  requiredFieldNames,
  type EnumVal,
} from "../../_shared/_lib/yaml-utils";

// ── Enum validation in mocks ──

/**
 * Walk a mock body object and validate that enum field values match the enum definition.
 * Emits warnings for mismatched values.
 */
function validateMockEnumValues(
  body: unknown,
  localEnumMap: Map<string, EnumVal[]>,
  fieldPath: string,
  warnings: string[],
  epId: string,
  mockName: string,
): void {
  if (body == null || typeof body !== "object") return;
  const obj = body as Record<string, unknown>;
  for (const [key, value] of Object.entries(obj)) {
    const enumKey = fieldPath ? `${fieldPath}${kebabToPascal(key)}` : kebabToPascal(key);
    const validValues = localEnumMap.get(enumKey);
    if (validValues && (typeof value === "string" || typeof value === "number")) {
      if (!validValues.includes(value)) {
        const msg = `Mock "${mockName}" : valeur enum invalide pour "${key}" — "${value}" (valeurs attendues: ${validValues.join(", ")}) : ${epId}`;
        warnings.push(msg);
        console.warn(`⚠ ${msg}`);
      }
    }
    if (typeof value === "object" && value !== null && !Array.isArray(value)) {
      validateMockEnumValues(value, localEnumMap, enumKey, warnings, epId, mockName);
    }
    if (Array.isArray(value)) {
      for (const item of value) {
        if (typeof item === "object" && item !== null) {
          validateMockEnumValues(item, localEnumMap, enumKey, warnings, epId, mockName);
        }
      }
    }
  }
}

// ── Feature key helper ──

function featureKey(ep: ParsedEndpoint): string {
  return `${ep.app}/${ep.module}/${ep.feature}`;
}

// ── Shared enums computation per feature ──

/** Enums définis par un endpoint (body, réponse, query) — clé = chemin du champ. */
function ownEnums(ep: ParsedEndpoint): Map<string, EnumVal[]> {
  const own = new Map<string, EnumVal[]>();
  collectEnumTypes(ep.spec?.http?.request?.body?.properties, "", own);
  collectEnumTypes(ep.spec?.http?.response?.body?.properties, "", own);
  for (const q of coerceFieldDefs(ep.spec?.http?.request?.query)) {
    if (q.enum && q.enum.length > 0) own.set(kebabToPascal(q.name), q.enum);
  }
  return own;
}

/**
 * Pour les endpoints d'une feature : un enum est partagé (types.ts) si ≥2
 * endpoints le définissent avec exactement les mêmes valeurs ; sinon il reste
 * propre à l'endpoint (même nom + valeurs différentes ⇒ jamais fusionnés).
 */
function computeFeatureSharedEnums(
  endpoints: ParsedEndpoint[],
): [Map<string, EnumVal[]>, Map<ParsedEndpoint, Map<string, EnumVal[]>>] {
  const own = new Map(endpoints.map((ep) => [ep, ownEnums(ep)] as const));
  const byName = new Map<string, { sigs: Set<string>; count: number; values: EnumVal[] }>();
  for (const m of own.values()) {
    for (const [name, values] of m) {
      const e = byName.get(name) ?? { sigs: new Set<string>(), count: 0, values };
      e.sigs.add(JSON.stringify(values));
      e.count++;
      byName.set(name, e);
    }
  }
  const shared = new Map<string, EnumVal[]>();
  for (const [name, e] of byName) if (e.count >= 2 && e.sigs.size === 1) shared.set(name, e.values);
  const specific = new Map<ParsedEndpoint, Map<string, EnumVal[]>>();
  for (const [ep, m] of own) {
    specific.set(ep, new Map([...m].filter(([name]) => !shared.has(name))));
  }
  return [shared, specific];
}

// ── Main entry point ──

export function generateSharedTypes(context: SpecContext, versionDir?: string): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const centralEntries: CentralEntry[] = [];
  const vd = versionDir ?? "v1";

  // Phase 1: Generate shared shapes files
  files.push({
    path: "src/api-shared/shapes/error-shapes.ts",
    content: generateErrorShapesFile(),
  });
  files.push({
    path: "src/api-shared/shapes/response-shapes.ts",
    content: generateResponseShapesFile(),
  });
  files.push({
    path: "src/api-shared/shapes/mock-shapes.ts",
    content: generateMockShapesFile(),
  });

  // Phase 2: Group endpoints by feature for enum deduplication
  const byFeature = new Map<string, ParsedEndpoint[]>();
  for (const ep of context.endpoints) {
    const key = featureKey(ep);
    const list = byFeature.get(key) ?? [];
    list.push(ep);
    byFeature.set(key, list);
  }

  const endpointSpecificEnums = new Map<ParsedEndpoint, Map<string, EnumVal[]>>();

  const featureShared = new Map<string, Map<string, EnumVal[]>>();
  for (const [key, featureEndpoints] of byFeature) {
    const [sharedEnums, specificEnumsMap] = computeFeatureSharedEnums(featureEndpoints);
    featureShared.set(key, sharedEnums);
    for (const [ep, specific] of specificEnumsMap) endpointSpecificEnums.set(ep, specific);
    if (sharedEnums.size > 0) {
      const { app, module: mod, feature } = featureEndpoints[0];
      files.push({
        path: `src/api-shared/${vd}/${app}/${mod}/${feature}/types.ts`,
        content: generateFeatureTypesFile(sharedEnums),
      });
    }
  }

  // Generate per-endpoint files
  for (const ep of context.endpoints) {
    const key = featureKey(ep);
    const sharedEnums = featureShared.get(key) ?? new Map<string, EnumVal[]>();

    const specific = endpointSpecificEnums.get(ep) ?? new Map<string, EnumVal[]>();
    const { mainContent, mocksContent } = generateEndpointFile(ep, context.warnings, sharedEnums, specific);
    const basePath = `src/api-shared/${vd}/${ep.app}/${ep.module}/${ep.feature}/${ep.id}/${ep.id}`;
    files.push({ path: `${basePath}.ts`, content: mainContent });
    files.push({ path: `${basePath}.mocks.ts`, content: mocksContent });

    centralEntries.push({
      parts: [ep.app, ep.module, ep.feature, ep.id],
      importAlias: pathToImportAlias([ep.app, ep.module, ep.feature, ep.id]),
      importPath: `./${vd}/${ep.app}/${ep.module}/${ep.feature}/${ep.id}/${ep.id}`,
      app: ep.app,
      module: ep.module,
      feature: ep.feature,
      usecase: ep.id,
    });
  }

  const centralContent = generateCentralContent(centralEntries);
  files.push({ path: "src/api-shared/shared-types.ts", content: centralContent });

  return files;
}

// ── Error shapes file (Phase 1) ──

function generateErrorShapesFile(): string {
  return [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// Shared error format for all api-shared endpoint files",
    "// ────────────────────────────────────────────────────────────",
    "",
    "export interface ApiError {",
    "  status: number;",
    "  code: string;",
    "  message: string;",
    "  description?: string;",
    "  cause?: string;",
    "  resolution?: string;",
    "}",
    "",
    "/**",
    " * Error envelope (scaf §7.3 F): { success:false, message, error }.",
    " */",
    "export interface ApiErrorResponse<C extends string = string> {",
    "  success: false;",
    "  message: string;",
    "  error: {",
    "    code: C;",
    "    message: string;",
    "    cause?: string;",
    "    resolution?: string;",
    "    /** Détail par champ (erreur de validation de la requête). */",
    "    fields?: { path: string; message: string }[];",
    "  };",
    "}",
    "",
    "/** Codes produits par la couche d'action, hors contrat. */",
    'export type CommonErrorCode = "VALIDATION_ERROR" | "INTERNAL_ERROR" | "NETWORK_ERROR" | "UNKNOWN_ERROR";',
    "",
    "/**",
    " * Constraint type for endpoint `errors` const.",
    " * Each endpoint validates with `satisfies ApiErrorsMap`.",
    " */",
    "export type ApiErrorsMap = Record<string, ApiError>;",
    "",
    "/** Build the error envelope from an error definition. */",
    "export function toErrorResponse(err: ApiError): ApiErrorResponse {",
    "  return {",
    "    success: false,",
    "    message: err.message,",
    "    error: {",
    "      code: err.code,",
    "      message: err.message,",
    "      ...(err.cause ? { cause: err.cause } : {}),",
    "      ...(err.resolution ? { resolution: err.resolution } : {}),",
    "    },",
    "  };",
    "}",
    "",
  ].join("\n");
}

// ── Response shapes file (Phase 1) ──

function generateResponseShapesFile(): string {
  return [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// Shared response wrapper for all api-shared endpoint files",
    "// ────────────────────────────────────────────────────────────",
    "",
    "/** Pagination metadata for list endpoints. */",
    "export interface PaginationData {",
    "  current_page: number;",
    "  page_size: number;",
    "  total_items: number;",
    "  total_pages: number;",
    "}",
    "",
    "/** A single warning item returned by the API. */",
    "export interface WarningItem {",
    "  title: string;",
    "  description: string;",
    "  tips: string[];",
    "}",
    "",
    "/**",
    " * Success envelope (scaf §7.3): { success, message, data, pagination?, warnings? }.",
    " * @template T - The shape of the business data in `data`.",
    " */",
    "export interface ApiResponse<T> {",
    "  success: true;",
    "  message: string;",
    "  data: T;",
    "  pagination?: PaginationData;",
    "  warnings?: WarningItem[];",
    "}",
    "",
  ].join("\n");
}

// ── Mock shapes file (Phase 1) ──

function generateMockShapesFile(): string {
  return [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// Shared mock scenario type for api-shared endpoint files",
    "// ────────────────────────────────────────────────────────────",
    "",
    "/**",
    " * A named mock scenario for development and testing.",
    " */",
    "export interface MockScenario<T> {",
    "  name: string;",
    "  description: string;",
    "  given: {",
    "    method: string;",
    "    path: string;",
    "    headers?: Record<string, string>;",
    "    query?: Record<string, unknown>;",
    "    body?: unknown;",
    "  };",
    "  expect: {",
    "    status: number;",
    "    headers?: Record<string, string>;",
    "    body: T;",
    "  };",
    "}",
    "",
  ].join("\n");
}

// ── Feature types.ts file (Phase 2) ──

function generateFeatureTypesFile(sharedEnums: Map<string, EnumVal[]>): string {
  const lines: string[] = [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// Shared enum types for this feature",
    "// ────────────────────────────────────────────────────────────",
    "",
  ];

  const sorted = [...sharedEnums.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  for (const [typeName, values] of sorted) {
    lines.push(generateEnumDef(typeName, values, 0));
    lines.push("");
  }

  return lines.join("\n");
}

// ── Per-endpoint mocks file ──

function generateMocksFile(
  ep: ParsedEndpoint,
  effectiveErrors: CoercedErrorDef[],
  successScenario: { expect: { body?: unknown } } | undefined,
  parseMethod: string,
): string {
  const lines: string[] = [
    HEADER,
    `// Mocks for ${ep.app} / ${ep.module} / ${ep.feature} / ${ep.id}`,
    "// Auto-generated — do not edit manually",
    "",
    `import type { Response, Errors } from "./${ep.id}";`,
    `import { errors } from "./${ep.id}";`,
    'import type { ApiError } from "@/api-shared/shapes/error-shapes";',
    'import type { MockScenario } from "@/api-shared/shapes/mock-shapes";',
    'import { toErrorResponse, type ApiErrorResponse } from "@/api-shared/shapes/error-shapes";',
    "",
  ];

  // Mock scenarios
  const scenarios = Array.isArray(ep.scenarios) ? ep.scenarios : [];
  if (scenarios.length > 0) {
    lines.push(`/** Named mock scenarios for this endpoint. */`);
    lines.push(`export const mocks: MockScenario<Response | ApiErrorResponse>[] = ${mockValueToConst(scenarios, 0)};`);
  } else {
    lines.push(`/** Named mock scenarios for this endpoint. */`);
    lines.push(`export const mocks: MockScenario<Response | ApiErrorResponse>[] = [];`);
  }
  lines.push("");

  // mockSuccess
  lines.push(`/** Generate a mock successful response for this endpoint. */`);
  if (parseMethod === "text") {
    const mockValue = successScenario
      ? mockValueToConst(successScenario.expect.body ?? "", 0)
      : '""';
    lines.push(`export function mockSuccess(): Response {`);
    lines.push(`  return ${mockValue} as unknown as Response;`);
    lines.push(`}`);
  } else if (successScenario) {
    const bodyConst = mockValueToConst(successScenario.expect.body ?? {}, 0);
    lines.push(`export function mockSuccess(overrides?: Partial<Response>): Response {`);
    lines.push(`  return { ...${bodyConst}, ...overrides } as unknown as Response;`);
    lines.push(`}`);
  } else {
    lines.push(`export function mockSuccess(overrides?: Partial<Response>): Response {`);
    lines.push(`  return { success: true, message: "", data: {}, ...overrides } as unknown as Response;`);
    lines.push(`}`);
  }
  lines.push("");

  // mockError
  lines.push(`/** Generate a mock error for this endpoint by error key. */`);
  if (effectiveErrors.length > 0) {
    lines.push(`export function mockError<K extends keyof Errors>(key: K, overrides?: Partial<Errors[K]>): ApiErrorResponse {`);
    lines.push(`  return toErrorResponse({ ...errors[key], ...overrides } as ApiError);`);
    lines.push(`}`);
  } else {
    lines.push(`export function mockError<K extends never>(_key: K, _overrides?: Partial<Errors[K]>): ApiErrorResponse {`);
    lines.push(`  return _key as never;`);
    lines.push(`}`);
  }
  lines.push("");

  return lines.join("\n");
}

/** Un code d'erreur = une clé d'objet (et l'identifiant runtime côté client) : les doublons d'un même endpoint sont fusionnés (1er statut, description/cause/resolution concaténées) au lieu de produire des clés dupliquées (TS1117). Le contrat devrait donner un code distinct par cas. */
export function dedupeErrorsByCode(list: CoercedErrorDef[], epId: string, warnings: string[]): CoercedErrorDef[] {
  const byCode = new Map<string, CoercedErrorDef>();
  const join = (a?: string, b?: string) => !b || a === b ? a : a ? (a.includes(b) ? a : `${a} / ${b}`) : b;
  for (const e of list) {
    const k = e.code ?? "";
    const first = byCode.get(k);
    if (!first) { byCode.set(k, { ...e }); continue; }
    const msg = `Erreur dupliquée ${k} fusionnée (statuts ${first.status}, ${e.status}) : ${epId} : donner un code distinct à chaque cas dans le contrat`;
    warnings.push(msg); console.warn(`⚠ ${msg}`);
    for (const f of ["description", "message", "cause", "resolution"] as const) first[f] = join(first[f], e[f]);
  }
  return [...byCode.values()];
}

// ── Per-endpoint file ──

function generateEndpointFile(
  ep: ParsedEndpoint,
  warnings: string[],
  sharedEnums: Map<string, EnumVal[]>,
  endpointSpecificEnums: Map<string, EnumVal[]>,
): { mainContent: string; mocksContent: string } {
  const spec = ep.spec;
  const relParts = [ep.app, ep.module, ep.feature, ep.id];
  const pathParams = extractPathParams(ep.path);
  const successStatus = spec.http?.response?.status ?? 200;
  const queryParams = coerceFieldDefs(spec.http?.request?.query);

  const localEnumMap = ownEnums(ep);

  let usesZod = false;
  const hasSharedEnums = sharedEnums.size > 0;

  const lines: string[] = [
    HEADER,
    "// ============================================================",
    `// ${ep.app} - ${ep.module} - ${ep.feature} - ${ep.id}`,
    "// ============================================================",
    "",
    "",
  ];

  // Enum type definitions: shared enums imported from types.ts, specific enums inline
  if (hasSharedEnums || endpointSpecificEnums.size > 0) {
    usesZod = true;

    if (hasSharedEnums) {
      const sharedNames = [...sharedEnums.keys()].sort();
      lines.push(`import { ${sharedNames.join(", ")} } from "../types";`);
      lines.push("");
    }

    const sortedSpecific = [...endpointSpecificEnums.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    for (const [typeName, values] of sortedSpecific) {
      lines.push(generateEnumDef(typeName, values, 0));
      lines.push("");
    }

    if (hasSharedEnums) {
      const sharedNames = [...sharedEnums.keys()].sort();
      lines.push(`// Re-export shared enums for backward compatibility`);
      lines.push(`export { ${sharedNames.join(", ")} };`);
      lines.push("");
    }
  }

  // Query
  const query = queryParams;
  if (!query || query.length === 0) {
    lines.push(`/** Query parameters for this endpoint. */`);
    lines.push(`export type Query = Record<string, never>;`);
  } else {
    lines.push(`/** Query parameters for this endpoint. */`);
    lines.push(`export interface Query {`);
    for (const q of query) {
      const opt = q.required ? "" : "?";
      const qPath = kebabToPascal(q.name);
      const tsType = yamlTypeToTS({ type: q.type, enum: q.enum }, 2, qPath, localEnumMap);
      lines.push(`  ${q.name}${opt}: ${tsType};`);
    }
    lines.push(`}`);
  }
  lines.push("");

  // Headers
  const hdrs = coerceFieldDefs(spec.http?.request?.headers);
  if (!hdrs || hdrs.length === 0) {
    lines.push(`/** Request headers for this endpoint. */`);
    lines.push(`export type Headers = Record<string, string>;`);
    lines.push(``);
    lines.push(`/** Header name constants for this endpoint. */`);
    lines.push(`export const Hdr = {} as const;`);
  } else {
    lines.push(`/** Request headers for this endpoint. */`);
    lines.push(`export type Headers = {`);
    for (const h of hdrs) {
      const opt = h.required ? "" : "?";
      const tsType = yamlTypeToTS({ type: h.type, enum: h.enum, format: h.format });
      const key = h.name.includes("-") ? `"${h.name}"` : h.name;
      lines.push(`  ${key}${opt}: ${tsType};`);
    }
    lines.push(`  [key: string]: string | undefined;`);
    lines.push(`};`);
    lines.push(``);
    lines.push(`/** Header name constants for this endpoint. */`);
    lines.push(`export const Hdr = {`);
    for (const h of hdrs) {
      const propName = kebabToCamel(h.name);
      lines.push(`  ${propName}: "${h.name}",`);
    }
    lines.push(`} as const;`);
  }
  lines.push("");

  // Params
  if (pathParams.length === 0) {
    lines.push(`/** Path parameters for this endpoint. */`);
    lines.push(`export type Params = Record<string, never>;`);
  } else {
    lines.push(`/** Path parameters for this endpoint. */`);
    lines.push(`export interface Params {`);
    for (const p of pathParams) {
      lines.push(`  ${p}: string;`);
    }
    lines.push(`}`);
  }
  lines.push("");

  // Body
  const body = spec.http?.request?.body;
  if (!body || (!body.properties && !body.additionalProperties)) {
    lines.push(`/** Request body for this endpoint. */`);
    lines.push(`export type Body = Record<string, never>;`);
  } else if (body.additionalProperties && (!body.properties || Object.keys(body.properties).length === 0)) {
    lines.push(`/** Request body for this endpoint. */`);
    lines.push(`export type Body = Record<string, unknown>;`);
  } else {
    lines.push(`/** Request body for this endpoint. */`);
    lines.push(`export interface Body {`);
    const reqSet = new Set(requiredFieldNames(body.properties, body.required));
    for (const [key, val] of Object.entries(body.properties!)) {
      const opt = reqSet.has(key) ? "" : "?";
      const tsType = yamlTypeToTS(val, 2, kebabToPascal(key), localEnumMap);
      lines.push(`  ${key}${opt}: ${tsType};`);
    }
    if (body.additionalProperties) {
      lines.push(`  [key: string]: unknown;`);
    }
    lines.push(`}`);
  }
  lines.push("");

  // Response
  const response = spec.http?.response?.body;
  let parseMethod = "json";
  const isTextResponse = response?.type === "string";
  if (isTextResponse) {
    lines.push(`/** Successful response body for this endpoint. */`);
    lines.push(`export type Response = string;`);
    parseMethod = "text";
  } else if (response?.type === "object" && response.properties && Object.keys(response.properties).length > 0) {
    // scaf §7.3 : le corps est l'enveloppe ; ResponseData = type de `data`.
    const dataProp = response.properties.data;
    const dataType = dataProp ? yamlTypeToTS(dataProp, 0, "Data", localEnumMap) : "Record<string, never>";
    lines.push(`/** Business data payload (\`data\` of the envelope). */`);
    lines.push(`export type ResponseData = ${dataType};`);
    lines.push("");
    lines.push(`/** Successful response body for this endpoint. */`);
    lines.push(`export type Response = ApiResponse<ResponseData>;`);
  } else if (response?.additionalProperties) {
    lines.push(`/** Business data payload for this endpoint. */`);
    lines.push(`export type ResponseData = Record<string, unknown>;`);
    lines.push("");
    lines.push(`/** Successful response body for this endpoint. */`);
    lines.push(`export type Response = ApiResponse<ResponseData>;`);
  } else {
    lines.push(`/** Business data payload for this endpoint. */`);
    lines.push(`export type ResponseData = Record<string, never>;`);
    lines.push("");
    lines.push(`/** Successful response body for this endpoint. */`);
    lines.push(`export type Response = ApiResponse<ResponseData>;`);
  }
  lines.push("");
  lines.push(`/** How the response body should be parsed. */`);
  lines.push(`export const RESPONSE_PARSE_METHOD = "${parseMethod}" as const;`);
  lines.push("");

  // Endpoint metadata
  lines.push(`/** Endpoint metadata (id, method, path). */`);
  lines.push(`export const endpoint = {`);
  lines.push(`  id: "${ep.id}",`);
  lines.push(`  method: "${ep.method}",`);
  lines.push(`  path: "${ep.path}",`);
  lines.push(`} as const;`);
  lines.push("");

  // Errors
  const errList = dedupeErrorsByCode(coerceErrorDefs(spec.http?.response?.errors), ep.id, warnings);
  const mockByKey = buildMockByKey(ep.scenarios);

  const errScenarios = Array.isArray(ep.scenarios) ? ep.scenarios : [];
  const derivedErrors: CoercedErrorDef[] = [];
  if (errList.length === 0) {
    const seen = new Set<string>();
    for (const sc of errScenarios) {
      const scBody = sc.expect.body as Record<string, unknown> | undefined;
      // Support both old format { error: { code } } and new ApiError format { code }
      let code: string | undefined;
      if (scBody) {
        if (typeof scBody.error === "object" && scBody.error !== null) {
          code = String((scBody.error as Record<string, unknown>).code ?? "");
        } else if (typeof scBody.code === "string") {
          code = scBody.code;
        }
      }
      if (typeof code === "string" && code && sc.expect.status !== successStatus && !seen.has(code)) {
        seen.add(code);
        derivedErrors.push({ status: String(sc.expect.status), code });
      }
    }
  }
  const effectiveErrors = errList.length > 0 ? errList : derivedErrors;

  if (errList.length === 0 && derivedErrors.length > 0) {
    const msg = `Spec sans erreurs déclarées — errors dérivées des mocks : ${ep.id}`;
    warnings.push(msg);
    console.warn(`⚠ ${msg}`);
  }

  if (effectiveErrors.length === 0) {
    lines.push(`/** Known error codes for this endpoint. */`);
    lines.push(`export const errors = {} as const;`);
    lines.push(`/** Typed error map derived from errors const. */`);
    lines.push(`export type Errors = Record<string, never>;`);
    lines.push(`/** Codes d'erreur possibles côté vue. */`);
    lines.push(`export type ErrorCode = CommonErrorCode;`);
  } else {
    lines.push(`/** Known error codes for this endpoint. */`);
    lines.push(`export const errors = {`);
    for (const err of effectiveErrors) {
      const key = err.code;
      const desc = escapeString(err.description ?? "");
      const message = escapeString(err.message ?? err.description ?? defaultErrorMessage(err.status, err.code));
      const cause = escapeString(err.cause ?? "");
      const resolution = escapeString(err.resolution ?? "");
      lines.push(`  ${key}: {`);
      lines.push(`    status: ${err.status} as const,`);
      lines.push(`    code: "${key}" as const,`);
      lines.push(`    message: "${message}",`);
      if (desc) lines.push(`    description: "${desc}",`);
      if (cause) lines.push(`    cause: "${cause}",`);
      if (resolution) lines.push(`    resolution: "${resolution}",`);
      lines.push(`  },`);
    }
    lines.push(`} as const satisfies ApiErrorsMap;`);
    lines.push(``);
    lines.push(`/** Typed error map derived from errors const. */`);
    lines.push(`export type Errors = typeof errors;`);
    lines.push(`/** Codes d'erreur possibles côté vue : ceux du contrat + ceux de la couche d'action. */`);
    lines.push(`export type ErrorCode = keyof Errors | CommonErrorCode;`);
  }
  lines.push("");

  // Mock scenarios — warn if missing
  const scenarios = Array.isArray(ep.scenarios) ? ep.scenarios : [];
  const successScenario = scenarios.find(s => s?.expect?.status === successStatus);
  if (scenarios.length > 0 && !successScenario) {
    const msg = `Scenario mock manquant pour le code ${successStatus} (success) : ${ep.id}`;
    warnings.push(msg);
    console.warn(`⚠ ${msg}`);
  }
  for (const err of effectiveErrors) {
    if (!mockByKey.has(`${err.status}-${err.code}`)) {
      const msg = `Scenario mock manquant pour l'erreur ${err.code} (${err.status}) : ${ep.id}`;
      warnings.push(msg);
      console.warn(`⚠ ${msg}`);
    }
  }

  // Validate enum values in mock bodies
  if (parseMethod !== "text") {
    for (const sc of scenarios) {
      if (sc?.expect?.status && sc.expect.body != null && sc.expect.status < 400) {
        const body = sc.expect.body as Record<string, unknown>;
        const dataBody = body && typeof body === "object" ? (body as Record<string, unknown>).data : undefined;
        validateMockEnumValues(dataBody, localEnumMap, "Data", warnings, ep.id, sc.name);
      }
    }
  }

  // Zod schemas
  lines.push("// ── Zod schemas ──");

  usesZod = usesZod || pathParams.length > 0;
  if (pathParams.length > 0) {
    const entries = pathParams.map(p => {
      const hasUuid = hdrs.some(
        h => h.name.toLowerCase() === p && h.format === "uuid"
      );
      return `  ${p}: ${hasUuid ? "z.string().uuid()" : "z.string()"},`;
    });
    lines.push(`/** Zod schema for path parameters. */`);
    lines.push(`export const ParamsSchema = z.object({`);
    lines.push(entries.join("\n"));
    lines.push(`}).strip();`);
    lines.push("");
  }

  usesZod = usesZod || queryParams.length > 0;
  const queryForZod = queryParams;
  if (queryForZod && queryForZod.length > 0) {
    const entries = queryForZod.map(q => {
      const qPath = kebabToPascal(q.name);
      const fieldZod = yamlTypeToZod({ type: q.type, enum: q.enum, format: q.format }, 2, !!q.required, qPath, localEnumMap);
      return `  ${q.name}: ${fieldZod},`;
    });
    lines.push(`/** Zod schema for query parameters. */`);
    lines.push(`export const QuerySchema = z.object({`);
    lines.push(entries.join("\n"));
    lines.push(`}).strip();`);
    lines.push("");
  }

  const bodyForZod = spec.http?.request?.body;
  if (bodyForZod && bodyForZod.additionalProperties) {
    usesZod = true;
    if (bodyForZod.properties && Object.keys(bodyForZod.properties).length > 0) {
      const reqSet = new Set(requiredFieldNames(bodyForZod.properties, bodyForZod.required));
      const entries = Object.entries(bodyForZod.properties).map(([key, val]) => {
        const childPath = kebabToPascal(key);
        const fieldZod = yamlTypeToZod(val, 2, reqSet.has(key), childPath, localEnumMap);
        return `  ${key}: ${fieldZod},`;
      });
      lines.push(`/** Zod schema for request body. */`);
      lines.push(`export const BodySchema = z.object({`);
      lines.push(entries.join("\n"));
      lines.push(`}).loose();`);
      lines.push("");
    } else {
      lines.push(`/** Zod schema for request body. */`);
      lines.push(`export const BodySchema = z.record(z.string(), z.unknown());`);
      lines.push("");
    }
  } else if (bodyForZod && bodyForZod.properties && Object.keys(bodyForZod.properties).length > 0) {
    usesZod = true;
    const reqSet = new Set(requiredFieldNames(bodyForZod.properties, bodyForZod.required));
    const entries = Object.entries(bodyForZod.properties).map(([key, val]) => {
      const childPath = kebabToPascal(key);
      const fieldZod = yamlTypeToZod(val, 2, reqSet.has(key), childPath, localEnumMap);
      return `  ${key}: ${fieldZod},`;
    });
    lines.push(`/** Zod schema for request body. */`);
    lines.push(`export const BodySchema = z.object({`);
    lines.push(entries.join("\n"));
    lines.push(`}).strip();`);
    lines.push("");
  }

  const headerImports: string[] = [
    'import { apiClient, ApiClientError, buildUrl, toSearchParams } from "@/lib/api-client";',
    'import { toErrorResponse, type ApiError, type ApiErrorResponse, type ApiErrorsMap, type CommonErrorCode } from "@/api-shared/shapes/error-shapes";',
    'import type { ApiResponse } from "@/api-shared/shapes/response-shapes";',
    `import { mocks, mockSuccess } from "./${ep.id}.mocks";`,
  ];
  if (usesZod) {
    headerImports.push('import { z } from "zod";');
  }
  lines.splice(5, 0, ...headerImports);

  // ── API Client ──
  const callErrorKeys = effectiveErrors.map(e => e.code);

  lines.push("");
  lines.push("// ── API Client ──");
  lines.push("");
  lines.push("export type MockMode = \"success\" | \"real\"");
  if (callErrorKeys.length > 0) {
    lines.push(`  | ${callErrorKeys.map(k => `"${k}"`).join("\n  | ")}`);
  }
  lines.push("  | string;");
  lines.push("");
  lines.push("/**");
  lines.push(" * Call this endpoint.");
  lines.push(" */");
  lines.push("export async function call(opts: {");
  lines.push("  query?: Query;");
  lines.push("  params?: Params;");
  lines.push("  body?: Body;");
  lines.push("  headers?: Headers;");
  lines.push("  signal?: AbortSignal;");
  lines.push("  mock?: MockMode;");
  lines.push("  mockOverrides?: Partial<Response>;");
  lines.push("  errorOverrides?: Partial<Errors[keyof Errors]>;");
  lines.push("} = {}): Promise<Response> {");
  lines.push("  if (opts.mock === \"real\" || opts.mock === undefined) {");
  lines.push("    // fall through to HTTP");
  lines.push("  } else if (opts.mock === \"success\") {");
  if (parseMethod === "text") {
    lines.push("    return mockSuccess();");
  } else {
    lines.push("    return mockSuccess(opts.mockOverrides);");
  }
  lines.push("  } else {");
  lines.push("    // Check named mocks first");
  lines.push("    const found = mocks.find(m => m.name === opts.mock);");
  lines.push("    if (found) {");
  if (parseMethod !== "text") {
    lines.push("      if (found.expect.status < 400) {");
    lines.push("        return { ...(found.expect.body as Response), ...(opts.mockOverrides ?? {}) };");
    lines.push("      }");
    lines.push("      const failure = found.expect.body as ApiErrorResponse;");
    lines.push("      throw new ApiClientError(found.expect.status, failure.error?.code ?? opts.mock, {");
    lines.push("        ...failure,");
    lines.push("        error: { ...failure.error, ...(opts.errorOverrides ?? {}) },");
    lines.push("      });");
    lines.push("    }");
  } else {
    lines.push("      if (found.expect.status < 400) {");
    lines.push("        return found.expect.body as Response;");
    lines.push("      }");
    lines.push("      throw new ApiClientError(found.expect.status, opts.mock, found.expect.body);");
    lines.push("    }");
  }
  lines.push("    // Check error keys");
  lines.push("    if (opts.mock in errors) {");
  lines.push("      const err = { ...errors[opts.mock as keyof Errors], ...(opts.errorOverrides ?? {}) } as ApiError;");
  lines.push("      throw new ApiClientError(err.status, err.code, toErrorResponse(err));");
  lines.push("    }");
    lines.push("    // Fallback to success mock");
  if (parseMethod === "text") {
    lines.push("    return mockSuccess();");
  } else {
    lines.push("    return mockSuccess(opts.mockOverrides);");
  }
  lines.push("  }");
  lines.push("");
  lines.push("  // Real HTTP");
  lines.push("  try {");
  lines.push("    const res = await apiClient(buildUrl(endpoint.path, opts.params), {");
  lines.push("      method: endpoint.method,");
  lines.push("      searchParams: toSearchParams(opts.query),");
  lines.push("      json: opts.body,");
  lines.push("      headers: opts.headers,");
  lines.push("      signal: opts.signal,");
  lines.push("    });");
  if (parseMethod === "text") {
    lines.push("    return (await res.text()) as unknown as Response;");
  } else {
    lines.push("    return (await res.json()) as Response;");
  }
  lines.push("  } catch (e) {");
  lines.push('    if (e != null && typeof e === "object" && "response" in e) {');
  lines.push("      const httpErr = e as { response: { status: number }; data: unknown };");
  lines.push("      const body = (httpErr.data ?? {}) as Record<string, unknown>;");
  lines.push('      if (body.valid === false && Array.isArray(body.errors)) {');
  lines.push('        throw new ApiClientError(httpErr.response.status, "VALIDATION_ERROR", body);');
  lines.push("      }");
  lines.push("      const code =");
  lines.push('        typeof body?.error === "object" && body.error !== null');
  lines.push('          ? String((body.error as Record<string, unknown>).code ?? "UNKNOWN")');
  lines.push('          : "UNKNOWN";');
  lines.push("      throw new ApiClientError(httpErr.response.status, code, body);");
  lines.push("    }");
  lines.push("    throw e;");
  lines.push("  }");
  lines.push("}");
  lines.push("");

  // ── Re-export mocks from .mocks.ts for backward compatibility ──
  lines.push(`export { mocks, mockSuccess, mockError } from "./${ep.id}.mocks";`);
  lines.push("");

  const mocksContent = generateMocksFile(ep, effectiveErrors, successScenario, parseMethod);
  return { mainContent: lines.join("\n"), mocksContent };
}

// ── Central reference ──

interface CentralEntry {
  parts: string[];
  importAlias: string;
  importPath: string;
  app: string;
  module: string;
  feature: string;
  usecase: string;
}

function generateCentralContent(entries: CentralEntry[]): string {
  const lines: string[] = [
    HEADER,
    "// ────────────────────────────────────────────────────────────",
    "// Central reference for all shared types",
    "// ────────────────────────────────────────────────────────────",
    "",
  ];

  for (const entry of entries) {
    lines.push(`import * as ${entry.importAlias} from "${entry.importPath}";`);
  }
  lines.push("");
  lines.push("export const ApiSharedTypes = {");
  lines.push("");

  interface CTNode {
    name: string;
    children: Map<string, CTNode>;
    entry: CentralEntry | null;
  }

  const root = new Map<string, CTNode>();

  for (const entry of entries) {
    let current = root;
    for (let i = 0; i < entry.parts.length; i++) {
      const key = kebabToScreamingSnake(entry.parts[i]);
      let node = current.get(key);
      if (!node) {
        node = { name: key, children: new Map(), entry: null };
        current.set(key, node);
      }
      if (i === entry.parts.length - 1) {
        node.entry = entry;
      }
      current = node.children;
    }
  }

  function writeTree(nodes: Map<string, CTNode>, indent: string) {
    const sorted = [...nodes.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    for (const [, node] of sorted) {
      lines.push(`${indent}${node.name}: {`);
      if (node.entry) {
        const alias = node.entry.importAlias;
        lines.push(`${indent}  // Types (asserted null -- use typeof for type access)`);
        lines.push(`${indent}  Query: null! as ${alias}.Query,`);
        lines.push(`${indent}  Params: null! as ${alias}.Params,`);
        lines.push(`${indent}  Body: null! as ${alias}.Body,`);
        lines.push(`${indent}  Response: null! as ${alias}.Response,`);
        lines.push(`${indent}  ResponseData: null! as ${alias}.ResponseData,`);
        lines.push(`${indent}  Errors: null! as ${alias}.Errors,`);
        lines.push(`${indent}  Headers: null! as ${alias}.Headers,`);
        lines.push(`${indent}  MockMode: null! as ${alias}.MockMode,`);
        lines.push(`${indent}  // Runtime values`);
        lines.push(`${indent}  endpoint: ${alias}.endpoint,`);
        lines.push(`${indent}  errors: ${alias}.errors,`);
        lines.push(`${indent}  mocks: ${alias}.mocks,`);
        lines.push(`${indent}  mockSuccess: ${alias}.mockSuccess,`);
        lines.push(`${indent}  mockError: ${alias}.mockError,`);
        lines.push(`${indent}  Hdr: ${alias}.Hdr,`);
      }
      if (node.children.size > 0) {
        writeTree(node.children, `${indent}  `);
      }
      lines.push(`${indent}} as const,`);
      lines.push("");
    }
  }

  writeTree(root, "  ");
  lines.push("} as const;");
  lines.push("");

  return lines.join("\n");
}
