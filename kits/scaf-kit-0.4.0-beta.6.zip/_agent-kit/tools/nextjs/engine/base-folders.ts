// Socle de dossiers de base (L2+) : posé seulement si le dossier n'existe pas encore (`scaffoldDir`), jamais réécrit ensuite.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { GeneratedFile } from "../../_shared/generated-file";
import { HEADER } from "../../_shared/_lib/header";
import { COMPOSE } from "./contexts";

const EMPTY = ["app-actions", "external-modules", "app-scripts"];
const CONTEXTS: [dir: string, providers: string][] = [["ui-contexts", "UiProviders"], ["app-contexts", "AppProviders"]];

export function generateBaseFolders(): GeneratedFile[] {
  const files: GeneratedFile[] = [];
  const add = (scaffoldDir: string, rel: string, content = "") => files.push({ path: `${scaffoldDir}/${rel}`, content, scaffoldDir });
  for (const d of EMPTY) add(`src/${d}`, ".gitkeep");
  for (const [d, name] of CONTEXTS) {
    const base = `src/${d}`;
    add(base, "compose-wrappers.tsx", COMPOSE.replace(HEADER, ""));
    add(base, "contexts/.gitkeep");
    add(base, "wrappers/.gitkeep");
    add(base, "providers.tsx", `"use client";\nimport { composeWrappers } from "./compose-wrappers";\n\nexport const ${name} = composeWrappers([]);\n`);
    add(base, "index.ts", "export {};\n");
  }
  return files;
}

/** Monte UiProviders > AppProviders dans [locale]/layout.tsx (idempotent ; ancre introuvable : on n'écrit rien et on dit quoi faire). */
export function patchAppForProviders(root: string, dry: boolean): string[] {
  const name = "src/app/[locale]/layout.tsx", p = join(root, name);
  if (!existsSync(p)) return [`${name} absent : monter <UiProviders><AppProviders> (src/ui-contexts/providers, src/app-contexts/providers) dans NextIntlClientProvider`];
  const src = readFileSync(p, "utf8");
  if (src.includes("UiProviders")) return [];
  if (src.includes("AppProviders")) return [`${name} : AppProviders déjà monté : envelopper à la main avec <UiProviders> (src/ui-contexts/providers)`];
  const out = src.replace(/(<NextIntlClientProvider[^>]*>)/, "$1\n<UiProviders>\n<AppProviders>").replace("</NextIntlClientProvider>", "</AppProviders>\n</UiProviders>\n</NextIntlClientProvider>");
  if (!out.includes("</UiProviders>")) return [`${name} : NextIntlClientProvider introuvable : monter <UiProviders><AppProviders> (src/ui-contexts/providers, src/app-contexts/providers)`];
  if (!dry) writeFileSync(p, out.replace(/^import /m, 'import { UiProviders } from "@/ui-contexts/providers";\nimport { AppProviders } from "@/app-contexts/providers";\nimport '));
  return [`${name} complété (providers)`];
}
