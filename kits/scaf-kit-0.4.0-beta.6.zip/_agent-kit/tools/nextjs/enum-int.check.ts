// Enum entier : les valeurs restent numériques (type TS, const, zod). Lancé par golden.sh.
import assert from "node:assert/strict";
import { generateEnumDef, yamlTypeToTS, yamlTypeToZod } from "../_shared/_lib/yaml-utils";

assert.match(generateEnumDef("Lvl", [1, 2], 0), /_1: 1,\n\s+_2: 2,/);
assert.match(generateEnumDef("S", ["A", "B"], 0), /A: "A",/);
assert.equal(yamlTypeToTS({ type: "integer", enum: [1, 2] }), "1 | 2");
assert.equal(yamlTypeToTS({ type: "string", enum: ["A", "B"] }), '"A" | "B"');
assert.equal(yamlTypeToZod({ type: "integer", enum: [1, 2] }), "z.union([z.literal(1), z.literal(2)])");
assert.equal(yamlTypeToZod({ type: "string", enum: ["A", "B"] }), 'z.enum(["A", "B"])');
console.log("enum entier: ok");
