// Usage : tsx gen_nextjs.ts <scaf/version> --level L2|L3|L4 --out <dir> [--app <slug>] [--version-dir v1]
//   --app <slug> : génère UNE app, indépendamment des autres ; --out = racine de cette app (ex. frontend/miidjo-admin).
//   sans --app   : génère toutes les apps ; --out = dossier parent, un sous-dossier <slug>/ par app.
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readdirSync, readFileSync, rmdirSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { loadContracts, loadProjectApps } from "../_shared/load-contracts";
import { parseContractsToSpecContext, splitSpecContextByApp } from "../_shared/spec-loader";
import { generateSharedTypes } from "./engine/shared-types";
import { generateApiClient } from "./engine/api-client";
import { generateActions } from "./engine/actions";
import type { SessionCfg } from "./engine/session";
import { generateContexts } from "./engine/contexts";
import { generateAppLayer, loadUsecases, type AppLayerCfg } from "./engine/app-layer";
import { generateDocsTool, patchAppForDocs } from "./engine/docs-tool";
import { generateBaseFolders, patchAppForProviders } from "./engine/base-folders";
import { generatePwa, patchAppForPwa, type PwaCfg } from "./engine/pwa";
import { generateModules, ARCHITECTURES, type Architecture } from "./engine/architecture";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import type { GeneratedFile } from "../_shared/generated-file";
import { pmFiles, pmText } from "../_shared/package-manager";
import { olderVersionError, resolveVersionDir, scafVersionName } from "../_shared/scaf-version";

const argv = process.argv.slice(2);
const opt = (name: string) => { const i = argv.indexOf(`--${name}`); return i >= 0 ? argv[i + 1] : undefined; };
const versionDir = resolveVersionDir(argv[0]) as string; // vérifié juste après (Usage)
const level = opt("level") ?? "L2";
const out = opt("out");
const onlyApp = opt("app");
const vd = opt("version-dir") ?? "v1";
const dry = argv.includes("--dry-run");
const sha = (c: string | Buffer) => createHash("sha256").update(c).digest("hex");
const RANK: Record<string, number> = { L0: 0, L1: 1, L2: 2, L3: 3, L4: 4 };
const MANIFEST = ".scaf-generated.json";
if (!versionDir || !out || !["L2", "L3", "L4"].includes(level)) {
  console.error("Usage: gen_nextjs.ts [<scaf/version>] --level L2|L3|L4 --out <dir> [--app <slug>] [--version-dir v1] [--dry-run]");
  process.exit(1);
}

// Config nextjs effective de l'app (base ⊕ override), résolue par le kit — même logique que audit.rb.
function resolveConfig(slug: string): PwaCfg & { architecture?: string; behaviors?: AppLayerCfg; docsTool?: boolean; packageManager?: string; auth?: string; session?: SessionCfg; pwa?: boolean } {
  const rb = fileURLToPath(new URL("../export_configs.rb", import.meta.url));
  const r = spawnSync("ruby", [rb, versionDir, "--resolve", "nextjs", slug], { encoding: "utf8" });
  if (r.status !== 0) { console.error(`[${slug}] config nextjs introuvable/invalide :\n${r.stdout}${r.stderr}`); process.exit(1); }
  return JSON.parse(r.stdout);
}
function resolveArchitecture(slug: string): Architecture {
  const arch = resolveConfig(slug).architecture as string;
  if (!(ARCHITECTURES as readonly string[]).includes(arch)) {
    console.error(`[${slug}] architecture "${arch}" non supportée par le générateur (${ARCHITECTURES.join(", ")})`);
    process.exit(1);
  }
  return arch as Architecture;
}

const apps = splitSpecContextByApp(parseContractsToSpecContext(loadContracts(versionDir)), loadProjectApps(versionDir));
if (onlyApp && !apps.has(onlyApp)) {
  console.error(`App inconnue : ${onlyApp} (disponibles : ${[...apps.keys()].join(", ")})`);
  process.exit(1);
}
function filesImporting(dir: string, needle: string): string[] {
  if (!existsSync(dir)) return [];
  return readdirSync(dir, { withFileTypes: true }).flatMap(e => {
    const p = join(dir, e.name);
    return e.isDirectory() ? filesImporting(p, needle) : /\.tsx?$/.test(e.name) && readFileSync(p, "utf8").includes(needle) ? [p] : [];
  });
}
const allIds = new Set([...apps.values()].flatMap(c => c.endpoints.map(e => e.id)));
// Ids de `session` : ceux d'une autre app sont ignorés (config de base partagée) ; un id inconnu partout est une erreur.
function checkSession(slug: string, ctx: { endpoints: { id: string; path: string; spec: any }[] }, o: { auth?: string; session?: SessionCfg }) {
  const ids = [...Object.keys(o.session?.endpoints ?? {}), ...(o.session?.logout ?? [])];
  const bad = ids.filter(i => !allIds.has(i));
  if (bad.length) { console.error(`[${slug}] session : endpoint(s) inconnu(s) : ${bad.join(", ")}`); process.exit(1); }
  if (o.auth !== "custom_jwt") return;
  const rf = o.session?.refresh;
  if (rf) {
    const ep = ctx.endpoints.find(e => e.id === rf.endpoint);
    if (!allIds.has(rf.endpoint)) { console.error(`[${slug}] session.refresh : endpoint inconnu : ${rf.endpoint}`); process.exit(1); }
    if (o.auth === "custom_jwt" && ep && /\{/.test(ep.path)) { console.error(`[${slug}] session.refresh : ${rf.endpoint} a des paramètres de chemin (non supporté)`); process.exit(1); }
  }
  const mine = ids.filter(i => ctx.endpoints.some(e => e.id === i));
  if (mine.length) return;
  const cand = ctx.endpoints.filter(e => /"(access_?[tT]oken|token)"|access_token|accessToken/.test(JSON.stringify(e.spec?.response?.body ?? ""))).map(e => e.id);
  console.warn(`[${slug}] auth custom_jwt sans "session" : aucun cookie posé.${cand.length ? ` Candidats : ${cand.join(", ")}` : ""}`);
}
let total = 0;
for (const [slug, ctx] of apps) {
  if (onlyApp && slug !== onlyApp) continue;
  let currentArch: string | undefined;
  let docsOn = false;
  const rcfg = resolveConfig(slug);
  const { auth, session } = rcfg;
  const pwaOn = !!rcfg.pwa && RANK[level] >= 2;
  const gopts = { app: slug, auth, session };
  checkSession(slug, ctx, gopts);
  // App sans API (aucun endpoint) : pas de api-* (shared, client, actions, modules, di, contexts) ; app-* (behaviors, events, dossiers de base) conservés.
  const hasApi = ctx.endpoints.length > 0;
  if (!hasApi) console.log(`[${slug}] app sans API : api-* non générés`);
  const files: GeneratedFile[] = hasApi ? [...generateSharedTypes(ctx, vd), ...generateApiClient(ctx, vd, gopts)] : [];
  if (hasApi && level !== "L0") files.push(...generateActions(ctx, "mvvm", false, vd, gopts));
  if (RANK[level] >= 2) {
    const architecture = currentArch = resolveArchitecture(slug);
    console.log(`[${slug}] architecture : ${architecture}`);
    files.push(...(hasApi ? generateModules(ctx, vd, architecture) : []), ...generateBaseFolders(), ...(pwaOn ? generatePwa(rcfg) : []));
  }
  if (hasApi && RANK[level] >= 3) files.push(...generateContexts(ctx, vd));
  if (RANK[level] >= 4) {
    const cfg = resolveConfig(slug);
    const docs = docsOn = !!cfg.docsTool;
    files.push(...generateAppLayer(ctx, slug, loadUsecases(versionDir, slug, "consumer"), loadUsecases(versionDir, slug, "producer"), vd, cfg.behaviors ?? {}, docs));
    if (docs) files.push(...generateDocsTool(slug));
  }
  pmFiles(files, rcfg.packageManager);
  const root = onlyApp ? out : join(out, slug);
  const mpath = join(root, MANIFEST);
  const prev: { level?: string; scafVersion?: string; files: Record<string, string> } = existsSync(mpath) ? JSON.parse(readFileSync(mpath, "utf8")) : { files: {} };
  { const e = olderVersionError(prev.scafVersion, scafVersionName(versionDir), root); if (e && !dry && !argv.includes("--force")) { console.error(`[${slug}] ${e}`); process.exit(1); } }
  const next: Record<string, string> = {};
  const had = new Set(files.flatMap(f => f.scaffoldDir && existsSync(join(root, f.scaffoldDir)) ? [f.scaffoldDir] : []));
  for (const d of had) console.log(`[${slug}] socle existant, conservé : ${d}`);
  for (const f of files) {
    const p = join(root, f.path);
    if (f.scaffoldDir) { if (!had.has(f.scaffoldDir) && !dry) { mkdirSync(dirname(p), { recursive: true }); writeFileSync(p, f.content); } else if (!had.has(f.scaffoldDir)) console.log(`[${slug}] écrit : ${f.path}`); continue; }
    if (f.preserve) {
      if (existsSync(p)) { console.log(`[${slug}] conservé (fichier utilisateur) : ${f.path}`); continue; }
    } else next[f.path] = sha(f.content);
    if (dry) { console.log(`[${slug}] écrit : ${f.path}`); continue; }
    mkdirSync(dirname(p), { recursive: true });
    writeFileSync(p, f.content);
  }
  if (RANK[level] >= 2) for (const m of patchAppForProviders(root, dry)) console.log(`[${slug}] ${m}`);
  if (pwaOn) for (const m of patchAppForPwa(root, dry, rcfg.packageManager ?? "pnpm")) console.log(`[${slug}] ${pmText(m, rcfg.packageManager)}`);
  if (docsOn) {
    for (const m of patchAppForDocs(root, dry)) console.log(`[${slug}] ${pmText(m, rcfg.packageManager)}`);
    console.log(`[${slug}] docs-tool : ${pmText("lancer `pnpm install` dans l'app", rcfg.packageManager)}`);
  }
  // Obsolètes : fichiers du manifeste précédent que cette génération ne produit plus.
  // Un niveau inférieur à la génération précédente ne supprime rien (il produit moins de fichiers par construction).
  // Une architecture n'écrase/supprime que ses propres fichiers : les dossiers api-modules/<v>/<autre architecture>/ coexistent.
  // docsTool désactivé mais des fichiers (utilisateur, `preserve`) importent encore `@docs/` : on garde docs-tool/ et on signale.
  const docsUsers = docsOn || dry ? [] : filesImporting(join(root, "src"), "@docs/").map(f => f.slice(root.length + 1));
  for (const f of docsUsers) console.warn(`[${slug}] ${f} importe "@docs/…" alors que docsTool est désactivé : retirer l'enveloppe indexDoc ou réactiver docsTool (docs-tool/ conservé)`);
  const archOf = (path: string) => path.match(/^src\/api-modules\/[^/]+\/(clean_architecture|mvvm|mvc)\//)?.[1];
  const lowerLevel = (RANK[prev.level ?? "L0"] ?? 0) > RANK[level];
  for (const [path, hash] of Object.entries(prev.files)) {
    if (path in next) continue;
    if (docsUsers.length && (path.startsWith("docs-tool/") || path === "genealogy.config.ts")) { next[path] = hash; continue; }
    const owner = archOf(path);
    if (lowerLevel || (owner && owner !== currentArch)) { next[path] = hash; continue; }
    const p = join(root, path);
    if (!existsSync(p)) continue;
    if (sha(readFileSync(p)) !== hash) { console.warn(`[${slug}] obsolète mais modifié, conservé : ${path}`); next[path] = hash; continue; }
    console.log(`[${slug}] supprimé (obsolète) : ${path}`);
    if (dry) continue;
    rmSync(p);
    for (let d = dirname(p); d.startsWith(root + "/") && readdirSync(d).length === 0; d = dirname(d)) rmdirSync(d);
  }
  if (!dry) writeFileSync(mpath, JSON.stringify({ level, scafVersion: scafVersionName(versionDir), files: Object.fromEntries(Object.entries(next).sort()) }, null, 2) + "\n");
  for (const w of ctx.warnings) console.warn(`[${slug}] ${w}`);
  console.log(`${slug}: ${files.length} fichiers`);
  total += files.length;
}
console.log(`total: ${total}`);
