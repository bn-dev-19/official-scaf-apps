// Erreurs de même code sur un endpoint : fusionnées (pas de clé d'objet dupliquée, TS1117) + avertissement. Lancé par golden.sh.
import assert from "node:assert/strict";
import { dedupeErrorsByCode } from "./engine/shared-types";

const w: string[] = [];
const out = dedupeErrorsByCode([
  { status: 403, code: "FORBIDDEN", description: "Rôle sans permission.", cause: "c1" },
  { status: 404, code: "NOT_FOUND", description: "Absent." },
  { status: 403, code: "FORBIDDEN", description: "Session conservée pour la traçabilité.", cause: "c1" },
], "ep-x", w);
assert.deepEqual(out.map(e => e.code), ["FORBIDDEN", "NOT_FOUND"]);
assert.equal(out[0].status, 403);
assert.equal(out[0].description, "Rôle sans permission. / Session conservée pour la traçabilité.");
assert.equal(out[0].cause, "c1");
assert.equal(w.length, 1);
assert.match(w[0], /FORBIDDEN fusionnée.*ep-x/);
assert.equal(dedupeErrorsByCode([{ status: 401, code: "A" }], "e", []).length, 1);
console.log("erreurs dupliquées fusionnées: ok");
