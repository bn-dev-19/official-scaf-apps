// Upload multipart : types binary, détection, client FormData. Lancé par golden.sh.
import assert from "node:assert/strict";
import { yamlTypeToTS, yamlTypeToZod } from "../_shared/_lib/yaml-utils";
import { isMultipartSpec } from "../_shared/_lib/spec-normalize";
import { generateLibApiClient } from "./engine/api-client";

assert.equal(yamlTypeToTS({ type: "string", format: "binary" }), "File | Blob");
assert.equal(yamlTypeToTS({ type: "array", items: { type: "string", format: "binary" } }), "(File | Blob)[]");
assert.equal(yamlTypeToZod({ type: "string", format: "binary" }), "z.instanceof(Blob)");
const hdr = [{ name: "Content-Type", type: "string", description: "multipart/form-data" }];
assert.equal(isMultipartSpec({ http: { request: { headers: hdr } } }), true);
assert.equal(isMultipartSpec({ http: { request: { body: { properties: { file: { format: "binary" } } } } } }), true);
assert.equal(isMultipartSpec({ http: { request: { body: { properties: { name: {} } } } } }), false);
assert.equal(isMultipartSpec(undefined), false);
const lib = generateLibApiClient({} as never, false);
assert.match(lib, /export function toFormData/);
assert.match(lib, /export function withoutContentType/);
console.log("upload multipart: ok");
