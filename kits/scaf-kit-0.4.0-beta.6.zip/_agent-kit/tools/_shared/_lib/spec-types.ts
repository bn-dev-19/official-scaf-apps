export interface SpecProp {
  type?: string;
  format?: string;
  enum?: (string | number)[];
  nullable?: boolean;
  properties?: Record<string, SpecProp>;
  items?: SpecProp;
  required?: string[];
  additionalProperties?: boolean | { type: string };
  description?: string;
  minimum?: number;
  maximum?: number;
  minItems?: number;
  maxItems?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
}

export interface SpecBody {
  type: string;
  format?: string;
  nullable?: boolean;
  enum?: (string | number)[];
  required?: string[];
  properties?: Record<string, SpecProp>;
  items?: SpecProp;
  additionalProperties?: boolean | { type: string };
  description?: string;
  minimum?: number;
  maximum?: number;
  minItems?: number;
  maxItems?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
}

export interface IndexSpec {
  endpoint?: { id?: string; name?: string; description?: string };
  http?: {
    method?: string;
    path?: string;
    auth?: { type?: string; guard?: string; description?: string };
    request?: {
      headers?: { name: string; type: string; format?: string; required?: boolean; description?: string; enum?: (string | number)[]; minimum?: number; maximum?: number; minItems?: number; maxItems?: number; minLength?: number; maxLength?: number; pattern?: string }[];
      path?: { name: string; type: string; format?: string; enum?: (string | number)[]; description?: string; minimum?: number; maximum?: number; minItems?: number; maxItems?: number; minLength?: number; maxLength?: number; pattern?: string }[];
      query?: { name: string; type: string; format?: string; required?: boolean; description?: string; enum?: (string | number)[] }[];
      body?: SpecBody;
    };
    response?: {
      status?: number;
      body?: SpecBody;
      errors?: { status: number; code: string; description?: string; cause?: string; resolution?: string }[];
    };
  };
  usecase?: { description?: string };
}

export interface MockScenario {
  name: string;
  description?: string;
  given?: Record<string, unknown>;
  expect: {
    status: number;
    body?: unknown;
  };
}

export interface ParsedEndpoint {
  app: string;
  module: string;
  feature: string;
  id: string;
  name: string;
  method: string;
  path: string;
  spec: IndexSpec;
  scenarios: MockScenario[];
  specYaml: string;
  mocksJson: string;
}

export interface SpecContext {
  endpoints: ParsedEndpoint[];
  enumMap: Map<string, (string | number)[]>;
  warnings: string[];
}
