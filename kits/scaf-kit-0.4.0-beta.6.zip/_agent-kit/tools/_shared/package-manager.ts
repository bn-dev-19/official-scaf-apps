// Gestionnaire de paquets (`packageManager` : pnpm|npm|yarn|bun). Le code généré est écrit pour pnpm ; les commandes citées
// (scripts, README, messages, commentaires) sont traduites ici — un seul endroit pour les deux générateurs.
const RUN: Record<string, string> = { npm: "npm run ", yarn: "yarn ", bun: "bun run " };
const EXEC: Record<string, string> = { npm: "npx ", yarn: "yarn ", bun: "bunx " };

/** `pnpm install` → `<pm> install` ; `pnpm exec x` → `npx x` ; `pnpm <script>` → `<pm> run <script>`. Inchangé pour pnpm (ou inconnu). */
export function pmText(text: string, pm?: string): string {
  if (!pm || !RUN[pm]) return text;
  return text.replace(/\bpnpm (exec |install\b)?/g, (_m, k) => k === "install" ? `${pm} install` : k ? EXEC[pm] : RUN[pm]);
}

/** Traduit le contenu des fichiers générés (en place). */
export function pmFiles(files: { content: string }[], pm?: string): void {
  if (pm && RUN[pm]) for (const f of files) f.content = pmText(f.content, pm);
}
