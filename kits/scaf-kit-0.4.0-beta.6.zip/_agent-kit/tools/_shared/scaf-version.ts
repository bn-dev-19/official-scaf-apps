// Version scaf (snapshot `scaf/vN`) ciblée par un générateur : argument explicite, sinon `scaf/.scaf-version`, sinon dernier `v*` (01-structure.md §Versions).
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const SCAF_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..", ".."); // _shared → tools → _agent-kit → scaf

/** Dossier de version : `arg` s'il est donné (hors option `--x`), sinon la version active. */
export function resolveVersionDir(arg?: string): string | undefined {
  if (arg && !arg.startsWith("--")) return arg;
  const f = join(SCAF_ROOT, ".scaf-version");
  const name = existsSync(f) ? readFileSync(f, "utf8").trim()
    : readdirSync(SCAF_ROOT).filter(d => /^v/.test(d) && existsSync(join(SCAF_ROOT, d, "input"))).sort().pop();
  return name && existsSync(join(SCAF_ROOT, name, "input")) ? join(SCAF_ROOT, name) : undefined;
}

export const scafVersionName = (versionDir: string) => basename(resolve(versionDir));

/** Message d'erreur si `cur` est une version scaf plus ancienne que `prev` (comparaison du nombre après `v` ; `v1-beta` = `v1`). */
export function olderVersionError(prev: string | undefined, cur: string, out: string): string | undefined {
  const n = (v?: string) => { const m = /^v(\d+)/.exec(v ?? ""); return m ? Number(m[1]) : undefined; };
  const p = n(prev), c = n(cur);
  return p !== undefined && c !== undefined && p > c
    ? `le projet ${out} a été généré depuis ${prev} : régénérer depuis ${cur} (plus ancienne) risque de supprimer/écraser ses fichiers. Relancer avec la version ${prev} (ou --force).`
    : undefined;
}
