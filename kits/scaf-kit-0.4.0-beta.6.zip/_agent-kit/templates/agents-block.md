<!-- scaf-kit:begin (bloc géré par le kit scaf : à mettre à jour en remplaçant tout ce qui est entre les marqueurs) -->
## scaf — spécification du projet

Ce projet contient un dossier `scaf/` : le **projet SCAF**, spécification unique de l'application (scaffolding), découpée en petits fichiers YAML/JSON. C'est le pont de découpage et de contrats entre toutes les apps (frontend et backend) : toute feature/endpoint se spécifie d'abord ici (`app → module → feature → endpoint`, contrats YAML + mocks), les apps l'implémentent ensuite. OpenAPI, SQL/Drizzle, guides et code généré en dérivent. Le kit qui explique et outille `scaf/` est dans `scaf/_agent-kit/` (version : `scaf/_agent-kit/.scaf-kit`).

- Avant toute tâche dans `scaf/` : lire `scaf/_agent-kit/README.md` → `01-structure.md` → `02-file-formats.md` → `03-rules-and-validation.md`, puis le skill correspondant dans `scaf/_agent-kit/skills/`.
- Ne toucher que la version active (lue dans `scaf/.scaf-version`) ; jamais les autres dossiers `v*`.
- Éditer uniquement les sources : `project.parts/`, `usecases/`, `contracts/`, `database/visual/`, `export-configs/`. `openapi.parts/` et `output/` sont dérivés : les régénérer, ne jamais les éditer.
- Un fichier non listé dans son `_index.yml` n'existe pas (il sera supprimé) : garder index et fichiers synchrones.
- Enveloppe uniforme : `{ success, message, data }` ; erreurs `{ success:false, message, error:{code,message} }`.
- Dérivés : contrats modifiés → `ruby scaf/_agent-kit/tools/contracts_to_openapi.rb scaf/<version> --doc` ; visuel DB modifié → `ruby scaf/_agent-kit/tools/visual_to_sql.rb scaf/<version>`.
- Après chaque modification : `ruby scaf/_agent-kit/tools/audit.rb scaf/<version>`.
- Générer une app : `tools/nextjs` (`gen_nextjs.ts`) ou `tools/nestjs` (`gen_nestjs.ts`), voir `scaf/_agent-kit/04-tooling-map.md`. Prérequis : Ruby (spec) ; Node + pnpm (générateurs : `cd scaf/_agent-kit/tools && pnpm install`).
- Création, refonte, complément ou confrontation du scaf : suivre `scaf/_agent-kit/skills/scaf-bootstrap-from-sources.md` — **demander explicitement** sur quelles bases d'information partir (cahier des charges, description du projet, code existant…) et comment (de zéro, confronter l'existant, compléter), même si aucun dossier de ressources n'est précisé ; ne jamais deviner ni inventer.
- Mise à jour du kit : **uniquement si l'utilisateur le demande** (vérifier les versions récentes sur le dépôt officiel, télécharger, remplacer `scaf/_agent-kit/`) — suivre `scaf/_agent-kit/skills/scaf-update-kit.md`.
<!-- scaf-kit:end -->
