# 02 — Formats de fichiers (schémas exacts)

Légende : **R** = requis, **O** = optionnel. Les exemples viennent de `scaf/v1/input`.
Les types Go de référence : `cli/internal/schema/{project,usecase,contract}.go`.

---

## 1. `project.parts/info.yml`

```yaml
name: Solution de gestion des CV      # R, >= 3 caractères
version: 1.0.0                        # R, >= 3 caractères
description: Plateforme web ...       # R, >= 3 caractères
```

## 2. `project.parts/actors.yml` (tableau)

```yaml
- id: candidate                       # R, kebab-case, unique
  type: human                         # R : human | machine | program | external | data
  description: 'Candidat externe authentifié : ...'   # O (recommandé)
```
Sens des types : `human` personne ; `machine` service automatique (email) ; `program` logiciel/IA interne ;
`external` système tiers (SSO, stockage) ; `data` entrepôt/index de données.
`actors.yml` est **obligatoire** (audit : E si absent/vide). Les ids sont référencés par `atomic_actions[].actor`, les journeys (`actor`) et `usecases/*.intent.actors`.
Champ optionnel `guards: [RequireAdmin]` : gardes d'auth des contrats (`http.auth.guard`) que l'acteur peut franchir ; sert à l'audit pour vérifier `intent.actors` ↔ garde du contrat.

## 3. `project.parts/apps/<app>.yml`

```yaml
name: Talent                          # R, >= 2
slug: candidate                       # R, slug unique
description: 'Portail du candidat externe : ...'   # R (>= 15 recommandé, warning sinon)
tagline: Candidatez en quelques clics # O
principe: Permettre au candidat ...   # O (principe directeur)
api: false                            # O (défaut true) : app sans API (worker, event-driven…) — aucun contrat d'endpoint attendu (A3 exempté), générée quand même (Next.js : sans api-*, avec app-*) ; ses usecases se rattachent à une feature par `feature:`
seo:                                  # O (tout est optionnel dans seo)
  siteName: MafCV Candidate Portal
  description: '...'
  baseUrl: https://example.test       # http(s) uniquement
  google: { searchConsoleVerification: google3a7b... }
  bing:   { siteVerification: BingSiteAuth=7a8b... }
```

## 4. `project.parts/modules/<app>.<module>.yml`

```yaml
name: Analyse IA des CV               # R
slug: cv-ai-analysis                  # R (unique global parmi les modules)
description: Pipeline d'intelligence artificielle ...   # R (>= 15 recommandé)
app: candidate                        # recommandé : slug d'app déclarée (warning si inconnue)
more: ...                             # O : texte long « pourquoi / périmètre »
explication: ...                      # O : texte long « comment il s'articule avec les autres modules »
dependencies: [candidate-portal, public-offers-management]   # O : slugs de MODULES existants, sans cycle
features:                             # R (tableau, peut être vide mais déconseillé)
  - name: Extraction et classification        # R
    slug: extraction-classification           # R (unique dans le module) = slug de feature des contrats
    internal: false                           # O (défaut false) : true = feature sans endpoint (usecases internes `feature: <module>/<feature>`) — A3 exempté, erreur si elle figure dans contracts
    description: ...                          # R
    more: ...                                 # O
    explication: ...                          # O
    atomic_actions:                           # recommandé
      - name: Extraire les informations structurées   # R, >= 3
        description: ...                              # O
        actor: ai-cv-analyzer                         # O : id présent dans actors.yml
```
Les clés sont écrites dans cet ordre par le backend : `name, slug, description, app, more, explication, dependencies, features`.

## 5. `usecases/<type>/<app>/<id>.usecase.yml`

Le dossier `<type>` **doit** porter le même nom que `type` ; `<app>` doit être un slug d'app de `project.parts` et, si `openapi` est présent, l'app du contrat de `operationId`. Vocabulaire neutre (pas lié à un frontend/backend littéral) :
`producer` = côté qui fournit/expose (serveur, source, éditeur), `consumer` = côté qui appelle/reçoit (client, cible, abonné), `shared` = les deux.

```yaml
id: login-candidate                   # R en pratique ; = nom de fichier ; kebab-case
usecase: ""                           # champ historique, toujours "" — le laisser tel quel
name: Connecter un candidat           # R, >= 2, unique
type: producer                        # R : producer | consumer | shared (= dossier parent)
description: Authentifie un candidat ...    # R, >= 5
input:                                # R
  schema:                             # map nom-de-champ → définition
    email:    { type: string, required: true }
    password: { type: string, required: true }
output:                               # R
  schema:
    token: { type: string }
    expires_at: { type: string }
steps:                                # R, tableau ordonné
  - code: auth.validate_credentials_format   # R : "<domaine>.<action_snake_case>"
    order: 1                                 # R, entier
    severity: medium                         # critical | high | medium | low
    stepDescription: ...                     # O
errors:                               # R (warning si absent)
  - code: INVALID_CREDENTIALS         # R, SCREAMING_SNAKE
    status: 401                       # R, entier HTTP
    description: Les identifiants fournis sont invalides.   # R
feature: jobs/cleanup                 # O : `<module>/<feature>` de project.parts de l'app ; rattachement explicite d'un usecase sans endpoint (app `api: false`) — sinon la feature vient de l'endpoint `openapi.operationId`
openapi:                              # O (obligatoire pour un usecase producer exposé en HTTP ; absent + `feature:` = usecase interne sans route, appelé par `calls`)
  operationId: post-candidate-auth-login   # = id d'un endpoint de contracts/
  method: POST                             # GET|POST|PUT|PATCH|DELETE
  path: /api/v1/candidate/auth/login       # commence par /
trigger:                              # O : déclencheur d'un usecase interne sans HTTP (app `api: false` ou worker) ; une seule clé : cron: "0 3 * * *" | queue: "send-emails" | event: "user.created" | command: "purge" ; incompatible avec `openapi`, exige `feature:`
intent:                               # R en pratique pour tout endpoint (W d'audit « intent manquant » sinon) : pourquoi/qui/quoi attendre — guide d'implémentation (voir ci-dessous)
  purpose: Permet à ... de ... afin de ...   # R si intent, >= 10 : raison d'être réelle, en langage métier
  actors: [candidate]                        # O : acteurs autorisés à l'appeler, ids de actors.yml
  preconditions: [ "État/droit requis ..." ] # O
  effects: [ "Changement d'état, écriture, notification ..." ]   # O : ce que le producteur doit garantir
  depends_on:                                # O : appels liés, par ordre logique
    - { endpoint: get-wallet, when: before, why: "Vérifier le solde" }   # when : before | during | after ; endpoint (id existant) OU usecase (id existant) ; why requis
  consumer_notes: "Comment/quand l'appeler, impact sur l'écran ou l'état côté consommateur."   # O
  tables:                                    # O : tables de database/visual/ lues/écrites (injectées comme repositories par le générateur NestJS N2) ; entrée `{ table, access, why }`, `why` (O) = rôle de CE usecase, repris dans le guide d'utilisation
    - { table: platform_settings, access: write }   # table = nom SQL existant ; access : read (défaut) | write
calls:                                # O : use cases appelés ; mode (O) : sync (défaut, appel direct) | event (événement émis après succès, la cible l'écoute)
  - { usecase: send-email, mode: event, after: auth.send_welcome, when: "..." }   # after (O) = code d'un step de CE usecase où l'appel se place ; when = condition en prose (non évaluée)
links:                                # O : enchaînements
  - rel: next
    usecase: list-external-applications
    when: Le candidat consulte ses candidatures après connexion
```
Définition de champ (`input.schema.*`, `output.schema.*`, et `properties` imbriqués) :
`type` (`string|number|boolean|integer|object|array|any`), `format`, `required` (bool), `nullable` (bool), `default`,
`minLength`/`maxLength` (nombres), `minimum`/`maximum` (nombres), `minItems`/`maxItems` (tableaux), `pattern`, `description`, `enum` (liste de chaînes, ou d'entiers pour `type: integer` : généré en littéraux numériques), `enumDescriptions` (map),
`properties` (si `object`), `items` (si `array`).
`description` est optionnelle ; renseignée, elle est reprise par les générateurs (NestJS : JSDoc + `@ApiProperty` sur les DTO, JSDoc + `@ApiProperty` sur les classes de réponse).

Côté producer, `calls` relie un usecase à un **usecase interne** (producer sans `openapi`, rattaché par `feature: <module>/<feature>`) : `sync` = le usecase cible est injecté et appelé ; `event` = événement `<source>.<cible>` émis après succès, la cible l'écoute (NestJS : `EventEmitter2`, `@OnEvent`, `domain/events/`). `when` (prose) et `after` (code de step, E si inconnu) sont repris dans le code NestJS : tags `@emitsWhen`/`@callsWhen`, méthode `emit<Cible>()` et commentaire dans le handler du step `after`. Cible `event` = producer (W sinon) ; cycle de `calls` sync = E. Le guide d'implémentation ajoute « Appelle », « Émet un événement vers », « Déclenché par ».

`trigger` (NestJS) : `cron` → `@Cron` (`@nestjs/schedule`), `queue` → `@Processor` BullMQ (`queue: bullmq`), `event` → `@OnEvent`, exécutés par un provider qui appelle le usecase ; `command` (CLI) est accepté mais non généré. Un usecase interne d'une app `api: false` sans `trigger` ni appel `calls` n'est jamais exécuté (W). Sortie 100 % `api: false` : `main.ts` standalone (`createApplicationContext`, aucun port) ; dès qu'une app `api: true` est fusionnée dans la sortie, `main.ts` reste HTTP et le worker tourne dans ce process.

Format des textes de `intent` : ≤ 100 caractères → une ligne entre guillemets ; sinon scalaire replié `>-` (lignes ~90 car., indentées sous la clé ou sous `- `). Un `why` long dans `depends_on` passe en forme développée (`- endpoint:` / `when:` / `why: >-`).

Le bloc `intent` n'altère pas l'OpenAPI ; `tools/intent_to_md.rb` en dérive `output/implementation-guide/`. Il s'ajoute à `steps` (qui restent les étapes d'implémentation).

Remarque : sur les données actuelles, 22 use cases n'ont pas de bloc `openapi` (flux `consumer`/`shared`) ; les `openapi.path` de
certains use cases n'ont pas le préfixe `/v1` alors que les contrats l'ont → **relier par `operationId`, pas par chemin**.

`usecases/usecases-config.json` (optionnel, utilisé par le runner de scénarios) :
`{ project, version?, description?, usecases:[{ id, file, name, operationId?, description?, links_to?[] }] }`.

## 6. `contracts/servers.yml`

```yaml
servers:
  - { url: http://localhost:8080, description: Local development }
  - { url: https://staging.example.com, description: Staging }
```

## 7. `contracts/apps/<app>/<module>/<feature>.yml` — le fichier central

```yaml
slug: initial-matching                # R = nom du fichier = slug de feature
name: initial-matching                # R
endpoints:                            # R
  - id: get-candidate-ia-match-history      # R, unique global
    name: Consulter l'historique de matching # R
    method: GET                              # R : GET|POST|PUT|PATCH|DELETE (majuscules)
    path: /api/v1/candidate/ia/match/history # R, commence par /api/vN/
    spec: |                                  # R : CHAÎNE YAML (voir §7.1)
      endpoint: { ... }
      http: { ... }
      usecase: { description: ... }
    mocks: |-                                # R : CHAÎNE JSON (voir §7.2), indentée de façon cohérente
      { "endpoint": "...", "mocks": [ ... ] }
    coverage:                                # O, dérivé — peut rester à zéro
      totalMocks: 0
      nominalCount: 0
      errorCount: 0
      errorCodes: []
      coverageScore: 0
```
`method`/`path` du niveau endpoint **doivent être égaux** à `spec.http.method` / `spec.http.path`.

### 7.1 `spec` (YAML)

```yaml
endpoint:
  id: get-candidate-ia-match-by-cvid-offers   # = id du contrat
  name: Associer un CV aux offres pertinentes
  description: ...
http:
  method: GET
  path: /api/v1/candidate/ia/match/{cv_id}/offers
  auth:
    type: required                 # required | none
    guard: RequireAuth             # RequireAuth | RequireAdmin | None (omettre guard si type: none)
  request:
    headers:                       # tableau de FieldDef
      - { name: Authorization, type: string, format: "Bearer {token}", required: true }
    path:                          # tableau de FieldDef (un par {param})
      - { name: cv_id, type: string, format: uuid, required: true, description: Identifiant du CV }
    query:                         # tableau de FieldDef
      - { name: page, type: integer, required: false }
    body:                          # SchemaField (POST/PUT/PATCH)
      type: object
      properties: { ... }
  response:
    status: 200                    # code de succès (entier)
    headers: []                    # O
    body:                          # SchemaField — TOUJOURS l'enveloppe {success,message,data}
      type: object
      properties:
        success: { type: boolean }
        message: { type: string }
        data:    { type: object, properties: { ... } }
    errors:                        # une entrée par erreur possible
      - status: 401
        code: UNAUTHORIZED                 # SCREAMING_SNAKE
        description: Token manquant ou invalide.
        message: Token manquant ou invalide.       # message exposé au client (prioritaire sur description)
        cause: Le jeton d'authentification est absent, expiré ou malformé.   # O
        resolution: Authentifiez-vous et fournissez un jeton valide.         # O
usecase:
  description: Associer automatiquement un CV aux offres publiques pertinentes.
```
FieldDef = `{ name, type, format?, required?, description? }`.
SchemaField = `{ type, format?, title?, description?, nullable?, enum?, properties?, items?, required? }`.
`title` (optionnel) nomme le composant OpenAPI quand le sous-schéma est factorisé (≥ 3 occurrences) ; sans `title`, le nom vient de la clé (`data`, `item`… génériques ⇒ nom de la ressource de l'endpoint : `/offers` → `Offer`, `OfferItem`).
Types : `string integer number boolean object array`. Formats `string` : `uuid email uri date-iso password`
(les formats `date`, `date-time`, `phone`, `int32`, `int64`, `float`, `double`… sont compris par le générateur SQL).
`object` ⇒ `properties` ; `array` ⇒ `items`. **Enums** : `enum: [A, B, C]` (MAJUSCULES), jamais `format: enum: ...`. Un enum `type: integer` (`enum: [1, 2, 3]`) reste numérique dans le code généré (`_1: 1`, union `1 | 2`, zod `z.enum`/`z.union`).

### 7.2 `mocks` (JSON)

```json
{
  "endpoint": "get-candidate-ia-match-history",
  "mocks": [
    {
      "name": "nominal-200",
      "description": "Cas nominal",
      "given":  { "method": "GET", "path": "/api/v1/candidate/ia/match/history",
                  "headers": { "Authorization": "Bearer <jwt>" }, "query": {}, "body": null },
      "expect": { "status": 200, "headers": { "Content-Type": "application/json" },
                  "body": { "success": true, "message": "Récupération réussie", "data": { "history": [] } } }
    },
    {
      "name": "error-unauthorized",
      "description": "Token manquant ou invalide.",
      "given":  { "method": "GET", "path": "/api/v1/candidate/ia/match/history", "headers": {}, "query": {}, "body": null },
      "expect": { "status": 401, "headers": { "Content-Type": "application/json" },
                  "body": { "success": false, "message": "Token manquant ou invalide.",
                            "error": { "code": "UNAUTHORIZED", "message": "Token manquant ou invalide.",
                                       "cause": "...", "resolution": "..." } } }
    }
  ]
}
```
Détails de rédaction : voir [`skills/scaf-write-mocks.md`](skills/scaf-write-mocks.md).

### 7.3 Formes de réponse (enveloppe) — une par cas

Racine du corps : `{ success, message, data, pagination?, warnings? }` en succès, `{ success:false, message, error }` en erreur.
`pagination` et `warnings` sont **hors `data`**. Listes = tableaux sous des **clés nommées** dans `data` (jamais `data.data`, jamais un tableau nu).
Dans `spec.http.response.body`, déclarer chaque clé de racine comme `properties` (comme pour `data`) ; le convertisseur impose la forme canonique de `pagination` et `warnings`.

| # | Cas | Racine du corps |
|---|---|---|
| A | Objet | `data: { ... }` |
| B | Liste non paginée | `data: { <clé>: [ ... ] }` |
| C | Liste paginée | `data: { <clé>: [ ... ] }` + `pagination` |
| D | Sans données | `data: null` (déclarer `data` avec `nullable: true`) |
| E | Avec avertissements | un des cas ci-dessus + `warnings: [ ... ]` |
| F | Erreur | `error: { code, message, cause?, resolution? }`, pas de `data` |

**A — objet**
```json
{ "success": true, "message": "Récupération réussie", "data": { "offer_id": "3f2b...", "title": "Analyste Financier" } }
```
**B — liste non paginée**
```json
{ "success": true, "message": "Récupération réussie", "data": { "permissions": [ { "code": "OFFER_READ" } ] } }
```
**C — liste paginée** (requête : `page`, `page_size` ; réponse : `pagination` entiers, `total_pages = 0` si liste vide)
```json
{ "success": true, "message": "Récupération réussie",
  "data": { "offers": [ { "offer_id": "3f2b...", "title": "Analyste Financier" } ] },
  "pagination": { "current_page": 2, "page_size": 10, "total_items": 25, "total_pages": 3 } }
```
Spec correspondante :
```yaml
body:
  type: object
  properties:
    success: { type: boolean }
    message: { type: string }
    data:
      type: object
      properties:
        offers: { type: array, items: { type: object, properties: { offer_id: { type: string, format: uuid } } } }
    pagination:
      type: object
      properties:
        current_page: { type: integer }
        page_size: { type: integer }
        total_items: { type: integer }
        total_pages: { type: integer }
```
**D — sans données** (ex. réinitialisation de mot de passe, suppression)
```json
{ "success": true, "message": "Mot de passe réinitialisé", "data": null }
```
```yaml
data: { type: object, nullable: true }
```
**E — avertissements** (succès avec réserves ; `warnings` = tableau de `{ title, description, tips[] }`, absent si rien à signaler)
```json
{ "success": true, "message": "Import terminé",
  "data": { "created": 48, "skipped": 2 },
  "warnings": [ { "title": "Lignes ignorées", "description": "2 lignes ont un domaine e-mail non autorisé.",
                  "tips": [ "Vérifiez la colonne email.", "Ajoutez le domaine dans les domaines autorisés." ] } ] }
```
```yaml
warnings:
  type: array
  items:
    type: object
    properties:
      title: { type: string }
      description: { type: string }
      tips: { type: array, items: { type: string } }
```
**F — erreur** (voir 7.2 `error-unauthorized`) : `success:false`, `message` = `error.message`, aucun `data`/`pagination`/`warnings`.

**Déclarer `warnings` (optionnel, au niveau de `data`) dans toute réponse de succès** : le backend peut signaler une réserve sur n'importe quelle opération réussie. S'il est oublié, le convertisseur l'ajoute (`$ref: Warnings`) ; déclaré, il est ramené à la forme canonique.

Combinaisons : C + E est valide (liste paginée avec avertissements) ; D + E aussi. Règles vérifiées par `audit.rb` : `pagination-in-data`, `pagination-shape`, `warnings-shape`, `warnings-missing`.

**Quelle forme pour quelle liste ?**

| Famille | Forme | Exemple |
|---|---|---|
| Collection de ressources (offres, utilisateurs…) | C | `data.offers` + `pagination` |
| Catalogue / référentiel (pays, rôles, types…) | **C aussi** : toujours paginé, même court (`current_page: 1`, `total_pages: 1`) ; la requête accepte `page`/`page_size` | `data.items` + `pagination` |
| Liste avec contexte parent | C ; l'id du parent reste dans `data` à côté de la clé de liste | `data: { candidate_id, items: [...] }` + `pagination` |
| Résultats de recherche / matching | C ; clé nommée (`candidates`, `offers`, `history`…), compteur = `pagination.total_items` (jamais `total`/`total_results` dans `data`) ; métadonnées d'exécution (`execution_time_ms`) restent dans `data` | `data.candidates` + `pagination` |
| Détail avec sous-éléments (`roles`, `skills`, `questions`…) | A (objet), pas de pagination | `GET /offers/{id}` |
| Configuration remplacée en bloc (`GET`/`PUT`) | A, pas de pagination | `confidentiality-levels` |
| Compte rendu d'opération (`import`, `assign`) | A, pas de pagination | `data: { created_count, results: [...] }` |
| Format imposé par un tiers (JSON-LD…) | enveloppe conservée ; seules les clés JSON-LD camelCase de `data` font exception | `offers/feed.json` |

`B` ne sert plus qu'aux listes dont la taille est bornée par nature et qui ne sont pas un catalogue ; en cas de doute, utiliser C.

**Recherche = GET.** Une recherche ne modifie rien : `GET` avec les critères en `query` (`page`, `page_size` inclus). Un tableau se passe en paramètre répété (`?keywords=a&keywords=b`) et se déclare `type: array` + `items` dans la `query` ; dans un mock : `"query": { "keywords": ["a", "b"] }`. Le `POST` n'est réservé qu'aux critères trop longs ou sensibles pour une URL (ex. texte libre NLP : `ia/search/nlp`) ; la pagination va alors dans le body (`page`, `page_size`).

---

## 8. `database/visual/_visual_<module>.yml`

Principe : les contrats décrivent ce qui entre et sort ; le visuel décrit ce qui est **stocké**. Il peut contenir des tables et colonnes sans contrat (pivot, audit, jetons, files, compteurs, soft-delete, clés techniques) et omettre les champs calculés (agrégats, libellés dérivés). Un écart contrat↔visuel n'est pas une erreur.

```yaml
name: cv-ai-analysis                  # R = slug du module de contrat
description: Module cv-ai-analysis    # O
tables:
  - name: classifies                  # R, pluriel snake/kebab ; unique dans le module
    description: Enregistrer le résultat ...   # R
    kind: entity                      # R (sauf external) : entity = exposée par un contrat · pivot = liaison N-N · internal = technique non exposée (jetons, files) · audit = trace en ajout seul ; informatif (docs), sans effet sur SQL/Drizzle
    columns:
      - name: cv_id                   # R
        type: uuid                    # R : uuid text varchar(n) integer bigint decimal decimal(p,s) boolean datetime date jsonb enum  (decimal seul = 18,2)
        nullable: false               # O (défaut : null = non précisé)
        primary: true                 # O ; plusieurs colonnes primary = clé composite
        default: NOW()                # O : expression SQL telle quelle ; jsonb : '''{}''::jsonb'
        unique: false                 # O ; true = contrainte UNIQUE sur la colonne
        references: { table: cvs, column: id, onDelete: cascade }   # O : clé étrangère ; onDelete/onUpdate (O) : cascade|set null|restrict|no action (`set null` exige nullable: true)
        description: Identifiant du CV classifié.
        enumRef: classifies_classification_status   # OBLIGATOIRE si type: enum → nom dans _visual_enums.yml
    indexes:                          # O
      - { name: idx_classifies_status, columns: [classification_status], unique: false }
      # variantes (O) : method btree|hash|gin|gist|brin ; where = prédicat SQL (index partiel) ; expressions = liste d'expressions SQL à la place/en plus de columns
      - { name: idx_classifies_active, columns: [classification_status], where: deleted_at IS NULL }
      - { name: idx_classifies_tags, columns: [tags], method: gin }
      - { name: idx_classifies_lower, expressions: ["lower(label)"] }
    rls:                              # O ; Row Level Security (PostgreSQL seulement ; ignoré avec W sur MySQL/SQLite)
      enabled: true                   #   ENABLE ROW LEVEL SECURITY (force: true ajoute FORCE : le propriétaire est aussi soumis aux policies ; inutile avec SET LOCAL ROLE app_user, et il lui faut alors ses propres policies)
      owner: [passenger_id]           #   O ; colonnes = utilisateur courant → policies select/insert/update/delete
      admin: [admin]                  #   O ; rôles qui passent outre (policy ALL)
      policies:                       #   O ; { name, for: select|insert|update|delete|all, using, withCheck } SQL libre ; helpers app_user_id() / app_has_role('x')
        - { name: trips_public_read, for: select, using: "status = 'PUBLISHED'" }
    checks:                           # O ; contraintes CHECK (SQL libre, noms de colonnes de la table) ; name unique
      - { name: chk_classifies_score, expression: score >= 0 AND score <= 100, description: Score borné. }
  - name: users                       # table externe (ex. Better Auth) : valide comme cible de FK, NON générée (ni SQL ni Drizzle)
    external: true                    # O ; déclarer au moins la colonne primary
    description: Table gérée hors scaf.
    columns:
      - { name: id, type: text, primary: true, description: Identifiant. }
```

## 9. `database/visual/_visual_enums.yml`

```yaml
enums:
  - name: classifies_classification_status    # <table>_<colonne>
    description: Statut de la classification.
    values:
      - { value: PENDING, description: En attente. }
      - { value: DONE,    description: Terminée. }
```
Remarque : les valeurs d'enums DB existantes sont mixtes (certaines minuscules, certaines MAJUSCULES) ; pour tout nouvel enum
dérivé d'un `enum:` de spec, **reprendre exactement les valeurs de la spec** (MAJUSCULES).

## 10. `openapi.parts/**` (dérivé — lecture seule en pratique)

Fichier endpoint (`<app>/<module>/<feature>/<endpoint-id>.yml`) :
```yaml
tags:
  - { name: "candidate / cv-ai-analysis / initial-matching", description: "Module candidate / cv-ai-analysis / initial-matching" }
paths:
  /api/v1/candidate/ia/match/history:
    get:
      operationId: get-candidate-ia-match-history
      description: ...
      responses:
        "200": { description: ..., content: { application/json: { schema: {...}, examples: {...} } } }
        "401": ...
```
Les fichiers de niveau app/module/feature sont des squelettes (`openapi: 3.0.3`, `info.title: <app>/<module>`, `paths: {}`) ou
agrègent les chemins du niveau. `info.yml` (optionnel) = `{ openapi, info, servers?, security?, components? }`.
Les exemples (`examples:`) proviennent du **nom** des mocks (`summary: <nom du mock>`) ; plusieurs mocks de même nom
sont suffixés `_2`, `_3`.

## 11. `export-configs/<technologie>.json` et `<technologie>.<app>.json`

Config de génération de l'app cible. `nextjs` et `nestjs` : formats définis par le kit (voir « NestJS » ci-dessous). Sens et source de chaque option : [`05-export-config-reference.md`](05-export-config-reference.md). Validé par `tools/export_configs.rb` (règles EC pour nextjs, NS pour nestjs : §EC et §NS de `03`).

```json
{ "technology": "nextjs", "version": 46, "savedAt": "2026-10-30T16:42:05.000Z",
  "config": { "projectName": "miidjo", "architecture": "clean_architecture", "auth": "custom_jwt",
              "apiLayer": "server_actions", "stateManagement": "zustand", "httpClient": "ky", "logger": "pino",
              "i18n": true, "i18nLanguages": ["fr"], "pwa": true, "seo": { ... }, "agentLoop": { ... },
              "pushNotifications": { "vapidPrivateKey": "$var:VAPID_PRIVATE_KEY", ... } } }
```
`version` s'incrémente à chaque sauvegarde de l'app.

**Base** `nextjs.json` : valeurs communes à toutes les apps. **Override** `nextjs.<app-slug>.json` (O) : `{ "technology": "nextjs", "app": "<slug>", "config": { …partiel… } }` ; `<slug>` ∈ `project.parts`, `projectName` interdit (= slug de l'app).
Config effective d'une app = base ⊕ override (objets fusionnés récursivement, tableaux et scalaires remplacés) ⊕ surcharges de `project.parts/apps/<app>.yml` (`description`, `tagline`, `principe`, `seo.siteName/description/baseUrl/google/bing`; `projectName` = slug).
Voir la config effective : `ruby scaf/_agent-kit/tools/export_configs.rb scaf/<v> --resolve <techno> <app>`. Les overrides et `$var:` sont une convention du kit.

**Champs** (valeurs d'enum validées par `export_configs.rb`) :

| Champ | Type / valeurs | Notes |
|---|---|---|
| `projectName`* `description` `tagline` `principe` | string | par app : dérivés de `project.parts` |
| `packageManager`* | `pnpm\|npm\|yarn\|bun` | |
| `styling`* | `tailwind_shadcn\|css_modules\|styled_components\|chakra_ui` | `shadcnPreset` : string (vide = aucun) |
| `theme` `font` | `light\|dark\|system` · `geist\|inter\|poppins\|custom` | `custom` ⇒ `customFontPath` **relatif au dépôt** (`_ui-kits/…`), jamais absolu |
| `architecture`* | `mvvm\|mvc\|clean_architecture` | |
| `apiLayer`* | `server_actions\|route_handlers\|trpc\|graphql` | |
| `auth`* | `nextauth_v5\|clerk\|supabase\|custom_jwt\|none` | `oauthProviders`: string[] |
| `orm` `database` | `prisma\|drizzle\|typeorm\|mongoose\|none` · `postgresql\|mysql\|sqlite\|mongodb\|none` | `none` quand le front consomme l'API scaf (EC6) |
| `stateManagement` `httpClient` `logger` | `zustand\|jotai\|redux_toolkit\|tanstack\|none` · `ky\|axios\|fetch` · `pino\|winston\|none` | |
| `errorMonitoring` `analytics` | `sentry\|logrocket\|none` · `vercel\|plausible\|none` | |
| `i18n` `i18nLanguages` | bool · string[] | `i18n` ⇒ liste non vide, contient `seo.defaultLocale` |
| `pwa` | bool | requis par `pushNotifications.enabled` |
| `seo`* | objet (`enabled, siteName, description, baseUrl, defaultLocale, locales, robots, sitemap, openGraph, jsonLd, llms{enabled,index,full,llmsPage}, legal{privacy,terms,license,credits}, footerLinks, google, bing`) | `baseUrl/google/bing` surchargés par app |
| `pushNotifications` | objet (`enabled, vapidPublicKey, vapidPrivateKey, vapidSubject, defaultTitle, icon, badge, tag, deepLink, actions, ttl, urgency, iosGate, includeTestPage`) | clés VAPID : `$var:` |
| `agentLoop` `behaviors` | objets | `behaviors.behaviorOnly` : génère sans specs/mocks |
| `srcDir` `importAlias` `eslintInBuild` `imagesUnoptimized` `allowedImageDomains` `allowedDevOrigins` `reactStrictMode` `bodySizeLimit` `rateLimiting` `agentsFilename` `targetOs` `nextDevToolsMcp` `docsTool` | bool / string / string[] / enum | |

`*` requis dans la base.

**Secrets** : jamais en clair. Une valeur `"$var:NOM"` renvoie à `contracts/variables.yml` (`variables: [{key, value, sensitive?}]`). Concernés : `pushNotifications.vapidPublicKey` et `vapidPrivateKey` (`sensitive: true` pour la privée). `customFontPath` est le seul chemin : relatif au dépôt, jamais machine-spécifique.

### NestJS — `nestjs.json` / `nestjs.<app>.json`

Même mécanique que Next.js (base + override partiel par app, `projectName` interdit en override, `$var:` pour les secrets, tableaux/scalaires remplacés). Schéma défini par le kit, indépendant de tout projet (un projet comme Miidjo n'en est qu'un exemple).

```json
{ "technology": "nestjs", "version": 1, "savedAt": "2026-10-31T12:00:00.000Z",
  "config": { "projectName": "miidjo", "packageManager": "pnpm", "orm": "drizzle", "database": "postgresql",
              "databaseUrl": "$var:NEON_DATABASE_CONNEXION_STRING", "auth": "better_auth", "bodyParser": false,
              "architecture": "ddd_layered", "generator": { "level": "N1" } } }
```

| Groupe | Champs (`*` requis dans la base) |
|---|---|
| Identité | `projectName`* `description` `packageManager`* `pnpm\|npm\|yarn\|bun` · `nodeVersion` (string) · `srcDir` (NestJS : `true` seulement, NS13) |
| Plateforme | `httpAdapter` `express\|fastify` · `port` (1–65535) · `globalPrefix` · `versioning` `none\|uri\|header` · `bodyParser` (bool) · `cors{origins[],credentials,methods[]}` · `rateLimiting` (bool ou `{default?: {limit, ttlMs}, endpoints?: {<endpoint-id>: {limit, ttlMs}}}`) · `swagger{enabled,path,type}` (`type` `ui\|scalar\|redoc`, défaut `ui`) |
| Données | `orm`* `drizzle\|typeorm\|prisma\|none` · `database`* `postgresql\|mysql\|sqlite\|none` · `schemaDir` (dossier du schéma Drizzle du backend, lu par `db_compare.rb`) · `schemaKeyStyle` `snake\|camel` (clés TS du Drizzle généré, défaut snake) · `tablesNames` (bool : génère `tables-names.ts`) · `databaseProvider` `neon\|pg\|none` (typeorm : mêmes valeurs ; mysql2, better_sqlite3 selon `database`) · `migrations` `drizzle_kit\|none` · `databaseUrl` (secret) · `idStrategy` `uuid\|serial` |
| Auth | `auth`* `better_auth\|jwt\|none` · `authPlugins[]` ⊂ `admin\|username\|bearer\|jwt\|multiSession\|anonymous\|organization\|twoFactor\|openAPI\|customSession\|phoneNumber\|emailOTP\|magicLink\|apiKey` · `emailVerification` · `minPasswordLength` · `oauthProviders[]` · `trustedOrigins[]` · `authSecret` (secret) · `authBaseUrl` (`$var:` admis, non secret) |
| API | `validation` `class_validator\|zod\|none` · `responseEnvelope` (`{ success, message, data }`) (enveloppe d'erreur et pagination : imposées par le contrat, pas des options) |
| Infra | `logger` `nest\|pino\|winston` (`LOG_LEVEL`) · `cache` `none\|redis` (`REDIS_URL`, `CACHE_MANAGER`) · `queue` `none\|bullmq` · `mailer` `none\|resend\|nodemailer\|smtp` (better_auth : e-mails d'OTP/lien magique/vérification/reset ; `smtp`=`nodemailer`) · `sms` `none\|twilio` (plugin `phoneNumber`) · `errorMonitoring` `sentry\|none` (`SENTRY_DSN`) · `healthCheck` |
| Tests | `testFramework` `jest\|vitest` · `e2e` |
| Identité & RLS | `authUserTable` (nom d'une table du visuel qui EST la table des comptes ; better_auth + drizzle|prisma ; refusé avec typeorm) · `authUserFields` (objet champ Better Auth → colonne, ex. `{"name":"full_name","image":"avatar_url"}` ; les colonnes snake_case du visuel (`email_verified`, `created_at`, `ban_reason`…) sont mappées automatiquement) · `authDefaultRole` (rôle écrit par le plugin admin à l'inscription, doit appartenir à l'enum de `users.role` ; défaut Better Auth : `user`) · `rls` `none\|session` (défaut none ; `session` = contexte RLS par requête, postgresql + drizzle seulement) |
| Environnement | `envFile` `example_and_file\|example\|none` (défaut `example_and_file`) · `generateSecrets` (bool, défaut true) |
| Modules | `architecture`* `ddd_layered\|modular_simple` · `moduleLayout{layers[],domainDirs[]}` (`domainDirs` → `domain/<dir>/.gitkeep` par module) · `usecaseStyle` `service_per_usecase\|handler` · `usecaseBase` `none\|template_method` (enveloppe d'exécution : `BaseUsecase` avec `run()`) · `generator{level}` (`N0|N1|N2`, voir `04-tooling-map.md` §Génération NestJS) |

Secrets nestjs : `databaseUrl`, `authSecret` en `"$var:NOM"` (`sensitive: true` dans `contracts/variables.yml`).

## 12. `tickets/<id>.ticket.yml` (O)

Champs : `id, title, description?, status, priority, category, app?, module?, feature?, actorId?, roleAssign?, parentTicketId?,
items[{id,label,checked}], sources[{kind,origin,sourceId,app?,module?,feature?,endpointId?,tableName?,columnName?,migrationFile?,usecaseId?,scenarioPath?}],
enrichments[{id,type,title,content,scope?,ticketId?,createdAt,updatedAt}], tags[], deadline?, observations?, suggestions?, createdAt, updatedAt`.
`tickets/actors.yml` : `actors: [{ id, name, role }]` (distinct de `project.parts/actors.yml`).

## 13. `journeys/<id>.journey.yml` (O) — parcours de vérification de complétude

Une **question** métier découpée en étapes logiques ; chaque étape pointe l'endpoint qui la réalise. `endpoint: null` = **écart à combler**
(l'endpoint n'existe pas encore) : ce n'est pas une erreur de fichier, c'est le résultat recherché. Vérifié par `tools/journeys.rb` (règles J, §J de `03`).

```yaml
id: apply-to-offer-and-get-result          # R, = nom de fichier
question: Un candidat peut-il postuler ... ?   # R, >= 5 caractères
apps: [candidate, recruitment-portal]      # O : apps traversées
given: [candidate_session]                 # O : données/états disponibles d'emblée
steps:                                     # R
  - id: apply                              # R, unique dans le parcours
    actor: candidate                       # R : id de actors.yml
    intent: Postuler à l'offre             # O
    endpoint: post-candidate-offers-by-offerid-apply   # id d'endpoint ; null/absent = ÉCART ; ou `usecase: <id>` (étape UI/shared)
    gap: Aucun endpoint pour ...           # O (recommandé si endpoint null)
    app: candidate                         # O : app appelante (défaut : app de l'endpoint) — sert aux contraintes calls_app
    after: [see-offer, upload-cv]          # O : défaut = l'étape précédente du tableau ; [] = étape racine
    needs: [offer_id, cv_id]               # O : données requises
    produces: [application_id, application.status=SUBMITTED]   # O : données/états produits
```
Jetons `needs`/`produces` : `nom` (ex. `cv_id`) ou `entité.champ=VAL1|VAL2` (état ; un besoin `=A|B` est satisfait si les valeurs sont produites).
Un jeton `*_id` ou `entité.champ` est confronté aux champs de l'endpoint (J6/J7) ; un jeton sans point ni `_id` (ex. `candidate_session`) est logique, non vérifié.
Branches : plusieurs étapes produisant des états alternatifs. Un parcours cross-app change simplement d'`actor`/d'endpoint d'une app à l'autre.

## 14. `constraints.yml` (O) — cadrage de faisabilité (ce qui est permis / interdit)

```yaml
rules:
  - id: candidate-no-recruiter-api         # R, unique
    scope: { app: candidate }              # R : app, module et/ou feature (tous optionnels, cumulatifs)
    kind: forbid                           # R : forbid | require | limit
    rule: calls_app                        # R : forme vérifiable (liste fermée ci-dessous) ; autre = prose, W
    value: recruitment-portal              # selon la forme
    severity: warn                         # O : warn → W au lieu de E
    # scope accepte aussi method: GET|[GET, POST] pour restreindre la règle à certaines méthodes
    why: Le portail candidat n'appelle jamais ...   # O mais recommandé ; publié dans les OpenAPI (x-constraints / Règles métier) : à rédiger pour un lecteur d'API
```
| `rule` | `value` | Vérifie |
|---|---|---|
| `calls_app` | slug(s) d'app | aucune étape de parcours dont l'app appelante (`scope.app`) appelle un endpoint de ces apps |
| `endpoint_auth` | `none` \| `required` | tous les endpoints de la portée ont ce `auth.type` |
| `actors_only` | liste d'acteurs | les atomic_actions de la portée n'utilisent que ces acteurs |
| `http_method` | liste de méthodes | (avec `forbid`) aucun endpoint de la portée n'utilise ces méthodes |
| `usecase_per_endpoint` | — | chaque endpoint de la portée a un usecase (`openapi.operationId`) |
| `endpoint_absent` | liste d'ids d'endpoints | aucun de ces endpoints n'existe dans la portée (ex. le candidat ne déclenche pas l'analyse IA) |
| `forbid_field` | liste de noms de champs | aucun endpoint de la portée n'accepte ces champs en entrée (chemin, query ou corps) (ex. compétences modifiables après soumission) |
| `response_fields` | map `endpoint-id: [champs]` | la réponse de chaque endpoint cité expose ces champs (`kind: require`) |
| `forbid_response_field` | liste de noms de champs | aucun endpoint de la portée ne renvoie ces champs (ex. clé API, bonnes réponses d'un test, résumé réservé au recruteur) |
| `error_codes` | map `endpoint-id: [codes]` | l'endpoint déclare ces codes d'erreur (ex. règle de validation métier) |
| `endpoint_exists` | liste d'ids d'endpoints | chacun de ces endpoints existe dans les contrats (`kind: require`) ; sert à poser un endpoint cible pas encore écrit |
| `request_fields` | map `endpoint-id: [champs]` | chaque endpoint cité accepte ces champs en entrée (chemin, query ou corps ; `kind: require`) |
| `max_endpoints` | nombre | la portée compte au plus N endpoints |
| `needs_journey` | — | chaque feature de la portée apparaît dans ≥ 1 parcours |

## 15. `enums.yml` (O) — registre d'alignement des énumérations

Un **concept** = un ensemble de valeurs fixes (UPPER_SNAKE_CASE, ou entiers) propre à un contexte (statut de candidature, état d'analyse d'un CV…). Tout champ lié à un concept doit porter **exactement** ces valeurs, quelle que soit l'app, l'endpoint ou le sens (requête, réponse, filtre). Un même nom de champ peut appartenir à des concepts différents selon le contexte (`status` d'une offre ≠ `status` d'une société) : le contexte se déclare par les liaisons.

```yaml
severity: warn                    # O : warn (défaut) | error — gravité des écarts
watch: 'status|type|level'        # O : regex des noms de champs de typologie surveillés (défaut : status, type, level, origin, decision…)
ignore: [content_type, "schema_org.*"]   # O : noms ou chemins de champs hors périmètre
ignore_endpoints: [get-public-site-offers-feed-json]   # O : endpoints hors périmètre
concepts:
  - id: application-status        # R, unique
    description: ...              # O
    values: [SUBMITTED, IN_REVIEW, ACCEPTED, REJECTED]   # R (quoter YES/NO : YAML les lit comme booléens)
    severity: error               # O : surcharge par concept
    bindings:                     # R
      - { endpoint: get-candidate-applications, field: "items.status" }        # égalité stricte avec values
      - { endpoint: get-recruitment-portal-applications-received, field: status, in: query }
      - { endpoint: post-candidate-offers-by-offerid-apply, field: status, subset: true }   # réponse d'action : sous-ensemble admis
```
`endpoint` : id d'endpoint ou glob (`*`, `get-candidate-*`). `field` : chemin pointé sous `data` (réponse) ou corps (requête), ou nom de paramètre de query ; glob admis (`*status`). `in` : `resp` | `req` | `query` (défaut : les trois). `subset: true` : l'enum du champ doit être inclus dans `values` (états initiaux, réponses d'action).
