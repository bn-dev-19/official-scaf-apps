# 03 — Invariants, règles de validation, couverture de mocks

Ces règles décrivent ce que valident `tools/audit.rb` et les outils du kit.
**E** = erreur bloquante, **W** = avertissement (à corriger quand même). `tools/audit.rb` automatise la plupart d'entre elles.

## A. Cohérence inter-fichiers (invariants du projet)

| # | Invariant | Gravité |
|---|---|---|
| A1 | Chaque entrée de `contracts/_index.yml` a son fichier `apps/<app>/<module>/<feature>.yml`, et `slug:` du fichier = nom du fichier | E |
| A2 | Chaque module de `project.parts/_index.yml` a son fichier `modules/<app>.<module>.yml` ; chaque app son `apps/<app>.yml` | E |
| A3 | Les features d'un module sont **identiques** dans `project.parts` et `contracts` (mêmes slugs, mêmes modules, mêmes apps). **Exception : app `api: false`** (`project.parts/apps/<app>.yml`) — aucun contrat attendu ; à l'inverse, une app `api: false` listée dans `contracts/_index.yml` est une erreur. **Exception : feature `internal: true`** (`project.parts/modules/<m>.yml`) — aucun contrat attendu ; à l'inverse, une feature `internal: true` présente dans `contracts` est une erreur. `api` et `internal` doivent être des booléens (B) | E (dérive métier) |
| A4 | `id` d'endpoint unique dans tout le projet ; `spec.endpoint.id` = `mocks.endpoint` = `id` | E |
| A5 | `endpoint.method`/`path` = `spec.http.method`/`spec.http.path` | E |
| A6 | `usecase.openapi.operationId` référence un `id` d'endpoint existant | E |
| A7 | `atomic_actions[].actor` ∈ ids de `actors.yml` | W |
| A8 | `dependencies` ∈ slugs de modules existants ; pas de cycle (détection DFS) | E |
| A9 | `module.app` ∈ slugs de `apps` | W |
| A10 | Tout endpoint a son fichier `openapi.parts/<app>/<module>/<feature>/<id>.yml` (sinon régénérer) | W |
| A11 | Nom de fichier usecase = `<id>.usecase.yml` | E |
| A13 | `rls` d'une table du visuel (PostgreSQL) : objet avec `enabled` booléen ; `owner` = colonnes existantes ; `admin` = rôles (chaînes) ; `policies` : `name` + `using`/`withCheck`, `for` ∈ select\|insert\|update\|delete\|all, noms uniques ; `enabled` sans owner/admin/policies refusé ; W si table `external` (non-PostgreSQL : W émis par `visual_to_sql.rb`, `rls` ignoré) | E |
| A12 | Table d'un `_visual_<module>.yml` : toute colonne `type: enum` a un `enumRef` existant dans `_visual_enums.yml` ; type de colonne connu ; `references.onDelete/onUpdate` valides (`set null` ⇒ `nullable: true`) ; table `external` avec colonne `primary` ; `kind` obligatoire (sauf `external`) ∈ entity\|pivot\|internal\|audit ; index : `columns` ou `expressions` non vides, `method` ∈ btree\|hash\|gin\|gist\|brin (pas `unique` avec gin/gist/brin), `where` non vide ; `checks` : `name` + `expression`, noms uniques | E |
| A13 | Un endpoint ne s'appelle pas comme sa feature (collision `<feature>/<feature>.yml` dans `openapi.parts`) | E |

## B. Règles `project.parts` (validate-project-format)

- `info`: `name`, `version`, `description` ≥ 3 caractères (E).
- App : `name` ≥ 2, `slug` valide et unique, `description` ≥ 2 (E) ; description < 15 caractères (W) ; `seo.baseUrl` = URL `http`/`https` valide (E) ; `seo.*` doit être un objet de chaînes.
- Acteur : `id` slug unique, `type` ∈ {human, machine, program, external, data} (E).
- Module : `name`, `slug`, `description` ≥ 2 ; slug valide et unique ; `features` est un tableau ; description < 15 (W).
- Feature : `name`, `slug`, `description` ≥ 2 ; slug unique dans le module ; `atomic_actions` absent/vide (W) ; chaque action : `name` ≥ 3.
- `more`, `explication` : chaînes si présents.

## C. Règles use case (validate-usecase-format)

- `name` ≥ 2 et **unique** ; `type` obligatoire ∈ {producer, consumer, shared} et le fichier est dans `usecases/<type>/<app>/` (`<app>` ∈ apps du projet, = app du contrat si `openapi`) ; `description` ≥ 5.
- `id` : kebab-case (W si non conforme).
- `input` et `output` : objet avec `schema` (map de champs, chacun un objet). Champ : `type` connu (sinon W), `required`/`nullable` booléens,
  `minLength`/`maxLength`/`minimum`/`maximum`/`minItems`/`maxItems` nombres, **toute contrainte déclarée = VALIDATION_ERROR** (NestJS la fait respecter par les DTO) : une règle qui doit renvoyer un code métier dédié (ex. WEAK_PASSWORD) ne se déclare pas sur le champ (W d'audit si un mock d'erreur dédiée la viole), `enum` = liste de chaînes, `object` sans `properties` (W).
- `steps` : tableau ; chaque step a `code` (chaîne) et `order` (nombre) ; `severity` ∈ {critical, high, medium, low}.
- `errors` : tableau (W si absent) ; chaque erreur : `code`, `status` (nombre), `description` (W si absente).
- `openapi` (si présent) : `operationId`, `method` ∈ {GET, POST, PUT, PATCH, DELETE}, `path` commençant par `/`.
- `intent` (si présent) : `purpose` ≥ 10 ; `actors[]` ∈ ids de `actors.yml` ; `tables[]` : `table` ∈ tables de `database/visual/` (E), `access` ∈ {read, write} (E), `why` optionnel (texte non vide si présent, E), doublon (W) ; `depends_on[]` : `when` ∈ {before, during, after}, `why` requis, `endpoint` (id de contrat existant) ou `usecase` (existant). `actors.yml` absent/vide = E. **Cohérence de l'intent avec le projet** : E si cycle de `depends_on` en `before` ; W si `depends_on` s'auto-référence ou cible une autre app ; W si `intent.actors` n'a aucun acteur dont `guards` (champ optionnel de `actors.yml`, ex. `[RequireAdmin]`) contient la garde du contrat ; W si une valeur MAJUSCULE (≥ 4 car.) citée dans l'intent n'apparaît dans aucun contrat, enum, DB visuelle ou journey (faute de frappe ou valeur inventée). **Usecase producer ↔ contrat** : W si les champs de premier niveau de `input.schema` diffèrent de ceux de la requête du contrat (paramètres de chemin + query + propriétés du body), ou ceux de `output.schema` (hors `pagination`) de `response.body.data.properties` — le contrat fait foi, le générateur n'utilise que lui. **Couverture consommateur** : dès qu'une app a un usecase `consumer`, chaque endpoint de cette app doit avoir le sien (`usecases/consumer/<app>/consume-<operationId>.usecase.yml`), sinon W. **Intent manquant** (usecase producer avec `openapi` sans `intent`, ou endpoint de contrat sans usecase) = **W sévère, non bloquant** : l'audit ajoute « ⚠ N endpoint(s) sans intent » à sa synthèse et le guide liste ces endpoints en tête de son README.
- `calls[]` : `usecase` requis, `mode` ∈ `sync|event` (E sinon), `after` = code de step du usecase (E sinon), pas de cycle d'appels `sync` (E), cible `event` non producer (W) ; usecase interne (sans `openapi`, avec `feature`) sans `intent.purpose` (W). `links[]` : `rel` et `usecase` requis. `trigger` : une seule clé parmi `cron|queue|event|command` (valeur non vide, cron 5-6 champs, queue kebab-case, event `domaine.action`), jamais avec `openapi`, `feature` requis (E) ; usecase interne d'une app `api: false` sans `trigger` ni `calls` entrant (W).
- Couverture : un use case `producer` est « couvert » si `METHOD path` existe tel quel dans les contrats ; sans `openapi`, par repli si un chemin contient le slug du nom.
  Les `consumer`/`shared` sont exclus du calcul de trous. → **mettre le chemin complet avec `/v1`** dans `openapi.path`.

## D. Règles contrats (validate-contracts)

Endpoint :
- `id` présent et unique (E) ; `name` présent (W) ; `path` commence par `/` (E) ; préfixe de version `^/(api/)?v\d+/` (W) ; `method` valide (E).
- `spec` non vide (W) ; YAML valide (E) ; doit contenir `http` (ou `responses`) (E) ; `http.response` présent (E) ; `http.response.status` numérique (W).
- `mocks` non vides (W) ; JSON (ou YAML) valide (E) ; tableau `mocks` (ou `scenarios`) non vide (W).
- Chaque mock : objet, `name` (W), `expect` (E), `expect.status` ∈ [100,599] (E), **présent dans la spec** (W) :
  codes autorisés = `response.status` + chaque `errors[].status`.
- Mock d'erreur (`status ≥ 400`) : `expect.body.error.code` doit exister dans `errors[]` avec le **même status** (W) ;
  `expect.body.error.message` non vide (W).
- Aucun mock (W) ; moins de mocks que recommandé (W, voir §F).
- Feature sans endpoint, module sans feature (W). Pour une app `api: false`, une feature sans contrat est normale ; un usecase `feature:` doit désigner un `<module>/<feature>` existant de l'app (E) ; usecase sans `openapi` ni `feature:` : W (non rattaché, ignoré par L4).

## E. Format de réponse (validate-response-format)

Détecte (et l'app sait réparer automatiquement) :

| Problème | Définition |
|---|---|
| `missing-response-body` | `http.response.body` absent |
| `not-api-response` | `body.properties` ne contient pas `data` ; ou un mock n'a ni `success`+`error` ni `data` |
| `double-nested-data` | `data.data` (spec : `properties.data.properties.data` ; mock : `body.data.data`) |
| `error-in-data-wrapper` | `{success, data:{error:{...}}}` au lieu de `{success:false, error:{...}}` |

Forme canonique du succès : `{ "success": true, "message": "<texte>", "data": <payload> }`
(`message` par défaut selon méthode : GET « Récupération réussie », POST « Création réussie », PUT/PATCH « Mise à jour réussie », DELETE « Suppression réussie »).
Forme canonique de l'erreur : `{ "success": false, "message": "...", "error": { "code", "message", "cause?", "resolution?" } }`.
Enveloppe complète : `{ success, message, data, pagination?, warnings? }` — `data` peut être `null` selon l'endpoint ; `pagination` et `warnings` sont **hors `data`**.
Listes : tableaux sous des clés nommées dans `data` (ex. `data.offers`). Si paginée : `pagination: { current_page, page_size, total_items, total_pages }` (snake_case, entiers ; requête : `page`, `page_size`). `warnings` : tableau de `{ title, description, tips[] }`. Audit : `pagination-in-data`, `pagination-shape`, `pagination-consistency` (total_pages = ceil(total_items/page_size), sauf liste vide : 0 ou 1 page tolérée (helper de pagination commun), éléments ≤ page_size, page/page_size = query du mock), `warnings-shape`, `query-snake-case`, `query-sans-400` (un GET avec paramètres de query déclare un 400 ou 422).

## F. Mocks : nommage et couverture

Noms générés (et à respecter pour les mocks écrits à la main) :

| Catégorie | Nom | Rôle |
|---|---|---|
| nominal | `nominal-<status>` (ex. `nominal-200`, `nominal-201`) ; variantes libres `nominal-empty`, `nominal-multiple` | cas de succès |
| error | `error-<code en minuscules>` (ex. `error-unauthorized`, `error-not_found`) | un par entrée de `errors[]` |
| enum | `enum-<chemin.champ joint par ->-<VALEUR>` | une valeur d'enum par mock |
| nullable | `nullable-<combinaison>` | champs nullables à `null` |
| boolean | `boolean-<champ>-<true\|false>` | les deux états |
| empty | `empty-arrays` | tous les tableaux vides |
| critical | `critical-all-edge-cases` | combinaison extrême : nullables null, booléens false, dernier enum, tableaux vides |
| custom | libre (ex. `low-confidence`) | cas métier |

Mocks recommandés par endpoint (`mock-coverage-calculator`) :

```
recommandés = nb_status            # response.status + errors[].status distincts
            + max(1, Σ valeurs d'enum dans request.body)
            + (n_nullable > 0 ? min(2^n_nullable, 8) : 0)   # n_nullable = champs nullable:true ou required:false de la réponse
            + (réponse tableau/liste ? 1 : 0)               # empty-arrays
            + 1                                             # critical-all-edge-cases
couverture % = round(100 × nb_mocks_existants / recommandés)
```

## G. Conventions de contenu

- **Descriptions en français** ; messages d'erreur actionnables : `message` (court, exposé), `cause` (pourquoi), `resolution` (que faire).
- Erreurs standard à envisager selon le contexte : 400 `VALIDATION_ERROR`, 401 `UNAUTHORIZED`, 403 `FORBIDDEN`, 404 `NOT_FOUND`,
  409 `CONFLICT`, 422, 429 `RATE_LIMITED`, 500 `INTERNAL_SERVER_ERROR`. Un endpoint authentifié a au minimum 401 + 500.
- Données de mock réalistes et **cohérentes** (mêmes UUID entre `given.path` et `expect.body.data`), dates ISO 8601 (`2026-08-15T10:24:37Z`).
- Jetons de mock : un `Authorization: Bearer <jwt-factice>` suffit ; ne jamais mettre de vrai secret.
- Granularité des endpoints : `use-case` (défaut ; un endpoint par cas d'usage métier, regroupe des atomic actions) ou
  `atomic` (un endpoint par action CRUD). Rester homogène dans un module.
- YAML : indentation 2 espaces dans `spec` (le backend réécrit le reste avec 4) ; valeurs contenant `: ` entre guillemets.
- Ne jamais éditer `openapi.parts/`, ni `coverage:` à la main.

## GI. Guide d'implémentation dérivé — `tools/intent_to_md.rb --check`

`output/implementation-guide/` est entièrement dérivé des usecases (jamais édité à la main). `audit.rb` régénère le guide **en mémoire** (aucune écriture) et le compare au disque, seulement si le dossier existe :

| Règle | Contrôle | Sév. |
|---|---|---|
| GI1 | page absente, différente de la régénération (périmée : usecase modifié sans relancer `intent_to_md.rb`, ou éditée à la main) ou page orpheline (aucun usecase ne la produit) | W |

Correction : relancer `ruby scaf/_agent-kit/tools/intent_to_md.rb scaf/<version>` (écrase tout le dossier).

## J. Parcours (`journeys/`) — `tools/journeys.rb`

| # | Règle | Gravité |
|---|---|---|
| J1 | parcours valide : `id` = fichier, `question`, étapes à ids uniques, `after` connus, pas de cycle | E |
| J2 | `endpoint` renseigné ⇒ existe dans `contracts` ; `usecase` ⇒ existe | E |
| J3 | `endpoint` null/absent = **écart** (rapporté, jamais une erreur) ; W si `gap:` non renseigné | info / W |
| J4 | acteur ∈ `actors.yml` et présent dans les atomic_actions de l'app de l'endpoint | W |
| J5 | chaque `needs` est produit par une étape antérieure (ou `given`) | W |
| J6 | paramètres de chemin `*_id` fournis par une étape antérieure ; champs `produces` exposés par l'endpoint | W |
| J7 | état échangé entre deux apps : l'endpoint consommateur l'expose ou l'accepte | W |
| J8 | étape dépendant d'une étape-écart = **bloquée** (propagation, rapport) | info |

## K. Contraintes (`constraints.yml`)

K1 : `kind` ∈ {forbid, require, limit} (E) ; forme `rule` inconnue = prose non vérifiée (W) ; portée vide (W).
K : violation d'une forme vérifiable (voir `02-file-formats.md §14`) = E, ou W si `severity: warn`.

Rapport : `ruby scaf/_agent-kit/tools/journeys.rb scaf/<v> [--md rapport.md]` — par parcours (étapes OK / écart / bloquée),
complétude par app, endpoints hors parcours. `audit.rb` en inclut les lignes E/W.

## EC. Configs d'export Next.js (`nextjs*.json`) — `tools/export_configs.rb`

| # | Règle | Gravité |
|---|---|---|
| EC0 | JSON valide ; `technology` = préfixe du nom de fichier (technologie connue : `nextjs`) ; `config` objet | E |
| EC1 | valeur d'enum hors des valeurs d'enum du kit (`architecture`, `apiLayer`, `auth`, `orm`, …) | E |
| EC2 | champ requis absent (`projectName, seo, packageManager, architecture, auth, apiLayer, styling`) ou mauvais type ; clé inconnue | E / W |
| EC3 | override : `app` absente de `project.parts`, champ `app` ≠ nom de fichier, `projectName` présent, clé inconnue, base absente | E |
| EC4 | `pushNotifications.enabled` sans `pwa` ; `i18n` sans `i18nLanguages` ou `seo.defaultLocale` ∉ langues ; `font: custom` sans `customFontPath` | E |
| EC5 | `$var:X` absent de `contracts/variables.yml` ; `customFontPath` absolu | E |
| EC5 | clé VAPID en clair ; variable référencée non `sensitive` | W |
| EC6 | `orm`/`database` ≠ `none` alors que le front consomme l'API scaf | W |
| EC8 | `session` (jetons de session, `auth: custom_jwt`) : objet `{endpoints, logout, refresh}` ; `refresh` = `{endpoint, bodyField, accessToken}` (+ `refreshToken`, `expiresIn` optionnels, chaînes) ; chaque `endpoints.<id>` est un objet avec `accessToken` (chemin pointé, ex. `data.access_token`) obligatoire, `refreshToken`/`expiresIn` optionnels, tous des chaînes ; `logout` = liste d'ids | E |
| EC8 | `session` renseigné alors que `auth` ≠ `custom_jwt` (ignoré) ; `refreshToken` stocké sans `session.refresh` (jamais utilisé) | W |
| EC9 | `session` confrontée aux contrats (`custom_jwt`) : endpoint (`endpoints`, `logout`, `refresh.endpoint`) absent des contrats ; chemin de jeton absent de `response.body` de l'endpoint ou de mauvais type (`accessToken`/`refreshToken` string, `expiresIn` integer/number) ; `refresh.bodyField` absent du corps de la requête | E |
| EC9 | chemin de jeton présent dans les mocks mais pas dans le schéma de réponse (le déclarer dans le contrat) | W |

La base est validée seule ; chaque override l'est fusionné sur la base (un écart hérité n'est pas répété). Config effective : `export_configs.rb scaf/<v> --resolve <techno> <app>` (nextjs, nestjs).

## NS. Configs d'export NestJS (`nestjs*.json`) — `tools/export_configs.rb`

Mêmes principes que EC (base validée seule, override validé fusionné sur la base) ; numérotation propre à nestjs :

| # | Règle | Gravité |
|---|---|---|
| NS0 | JSON valide ; `technology` = `nestjs` ; `config` objet | E |
| NS1 | valeur d'enum hors liste (`orm`, `auth`, `architecture`, `authPlugins[]`…) | E |
| NS2 | champ requis absent (`projectName, packageManager, orm, database, auth, architecture`) ou mauvais type ; clé inconnue | E / W |
| NS3 | override : app absente de `project.parts`, champ `app` ≠ nom de fichier, `projectName` présent, clé inconnue, base absente | E |
| NS4 | `auth: better_auth` sans `bodyParser: false` ou avec `orm: none` ; `authPlugins` sans `better_auth` ; `orm` sans `database` ; `prisma`/`typeorm` sans `database` ; `drizzle` sans `migrations: drizzle_kit` ; `generator.level` hors `N0|N1|N2`, ou `N2` avec `orm: none` ; `port` hors 1–65535 ; `authUserTable` sans better_auth+(drizzle|prisma) (typeorm refusé) ; `authUserFields`/`authDefaultRole` sans `authUserTable` (`authDefaultRole` : plugin `admin` requis) ; `rls: session` sans `authUserTable` | E |
| NS8 | `globalPrefix` ni vide ni segment simple (ex. `api`) ; `versioning` ∉ `none\|uri\|header` ; le générateur échoue si un chemin de contrat ne commence pas par `/<globalPrefix>/` (puis `/v<version>/` en `uri` ou `header` (version libre : `v1`, `v1-beta`…)) | E |
| NS10 | `moduleLayout` invalide : `layers` hors {application, domain, infrastructure, presentation} ou `domainDirs` non kebab-case / en double | E |
| NS13 | `srcDir: false` dans `nestjs.json` (Nest vit sous `src/` : nest-cli, tsconfig, jest) | E |
| NS9 | `swagger.path` ≠ chemin de segments simples (`docs`, `docs/admin`), ou `swagger.type` ∉ `ui`/`scalar`/`redoc` | E |
| NS11 | `rateLimiting` objet invalide : clé hors `default\|endpoints`, `limit` non entier ≥ 1, `ttlMs` non entier ≥ 1000, ou id d'endpoint absent des contrats | E |
| NS12 | `auth: better_auth` avec `emailVerification: true` sans `mailer` (`resend`\|`smtp`\|`nodemailer`) : aucun e-mail de vérification envoyé, connexion refusée `EMAIL_NOT_VERIFIED` (sauf `sendVerificationEmail` écrit à la main) | W |
| NS5 | `$var:X` (`databaseUrl`, `authSecret`, `authBaseUrl`) absent de `contracts/variables.yml` | E |
| NS5 | secret en clair ; variable secrète non `sensitive` ; `cors.credentials` avec origine `*` | W |
| NS6 | `orm: drizzle|prisma|typeorm` sans `database/visual` (le schéma dérive de `visual_to_sql.rb`) ; `responseEnvelope: false` (viole l'enveloppe uniforme) ; `database/visual` présent avec `database` ∉ {postgresql, mysql, sqlite} ou `orm: mongoose` (non généré : drizzle, prisma et typeorm seulement) | W |

## EN. Énumérations (`enums.yml`) — `tools/enums.rb`

| # | Règle | Gravité |
|---|---|---|
| EN0 | concept valide : `values` non vides, UPPER_SNAKE_CASE ou entiers | E |
| EN1 | tout champ lié à un concept porte exactement ses valeurs (`subset: true` : inclus) ; un champ lié sans `enum` (chaîne libre) est un écart | `severity` (W par défaut) |
| EN2 | une liaison qui ne correspond à aucun champ (faute de chemin ou endpoint disparu) | W |
| EN3 | champ de typologie (`status`, `type`, `level`, `origin`…) hors de tout concept : chaîne libre, ou plusieurs ensembles de valeurs distincts sous un même nom | W |
| EN4 | champ `string` libre (hors `watch`) dont tous les mocks sont des valeurs fixes MAJUSCULES (≤ 12) : enum probable, à déclarer dans la spec et dans un concept (sinon l'ajouter à `ignore`) | W |

Principe : un même concept = les mêmes valeurs dans toutes les apps. Deux contextes distincts (ex. état d'analyse global d'un CV et état d'un matching pour une offre) sont deux concepts, même s'ils ont aujourd'hui les mêmes valeurs. Rapport détaillé : `ruby scaf/_agent-kit/tools/enums.rb scaf/<v> [--verbose]` ; `audit.rb` en reprend une ligne par concept.

## OA. Génération OpenAPI (`tools/contracts_to_openapi.rb`) — règles que les contrats doivent respecter

Procédure : `skills/scaf-generate-openapi.md`.

Le générateur (voir `04-tooling-map.md`) lit les contrats et **valide chaque mock 2xx contre le schema de sa spec**. Pour 0 E / 0 W :

| Règle | Détail |
|---|---|
| Mocks = examples | 1 mock = 1 example ; E si les nombres diffèrent. Id d'endpoint et couple `METHOD path` uniques (E sinon). |
| **Réponse : tous les champs sont `required`** | Le contrat ne porte pas `required` côté réponse : le générateur rend **tous** les champs requis, `nullable` compris. Donc **chaque mock 2xx contient chaque champ de la spec** ; un champ `nullable` absent de la donnée vaut `null` (pas omis). Un champ vraiment optionnel n'existe pas : le déclarer `nullable: true` et mettre `null`. |
| `nullable` | Un mock ne peut mettre `null` que sur un champ `nullable: true` (sinon W). Ex. `end_date` d'un poste en cours, `resolved_at` d'une alerte non résolue. |
| Clés exactes | Les clés d'un mock sont **exactement** celles de la spec, même casse (W « clé non déclarée » : `RESOLVED`, `LINKEDIN`, `REMOTE`, `companyId`… sont des erreurs). |
| `date-iso` | Format de contrat unique pour dates et date-times. Le générateur le convertit d'après les valeurs des mocks : toutes en `AAAA-MM-JJ` → `date` ; toutes en horodatage → `date-time` ; **mélange → W et format omis**. Garder un seul format par champ, dans tous les mocks. |
| Autres formats | `url` → `uri`, `ip` → `ipv4` ; `uuid`, `email`, `float`… passent tels quels. Un mock doit respecter `uuid` / `date` / `date-time` / `enum` / type. |
| Erreurs | Schéma d'erreur généré : `{success:false, message, error{code,message,cause,resolution}}`, `code` en enum des codes déclarés ; W si un mock d'erreur porte un code non déclaré dans `errors`, ou un statut sans erreur déclarée. |
| Exemples de requête | `requestBody.examples` = `given.body` des mocks **valides** : sont écartés les mocks `error-invalid*` / `error-validation*` (requête invalide voulue) et les gabarits de volume (`"<501 lignes>"`) ; upload `format: binary` → l'exemple porte le `filename` du fichier. Un exemple de requête qui ne respecte pas le schema est écarté avec un W. Les réponses d'erreur de ces mocks restent des examples de réponse. |
| Sécurité / enums | Endpoint public → `security: []` ; `enum` d'un tableau déplacé sur `items` ; champ `nullable` avec `enum` → `null` ajouté à `enum` (OpenAPI 3.0.3). Contrôle externe : `npx @redocly/cli lint` (0 erreur attendue). |
| Noms de composants | Un sous-schéma objet répété ≥ 3 fois devient `components.schemas.<Nom>` : `title:` du schéma si présent, sinon ressource de l'endpoint pour une clé générique (`data` → `Offer`). Pour des réponses d'une même ressource (créer / lire / modifier), **mettre le même `title` PascalCase singulier** (`Offer`, `Appointment`) : pas de `Data2`, et une seule forme garantie. W « collision, suffixé » = donner un `title:` distinct. |
| Concepts d'enums | La `description` du concept (`enums.yml`) est ajoutée à celle des champs liés (réponse, corps, query) ; la doc `--doc` affiche les valeurs (`null` inclus). |
| Contraintes | `constraints.yml` → `x-constraints` sur l'opération (règles ciblées : map par id d'endpoint, portée `feature` ou `module`+`method`) et section « Règles métier » avec `--doc` ; règles de portée app / module → `info.description` de l'app. Le `why` est publié : le rédiger pour un lecteur d'API. |
| Chemin | Tout `{param}` du `path` doit être déclaré dans `request.path` (W sinon). |
| Dossiers | Sortie `scaf/<version>/output/openapi/` (sous `output/`, non lu comme source). `openapi.parts/` est **réécrit** à chaque lancement (dossier de l'app recréé). |

## MK. Cohérence des mocks avec la spec — `tools/check_mocks.rb`

Contrôle champ par champ de **tous** les mocks (succès, erreurs, requêtes). Procédure : `skills/scaf-check-mocks.md`. Tous les constats sont des `E` sauf mention `W`.

| Règle | Contrôle |
|---|---|
| M1 | Réponse de succès : type, format (`uuid`, `date-iso`, `email`, `url`), `nullable`, **tous les champs présents**, aucune clé non déclarée, `success: true`, `message` string. |
| M2 | Réponse d'erreur : `success: false` + objet `error` ; `error.code` déclaré **pour ce statut** ; `error.message/cause/resolution` **identiques** à la spec ; `message` racine = `error.message` ; pas d'autre clé racine ; nom du mock `error-<code en minuscules>[-N]` (`W`). |
| M3 | Requête `given` : `query`, `path` (valeurs extraites du chemin concret) et `body` contre `request.*` : type, format, enum, clés inconnues, champs `required: true` présents, corps non fourni si la spec n'en déclare pas (`{}` toléré). Les mocks `error-invalid*` / `error-validation*` sont **exemptés** (valeur de requête invalide voulue). Upload `format: binary` : métadonnées `{filename, content_type, size}` acceptées. Gabarit de volume `"<501 lignes>"` accepté à la place d'un objet de requête. |
| M4 | **Enums, référence = le `enum:` du champ dans la spec (pas `enums.yml`)** : toute valeur d'un mock (réponse, erreur, requête, query, path) portée par un champ à `enum:` doit en faire partie, casse comprise ; un champ de typologie (`watch` de `enums.yml`) à valeurs MAJUSCULES sans `enum:` dans la spec est une erreur ; un mock nommé `enum-<chemin>-<VALEUR>` doit contenir cette valeur à ce chemin (`W` si le nom ne désigne aucun champ enum) ; pour un champ **dans un tableau** (ou un tableau portant l'`enum:`), un mock groupé `enum-<chemin avec *>-ALL` suffit : chaque élément du tableau porte une valeur différente (E s'il ne contient aucune valeur) ; une valeur d'enum de réponse jamais couverte par un mock (simple, ou via un mock groupé) est un `W`. Les enums à valeurs entières (`level: [1..7]`) sont comparés en texte. |

`enums.rb` vérifie en plus l'alignement des `enum:` de spec avec `enums.yml` (autre périmètre).

## H. Comportements du backend à connaître avant d'éditer à la main

1. **Orphelins supprimés** : à chaque enregistrement via l'app, tout fichier de `contracts/apps/**`, `project.parts/apps|modules/**`, `openapi.parts/**` non référencé par le payload est effacé, puis les dossiers vides aussi.
2. **Index en dernier** : l'écriture est parts → index (sûr en cas de crash). Reproduire cet ordre.
3. **`writeFileIfChanged`** : pas de réécriture si contenu identique (hash) → pas de bruit dans git ; ne pas reformater.
4. Lecture : si `contracts/_index.yml` (ou `project.parts/_index.yml`) existe → layout éclaté, sinon repli sur les fichiers monolithiques legacy.
5. Fichier module projet : `__noapp__.<module>.yml` si `app` vide.
6. La détection de version utilise `.scaf-version`, sinon le dernier dossier `v*`.

## DG. Génération base de données (`tools/visual_to_sql.rb`)

Procédure : `skills/scaf-database-visual.md` §Générer. Sortie dérivée : `<version>/output/database/<dialect>/` + `docs/` (jamais éditée à la main) ; le SQL est partitionné (`sql/00_enums` → `10_<module>` → `99_foreign_keys`) et commenté (doc partitionnée dans `docs/` ; `COMMENT ON` = `description` du visuel : une description vide ou manquante donne un commentaire vide, la renseigner).

| Règle | Contrôle | Sévérité |
|---|---|---|
| Toute colonne `type: enum` a un `enumRef` présent dans `_visual_enums.yml` | outil | E |
| Toute `references: {table, column}` vise une table et une colonne existantes (tous modules confondus) | outil | E |
| Tout index porte sur des colonnes existantes de sa table | outil | E |
| Noms de table uniques sur tous les modules ; types limités à `uuid text varchar(n) integer bigint decimal boolean datetime date jsonb enum` | outil | E |
| Le visuel est régénéré (SQL/Drizzle/doc) après chaque modification de `database/visual/` ou d'un champ persistant d'un contrat | revue | — |
