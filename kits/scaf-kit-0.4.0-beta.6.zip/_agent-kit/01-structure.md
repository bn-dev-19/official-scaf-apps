# 01 — Structure des dossiers et nommage

## Arbre complet (état réel de `scaf/`)

```
scaf/
├── .scaf-version                 # texte brut : nom du dossier de version actif, ex. "v1" (voir « Fichiers racine »)
├── _agent-kit/                   # ce kit (ignoré par l'outillage)
│   └── .scaf-kit                 #   état du KIT (YAML : version, développeur, lien…) — pas la version du projet
├── redocly.yaml                  # config du lint Redocly des OpenAPI générées (voir « Fichiers racine »)
├── v1/                           # UNE VERSION = un snapshot complet
│   └── input/
│       ├── project.parts/        # ── description métier ──────────── SOURCE
│       │   ├── _index.yml        #    ordre apps→modules (+ ordre global des modules)
│       │   ├── info.yml          #    name / version / description du projet
│       │   ├── actors.yml        #    liste des acteurs (tableau YAML) — OBLIGATOIRE (référencé par atomic_actions, journeys, intent.actors)
│       │   ├── apps/<app>.yml            # métadonnées d'une app (+ seo)
│       │   └── modules/<app>.<module>.yml  # un module + ses features + atomic_actions
│       ├── usecases/             # ── flux métier ───────────────────── SOURCE
│       │   └── <producer|consumer|shared>/<app>/<usecase-id>.usecase.yml   # un fichier par use case : dossier = `type`, puis app
│       ├── contracts/            # ── contrats d'API ─────────────────── SOURCE
│       │   ├── _index.yml        #    ordre apps→modules→features (+ label d'app)
│       │   ├── servers.yml       #    serveurs (url, description)
│       │   ├── variables.yml     #    (optionnel) variables {key,value,sensitive?}
│       │   ├── granularity.yml   #    (optionnel) granularité use-case|atomic + overrides par module
│       │   └── apps/<app>/<module>/<feature>.yml   # endpoints : spec(YAML) + mocks(JSON)
│       ├── database/visual/      # ── modèle de données ─────────────── SOURCE
│       │   ├── _visual_<module>.yml        # tables d'un module (stockage : peut dépasser les contrats)
│       │   └── _visual_enums.yml           # tous les enums SQL
│       ├── export-configs/       # ── config de génération de l'app cible ─ SOURCE
│       │   ├── <technologie>.json          # base commune, ex. nextjs.json
│       │   └── <technologie>.<app>.json    # override partiel d'une app (optionnel), ex. nextjs.admin.json
│       ├── openapi.parts/        # ── OpenAPI éclaté ──────────────────── DÉRIVÉ
│       │   ├── _index.yml        #    (info.yml optionnel : openapi/info/servers/security/components)
│       │   └── <app>/<app>.yml
│       │       <app>/<module>/<module>.yml
│       │       <app>/<module>/<feature>/<feature>.yml
│       │       <app>/<module>/<feature>/<endpoint-id>.yml
│       ├── journeys/             # ── parcours de complétude ───────── SOURCE (optionnel)
│       │   └── <id>.journey.yml
│       ├── constraints.yml       # ── contraintes de faisabilité ───── SOURCE (optionnel)
│       ├── enums.yml             # ── registre d'alignement des enums ─ SOURCE (optionnel)
│       ├── tickets/              # (optionnel, créé à la demande)  <id>.ticket.yml + actors.yml
│       ├── scenarios/            # (optionnel) *.scn.yml pour le runner de scénarios
│       └── isolated-nodes/       # (optionnel) nœuds isolés
│   └── output/                   # (optionnel) résultats : test-scenarios/ etc.
└── v1-beta/                      # version antérieure/forkée (même arbre)
```

Fichiers **legacy** (lus seulement en repli si le layout éclaté n'existe pas, jamais réécrits) :
`input/project.yml`, `input/contracts/contracts.yml`, `input/openapi.yml`. Ne pas en créer.

## Fichiers racine de `scaf/` (état et config de projet, hors kit)

Ils restent à `scaf/` et ne sont **pas** dans `_agent-kit/` : le kit est de l'outillage réutilisable, ces fichiers décrivent un projet (et les outils lisent `scaf/.scaf-version`).

- `.scaf-version` : texte brut, nom du dossier de version active (ex. `v0`, retour ligne facultatif). Écrit par fork/activation ; sans lui, l'outillage prend le dernier `v*` par ordre alphabétique.
- `_agent-kit/templates/agents-block.md` + `INSTALL.md` : bloc d'instructions à copier dans `AGENTS.md`/`CLAUDE.md` du projet (marqueurs `scaf-kit:begin/end`, remplaçable) et sa procédure.
- `redocly.yaml` : config du lint des OpenAPI générées (`extends: recommended`, `no-server-example.com: off` car `servers.yml` garde localhost/example.com). Redocly ne le lit que dans le dossier courant : `npx @redocly/cli lint --config scaf/redocly.yaml …` depuis la racine du dépôt. Gabarit pour un nouveau projet : [`templates/redocly.yaml`](templates/redocly.yaml) (à copier en `scaf/redocly.yaml`).

### Fichier racine du kit : `_agent-kit/.scaf-kit`

État **du kit lui-même**, distinct de `scaf/.scaf-version` (version active du **projet**). YAML plat : `name`, `version` (semver), `developer`, `repository` (dépôt GitHub source du kit), `homepage` (site), `download_url` (page du kit sur le site : liste de ses archives versionnées, téléchargeables directement) ; d'autres clés peuvent s'ajouter (licence, changelog…). Clés vides = à renseigner, ne pas les inventer. `version` se bumpe quand le kit change : patch = correction de doc/outil ; minor = nouvelle règle, outil ou section de format ; major = format de fichiers incompatible avec les projets existants.

## Versions

- Une version = tout dossier de `scaf/` dont le nom **commence par `v`** et qui contient `input/`.
- Active = contenu de `scaf/.scaf-version` ; à défaut, le dernier par ordre alphabétique.
- **Fork** = copie récursive `vA → vB` + écriture de `vB` dans `.scaf-version` (la cible ne doit pas exister).
- **Suppression** : impossible sur la version active.
- Procédure manuelle : voir [`skills/scaf-version-fork.md`](skills/scaf-version-fork.md).

## Règles de nommage (exhaustif)

| Élément | Règle | Exemple |
|---|---|---|
| slug app / module / feature / acteur | `^[a-z][a-z0-9_-]*$`, unique dans son niveau (feature : unique dans le module ; module : unique global) | `cv-ai-analysis` |
| fichier module projet | `<app-slug>.<module-slug>.yml` ; module sans app → `__noapp__.<module>.yml` | `candidate.cv-ai-analysis.yml` |
| fichier app projet | `<app-slug>.yml` | `candidate.yml` |
| fichier feature contrat | `contracts/apps/<app>/<module>/<feature>.yml` | `.../cv-ai-analysis/initial-matching.yml` |
| id d'endpoint | kebab-case, unique **globalement**, ≠ slug de sa feature (collision de fichier dans `openapi.parts`). Convention : `<méthode>-<chemin sans /api ni /vN>` ; `{x_y}` → `by-xy` | `get-candidate-ia-match-by-cvid-offers` |
| fichier use case | `usecases/<type>/<app>/<id>.usecase.yml` (`<type>` = `producer`, `consumer` ou `shared`, égal au champ `type` ; `<app>` = slug d'app, égal à l'app du contrat relié par `operationId`), `id` kebab-case (filtre : minuscules, tout caractère hors `[a-z0-9_-]` → `-`) | `usecases/producer/candidate/login-candidate.usecase.yml` |
| fichier visuel DB | `_visual_<nom-module>.yml` (nom = slug du module de contrat) ; enums : `_visual_enums.yml` | `_visual_cv-ai-analysis.yml` |
| nom d'enum SQL | `<table>_<colonne>` | `extracts_extraction_status` |
| fichier ticket | `<id>.ticket.yml` | |
| fichiers OpenAPI part | voir arbre ci-dessus ; le fichier endpoint porte l'**id** de l'endpoint | `get-candidate-ia-match-history.yml` |
| tag OpenAPI | `app / module / feature` (séparateur ` / `) | `candidate / cv-ai-analysis / initial-matching` |

Slug d'app ≠ `label` d'app dans `contracts/_index.yml` : `label` est un libellé libre
(ex. app `public-site` → label `careers-portal`, app `administration` → `admin-portal`).

## Fichiers d'index : rôle et règles

Trois index, tous avec `version: 1`. Ils fixent **l'ordre** et la **liste** des éléments.

```yaml
# project.parts/_index.yml
version: 1
apps:                         # ordre des apps + modules de chaque app
  - slug: candidate
    modules: [candidate-portal, cv-ai-analysis]
modules:                      # ORDRE GLOBAL des modules (peut entrelacer les apps) + app d'appartenance
  - { app: candidate, slug: candidate-portal }
  - { app: recruitment-portal, slug: public-offers-management }
```
```yaml
# contracts/_index.yml
version: 1
apps:
  - slug: candidate
    label: candidate-portal
    modules:
      - slug: cv-ai-analysis
        name: cv-ai-analysis
        features: [extraction-classification, initial-matching]
```
```yaml
# openapi.parts/_index.yml   (pas de label ni de name)
version: 1
apps:
  - slug: candidate
    modules:
      - slug: cv-ai-analysis
        features: [extraction-classification, initial-matching]
```

Règles :
- **Ajout** : créer le(s) fichier(s) part, puis ajouter l'entrée dans l'index (jamais l'inverse : un index qui pointe vers un fichier absent fait échouer la lecture).
- **Suppression** : retirer l'entrée de l'index **et** supprimer le fichier (sinon orphelin).
- Le backend écrit atomiquement (`.tmp` + rename) et n'écrit que si le contenu change → garder des diffs minimaux : ne pas reformater les fichiers inutilement.
- `project.parts/_index.yml` doit contenir **chaque module** dans `modules` ; la liste `apps[].modules` est dérivée (modules dont `app == slug`).

## Source de vérité vs dérivé

| Dossier | Statut | Qui le produit |
|---|---|---|
| `project.parts/`, `usecases/`, `contracts/`, `database/visual/`, `export-configs/`, `journeys/`, `constraints.yml`, `enums.yml`, `tickets/` | **Source** | humain / LLM |
| `openapi.parts/` | Dérivé de `contracts/` (spec + mocks → exemples) | `tools/contracts_to_openapi.rb` (étape 1, voir `04-tooling-map.md`) |
| `coverage:` dans un endpoint | Dérivé (calcul de couverture des mocks) ; peut valoir 0 sur disque | app (`mock-coverage-calculator`) |
| `scaf/redocly.yaml` | Source (config du lint, hors version) | humain |
| `scaf/<version>/output/openapi/openapi.<app>.yml` | Dérivé : OpenAPI réel fusionné **par app** (sous `output/`, non lu comme source) | `tools/contracts_to_openapi.rb` (étape 2) |
| `scaf/<version>/output/database/{<dialect>/{sql/,schema.sql,drizzle/,prisma/,typeorm/},docs/}` | Dérivé de `database/visual/` (SQL, Drizzle, Prisma et TypeORM par moteur : postgresql, mysql, sqlite ; doc commune) | `tools/visual_to_sql.rb` |
| `scaf/<version>/output/implementation-guide/` | Dérivé des usecases producer (bloc `intent`) et consumer (un .md par endpoint, par app) ; **jamais édité à la main** : le dossier est effacé et réécrit à chaque run | `tools/intent_to_md.rb` |

## Cardinalités observées (v1) — pour calibrer un audit

4 apps · 12 modules · 40 features · 194 endpoints (tous `auth.guard: RequireAuth` ou `auth.type: none`) · 64 use cases
(43 `producer`, 19 `consumer`, 2 `shared`) · 5 fichiers `_visual_*` · ~1235 mocks d'erreur, ~412 d'enum, ~319 nominaux.
